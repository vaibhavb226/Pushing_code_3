import React, { useState, useEffect, useRef } from 'react'
import { Routes, Route, Link, Navigate, useLocation, useNavigate } from 'react-router-dom'
import { FileText, Archive, Brain, LayoutDashboard, MessageSquare, LogOut, ChevronDown, ChevronLeft, ChevronRight, Sun, Moon, Radio } from 'lucide-react'
import { ThemeProvider, useTheme } from './context/ThemeContext'
import { getUserColor, getInitials } from './utils/presenceColors'
import { getTabSessionId } from './hooks/usePresence'
import BidQueue      from './components/BidQueue/index.jsx'
import BidDetail     from './components/BidDetail/index.jsx'
import DocumentVault from './components/DocumentVault/index.jsx'
import UploadRFP     from './components/BexAI/index.jsx'
import RfpAiqDrawer  from './components/RfpAiq/RfpAiqDrawer.jsx'
import SupplierPortal from './pages/SupplierPortal.jsx'
import Login          from './pages/Login.jsx'

// ── Auth helpers ──────────────────────────────────────────
const LS_KEY = 'rfpaiq_user'

function getStoredUser() {
  try {
    const raw = localStorage.getItem(LS_KEY)
    return raw ? JSON.parse(raw) : null
  } catch {
    return null
  }
}

// ── Protected route guard ─────────────────────────────────
function ProtectedRoute({ children }) {
  const auth = getStoredUser()
  if (!auth?.loggedIn) return <Navigate to="/login" replace />
  return children
}

// ── Sidebar nav ───────────────────────────────────────────
const navItems = [
  { path: '/',      label: 'Bid Queue',      icon: LayoutDashboard, exact: true },
  { path: '/vault', label: 'Document Vault', icon: Archive },
  { path: '/bex',   label: 'Upload RFP',     icon: Brain },
]

const TAB_LABELS = {
  overview: 'Overview', emailrepo: 'Email Repo', workingfile: 'Working File', suppliers: 'Suppliers',
}

function groupSessionsByName(sessions) {
  const map = {}
  sessions.forEach(s => {
    if (!map[s.name]) map[s.name] = { name: s.name, sessions: [] }
    map[s.name].sessions.push(s)
  })
  return Object.values(map)
}

function PresenceAvatarBar({ sessions }) {
  const [open, setOpen] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    if (!open) return
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [open])

  if (!sessions || sessions.length === 0) return null

  const visible = sessions.slice(0, 5)
  const overflow = sessions.length - visible.length

  return (
    <div ref={ref} className="relative flex items-center mr-2">
      <button
        onClick={() => setOpen(p => !p)}
        className="flex items-center gap-2 focus:outline-none"
        title="Who's online"
      >
        {/* Overlapping avatar stack */}
        <div className="flex -space-x-2">
          {visible.map(u => {
            const c = getUserColor(u.name)
            return (
              <div
                key={u.sessionId}
                title={`${u.name}${u.bidId ? ` · ${u.bidId}` : ''}`}
                className={`w-7 h-7 rounded-full border-2 border-white dark:border-[#1E293B] ${c.bg} ${c.text} flex items-center justify-center text-[10px] font-bold flex-shrink-0 transition-transform hover:scale-110 hover:z-10`}
              >
                {getInitials(u.name)}
              </div>
            )
          })}
          {overflow > 0 && (
            <div className="w-7 h-7 rounded-full border-2 border-white dark:border-[#1E293B] bg-gray-200 dark:bg-gray-600 text-gray-600 dark:text-gray-300 flex items-center justify-center text-[9px] font-bold flex-shrink-0">
              +{overflow}
            </div>
          )}
        </div>
        <span className="text-xs text-gray-400 dark:text-gray-500 hidden md:block">
          {sessions.length} online
        </span>
      </button>

      {/* Dropdown — grouped by user, with per-tab location */}
      {open && (
        <div className="absolute right-0 top-full mt-2 w-72 bg-white dark:bg-[#1E293B] border border-gray-200 dark:border-gray-700 rounded-xl shadow-xl z-50 overflow-hidden">
          <div className="px-4 py-2.5 border-b border-gray-100 dark:border-gray-700 flex items-center gap-2">
            <Radio className="w-3 h-3 text-emerald-400 flex-shrink-0" />
            <span className="text-xs font-semibold text-gray-600 dark:text-gray-300 uppercase tracking-widest">Who&apos;s Online</span>
            <span className="ml-auto text-xs text-gray-400 tabular-nums">{sessions.length}</span>
          </div>
          <div className="max-h-72 overflow-y-auto divide-y divide-gray-50 dark:divide-gray-800">
            {groupSessionsByName(sessions).map(({ name, sessions: userSessions }) => {
              const c = getUserColor(name)
              return (
                <div key={name} className="px-4 py-2.5 hover:bg-gray-50 dark:hover:bg-white/5">
                  <div className="flex items-start gap-2.5">
                    <div className={`w-7 h-7 rounded-full flex-shrink-0 ${c.bg} ${c.text} flex items-center justify-center text-[10px] font-bold mt-0.5`}>
                      {getInitials(name)}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <span className="text-sm font-medium text-gray-800 dark:text-gray-200 truncate">{name}</span>
                        {userSessions.length > 1 && (
                          <span className="text-[10px] bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 px-1.5 py-0.5 rounded-full flex-shrink-0">
                            {userSessions.length} tabs
                          </span>
                        )}
                      </div>
                      {userSessions.map((s, i) => (
                        <div key={s.sessionId} className="text-xs text-gray-400 dark:text-gray-500 truncate">
                          {userSessions.length > 1 && (
                            <span className="text-gray-300 dark:text-gray-600 mr-1">Tab {i + 1}:</span>
                          )}
                          {s.bidId
                            ? `${s.bidId}${s.tab ? ` · ${TAB_LABELS[s.tab] ?? s.tab}` : ''}`
                            : 'Browsing'
                          }
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

function OnlinePanel({ isCollapsed, onlineUsers }) {
  if (!onlineUsers || onlineUsers.length === 0) return null

  if (isCollapsed) {
    return (
      <div className="px-2 pb-2 flex flex-col items-center gap-1">
        {onlineUsers.slice(0, 3).map(u => {
          const color = getUserColor(u.name)
          return (
            <div
              key={u.sessionId}
              title={`${u.name}${u.bidId ? ` · ${u.bidId}` : ''}`}
              className={`w-7 h-7 rounded-full ${color.bg} ${color.text} flex items-center justify-center text-[10px] font-bold`}
            >
              {getInitials(u.name)}
            </div>
          )
        })}
        {onlineUsers.length > 3 && (
          <span className="text-white/40 text-[9px]">+{onlineUsers.length - 3}</span>
        )}
      </div>
    )
  }

  // Expanded: group sessions by name, show tabs badge when same user has multiple open
  const grouped = groupSessionsByName(onlineUsers)

  return (
    <div className="mx-3 mb-2 rounded-xl overflow-hidden" style={{ background: 'rgba(255,255,255,0.06)' }}>
      <div className="flex items-center gap-1.5 px-3 pt-2.5 pb-1">
        <Radio className="w-3 h-3 text-emerald-400" />
        <span className="text-white/40 text-[10px] uppercase tracking-widest font-medium">Who&apos;s Online</span>
        <span className="ml-auto text-white/30 text-[9px]">{onlineUsers.length}</span>
      </div>
      <div className="px-2 pb-2 space-y-0.5">
        {grouped.slice(0, 5).map(({ name, sessions }) => {
          const color = getUserColor(name)
          const main = sessions[0]
          const locationText = main.bidId
            ? `${main.bidId}${main.tab ? ` · ${TAB_LABELS[main.tab] ?? main.tab}` : ''}`
            : 'Browsing'
          return (
            <div key={name} className="flex items-center gap-2 px-1 py-1 rounded-lg hover:bg-white/5">
              <div className={`w-6 h-6 rounded-full flex-shrink-0 ${color.bg} ${color.text} flex items-center justify-center text-[9px] font-bold`}>
                {getInitials(name)}
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1">
                  <div className="text-white/80 text-[11px] font-medium truncate leading-tight">{name}</div>
                  {sessions.length > 1 && (
                    <span className="text-[9px] bg-white/10 text-white/50 px-1 rounded flex-shrink-0">{sessions.length} tabs</span>
                  )}
                </div>
                <div className="text-white/30 text-[9px] truncate leading-tight">{locationText}</div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function Sidebar({ isCollapsed, onToggle, onOpenAiq, aiqOpen, onlineUsers }) {
  const location = useLocation()

  const isActive = (path, exact) => {
    if (exact) return location.pathname === path || location.pathname.startsWith('/bids/')
    return location.pathname.startsWith(path) && path !== '/'
  }

  const w = isCollapsed ? 64 : 256

  return (
    <aside
      style={{
        width: w,
        minWidth: w,
        transition: 'width 0.25s ease, min-width 0.25s ease',
        position: 'fixed',
        left: 0,
        top: 0,
        height: '100vh',
        zIndex: 100,
        overflow: 'hidden',
        display: 'flex',
        flexDirection: 'column',
        backgroundColor: '#1F3864',
      }}
    >
      {/* Logo row */}
      <div className="border-b border-white/10" style={{ padding: isCollapsed ? '16px 0' : '16px 24px', position: 'relative' }}>
        <div className="flex items-center" style={{ gap: isCollapsed ? 0 : 10, justifyContent: isCollapsed ? 'center' : 'flex-start' }}>
          <div style={{ backgroundColor: 'white', borderRadius: '4px', padding: '2px 6px', display: 'flex', alignItems: 'center', flexShrink: 0 }}>
            <img
              src="/FoodCorp-Logo.jpg"
              alt="FoodCorp"
              style={{ height: '32px', objectFit: 'contain' }}
              onError={e => {
                e.currentTarget.style.display = 'none'
                e.currentTarget.nextSibling.style.display = 'block'
              }}
            />
            <span style={{ display: 'none', fontWeight: 'bold', color: '#1F3864', fontSize: '14px' }}>FOODCORP</span>
          </div>
          {!isCollapsed && (
            <div style={{ overflow: 'hidden' }}>
              <div className="text-white font-bold text-sm leading-tight">FoodCorp RFP AIQ</div>
              <div className="text-blue-300 text-xs">Bid Management Platform</div>
            </div>
          )}
        </div>

        {/* Toggle button — sits on the right edge */}
        <button
          onClick={onToggle}
          style={{
            position: 'absolute',
            right: -12,
            top: '50%',
            transform: 'translateY(-50%)',
            width: 24,
            height: 24,
            borderRadius: '50%',
            backgroundColor: 'white',
            border: '1.5px solid #1F3864',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            cursor: 'pointer',
            zIndex: 101,
            boxShadow: '0 1px 4px rgba(0,0,0,0.2)',
          }}
          title={isCollapsed ? 'Expand sidebar' : 'Collapse sidebar'}
        >
          {isCollapsed
            ? <ChevronRight style={{ width: 13, height: 13, color: '#1F3864' }} />
            : <ChevronLeft  style={{ width: 13, height: 13, color: '#1F3864' }} />
          }
        </button>
      </div>

      {/* Nav items */}
      <nav className="flex-1 py-4 space-y-0.5" style={{ padding: isCollapsed ? '16px 8px' : '16px 12px', overflowY: 'auto' }}>
        {!isCollapsed && (
          <p className="text-white/30 text-xs uppercase tracking-widest font-medium px-3 pb-2 pt-1">Navigation</p>
        )}
        {navItems.map(({ path, label, icon: Icon, exact }) => {
          const active = isActive(path, exact)
          return (
            <Link
              key={path}
              to={path}
              title={isCollapsed ? label : undefined}
              className={`
                flex items-center rounded-xl text-sm font-medium transition-all duration-150
                ${isCollapsed ? 'justify-center px-0 py-2.5' : 'gap-3 px-3 py-2.5'}
                ${active
                  ? 'bg-exl-orange text-white shadow-sm'
                  : 'text-blue-200 hover:bg-white/10 hover:text-white'
                }
              `}
            >
              <Icon className="w-4 h-4 flex-shrink-0" />
              {!isCollapsed && label}
            </Link>
          )
        })}

        {/* AIQ Chat — separator + button */}
        <div className="mx-1 my-2 border-t border-white/10" />
        <button
          onClick={onOpenAiq}
          title={isCollapsed ? 'Chat with AIQ' : undefined}
          className={`
            w-full flex items-center rounded-xl text-sm font-semibold transition-all duration-150
            active:scale-[0.98]
            ${isCollapsed ? 'justify-center px-0 py-2.5' : 'gap-3 px-3 py-2.5'}
            ${aiqOpen ? 'bg-exl-orange text-white' : 'text-blue-200 hover:bg-white/10'}
          `}
        >
          <MessageSquare className="w-4 h-4 flex-shrink-0" />
          {!isCollapsed && 'Chat with AIQ'}
        </button>
      </nav>

      {/* Who's Online panel */}
      <OnlinePanel isCollapsed={isCollapsed} onlineUsers={onlineUsers} />

      {/* Footer */}
      <div className="border-t border-white/10">
        {!isCollapsed && (
          <>
            <p className="text-blue-300/60 text-xs px-6 pt-4">Bid COE · bids@foodcorp.com</p>
            <p className="text-blue-400/40 text-xs px-6 mt-0.5">v1.0 · CONFIDENTIAL</p>
          </>
        )}
        <div style={{ textAlign: 'center', padding: isCollapsed ? '12px 4px' : '12px 16px' }}>
          {isCollapsed ? (
            <img
              src="/exl_logo_sidebar.png"
              alt="EXL Service"
              style={{ height: '28px', width: 'auto', display: 'block', margin: '0 auto' }}
            />
          ) : (
            <>
              <img
                src="/exl_logo_sidebar.png"
                alt="EXL Service"
                style={{ height: '36px', width: 'auto', display: 'block', margin: '0 auto 4px auto' }}
              />
              <p style={{ fontSize: '10px', color: '#94A3B8', margin: '0', letterSpacing: '0.3px' }}>
                EXLService.com™ · © 2026
              </p>
            </>
          )}
        </div>
      </div>
    </aside>
  )
}

// ── User avatar + sign-out dropdown ──────────────────────
function UserMenu() {
  const navigate            = useNavigate()
  const [open, setOpen]     = useState(false)
  const ref                 = useRef(null)
  const stored              = getStoredUser()
  const user                = stored?.user ?? {
    name:     'Morgan Davis',
    title:    'Bid COE Manager',
    email:    'morgan.davis@foodcorp.com',
    initials: 'MD',
  }

  // Close on outside click
  useEffect(() => {
    if (!open) return
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false) }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [open])

  const handleSignOut = () => {
    localStorage.removeItem(LS_KEY)
    localStorage.removeItem('theme')
    document.documentElement.classList.remove('dark')
    navigate('/login', { replace: true })
  }

  return (
    <div ref={ref} className="relative flex items-center gap-2">
      <span className="text-xs text-gray-400 hidden sm:block">
        {user.name} · {user.title}
      </span>

      {/* Avatar button */}
      <button
        onClick={() => setOpen(p => !p)}
        className="flex items-center gap-1 focus:outline-none group"
        title="Account menu"
      >
        <div className="w-8 h-8 rounded-full bg-exl-navy flex items-center justify-center text-white text-xs font-bold select-none group-hover:opacity-80 transition-opacity">
          {user.initials}
        </div>
        <ChevronDown className={`w-3 h-3 text-gray-400 transition-transform duration-150 ${open ? 'rotate-180' : ''}`} />
      </button>

      {/* Dropdown */}
      {open && (
        <div className="absolute right-0 top-full mt-2 w-56 bg-white dark:bg-[#1E293B] border border-gray-200 dark:border-gray-700 rounded-xl shadow-lg z-50 overflow-hidden">
          {/* User info (non-clickable) */}
          <div className="px-4 py-3 border-b border-gray-100 dark:border-gray-700">
            <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{user.name}</p>
            <p className="text-xs text-gray-400 dark:text-gray-500 mt-0.5 truncate">{user.email}</p>
          </div>

          {/* Sign out */}
          <button
            onClick={handleSignOut}
            className="w-full flex items-center gap-2.5 px-4 py-3 text-sm text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      )}
    </div>
  )
}

// ── Dark mode toggle button ───────────────────────────────
function DarkModeToggle() {
  const { isDark, toggleTheme } = useTheme()
  return (
    <button
      onClick={toggleTheme}
      title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
      className="p-2 rounded-lg text-gray-400 hover:text-gray-600 dark:text-gray-400 dark:hover:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-700 transition-all duration-150"
    >
      {isDark ? <Sun size={16} /> : <Moon size={16} />}
    </button>
  )
}

// ── Top header bar ─────────────────────────────────────────
function Header({ onlineUsers }) {
  const location   = useLocation()
  const isBidDetail = location.pathname.startsWith('/bids/')
  const isVault    = location.pathname.startsWith('/vault')
  const isBex      = location.pathname.startsWith('/bex')

  const breadcrumb = isBidDetail ? 'Bid Queue / RFP Detail'
    : isVault ? 'Document Vault'
    : isBex   ? 'Upload RFP'
    : null

  return (
    <header className="h-14 bg-white dark:bg-[#1E293B] border-b border-gray-200 dark:border-gray-700 flex items-center px-6 gap-4 flex-shrink-0">
      <div className="flex-1">
        {breadcrumb && (
          <p className="text-xs text-gray-400 dark:text-gray-500">
            {isBidDetail
              ? <><span className="text-exl-orange font-medium">Bid Queue</span>{' '}/ RFP Detail</>
              : <span className="text-exl-orange font-medium">{breadcrumb}</span>
            }
          </p>
        )}
      </div>
      <PresenceAvatarBar sessions={onlineUsers} />
      <DarkModeToggle />
      <UserMenu />
    </header>
  )
}

// ── Internal app layout (sidebar + header) ────────────────
function AppLayout({ onOpenAiq, aiqOpen }) {
  const [isCollapsed, setIsCollapsed] = useState(
    () => JSON.parse(localStorage.getItem('sidebar_collapsed') || 'false')
  )
  const [onlineUsers, setOnlineUsers] = useState([])

  const handleToggle = () => {
    setIsCollapsed(prev => {
      const next = !prev
      localStorage.setItem('sidebar_collapsed', JSON.stringify(next))
      return next
    })
  }

  // Poll global presence every 30s; filter the current tab's own session from the list
  // (other tabs of the same user remain visible — that's the intended multi-tab behavior)
  useEffect(() => {
    const selfSessionId = getTabSessionId()

    const fetch_presence = () => {
      fetch('/api/presence')
        .then(r => r.ok ? r.json() : { users: [] })
        .then(data => {
          const others = (data.users || []).filter(u => u.sessionId !== selfSessionId)
          setOnlineUsers(others)
        })
        .catch(() => {})
    }

    fetch_presence()
    const timer = setInterval(fetch_presence, 30_000)
    return () => clearInterval(timer)
  }, [])

  const marginLeft = isCollapsed ? 64 : 256

  return (
    <div className="flex h-screen overflow-hidden bg-gray-50 dark:bg-[#0F172A]">
      <Sidebar isCollapsed={isCollapsed} onToggle={handleToggle} onOpenAiq={onOpenAiq} aiqOpen={aiqOpen} onlineUsers={onlineUsers} />
      <div
        className="flex flex-col flex-1 h-screen overflow-hidden min-w-0"
        style={{ marginLeft, transition: 'margin-left 0.25s ease' }}
      >
        <Header onlineUsers={onlineUsers} />
        <main className="flex-1 p-6 overflow-y-auto overflow-x-hidden">
          <Routes>
            <Route path="/"         element={<BidQueue onlineUsers={onlineUsers} />} />
            <Route path="/bids"     element={<BidQueue onlineUsers={onlineUsers} />} />
            <Route path="/bids/:id" element={<BidDetail />} />
            <Route path="/vault"    element={<DocumentVault />} />
            <Route path="/bex"      element={<UploadRFP />} />
          </Routes>
        </main>
      </div>
    </div>
  )
}

// ── App root ──────────────────────────────────────────────
export default function App() {
  const [aiqOpen,     setAiqOpen]     = useState(false)
  const [aiqMessages, setAiqMessages] = useState([])

  const handleOpenAiq = () => {
    if (aiqOpen) {
      setAiqOpen(false)
    } else {
      setAiqMessages([])
      setAiqOpen(true)
    }
  }

  return (
    <ThemeProvider>
    <>
      <Routes>
        {/* ── LOGIN — public ── */}
        <Route path="/login" element={<Login />} />

        {/* ── SUPPLIER PORTAL — public, no auth ── */}
        <Route path="/submit/:bidId/thread/:threadId" element={<SupplierPortal />} />
        <Route path="/submit/:bidId" element={<SupplierPortal />} />

        {/* ── ALL INTERNAL ROUTES — protected ── */}
        <Route path="/*" element={
          <ProtectedRoute>
            <AppLayout onOpenAiq={handleOpenAiq} aiqOpen={aiqOpen} />
          </ProtectedRoute>
        } />
      </Routes>

      {/* Global AIQ drawer — available on all internal pages */}
      <RfpAiqDrawer
        isOpen={aiqOpen}
        onClose={() => setAiqOpen(false)}
        messages={aiqMessages}
        setMessages={setAiqMessages}
      />
    </>
    </ThemeProvider>
  )
}
