// Deterministic user color — stable across sessions for the same name.
// Six navy-theme colors that work in both light and dark mode.

const COLORS = [
  { bg: 'bg-purple-500',  text: 'text-white', borderColor: '#a855f7' },
  { bg: 'bg-emerald-500', text: 'text-white', borderColor: '#10b981' },
  { bg: 'bg-amber-500',   text: 'text-white', borderColor: '#f59e0b' },
  { bg: 'bg-rose-500',    text: 'text-white', borderColor: '#f43f5e' },
  { bg: 'bg-sky-500',     text: 'text-white', borderColor: '#0ea5e9' },
  { bg: 'bg-indigo-500',  text: 'text-white', borderColor: '#6366f1' },
]

export function getUserColor(name) {
  if (!name) return COLORS[0]
  let hash = 0
  for (let i = 0; i < name.length; i++) {
    hash = ((hash * 31) + name.charCodeAt(i)) >>> 0
  }
  return COLORS[hash % COLORS.length]
}

export function getInitials(name) {
  if (!name) return '?'
  return name
    .split(/\s+/)
    .map(w => w[0] ?? '')
    .join('')
    .toUpperCase()
    .slice(0, 2)
}
