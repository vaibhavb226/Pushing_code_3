/**
 * Async generator that decodes a ReadableStream as Server-Sent Events.
 * Yields each parsed JSON object from `data: {...}` lines.
 *
 * Usage:
 *   const reader = res.body.getReader()
 *   for await (const event of parseSSE(reader)) { ... }
 */
export async function* parseSSE(reader) {
  const decoder = new TextDecoder()
  let buffer = ''
  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop() ?? ''
    for (const line of lines) {
      if (!line.startsWith('data: ')) continue
      const jsonStr = line.slice(6).trim()
      if (jsonStr) {
        try { yield JSON.parse(jsonStr) } catch { /* skip malformed */ }
      }
    }
  }
}
