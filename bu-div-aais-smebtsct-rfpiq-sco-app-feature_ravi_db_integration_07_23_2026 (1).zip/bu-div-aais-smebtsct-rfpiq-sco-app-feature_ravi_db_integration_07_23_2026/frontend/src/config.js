const hostname = typeof window !== 'undefined' ? window.location.hostname : 'localhost'
const isDev = hostname === 'localhost'

export const APP_URL = isDev
  ? 'http://localhost:5173'
  : 'http://rfp-aiq.exlservice.com:5173'

export const PORTAL_URL = isDev
  ? 'http://localhost:5173'
  : 'http://rfp-aiq.supplier.exlservice.com:5173'
