import { useEffect, useState, useRef } from 'react'
import { getTabSessionId } from './usePresence'

// Stable per-tab session ID — same value for all reconnects within this tab.
const SESSION_ID = getTabSessionId()

/**
 * Opens a real-time SSE connection to GET /api/bids/{bidId}/stream?user=...&session_id=...
 * Reconnects automatically on error (5s backoff).
 *
 * @param {string|null}  bidId     — the RFP ID to subscribe to (null = no-op)
 * @param {string}       userName  — display name sent in the ?user= param
 * @param {function}     onEvent   — callback(event) for every server-sent message
 */
export function useBidStream(bidId, userName, onEvent) {
  const [retryCount, setRetryCount] = useState(0)
  const onEventRef = useRef(onEvent)
  useEffect(() => { onEventRef.current = onEvent })

  useEffect(() => {
    if (!bidId) return

    let done = false  // guard: onerror fires multiple times before es.close() takes effect

    const url = `/api/bids/${bidId}/stream?user=${encodeURIComponent(userName || '')}&session_id=${SESSION_ID}`
    const es = new EventSource(url)

    es.onmessage = (e) => {
      try {
        const event = JSON.parse(e.data)
        onEventRef.current(event)
      } catch {
        // ignore malformed frames
      }
    }

    es.onerror = () => {
      if (done) return
      done = true
      es.close()
      // Reconnect after 5s — only one retry scheduled regardless of how many onerror fires
      setTimeout(() => setRetryCount(n => n + 1), 5000)
    }

    return () => {
      done = true
      es.close()
    }
  }, [bidId, retryCount])
}
