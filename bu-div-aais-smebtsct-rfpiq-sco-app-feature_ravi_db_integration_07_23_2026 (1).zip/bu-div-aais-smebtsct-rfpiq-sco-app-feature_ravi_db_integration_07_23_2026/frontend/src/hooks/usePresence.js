import { useEffect, useRef } from 'react'

// Sends a heartbeat every 30s and on location changes.
// TTL on the backend is 60s — two missed heartbeats = evicted.
const HEARTBEAT_MS = 30_000

/**
 * Returns a stable UUID for this browser tab, persisted in sessionStorage.
 * A new tab (or a refreshed tab in a new session) gets a fresh UUID, so the
 * same user in multiple tabs appears as separate presence entries.
 */
export function getTabSessionId() {
  let sid = sessionStorage.getItem('presence_session_id')
  if (!sid) {
    sid = crypto.randomUUID()
    sessionStorage.setItem('presence_session_id', sid)
  }
  return sid
}

// Computed once per tab load — stable for the lifetime of this tab.
const SESSION_ID = getTabSessionId()

export function usePresence(name, bidId, tab, cellId = null) {
  const lastRef = useRef(null)

  useEffect(() => {
    if (!name) return

    const payload = {
      sessionId: SESSION_ID,
      name,
      bidId: bidId ?? null,
      tab: tab ?? null,
      cellId: cellId ?? null,
    }
    const key = JSON.stringify(payload)

    const send = () => {
      fetch('/api/presence/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }).catch(() => {})
    }

    // Only send if something changed or it's the first call
    if (lastRef.current !== key) {
      lastRef.current = key
      send()
    }

    const timer = setInterval(send, HEARTBEAT_MS)

    const handleUnload = () => {
      // sendBeacon survives page teardown; update to null location so we're
      // not shown as online after the tab closes
      navigator.sendBeacon(
        '/api/presence/update',
        new Blob(
          [JSON.stringify({ sessionId: SESSION_ID, name, bidId: null, tab: null, cellId: null })],
          { type: 'application/json' },
        ),
      )
    }
    window.addEventListener('beforeunload', handleUnload)

    return () => {
      clearInterval(timer)
      window.removeEventListener('beforeunload', handleUnload)
    }
  }, [name, bidId, tab, cellId])
}
