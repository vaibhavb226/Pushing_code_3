import React, { useState, useRef } from 'react'
import { X, Upload, FileText, FileSpreadsheet, AlertCircle, CheckCircle, Loader } from 'lucide-react'
import staticBids from '../../data/bids.json'

// ── Constants ─────────────────────────────────────────────
const DOC_TYPES = [
  'Pricing', 'Spec Sheet', 'CN Label', 'PFS', 'Compliance',
  'RFP', 'Item List', 'Supplier List', 'Filing',
]
const SUP_CATEGORIES = [
  'Protein', 'Dairy', 'Bakery', 'Produce', 'Grocery',
  'Beverage', 'Paper', 'Broker',
]
const COMMON_TAGS = ['K-12', 'DoD', 'Buy American', 'Child Nutrition', 'Halal', 'Kosher', 'Whole Grain', 'PFS']

// ── Field row ─────────────────────────────────────────────
function FieldRow({ label, required, children }) {
  return (
    <div className="mb-4">
      <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">
        {label} {required && <span className="text-red-500">*</span>}
      </label>
      {children}
    </div>
  )
}

const inputCls = 'w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange'

// ── Main UploadDrawer ─────────────────────────────────────
export default function UploadDrawer({ onClose, onUploaded }) {
  const fileInputRef = useRef(null)
  const [file, setFile]                   = useState(null)
  const [isDragging, setIsDragging]       = useState(false)
  const [supplier, setSupplier]           = useState('')
  const [bidId, setBidId]                 = useState('')
  const [docType, setDocType]             = useState('')
  const [supplierCategory, setSupCat]     = useState('')
  const [description, setDescription]     = useState('')
  const [tagInput, setTagInput]           = useState('')
  const [selectedTags, setSelectedTags]   = useState([])
  const [saving, setSaving]               = useState(false)
  const [error, setError]                 = useState(null)
  const [success, setSuccess]             = useState(false)

  // ── File drop handlers ──────────────────────────────────
  const handleFile = (f) => {
    if (!f) return
    const ext = f.name.split('.').pop().toLowerCase()
    if (!['pdf', 'xlsx', 'xls'].includes(ext)) {
      setError('Only PDF (.pdf) and Excel (.xlsx, .xls) files are accepted.')
      return
    }
    setError(null)
    setFile(f)
    // Auto-detect type from extension
    if (!docType) setDocType(ext === 'pdf' ? 'Pricing' : 'Item List')
  }

  const handleDrop = (e) => {
    e.preventDefault()
    setIsDragging(false)
    handleFile(e.dataTransfer.files[0])
  }

  const removeTag = (tag) => setSelectedTags(p => p.filter(t => t !== tag))
  const addTag    = (tag) => {
    if (tag && !selectedTags.includes(tag)) setSelectedTags(p => [...p, tag])
    setTagInput('')
  }

  // ── Save ──────────────────────────────────────────────
  const handleSave = async () => {
    if (!file) { setError('Please select a file.'); return }
    setSaving(true)
    setError(null)

    try {
      const formData = new FormData()
      formData.append('file', file)
      formData.append('supplier', supplier)
      formData.append('bidId', bidId || 'ALL')
      formData.append('documentType', docType || 'Filing')
      formData.append('supplierCategory', supplierCategory)
      formData.append('tags', selectedTags.join(','))
      formData.append('description', description)

      const res = await fetch('/api/documents/upload', { method: 'POST', body: formData })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Upload failed')

      setSuccess(true)
      setTimeout(() => {
        onUploaded(data.document)
        onClose()
      }, 800)
    } catch (err) {
      setError(err.message)
    } finally {
      setSaving(false)
    }
  }

  // ── Render ───────────────────────────────────────────
  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/30 z-40 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Drawer panel */}
      <div className="fixed right-0 top-0 bottom-0 w-[440px] bg-white shadow-2xl z-50 flex flex-col">

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-exl-navy flex-shrink-0">
          <div>
            <h2 className="text-white font-bold text-base">Upload Document</h2>
            <p className="text-blue-300 text-xs mt-0.5">Add to the Document Vault</p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 min-h-0 overflow-y-auto px-6 py-5">

          {/* Success state */}
          {success && (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <div className="w-16 h-16 bg-emerald-100 rounded-full flex items-center justify-center mb-4">
                <CheckCircle className="w-8 h-8 text-emerald-600" />
              </div>
              <p className="text-lg font-bold text-gray-900">Uploaded!</p>
              <p className="text-sm text-gray-500 mt-1">Document added to vault</p>
            </div>
          )}

          {!success && (
            <>
              {/* File drop zone */}
              <FieldRow label="File" required>
                <div
                  onDragOver={(e) => { e.preventDefault(); setIsDragging(true) }}
                  onDragLeave={() => setIsDragging(false)}
                  onDrop={handleDrop}
                  onClick={() => fileInputRef.current?.click()}
                  className={`
                    border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all
                    ${isDragging
                      ? 'border-exl-orange bg-exl-orange/5 dark:bg-orange-900/20'
                      : file
                        ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-900/20'
                        : 'border-gray-200 hover:border-exl-orange/50 hover:bg-gray-50 dark:hover:bg-[#253347]'
                    }
                  `}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".pdf,.xlsx,.xls"
                    className="hidden"
                    onChange={(e) => handleFile(e.target.files[0])}
                  />
                  {file ? (
                    <div className="flex items-center justify-center gap-3">
                      {file.name.endsWith('.pdf')
                        ? <FileText className="w-8 h-8 text-red-500" />
                        : <FileSpreadsheet className="w-8 h-8 text-emerald-600" />
                      }
                      <div className="text-left">
                        <p className="text-sm font-semibold text-gray-900">{file.name}</p>
                        <p className="text-xs text-gray-500">{Math.max(1, Math.round(file.size / 1024))} KB</p>
                      </div>
                      <button
                        onClick={(e) => { e.stopPropagation(); setFile(null) }}
                        className="ml-2 text-gray-400 hover:text-red-500"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-gray-300 mx-auto mb-2" />
                      <p className="text-sm font-medium text-gray-600">Drop file here or click to browse</p>
                      <p className="text-xs text-gray-400 mt-1">PDF or Excel · Max 20 MB</p>
                    </>
                  )}
                </div>
              </FieldRow>

              {/* Supplier name */}
              <FieldRow label="Supplier Name">
                <input
                  type="text"
                  value={supplier}
                  onChange={e => setSupplier(e.target.value)}
                  placeholder="e.g. Tyson Foods Inc."
                  className={inputCls}
                />
              </FieldRow>

              {/* Bid ID */}
              <FieldRow label="Bid ID">
                <select value={bidId} onChange={e => setBidId(e.target.value)} className={inputCls}>
                  <option value="">ALL Bids</option>
                  {staticBids.map(b => (
                    <option key={b.id} value={b.id}>{b.id} — {b.customer}</option>
                  ))}
                </select>
              </FieldRow>

              {/* Document type */}
              <FieldRow label="Document Type" required>
                <select value={docType} onChange={e => setDocType(e.target.value)} className={inputCls}>
                  <option value="">Select type…</option>
                  {DOC_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </FieldRow>

              {/* Supplier category */}
              <FieldRow label="Supplier Category">
                <select value={supplierCategory} onChange={e => setSupCat(e.target.value)} className={inputCls}>
                  <option value="">None (group by document type)</option>
                  {SUP_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </FieldRow>

              {/* Tags */}
              <FieldRow label="Tags">
                {/* Quick tag buttons */}
                <div className="flex flex-wrap gap-1 mb-2">
                  {COMMON_TAGS.map(t => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => selectedTags.includes(t) ? removeTag(t) : addTag(t)}
                      className={`px-2 py-0.5 text-xs rounded-full border transition-all ${
                        selectedTags.includes(t)
                          ? 'bg-exl-orange text-white border-exl-orange'
                          : 'bg-white text-gray-600 border-gray-200 hover:border-exl-orange/50'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
                {/* Custom tag input */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={tagInput}
                    onChange={e => setTagInput(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addTag(tagInput.trim()) } }}
                    placeholder="Type custom tag, press Enter"
                    className={`${inputCls} flex-1`}
                  />
                </div>
                {/* Selected tags */}
                {selectedTags.length > 0 && (
                  <div className="flex flex-wrap gap-1 mt-2">
                    {selectedTags.map(t => (
                      <span key={t} className="inline-flex items-center gap-1 px-2 py-0.5 bg-exl-navy/10 dark:bg-blue-900/30 text-exl-navy dark:text-blue-300 text-xs font-medium rounded-full">
                        {t}
                        <button onClick={() => removeTag(t)} className="hover:text-red-500">
                          <X className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                )}
              </FieldRow>

              {/* Description */}
              <FieldRow label="Description (optional)">
                <textarea
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  placeholder="Brief description of this document…"
                  rows={2}
                  className={`${inputCls} resize-none`}
                />
              </FieldRow>

              {/* Error */}
              {error && (
                <div className="flex items-start gap-2 text-sm text-red-700 bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  {error}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        {!success && (
          <div className="border-t border-gray-200 px-6 py-4 flex gap-3 flex-shrink-0">
            <button onClick={onClose} className="btn-secondary flex-1">Cancel</button>
            <button
              onClick={handleSave}
              disabled={saving || !file}
              className="btn-primary flex-1 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving
                ? <><Loader className="w-4 h-4 animate-spin" /> Uploading…</>
                : <><Upload className="w-4 h-4" /> Save to Vault</>
              }
            </button>
          </div>
        )}
      </div>
    </>
  )
}
