import React, { useState, useEffect, useMemo } from 'react'
import { Search, Upload, FileText, FileSpreadsheet, ChevronDown, FolderOpen, ExternalLink } from 'lucide-react'
import { EmptyState } from '../UI/EmptyState'
import staticDocs from '../../data/documents.json'
import UploadDrawer from './UploadDrawer'

// ── Config maps ───────────────────────────────────────────
const CATEGORY_CONFIG = {
  Protein:       { dot: 'bg-red-500',    label: 'Protein' },
  Dairy:         { dot: 'bg-blue-500',   label: 'Dairy' },
  Bakery:        { dot: 'bg-amber-500',  label: 'Bakery' },
  Produce:       { dot: 'bg-lime-500',   label: 'Produce' },
  Grocery:       { dot: 'bg-green-500',  label: 'Grocery' },
  Beverage:      { dot: 'bg-cyan-500',   label: 'Beverage' },
  Paper:         { dot: 'bg-gray-500',   label: 'Paper & Packaging' },
  Broker:        { dot: 'bg-purple-500', label: 'Broker' },
  RFP:           { dot: 'bg-indigo-500', label: 'RFP Documents' },
  'Item List':   { dot: 'bg-teal-500',   label: 'Item Lists' },
  Compliance:    { dot: 'bg-orange-500', label: 'Compliance' },
  'Spec Sheet':  { dot: 'bg-pink-500',   label: 'Spec Sheets' },
  'Supplier List': { dot: 'bg-yellow-500', label: 'Supplier Lists' },
  Filing:        { dot: 'bg-gray-400',   label: 'General Filing' },
}

const CATEGORY_ORDER = [
  'Grocery', 'Bakery', 'Protein', 'Dairy', 'Produce', 'Beverage',
  'Paper', 'Broker', 'RFP', 'Item List', 'Compliance', 'Spec Sheet',
  'Supplier List', 'Filing',
]

const ALL_FILTER_CATS = [
  'All Categories', 'Protein', 'Dairy', 'Bakery', 'Produce', 'Grocery',
  'Beverage', 'Paper', 'Broker', 'Compliance', 'RFP', 'Item List', 'Supplier List',
]

const DOC_STATUS_CONFIG = {
  'Extracted':    { bg: 'bg-emerald-100', text: 'text-emerald-700', dot: 'bg-emerald-500' },
  'Filed':        { bg: 'bg-blue-100',    text: 'text-blue-700',    dot: 'bg-blue-500'    },
  'Active':       { bg: 'bg-green-100',   text: 'text-green-700',   dot: 'bg-green-500'   },
  'Solicitation': { bg: 'bg-blue-100',    text: 'text-blue-700',    dot: 'bg-blue-400'    },
  'Working File': { bg: 'bg-amber-100',   text: 'text-amber-700',   dot: 'bg-amber-500'   },
  'Review':       { bg: 'bg-purple-100',  text: 'text-purple-700',  dot: 'bg-purple-500'  },
  'Awarded':      { bg: 'bg-gray-100',    text: 'text-gray-600',    dot: 'bg-gray-400'    },
  'At Risk':      { bg: 'bg-red-100',     text: 'text-red-700',     dot: 'bg-red-500'     },
}

const DOC_TYPE_CONFIG = {
  'Pricing':       { bg: 'bg-green-100',  text: 'text-green-800' },
  'RFP':           { bg: 'bg-blue-100',   text: 'text-blue-800' },
  'Item List':     { bg: 'bg-purple-100', text: 'text-purple-800' },
  'Compliance':    { bg: 'bg-orange-100', text: 'text-orange-800' },
  'Spec Sheet':    { bg: 'bg-cyan-100',   text: 'text-cyan-800' },
  'Supplier List': { bg: 'bg-amber-100',  text: 'text-amber-800' },
  'CN Label':      { bg: 'bg-teal-100',   text: 'text-teal-800' },
  'PFS':           { bg: 'bg-indigo-100', text: 'text-indigo-800' },
  'Filing':        { bg: 'bg-gray-100',   text: 'text-gray-600' },
}

const TAG_COLORS = {
  'K-12':          'bg-blue-100 text-blue-800',
  'DoD':           'bg-slate-100 text-slate-800',
  'Buy American':  'bg-blue-100 text-blue-800',
  'Child Nutrition':'bg-green-100 text-green-800',
  'Halal':         'bg-teal-100 text-teal-800',
  'Kosher':        'bg-indigo-100 text-indigo-800',
  'Whole Grain':   'bg-lime-100 text-lime-800',
  'PFS':           'bg-purple-100 text-purple-800',
}

// ── Helpers ───────────────────────────────────────────────
const getDisplayCategory = (doc) => doc.supplierCategory || doc.documentType || 'Filing'

const groupDocs = (docs) => {
  const map = {}
  docs.forEach(doc => {
    const cat = getDisplayCategory(doc)
    if (!map[cat]) map[cat] = []
    map[cat].push(doc)
  })
  // Sort by CATEGORY_ORDER
  const sorted = {}
  CATEGORY_ORDER.forEach(cat => {
    if (map[cat]) sorted[cat] = map[cat]
  })
  // Append any unexpected categories
  Object.keys(map).forEach(cat => {
    if (!sorted[cat]) sorted[cat] = map[cat]
  })
  return sorted
}

// ── Doc row ───────────────────────────────────────────────
function DocRow({ doc }) {
  const ext = doc.fileType === 'pdf' ? 'pdf' : 'xlsx'
  const typeCfg = DOC_TYPE_CONFIG[doc.documentType] ?? DOC_TYPE_CONFIG['Filing']

  return (
    <tr className="border-b border-gray-50 dark:border-gray-700 hover:bg-[#F8FAFC] dark:hover:bg-[#253347] transition-colors group">

      {/* File name + icon */}
      <td className="px-4 py-3">
        <div className="flex items-center gap-2.5 min-w-0">
          {doc.fileType === 'pdf'
            ? <FileText className="w-5 h-5 text-red-400 flex-shrink-0" />
            : <FileSpreadsheet className="w-5 h-5 text-emerald-500 flex-shrink-0" />
          }
          <div className="min-w-0">
            <button
              className="text-sm font-medium text-blue-600 hover:text-blue-800 hover:underline flex items-center gap-1 truncate max-w-[220px]"
              title={doc.fileName}
              onClick={() => alert('Download not available in demo mode — files are stored on the server in production.')}
            >
              {doc.fileName}
              <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 flex-shrink-0" />
            </button>
            {doc.description && (
              <p className="text-xs text-gray-400 truncate max-w-[220px]">{doc.description}</p>
            )}
          </div>
        </div>
      </td>

      {/* Supplier */}
      <td className="px-4 py-3">
        <span className="text-xs text-gray-700 font-medium">{doc.supplier}</span>
      </td>

      {/* Bid ID */}
      <td className="px-4 py-3">
        <span className={`font-mono text-xs font-semibold ${doc.bidId === 'ALL' ? 'text-gray-400' : 'text-exl-navy dark:text-blue-300'}`}>
          {doc.bidId || 'ALL'}
        </span>
      </td>

      {/* Document type badge */}
      <td className="px-4 py-3">
        <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${typeCfg.bg} ${typeCfg.text}`}>
          {doc.documentType}
        </span>
      </td>

      {/* Tags */}
      <td className="px-4 py-3">
        <div className="flex flex-wrap gap-1">
          {doc.tags.slice(0, 3).map(tag => (
            <span
              key={tag}
              className={`inline-flex px-1.5 py-0.5 rounded text-xs font-medium ${TAG_COLORS[tag] ?? 'bg-gray-100 text-gray-600'}`}
            >
              {tag}
            </span>
          ))}
          {doc.tags.length > 3 && (
            <span className="text-xs text-gray-400">+{doc.tags.length - 3}</span>
          )}
        </div>
      </td>

      {/* Upload date */}
      <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap">
        {new Date(doc.uploadDate).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}
      </td>

      {/* Status badge */}
      <td className="px-4 py-3">
        {(() => {
          const cfg = DOC_STATUS_CONFIG[doc.status] ?? DOC_STATUS_CONFIG['Filed']
          return (
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${cfg.bg} ${cfg.text}`}>
              <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
              {doc.status ?? 'Filed'}
              {doc.status === 'Extracted' && doc.extractionConfidence && (
                <span className="font-normal ml-0.5">{doc.extractionConfidence}%</span>
              )}
            </span>
          )
        })()}
      </td>
    </tr>
  )
}

// ── Category section ──────────────────────────────────────
function CategorySection({ category, docs }) {
  const [collapsed, setCollapsed] = useState(false)
  const cfg = CATEGORY_CONFIG[category] ?? { dot: 'bg-gray-400', label: category }

  return (
    <div className="card overflow-hidden mb-4">
      {/* Category header */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="w-full flex items-center gap-3 px-4 py-3 bg-gray-50 dark:bg-[#253347] hover:bg-gray-100 dark:hover:bg-[#334155] border-b border-gray-200 dark:border-gray-700 transition-colors text-left"
      >
        <span className={`w-3 h-3 rounded-full flex-shrink-0 ${cfg.dot}`} />
        <span className="font-semibold text-gray-800 dark:text-gray-200 text-sm flex-1">{cfg.label}</span>
        <span className="text-xs bg-gray-200 dark:bg-gray-600 text-gray-600 dark:text-gray-300 font-semibold px-2 py-0.5 rounded-full">
          {docs.length} file{docs.length !== 1 ? 's' : ''}
        </span>
        <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${collapsed ? '-rotate-90' : ''}`} />
      </button>

      {/* Doc rows */}
      {!collapsed && (
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-100 dark:border-gray-700 bg-white dark:bg-[#1E293B]">
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400">File Name</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400">Supplier</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400">Bid</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400">Type</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400">Tags</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400">Uploaded</th>
              <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-400">Status</th>
            </tr>
          </thead>
          <tbody>
            {docs.map(doc => <DocRow key={doc.id} doc={doc} />)}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ── Main DocumentVault page ───────────────────────────────
export default function DocumentVault() {
  const [docs, setDocs]         = useState(staticDocs)
  const [search, setSearch]     = useState('')
  const [category, setCategory] = useState('All Categories')
  const [drawerOpen, setDrawer] = useState(false)

  // Fetch live from API on mount (overwrites static data)
  useEffect(() => {
    fetch('/api/documents')
      .then(r => r.ok ? r.json() : null)
      .then(data => { if (data) setDocs(data) })
      .catch(() => {}) // fall back to static
  }, [])

  // Filtered docs
  const filtered = useMemo(() => {
    let out = docs
    if (search) {
      const q = search.toLowerCase()
      out = out.filter(d =>
        d.fileName.toLowerCase().includes(q) ||
        d.supplier.toLowerCase().includes(q) ||
        (d.bidId || '').toLowerCase().includes(q) ||
        d.tags.some(t => t.toLowerCase().includes(q)) ||
        (d.description || '').toLowerCase().includes(q)
      )
    }
    if (category !== 'All Categories') {
      out = out.filter(d =>
        getDisplayCategory(d) === category || d.documentType === category
      )
    }
    return out
  }, [docs, search, category])

  const grouped = useMemo(() => groupDocs(filtered), [filtered])

  const handleUploaded = (newDoc) => {
    setDocs(prev => [...prev, newDoc])
  }

  return (
    <div className="max-w-screen-xl mx-auto">

      {/* ── Page header ── */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-exl-navy dark:text-white">Document Vault</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Central repository for all bid-related documents
          </p>
          <p className="text-xs text-gray-400 mt-1">
            💬 Ask RFP AIQ questions about any document using the <span className="font-medium text-gray-500">Chat with AIQ</span> button
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-gray-400 bg-gray-100 border border-gray-200 px-2 py-0.5 rounded-full">
            Phase 2
          </span>
          <button
            onClick={() => setDrawer(true)}
            className="btn-primary flex items-center gap-2"
          >
            <Upload className="w-4 h-4" />
            Upload Document
          </button>
        </div>
      </div>

      {/* ── Stats row ── */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {[
          { label: 'Total Documents', value: docs.length },
          { label: 'Extracted by AI', value: docs.filter(d => d.status === 'Extracted').length },
          { label: 'Linked to Bids',  value: docs.filter(d => d.bidId !== 'ALL').length },
          { label: 'Categories',      value: Object.keys(grouped).length },
        ].map(({ label, value }) => (
          <div key={label} className="card px-4 py-3 text-center">
            <div className="text-2xl font-bold text-exl-navy dark:text-blue-300">{value}</div>
            <div className="text-xs text-gray-500 mt-0.5">{label}</div>
          </div>
        ))}
      </div>

      {/* ── Filter bar ── */}
      <div className="card px-4 py-3 flex items-center gap-3 mb-6">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search by file name, supplier, bid ID, or tag…"
            className="pl-8 pr-3 py-1.5 text-sm border border-gray-200 rounded-lg w-full focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange"
          />
        </div>

        {/* Category dropdown */}
        <div className="relative flex-shrink-0">
          <select
            value={category}
            onChange={e => setCategory(e.target.value)}
            className="appearance-none pl-3 pr-8 py-1.5 text-sm border border-gray-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange cursor-pointer"
          >
            {ALL_FILTER_CATS.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" />
        </div>

        {/* Active filter badge */}
        {(search || category !== 'All Categories') && (
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500">
              {filtered.length} of {docs.length} docs
            </span>
            <button
              onClick={() => { setSearch(''); setCategory('All Categories') }}
              className="text-xs text-exl-orange hover:underline"
            >
              Clear
            </button>
          </div>
        )}
      </div>

      {/* ── Empty state ── */}
      {filtered.length === 0 && docs.length > 0 && (
        <div className="card">
          <EmptyState
            icon={Search}
            title="No documents found"
            description="Try a different search term or category filter."
            secondaryAction={{ label: 'Clear search', onClick: () => { setSearch(''); setCategory('All Categories') } }}
            size="md"
          />
        </div>
      )}
      {docs.length === 0 && (
        <div className="card">
          <EmptyState
            icon={FolderOpen}
            title="Document Vault is empty"
            description="Upload RFP documents, pricing responses, and compliance certificates. All bid-related documents are stored and organized here."
            action={{ label: 'Upload Document', icon: Upload, onClick: () => setDrawer(true) }}
            size="lg"
          />
        </div>
      )}

      {/* ── Category groups ── */}
      {Object.entries(grouped).map(([cat, catDocs]) => (
        <CategorySection key={cat} category={cat} docs={catDocs} />
      ))}

      {/* ── Upload drawer ── */}
      {drawerOpen && (
        <UploadDrawer
          onClose={() => setDrawer(false)}
          onUploaded={handleUploaded}
        />
      )}

    </div>
  )
}
