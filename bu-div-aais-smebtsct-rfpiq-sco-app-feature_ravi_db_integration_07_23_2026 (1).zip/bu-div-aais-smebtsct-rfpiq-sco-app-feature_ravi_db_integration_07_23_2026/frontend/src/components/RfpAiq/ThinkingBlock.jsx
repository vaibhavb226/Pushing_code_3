import React, { useState } from 'react'
import {
  ChevronDown, ChevronRight, Loader,
  Database, FileText, Brain, ListChecks, Zap, Search,
} from 'lucide-react'

// ── Per-node type metadata ────────────────────────────────────────────────────
const NODE_META = {
  // v3 agentic nodes — EXL Navy/Blue for cognitive steps, EXL Orange/Amber for data steps
  plan:  {
    Icon: ListChecks, label: 'Plan',
    color: '#1F3864',
    textCls: 'text-[#1F3864] dark:text-blue-300',
    dotBg: 'bg-[#1F3864]',
    pillCls: 'bg-blue-50 dark:bg-blue-900/30 text-[#1F3864] dark:text-blue-300',
    expandBg: 'bg-blue-50 dark:bg-blue-950/20',
  },
  think: {
    Icon: Brain, label: 'Reasoning',
    color: '#2563EB',
    textCls: 'text-blue-600 dark:text-blue-400',
    dotBg: 'bg-blue-600',
    pillCls: 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300',
    expandBg: 'bg-blue-50 dark:bg-blue-950/20',
  },
  query: {
    Icon: Database, label: 'SQL',
    color: '#E05A2B',
    textCls: 'text-[#E05A2B] dark:text-orange-400',
    dotBg: 'bg-[#E05A2B]',
    pillCls: 'bg-orange-50 dark:bg-orange-900/20 text-[#E05A2B] dark:text-orange-400',
    expandBg: 'bg-orange-50 dark:bg-orange-950/20',
  },
  search: {
    Icon: FileText, label: 'Documents',
    color: '#B45309',
    textCls: 'text-amber-700 dark:text-amber-400',
    dotBg: 'bg-amber-600',
    pillCls: 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400',
    expandBg: 'bg-amber-50 dark:bg-amber-950/20',
  },
  // v2 legacy fallbacks — mapped to nearest EXL equivalent
  classify:     { Icon: Search,    label: 'Classify',    color: '#1F3864', textCls: 'text-[#1F3864] dark:text-blue-300',  dotBg: 'bg-[#1F3864]', pillCls: 'bg-blue-50 dark:bg-blue-900/30 text-[#1F3864] dark:text-blue-300',   expandBg: 'bg-blue-50 dark:bg-blue-950/20'    },
  generate_sql: { Icon: Database,  label: 'Writing SQL', color: '#E05A2B', textCls: 'text-[#E05A2B] dark:text-orange-400', dotBg: 'bg-[#E05A2B]', pillCls: 'bg-orange-50 dark:bg-orange-900/20 text-[#E05A2B] dark:text-orange-400', expandBg: 'bg-orange-50 dark:bg-orange-950/20' },
  execute_sql:  { Icon: Zap,       label: 'Execute SQL', color: '#E05A2B', textCls: 'text-[#E05A2B] dark:text-orange-400', dotBg: 'bg-[#E05A2B]', pillCls: 'bg-orange-50 dark:bg-orange-900/20 text-[#E05A2B] dark:text-orange-400', expandBg: 'bg-orange-50 dark:bg-orange-950/20' },
  vector_search:{ Icon: FileText,  label: 'Documents',   color: '#B45309', textCls: 'text-amber-700 dark:text-amber-400',  dotBg: 'bg-amber-600', pillCls: 'bg-amber-50 dark:bg-amber-900/20 text-amber-700 dark:text-amber-400',  expandBg: 'bg-amber-50 dark:bg-amber-950/20'  },
  synthesize:   { Icon: Brain,     label: 'Synthesize',  color: '#E05A2B', textCls: 'text-[#E05A2B] dark:text-orange-400', dotBg: 'bg-[#E05A2B]', pillCls: 'bg-orange-50 dark:bg-orange-900/20 text-[#E05A2B] dark:text-orange-400', expandBg: 'bg-orange-50 dark:bg-orange-950/20' },
}

// ── Inline markdown parser (bold / italic / code) ─────────────────────────────
function parseInline(text) {
  if (typeof text !== 'string' || !text) return text
  const parts = []
  const regex = /(\*\*([^*\n]+)\*\*|\*([^*\n]+)\*|`([^`\n]+)`)/g
  let lastIdx = 0, match, k = 0
  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIdx) parts.push(text.slice(lastIdx, match.index))
    if (match[2] != null)      parts.push(<strong key={k++} className="font-semibold">{match[2]}</strong>)
    else if (match[3] != null) parts.push(<em key={k++}>{match[3]}</em>)
    else if (match[4] != null) parts.push(
      <code key={k++} className="bg-black/10 dark:bg-white/10 px-1 py-0.5 rounded text-[0.85em] font-mono">{match[4]}</code>
    )
    lastIdx = match.index + match[0].length
  }
  if (lastIdx < text.length) parts.push(text.slice(lastIdx))
  return parts.length === 0 ? text : parts.length === 1 && typeof parts[0] === 'string' ? parts[0] : parts
}

// ── Content renderer for expanded step details ────────────────────────────────
// Handles: code fences (with language), markdown tables, prose lines
function renderContent(text) {
  if (!text) return null
  const lines = text.split('\n')
  const elements = []
  let k = 0, i = 0

  while (i < lines.length) {
    const trimmed = lines[i].trim()
    if (!trimmed) { i++; continue }

    // Fenced code block
    if (trimmed.startsWith('```')) {
      const lang = trimmed.slice(3).trim()
      i++
      const codeLines = []
      while (i < lines.length && !lines[i].trim().startsWith('```')) { codeLines.push(lines[i]); i++ }
      i++
      elements.push(
        <div key={k++} className="mt-1.5 rounded overflow-hidden text-[11px]">
          {lang && (
            <div className="px-2 py-1 bg-gray-700 dark:bg-gray-800 font-mono text-[10px] text-gray-300 uppercase tracking-wide">
              {lang}
            </div>
          )}
          <pre className="px-3 py-2 bg-[#0D1117] text-[#E6EDF3] font-mono whitespace-pre overflow-x-auto leading-relaxed">
            <code>{codeLines.join('\n')}</code>
          </pre>
        </div>
      )
      continue
    }

    // Markdown table
    if (trimmed.startsWith('|')) {
      const tableLines = []
      while (i < lines.length && lines[i].trim().startsWith('|')) { tableLines.push(lines[i].trim()); i++ }
      const isSep = ln => /^\|[-:\|\s]+$/.test(ln)
      const parseRow = ln => ln.split('|').slice(1, -1).map(c => c.trim())
      const headerCells = parseRow(tableLines[0])
      const dataStart = tableLines.length > 1 && isSep(tableLines[1]) ? 2 : 1
      const dataRows = tableLines.slice(dataStart).map(parseRow)
      elements.push(
        <div key={k++} className="mt-1.5 overflow-x-auto rounded border border-black/10 dark:border-white/10">
          <table className="text-[10px] border-collapse w-full">
            <thead>
              <tr>
                {headerCells.map((cell, ci) => (
                  <th key={ci} className="px-2 py-1 text-left font-semibold bg-black/10 dark:bg-white/10 border-b border-black/10 dark:border-white/10 whitespace-nowrap">
                    {parseInline(cell)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {dataRows.map((row, ri) => (
                <tr key={ri} className={ri % 2 === 0 ? '' : 'bg-black/5 dark:bg-white/5'}>
                  {row.map((cell, ci) => (
                    <td key={ci} className="px-2 py-1 border-b border-black/5 dark:border-white/5">
                      {parseInline(cell)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )
      continue
    }

    // Prose line
    elements.push(
      <p key={k++} className="text-[11px] leading-relaxed">{parseInline(trimmed)}</p>
    )
    i++
  }

  return elements.length > 0
    ? <div className="space-y-1">{elements}</div>
    : <p className="text-[11px] leading-relaxed">{text}</p>
}

// ── Individual timeline step ──────────────────────────────────────────────────
function StepItem({ node, label, content, done, isLast }) {
  const [expanded, setExpanded] = useState(false)
  const meta = NODE_META[node] || NODE_META.think
  const { Icon, textCls, dotBg, expandBg } = meta
  const displayLabel = label && label !== meta.label ? label : null

  return (
    <div className="flex gap-2.5 px-3 py-2">
      {/* Timeline dot + connector line */}
      <div className="flex flex-col items-center flex-shrink-0 pt-0.5">
        <div
          className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-300
            ${done ? dotBg : 'bg-gray-200 dark:bg-gray-700'}`}
        >
          {!done
            ? <Loader className="w-2.5 h-2.5 animate-spin text-gray-400" />
            : <Icon className="w-2.5 h-2.5 text-white" />
          }
        </div>
        {!isLast && (
          <div className="w-px flex-1 mt-1.5 bg-gray-200 dark:bg-gray-700" style={{ minHeight: 8 }} />
        )}
      </div>

      {/* Step header + expandable body */}
      <div className="flex-1 min-w-0 pb-1">
        <button
          onClick={() => content && setExpanded(e => !e)}
          disabled={!content}
          className="w-full flex items-start gap-1.5 text-left group disabled:cursor-default"
        >
          <span className={`text-[10px] font-bold uppercase tracking-wide flex-shrink-0 mt-[1px] ${textCls}`}>
            {meta.label}
          </span>
          {displayLabel && (
            <span className="text-[11px] text-gray-500 dark:text-gray-400 leading-snug flex-1 min-w-0 line-clamp-1">
              {displayLabel}
            </span>
          )}
          {content && (
            <span className="flex-shrink-0 text-gray-300 dark:text-gray-600 group-hover:text-gray-500 dark:group-hover:text-gray-400 mt-0.5 transition-colors">
              {expanded ? <ChevronDown className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
            </span>
          )}
        </button>

        {expanded && content && (
          <div className={`mt-2 rounded-lg p-2.5 text-gray-700 dark:text-gray-300 ${expandBg}`}>
            {renderContent(content)}
          </div>
        )}
      </div>
    </div>
  )
}

// ── Agent Trace panel (default export) ───────────────────────────────────────
// Wraps all thinking steps as a collapsible timeline
export default function AgentTrace({ steps }) {
  const [expanded, setExpanded] = useState(true)

  if (!steps || steps.length === 0) return null

  const allDone    = steps.every(s => s.done)
  const sqlCount   = steps.filter(s => ['query', 'execute_sql', 'generate_sql'].includes(s.node)).length
  const docCount   = steps.filter(s => ['search', 'vector_search'].includes(s.node)).length
  const thinkCount = steps.filter(s => ['think', 'classify'].includes(s.node)).length

  return (
    <div className="mb-3 rounded-xl border border-gray-200 dark:border-gray-600 overflow-hidden">
      {/* ── Trace header ── */}
      <button
        onClick={() => setExpanded(e => !e)}
        className="w-full flex items-center gap-2 px-3 py-2 bg-gray-50 dark:bg-gray-800/60 hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-colors text-left"
      >
        {/* Icon */}
        <div
          className="w-[18px] h-[18px] rounded flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: '#1F3864' }}
        >
          <Brain className="w-2.5 h-2.5 text-white" />
        </div>

        {/* Label */}
        <span className="text-[11px] font-semibold text-gray-600 dark:text-gray-300 flex-shrink-0">
          Agent trace
        </span>

        {/* Summary pills */}
        <div className="flex items-center gap-1 flex-1 min-w-0 overflow-hidden">
          {thinkCount > 0 && (
            <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-blue-50 dark:bg-blue-900/30 text-[#1F3864] dark:text-blue-300 flex-shrink-0">
              {thinkCount} step{thinkCount !== 1 ? 's' : ''}
            </span>
          )}
          {sqlCount > 0 && (
            <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-orange-50 dark:bg-orange-900/20 text-[#E05A2B] dark:text-orange-400 flex-shrink-0">
              {sqlCount} SQL
            </span>
          )}
          {docCount > 0 && (
            <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-900/40 text-amber-700 dark:text-amber-300 flex-shrink-0">
              {docCount} doc{docCount !== 1 ? 's' : ''}
            </span>
          )}
        </div>

        {/* Status indicator */}
        {!allDone
          ? <Loader className="w-3 h-3 animate-spin flex-shrink-0" style={{ color: '#E05A2B' }} />
          : expanded
            ? <ChevronDown className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
            : <ChevronRight className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
        }
      </button>

      {/* ── Timeline steps ── */}
      {expanded && (
        <div className="bg-white dark:bg-gray-900/20 divide-y divide-gray-50 dark:divide-gray-800">
          {steps.map((step, i) => (
            <StepItem
              key={i}
              node={step.node}
              label={step.label}
              content={step.content}
              done={step.done}
              isLast={i === steps.length - 1}
            />
          ))}
        </div>
      )}
    </div>
  )
}
