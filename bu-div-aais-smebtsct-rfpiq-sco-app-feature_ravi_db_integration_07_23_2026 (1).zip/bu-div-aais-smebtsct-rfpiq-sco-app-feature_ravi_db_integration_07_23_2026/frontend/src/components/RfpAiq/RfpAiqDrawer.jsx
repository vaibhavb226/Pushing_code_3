import React, { useState, useRef, useEffect } from 'react'
import { BrainCircuit, X, Send, Loader, Plus, Database, FileText } from 'lucide-react'
import RfpAiqMessageBubble from './RfpAiqMessageBubble'

// ── Starter prompts, grouped by category ─────────────────────────────────────
const PROMPT_GROUPS = [
  {
    label: 'Bid Pipeline',
    color: 'text-[#1F3864] dark:text-blue-300',
    prompts: [
      'Which bids are overdue or past their due date?',
      'Give me a quick overview of where all bids stand right now and which were added this month.',
    ],
  },
  {
    label: 'Items & Compliance',
    color: 'text-[#E05A2B] dark:text-orange-400',
    prompts: [
      'Which bids require Child Nutrition or Buy American compliance?',
      'What are the most common product categories across all current bids?',
    ],
  },
  {
    label: 'Supplier Activity',
    color: 'text-[#1F3864] dark:text-blue-300',
    prompts: [
      'Which supplier has been the most active across all bids?',
      'How are our suppliers distributed across all customer segments?',
    ],
  },
]

// ── Typing indicator ──────────────────────────────────────────────────────────
function TypingIndicator() {
  return (
    <div className="flex items-start gap-2.5 mb-5">
      <div
        className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 shadow-sm"
        style={{ backgroundColor: '#1F3864' }}
      >
        <span className="text-[9px] font-black tracking-tight" style={{ color: '#E05A2B' }}>AIQ</span>
      </div>
      <div className="bg-white dark:bg-[#1E293B] border border-gray-200 dark:border-gray-600 rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-1.5 shadow-sm">
        {[0, 150, 300].map(delay => (
          <span
            key={delay}
            className="w-2 h-2 rounded-full animate-bounce"
            style={{ backgroundColor: '#1F3864', animationDelay: `${delay}ms` }}
          />
        ))}
      </div>
    </div>
  )
}

// ── SSE event parser ──────────────────────────────────────────────────────────
async function* parseSSE(reader) {
  const decoder = new TextDecoder()
  let buffer = ''
  while (true) {
    const { done, value } = await reader.read()
    if (done) break
    buffer += decoder.decode(value, { stream: true })
    const lines = buffer.split('\n')
    buffer = lines.pop() ?? ''
    for (const line of lines) {
      if (line.startsWith('data: ')) {
        const jsonStr = line.slice(6).trim()
        if (jsonStr) {
          try { yield JSON.parse(jsonStr) } catch { /* skip malformed */ }
        }
      }
    }
  }
}

// ── Main drawer ───────────────────────────────────────────────────────────────
export default function RfpAiqDrawer({ isOpen, onClose, messages, setMessages }) {
  const [input,        setInput]        = useState('')
  const [isLoading,    setIsLoading]    = useState(false)
  const [error,        setError]        = useState(null)
  const [streamingMsg, setStreamingMsg] = useState(null)

  const bottomRef = useRef(null)
  const inputRef  = useRef(null)
  const abortRef  = useRef(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isLoading, streamingMsg])

  useEffect(() => {
    if (isOpen) setTimeout(() => inputRef.current?.focus(), 300)
  }, [isOpen])

  const handleSend = async (text) => {
    const content = (text ?? input).trim()
    if (!content || isLoading) return

    setInput('')
    setError(null)

    const updatedMessages = [...messages, { role: 'user', content }]
    setMessages(updatedMessages)
    setIsLoading(true)
    setStreamingMsg({ content: '', thinking: [] })

    const controller = new AbortController()
    abortRef.current = controller

    try {
      const apiMessages = updatedMessages.map(({ role, content }) => ({ role, content }))
      const res = await fetch('/api/ai/chat', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ messages: apiMessages }),
        signal:  controller.signal,
      })

      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        throw new Error(data.error || `HTTP ${res.status}`)
      }

      const reader = res.body.getReader()
      const thinkingRef = { steps: [], pendingIdx: -1 }
      let finalContent = ''
      // Stays false until the plan node completes with >2 steps.
      // All thinking events are buffered silently until this flips to true.
      let traceVisible = false

      for await (const event of parseSSE(reader)) {
        if (controller.signal.aborted) break

        if (event.type === 'thinking_start') {
          thinkingRef.steps = [...thinkingRef.steps, { node: event.node, label: event.label, content: '', done: false }]
          thinkingRef.pendingIdx = thinkingRef.steps.length - 1
          if (traceVisible) {
            setStreamingMsg(prev => ({ ...prev, thinking: [...thinkingRef.steps] }))
          }
        } else if (event.type === 'thinking_content') {
          if (thinkingRef.pendingIdx >= 0) {
            const idx = thinkingRef.pendingIdx
            thinkingRef.steps = thinkingRef.steps.map((s, i) =>
              i === idx ? { ...s, content: (s.content ? s.content + '\n' : '') + event.text } : s
            )
            if (traceVisible) {
              setStreamingMsg(prev => ({ ...prev, thinking: [...thinkingRef.steps] }))
            }
          }
        } else if (event.type === 'thinking_end') {
          if (thinkingRef.pendingIdx >= 0) {
            const idx = thinkingRef.pendingIdx
            const closedStep = thinkingRef.steps[idx]
            thinkingRef.steps = thinkingRef.steps.map((s, i) => i === idx ? { ...s, done: true } : s)
            thinkingRef.pendingIdx = -1

            if (closedStep?.node === 'plan') {
              // Count numbered steps in plan content (e.g. "1. Query ...\n2. Filter ...")
              const planStepCount = (closedStep.content.match(/^\d+\./gm) || []).length
              traceVisible = planStepCount > 3
              if (traceVisible) {
                // Flush all buffered steps to the UI now that we've decided to show the trace
                setStreamingMsg(prev => ({ ...prev, thinking: [...thinkingRef.steps] }))
              }
            } else if (traceVisible) {
              setStreamingMsg(prev => ({ ...prev, thinking: [...thinkingRef.steps] }))
            }
          }
        } else if (event.type === 'token') {
          finalContent += event.text
          setStreamingMsg(prev => ({ ...prev, content: finalContent }))
        } else if (event.type === 'error') {
          throw new Error(event.message || 'RFP AIQ encountered an error')
        } else if (event.type === 'done') {
          break
        }
      }

      if (finalContent || thinkingRef.steps.length > 0) {
        const thinkingToSave = traceVisible ? thinkingRef.steps : []
        setMessages(prev => [...prev, { role: 'assistant', content: finalContent, thinking: thinkingToSave }])
      }
    } catch (err) {
      if (err.name !== 'AbortError') {
        setError(err.message || 'RFP AIQ is unavailable right now')
        setMessages(prev => prev.slice(0, -1))
      }
    } finally {
      setIsLoading(false)
      setStreamingMsg(null)
      abortRef.current = null
    }
  }

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend() }
  }

  const handleClear = () => {
    if (isLoading) { abortRef.current?.abort(); setIsLoading(false); setStreamingMsg(null) }
    setMessages([])
    setError(null)
  }

  return (
    <>
      {/* Backdrop */}
      <div
        className={`fixed inset-0 bg-black/40 z-40 transition-opacity duration-300
          ${isOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
        onClick={onClose}
      />

      {/* Drawer */}
      <div
        className={`fixed right-0 top-0 h-full flex flex-col shadow-2xl z-50 bg-white dark:bg-[#1E293B]
          transform transition-transform duration-300 ease-in-out
          ${isOpen ? 'translate-x-0' : 'translate-x-full'}`}
        style={{ width: 460 }}
      >
        {/* ── Header ── */}
        <div className="flex-shrink-0 px-5 py-3.5" style={{ backgroundColor: '#1F3864' }}>
          <div className="flex items-center gap-3">
            {/* Brand */}
            <div className="flex items-center gap-2 flex-1 min-w-0">
              <BrainCircuit className="w-5 h-5 flex-shrink-0" style={{ color: '#E05A2B' }} />
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-white font-bold text-sm tracking-wide">RFP AIQ</span>
                  {isLoading && (
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-orange-500/20 text-[10px] font-medium text-orange-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-400 animate-pulse" />
                      thinking
                    </span>
                  )}
                </div>
                <p className="text-white/45 text-[10px] leading-none mt-0.5 truncate">
                  SQL · Documents · Multi-step reasoning
                </p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-1 flex-shrink-0">
              {messages.length > 0 && (
                <button
                  onClick={handleClear}
                  title="New chat"
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              )}
              <button
                onClick={onClose}
                className="w-7 h-7 rounded-lg flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* ── Chat area ── */}
        <div className="flex-1 min-h-0 overflow-y-auto px-5 py-5 bg-[#F7F8FA] dark:bg-[#0F172A]">

          {/* Empty state */}
          {messages.length === 0 && !isLoading && (
            <div className="h-full flex flex-col">
              {/* Intro */}
              <div className="text-center pt-6 pb-5">
                <div
                  className="w-11 h-11 rounded-xl flex items-center justify-center mx-auto mb-3"
                  style={{ backgroundColor: '#1F3864' }}
                >
                  <BrainCircuit className="w-5 h-5" style={{ color: '#E05A2B' }} />
                </div>
                <p className="text-sm font-semibold text-gray-800 dark:text-gray-100">Ask anything about your bids</p>
                <p className="text-xs text-gray-400 dark:text-gray-500 mt-1 max-w-xs mx-auto leading-relaxed">
                  RFP AIQ queries your live database and documents to answer complex procurement questions.
                </p>
                <div className="flex items-center justify-center gap-3 mt-3">
                  <span className="flex items-center gap-1 text-[10px] text-gray-400 dark:text-gray-500">
                    <Database className="w-3 h-3 text-[#E05A2B]" /> Live SQL
                  </span>
                  <span className="text-gray-300 dark:text-gray-700">·</span>
                  <span className="flex items-center gap-1 text-[10px] text-gray-400 dark:text-gray-500">
                    <FileText className="w-3 h-3 text-amber-500 dark:text-amber-400" /> Document search
                  </span>
                  <span className="text-gray-300 dark:text-gray-700">·</span>
                  <span className="flex items-center gap-1 text-[10px] text-gray-400 dark:text-gray-500">
                    <BrainCircuit className="w-3 h-3 text-[#1F3864] dark:text-blue-400" /> Multi-step
                  </span>
                </div>
              </div>

              {/* Grouped prompts */}
              <div className="space-y-4 pb-4">
                {PROMPT_GROUPS.map(group => (
                  <div key={group.label}>
                    <p className={`text-[10px] font-bold uppercase tracking-wider mb-2 px-0.5 ${group.color}`}>
                      {group.label}
                    </p>
                    <div className="space-y-1.5">
                      {group.prompts.map(prompt => (
                        <button
                          key={prompt}
                          onClick={() => handleSend(prompt)}
                          className="w-full text-left px-3 py-2.5 text-xs text-gray-700 dark:text-gray-300 bg-white dark:bg-[#1E293B] rounded-xl border border-gray-200 dark:border-gray-700 hover:border-[#E05A2B] hover:text-[#E05A2B] dark:hover:border-[#E05A2B] dark:hover:text-orange-300 transition-colors leading-snug shadow-sm"
                        >
                          {prompt}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Messages */}
          {messages.length > 0 && (
            <>
              {messages.map((msg, i) => (
                <RfpAiqMessageBubble key={i} message={msg} thinking={msg.thinking} />
              ))}

              {/* Typing indicator — before first SSE event arrives */}
              {isLoading && streamingMsg && streamingMsg.thinking.length === 0 && !streamingMsg.content && (
                <TypingIndicator />
              )}

              {/* In-flight streaming message */}
              {isLoading && streamingMsg && (streamingMsg.thinking.length > 0 || streamingMsg.content) && (
                <RfpAiqMessageBubble
                  message={{ role: 'assistant', content: streamingMsg.content }}
                  thinking={streamingMsg.thinking}
                />
              )}

              {error && (
                <div className="mb-4 flex items-start gap-2 px-4 py-3 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-xl text-xs text-red-700 dark:text-red-400">
                  <span className="flex-shrink-0 mt-0.5">⚠</span>
                  <span>{error}</span>
                </div>
              )}
            </>
          )}

          <div ref={bottomRef} />
        </div>

        {/* ── Input area ── */}
        <div className="flex-shrink-0 px-4 py-3 bg-white dark:bg-[#1E293B] border-t border-gray-200 dark:border-gray-700">
          <div className="flex items-end gap-2">
            <textarea
              ref={inputRef}
              rows={1}
              value={input}
              onChange={e => {
                setInput(e.target.value)
                e.target.style.height = 'auto'
                e.target.style.height = Math.min(e.target.scrollHeight, 120) + 'px'
              }}
              onKeyDown={handleKeyDown}
              placeholder="Ask about bids, suppliers, pricing, trends…"
              disabled={isLoading}
              className="flex-1 resize-none px-3.5 py-2.5 text-sm border border-gray-200 dark:border-gray-600 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#E05A2B]/20 focus:border-[#E05A2B] bg-white dark:bg-[#253347] dark:text-gray-200 dark:placeholder-gray-500 leading-relaxed disabled:opacity-50 transition-colors"
              style={{ minHeight: 42, maxHeight: 120 }}
            />
            <button
              onClick={() => handleSend()}
              disabled={!input.trim() || isLoading}
              className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center text-white transition-all disabled:opacity-40 hover:opacity-90 active:scale-95"
              style={{ backgroundColor: '#E05A2B' }}
            >
              {isLoading
                ? <Loader className="w-4 h-4 animate-spin" />
                : <Send className="w-4 h-4" />
              }
            </button>
          </div>
          <p className="text-center text-[10px] text-gray-400 dark:text-gray-600 mt-2 tracking-wide">
            RFP AIQ by EXL Service &nbsp;·&nbsp; <span className="font-mono">Shift+Enter</span> for new line
          </p>
        </div>
      </div>
    </>
  )
}
