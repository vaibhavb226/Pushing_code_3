import React, { useState } from 'react'
import AgentTrace from './ThinkingBlock'

// ── Inline formatter: **bold**, *italic*, `code` ──────────────────────────────
function parseInline(text) {
  if (typeof text !== 'string' || !text) return text
  const parts = []
  const regex = /(\*\*([^*\n]+)\*\*|\*([^*\n]+)\*|`([^`\n]+)`)/g
  let lastIdx = 0, match, k = 0
  while ((match = regex.exec(text)) !== null) {
    if (match.index > lastIdx) parts.push(text.slice(lastIdx, match.index))
    if (match[2] != null) {
      parts.push(<strong key={k++} className="font-semibold text-gray-900 dark:text-gray-100">{match[2]}</strong>)
    } else if (match[3] != null) {
      parts.push(<em key={k++} className="italic">{match[3]}</em>)
    } else if (match[4] != null) {
      parts.push(
        <code key={k++} className="bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 px-1.5 py-0.5 rounded text-[0.82em] font-mono border border-gray-200 dark:border-gray-700">
          {match[4]}
        </code>
      )
    }
    lastIdx = match.index + match[0].length
  }
  if (lastIdx < text.length) parts.push(text.slice(lastIdx))
  if (parts.length === 0) return text
  if (parts.length === 1 && typeof parts[0] === 'string') return parts[0]
  return parts
}

// ── Block-level markdown renderer ────────────────────────────────────────────
// Handles: headings, code fences, tables, blockquotes, bullets, numbered lists, hr
function renderMarkdown(text) {
  if (!text) return null
  const elements = []
  let k = 0
  const lines = text.split('\n')
  let i = 0

  while (i < lines.length) {
    const line = lines[i]
    const trimmed = line.trim()

    // ── Blank line ──
    if (!trimmed) { i++; continue }

    // ── Fenced code block ──
    if (trimmed.startsWith('```')) {
      const lang = trimmed.slice(3).trim()
      i++
      const codeLines = []
      while (i < lines.length && !lines[i].trim().startsWith('```')) { codeLines.push(lines[i]); i++ }
      i++ // skip closing ```
      elements.push(
        <div key={k++} className="my-3 rounded-lg overflow-hidden border border-gray-200 dark:border-gray-700 text-xs">
          {lang && (
            <div className="flex items-center gap-2 px-3 py-1.5 bg-gray-800 dark:bg-gray-900 border-b border-gray-700">
              <span className="font-mono font-semibold text-gray-300 uppercase tracking-wider text-[10px]">{lang}</span>
              <div className="flex gap-1 ml-auto">
                <div className="w-2.5 h-2.5 rounded-full bg-gray-600" />
                <div className="w-2.5 h-2.5 rounded-full bg-gray-600" />
                <div className="w-2.5 h-2.5 rounded-full bg-gray-600" />
              </div>
            </div>
          )}
          <pre className="px-4 py-3 bg-[#0D1117] text-[#E6EDF3] font-mono whitespace-pre overflow-x-auto leading-relaxed" style={{ fontSize: '0.75rem' }}>
            <code>{codeLines.join('\n')}</code>
          </pre>
        </div>
      )
      continue
    }

    // ── Headings ──
    const hMatch = trimmed.match(/^(#{1,3})\s+(.+)$/)
    if (hMatch) {
      const level = hMatch[1].length
      if (level === 1) {
        elements.push(
          <h3 key={k++} className="text-base font-bold text-gray-900 dark:text-gray-50 mt-4 mb-2 pb-1.5 border-b border-gray-200 dark:border-gray-700 first:mt-0">
            {parseInline(hMatch[2])}
          </h3>
        )
      } else if (level === 2) {
        elements.push(
          <h4 key={k++} className="text-sm font-bold text-gray-800 dark:text-gray-100 mt-3 mb-1 first:mt-0">
            {parseInline(hMatch[2])}
          </h4>
        )
      } else {
        elements.push(
          <h5 key={k++} className="text-sm font-semibold text-gray-700 dark:text-gray-200 mt-2.5 mb-0.5 first:mt-0">
            {parseInline(hMatch[2])}
          </h5>
        )
      }
      i++
      continue
    }

    // ── Blockquote ──
    if (trimmed.startsWith('>')) {
      const quoteLines = []
      while (i < lines.length && lines[i].trim().startsWith('>')) {
        quoteLines.push(lines[i].trim().replace(/^>\s*/, ''))
        i++
      }
      elements.push(
        <blockquote key={k++} className="pl-3 py-0.5 my-2 border-l-[3px] border-exl-orange text-gray-600 dark:text-gray-400 italic text-sm">
          {quoteLines.map((l, qi) => <span key={qi}>{qi > 0 && <br />}{parseInline(l)}</span>)}
        </blockquote>
      )
      continue
    }

    // ── Horizontal rule ──
    if (/^(-{3,}|\*{3,}|_{3,})$/.test(trimmed)) {
      elements.push(<hr key={k++} className="my-3 border-gray-200 dark:border-gray-700" />)
      i++
      continue
    }

    // ── Markdown table ──
    if (trimmed.startsWith('|')) {
      const tableLines = []
      while (i < lines.length && lines[i].trim().startsWith('|')) { tableLines.push(lines[i].trim()); i++ }
      const isSep = ln => /^\|[-:\|\s]+$/.test(ln)
      const parseRow = ln => ln.split('|').slice(1, -1).map(c => c.trim())
      const isNum = v => /^-?[\d,.]+%?$/.test(v.trim())
      const headerCells = parseRow(tableLines[0])
      const dataStart = tableLines.length > 1 && isSep(tableLines[1]) ? 2 : 1
      const dataRows = tableLines.slice(dataStart).map(parseRow)
      elements.push(
        <div key={k++} className="my-3 overflow-x-auto rounded-lg border border-gray-200 dark:border-gray-700">
          <table className="text-xs border-collapse w-full">
            <thead>
              <tr className="bg-gray-50 dark:bg-gray-800">
                {headerCells.map((cell, ci) => (
                  <th
                    key={ci}
                    className="px-3 py-2 font-semibold text-gray-700 dark:text-gray-200 border-b border-gray-200 dark:border-gray-700 whitespace-nowrap"
                    style={{ textAlign: dataRows.some(r => isNum(r[ci] || '')) ? 'right' : 'left' }}
                  >
                    {parseInline(cell)}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {dataRows.map((row, ri) => (
                <tr
                  key={ri}
                  className="border-b border-gray-100 dark:border-gray-800 hover:bg-gray-50 dark:hover:bg-gray-800/40 transition-colors last:border-b-0"
                >
                  {row.map((cell, ci) => (
                    <td
                      key={ci}
                      className="px-3 py-1.5 text-gray-700 dark:text-gray-300"
                      style={{ textAlign: isNum(cell) ? 'right' : 'left' }}
                    >
                      {parseInline(cell)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )
      continue
    }

    // ── Unordered list ──
    if (/^[-*+•]\s/.test(trimmed)) {
      const items = []
      while (i < lines.length && /^[-*+•]\s/.test(lines[i].trim())) {
        items.push(
          <li key={items.length} className="leading-relaxed text-gray-700 dark:text-gray-300">
            {parseInline(lines[i].trim().replace(/^[-*+•]\s/, ''))}
          </li>
        )
        i++
      }
      elements.push(<ul key={k++} className="list-disc pl-5 my-1.5 space-y-0.5">{items}</ul>)
      continue
    }

    // ── Ordered list ──
    if (/^\d+[.)]\s/.test(trimmed)) {
      const items = []
      while (i < lines.length && /^\d+[.)]\s/.test(lines[i].trim())) {
        items.push(
          <li key={items.length} className="leading-relaxed text-gray-700 dark:text-gray-300">
            {parseInline(lines[i].trim().replace(/^\d+[.)]\s/, ''))}
          </li>
        )
        i++
      }
      elements.push(<ol key={k++} className="list-decimal pl-5 my-1.5 space-y-0.5">{items}</ol>)
      continue
    }

    // ── Paragraph: collect consecutive non-special lines ──
    const paraLines = []
    while (i < lines.length) {
      const ct = lines[i].trim()
      if (!ct) break
      if (/^#{1,3}\s/.test(ct)) break
      if (ct.startsWith('```')) break
      if (ct.startsWith('>')) break
      if (ct.startsWith('|')) break
      if (/^[-*+•]\s/.test(ct)) break
      if (/^\d+[.)]\s/.test(ct)) break
      if (/^(-{3,}|\*{3,}|_{3,})$/.test(ct)) break
      paraLines.push(lines[i])
      i++
    }
    if (paraLines.length > 0) {
      if (paraLines.length === 1) {
        elements.push(
          <p key={k++} className="leading-relaxed text-gray-700 dark:text-gray-300">
            {parseInline(paraLines[0])}
          </p>
        )
      } else {
        const content = paraLines.flatMap((l, idx) =>
          idx < paraLines.length - 1
            ? [parseInline(l), <br key={`br-${k}-${idx}`} />]
            : [parseInline(l)]
        )
        elements.push(
          <p key={k++} className="leading-relaxed text-gray-700 dark:text-gray-300">{content}</p>
        )
      }
    }
  }

  return elements.length > 0
    ? <div className="space-y-1.5">{elements}</div>
    : <p className="leading-relaxed text-gray-700 dark:text-gray-300 break-words">{text}</p>
}

// ── Suggested action pill ─────────────────────────────────────────────────────
function ActionPill({ action }) {
  const [copied, setCopied] = useState(false)
  return (
    <div className="relative inline-block">
      <button
        onClick={() => {
          navigator.clipboard.writeText(action).catch(() => {})
          setCopied(true)
          setTimeout(() => setCopied(false), 2000)
        }}
        className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-full border border-[#E05A2B] text-[#E05A2B] hover:bg-[#E05A2B] hover:text-white transition-colors"
      >
        <span aria-hidden>→</span> {action}
      </button>
      {copied && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 px-2.5 py-1 bg-gray-900 text-white text-xs font-medium rounded-lg whitespace-nowrap z-10 pointer-events-none">
          Copied
          <div className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-t-4 border-t-gray-900" />
        </div>
      )}
    </div>
  )
}

// ── Message bubble ────────────────────────────────────────────────────────────
export default function RfpAiqMessageBubble({ message, thinking }) {
  // User bubble
  if (message.role === 'user') {
    return (
      <div className="flex justify-end mb-4">
        <div
          className="max-w-[82%] px-4 py-2.5 text-sm text-white rounded-2xl rounded-tr-sm leading-relaxed break-words"
          style={{ backgroundColor: '#E05A2B' }}
        >
          {message.content}
        </div>
      </div>
    )
  }

  // Assistant bubble — strip "Suggested action:" lines from body
  const allLines = (message.content || '').split('\n')
  const actionLines = []
  const bodyLines = []
  allLines.forEach(line => {
    if (line.trim().startsWith('Suggested action:')) {
      const t = line.replace(/^Suggested action:\s*/i, '').trim()
      if (t) actionLines.push(t)
    } else {
      bodyLines.push(line)
    }
  })
  while (bodyLines.length && !bodyLines[bodyLines.length - 1].trim()) bodyLines.pop()
  const bodyText = bodyLines.join('\n')

  return (
    <div className="flex items-start gap-2.5 mb-5">
      {/* Avatar */}
      <div
        className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 shadow-sm"
        style={{ backgroundColor: '#1F3864' }}
      >
        <span className="text-[9px] font-black tracking-tight" style={{ color: '#E05A2B' }}>
          AIQ
        </span>
      </div>

      <div className="flex-1 min-w-0">
        {/* Agent trace (thinking steps) */}
        {thinking && thinking.length > 0 && (
          <AgentTrace steps={thinking} />
        )}

        {/* Response body */}
        {bodyText && (
          <div className="bg-white dark:bg-[#1E293B] border border-gray-200 dark:border-gray-600 rounded-2xl rounded-tl-sm px-4 py-3 text-sm shadow-sm overflow-x-auto">
            {renderMarkdown(bodyText)}
          </div>
        )}

        {/* Suggested actions */}
        {actionLines.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-2">
            {actionLines.map((action, i) => <ActionPill key={i} action={action} />)}
          </div>
        )}
      </div>
    </div>
  )
}
