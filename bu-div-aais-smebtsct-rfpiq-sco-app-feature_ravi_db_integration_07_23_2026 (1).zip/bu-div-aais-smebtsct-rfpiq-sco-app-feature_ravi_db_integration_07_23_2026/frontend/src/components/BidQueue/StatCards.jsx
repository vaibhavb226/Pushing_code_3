import React from 'react'
import { TrendingUp, AlertTriangle, BarChart2, Layers } from 'lucide-react'
import { computeStats } from '../../utils/bidUtils'

// ── Info tooltip ──────────────────────────────────────────
// dir: 'left' (default) — tooltip extends right from icon
//      'right'          — tooltip extends left from icon (use on rightmost card)
function InfoTooltip({ text, dir = 'left' }) {
  return (
    <div className="relative group inline-flex flex-shrink-0">
      {/* Icon */}
      <span
        className="w-[15px] h-[15px] rounded-full bg-gray-200 hover:bg-gray-300 text-gray-500
                   text-[9px] font-bold flex items-center justify-center cursor-default
                   select-none leading-none transition-colors"
      >
        i
      </span>

      {/* Tooltip box */}
      <div
        className={`absolute ${dir === 'right' ? 'right-0' : 'left-0'} top-[22px] z-[200]
                   hidden group-hover:block w-[240px] bg-exl-navy text-white text-xs
                   rounded-lg px-3 py-3 shadow-2xl leading-relaxed pointer-events-none`}
      >
        {/* Arrow pointing up */}
        <div
          className={`absolute -top-[5px] ${dir === 'right' ? 'right-[4px]' : 'left-[4px]'}
                     w-2.5 h-2.5 bg-exl-navy rotate-45`}
        />
        <span className="relative">{text}</span>
      </div>
    </div>
  )
}

// ── Stat card ─────────────────────────────────────────────
// Note: deliberately NOT using card-hover (which applies transform: translateY)
// because CSS transforms create a new stacking context that traps the tooltip
// and prevents it from appearing above sibling cards. Shadow-only hover avoids this.
function StatCard({ icon: Icon, label, value, sub, subCls, accent, iconBg, tooltip, tooltipDir = 'left', subTitle, borderCls = '', pulse = false }) {
  return (
    <div className={`card px-5 py-4 flex items-center gap-4 border-l-4 ${borderCls} dark:shadow-gray-900 hover:shadow-lg transition-shadow duration-150`}>
      <div className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${iconBg}`}>
        <Icon className={`w-5 h-5 ${accent}`} />
      </div>

      <div className="min-w-0 flex-1">
        {/* Label row + tooltip icon */}
        <div className="flex items-center gap-1.5 mb-0.5">
          <p className="text-xs text-gray-500 font-medium uppercase tracking-wide leading-none">
            {label}
          </p>
          {tooltip && <InfoTooltip text={tooltip} dir={tooltipDir} />}
        </div>

        {/* Value */}
        <p className={`text-2xl font-bold leading-tight ${accent}`}>{value}</p>

        {/* Subtext */}
        {sub && (
          <div className="flex items-center gap-1.5 mt-0.5">
            {pulse && <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse flex-shrink-0" />}
            <p className={`text-xs truncate ${subCls ?? 'text-gray-400'}`} title={subTitle ?? sub}>{sub}</p>
          </div>
        )}
      </div>
    </div>
  )
}

// ── StatCards container ───────────────────────────────────
export default function StatCards({ bids }) {
  const { total, atRisk, avgRate, segments, segmentNames } = computeStats(bids)

  // Card 4: segment names joined with · (full list in title attr for hover)
  const segmentSub = segmentNames.join(' · ')

  return (
    <div className="grid grid-cols-4 gap-4 mb-6">

      {/* ── Card 1: Active RFPs ── */}
      <StatCard
        icon={Layers}
        label="Active RFPs"
        value={total}
        sub={`across ${segments} segments`}
        accent="text-exl-navy dark:text-blue-300"
        iconBg="bg-exl-navy/10"
        borderCls="border-l-[#1F3864]"
        tooltip="All RFPs currently in the system including Active, Solicitation, Working File, and Review stages. Excludes Awarded and Cancelled RFPs."
      />

      {/* ── Card 2: At Risk ── */}
      <StatCard
        icon={AlertTriangle}
        label="At Risk"
        value={atRisk}
        sub="internal due date within 7 days"
        subCls="text-red-700 font-semibold"
        accent="text-red-600"
        iconBg="bg-red-50"
        borderCls="border-l-red-500"
        pulse={atRisk > 0}
        tooltip="RFPs where the internal due date is today or within the next 7 days, or where the due date has already passed. These RFPs need immediate action from the Bid COE team."
      />

      {/* ── Card 3: Supplier Response Rate ── */}
      <StatCard
        icon={BarChart2}
        label="Supplier Response Rate"
        value={`${avgRate}%`}
        sub="across RFPs in Solicitation stage"
        accent="text-exl-orange"
        iconBg="bg-exl-orange/10 dark:bg-orange-900/30"
        borderCls="border-l-[#E05A2B]"
        tooltip="The average percentage of solicited suppliers who have submitted pricing responses, calculated only across RFPs currently in the Solicitation stage. Example: if 10 suppliers were solicited and 8 responded, the rate is 80%."
      />

      {/* ── Card 4: Segments Active — tooltip aligned right to avoid screen overflow ── */}
      <StatCard
        icon={TrendingUp}
        label="Segments Active"
        value={`${segments}/7`}
        sub={segmentSub}
        subTitle={segmentSub}
        accent="text-emerald-600"
        iconBg="bg-emerald-50"
        borderCls="border-l-emerald-500"
        tooltipDir="right"
        tooltip="Number of distinct customer segments with at least one active RFP in the system."
      />

    </div>
  )
}
