import React, { useState, useMemo, useEffect, useRef } from 'react'
import { createPortal } from 'react-dom'
import {
  Users, Search, AlertTriangle, CheckCircle, Mail,
  ChevronDown, ChevronUp, RefreshCw, Tag, MapPin, Plus, X,
  Loader, Loader2, Send, Clock, ArrowRight, UserPlus, Link2, Copy, Check, Globe,
  ExternalLink, Bell, Trophy, Paperclip, Settings, GripVertical, Info,
  Edit2, Trash2,
} from 'lucide-react'
import { Button } from '../UI/Button'
import { EmptyState } from '../UI/EmptyState'
import { buildAwardEmailSubject, buildAwardEmailBody } from '../../utils/awardEmailTemplate'
import { PORTAL_URL as PORTAL_BASE } from '../../config.js'

// ── Portal URL helper ─────────────────────────────────────
const getPortalUrl = (bidId) => `${PORTAL_BASE}/submit/${bidId}`

// ── Copyable portal URL chip ──────────────────────────────
function PortalUrlChip({ bidId }) {
  const [copied, setCopied] = useState(false)
  const url = getPortalUrl(bidId)
  const copy = () => {
    navigator.clipboard.writeText(url).catch(() => {})
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }
  return (
    <div className="flex items-center gap-2 bg-blue-50 border border-blue-100 rounded-xl px-3 py-2">
      <Link2 className="w-3.5 h-3.5 text-blue-500 flex-shrink-0" />
      <span className="text-xs text-blue-700 font-medium flex-1">Supplier Portal:</span>
      <a
        href={url}
        target="_blank"
        rel="noopener noreferrer"
        className="text-xs font-mono text-blue-600 hover:underline truncate max-w-[220px]"
        title={url}
      >
        {url}
      </a>
      <button
        onClick={copy}
        title="Copy portal URL"
        className="flex items-center gap-1 px-2 py-0.5 rounded-lg text-xs font-semibold bg-white border border-blue-200 text-blue-600 hover:bg-blue-100 transition-colors flex-shrink-0"
      >
        {copied
          ? <><Check className="w-3 h-3" /> Copied</>
          : <><Copy className="w-3 h-3" /> Copy</>
        }
      </button>
    </div>
  )
}

// ── Category dot colours ──────────────────────────────────
const CAT_DOTS = {
  Protein:  'bg-red-500',
  Dairy:    'bg-blue-500',
  Bakery:   'bg-amber-500',
  Produce:  'bg-lime-500',
  Grocery:  'bg-green-500',
  Beverage: 'bg-cyan-500',
  Paper:    'bg-gray-500',
  Broker:   'bg-purple-500',
}

const TAG_COLORS = {
  'K-12':           'bg-blue-100 text-blue-800',
  'DoD':            'bg-slate-100 text-slate-800',
  'Buy American':   'bg-red-100 text-red-700',
  'Child Nutrition':'bg-green-100 text-green-800',
  'CN':             'bg-green-100 text-green-800',
  'Halal':          'bg-teal-100 text-teal-800',
  'Kosher':         'bg-indigo-100 text-indigo-800',
  'Whole Grain':    'bg-lime-100 text-lime-800',
  'PFS':            'bg-purple-100 text-purple-800',
}

const SEGMENT_PALETTE = [
  'bg-blue-100 text-blue-700',
  'bg-violet-100 text-violet-700',
  'bg-teal-100 text-teal-700',
  'bg-orange-100 text-orange-700',
  'bg-indigo-100 text-indigo-700',
  'bg-rose-100 text-rose-700',
  'bg-cyan-100 text-cyan-700',
  'bg-lime-100 text-lime-700',
]
// Derives a stable color from the segment name so new/renamed segments never break.
const getSegmentColor = (seg) => {
  if (!seg || seg === 'All') return 'bg-gray-100 text-gray-600'
  const hash = seg.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0)
  return SEGMENT_PALETTE[hash % SEGMENT_PALETTE.length]
}

const STATUS_CFG = {
  Awaiting:               { bg: 'bg-gray-100',    text: 'text-gray-600',    dot: 'bg-gray-400',    label: 'Awaiting',               icon: '⏳' },
  Contacted:              { bg: 'bg-gray-100',    text: 'text-gray-600',    dot: 'bg-gray-400',    label: 'Contacted',              icon: '✉'  },
  Responded:              { bg: 'bg-emerald-100', text: 'text-emerald-700', dot: 'bg-emerald-500', label: 'Responded',              icon: '✓'  },
  'Under Consideration':  { bg: 'bg-orange-100',  text: 'text-orange-700',  dot: 'bg-orange-400',  label: 'Under Consideration',    icon: ''   },
  'Issues Found':         { bg: 'bg-amber-100',   text: 'text-amber-700',   dot: 'bg-amber-500',   label: 'Issues Found',           icon: '⚠️' },
  'Follow-up Sent':       { bg: 'bg-blue-100',    text: 'text-blue-700',    dot: 'bg-blue-500',    label: 'Follow-up Sent',         icon: '↩'  },
  Complete:               { bg: 'bg-teal-100',    text: 'text-teal-700',    dot: 'bg-teal-500',    label: 'Complete',               icon: '✓'  },
  Awarded:                { bg: 'bg-emerald-100', text: 'text-emerald-700', dot: 'bg-emerald-500', label: 'Awarded',                icon: '🏆' },
  'No Bid':               { bg: 'bg-slate-100',   text: 'text-slate-600',   dot: 'bg-slate-400',   label: 'No Bid',                 icon: '🚫' },
  Bounced:                { bg: 'bg-red-100',     text: 'text-red-700',     dot: 'bg-red-500',     label: 'Bounced',                icon: '❌' },
}

const ALL_STATUSES = [
  'Awaiting', 'Responded', 'Issues Found', 'Follow-up Sent', 'Complete', 'No Bid', 'Bounced',
]

const CATEGORIES = ['Protein', 'Dairy', 'Bakery', 'Produce', 'Grocery', 'Beverage', 'Paper', 'Broker']
const REGIONS    = ['Northeast', 'Southeast', 'Midwest', 'Southwest', 'Northwest', 'National']
const SEGMENTS   = ['K-12', 'DoD', 'University', 'Healthcare', 'Restaurant', 'Lodging', 'Government']

// ── Supplier row (pre-solicitation matching list) ─────────
function SupplierRow({ supplier, checked, onToggle, onEdit, onDelete }) {
  const isBounced = supplier.bounce === true
  const [confirmDelete, setConfirmDelete] = useState(false)
  const aliases = supplier.additionalEmails || []

  return (
    <tr className={`group border-b border-gray-50 transition-colors ${
      isBounced ? 'bg-red-50/40 opacity-60' : 'hover:bg-gray-50/80'
    }`}>
      <td className="pl-4 pr-2 py-3 w-10">
        <input
          type="checkbox"
          checked={checked && !isBounced}
          disabled={isBounced}
          onChange={() => !isBounced && onToggle(supplier.id)}
          className="w-4 h-4 rounded border-gray-300 text-exl-orange focus:ring-exl-orange/30 cursor-pointer disabled:cursor-not-allowed"
        />
      </td>
      <td className="px-3 py-3">
        <div className="flex items-center gap-2 flex-wrap">
          <span className={`text-sm font-semibold ${isBounced ? 'text-gray-400' : 'text-gray-900'}`}>
            {supplier.name}
          </span>
          {supplier.broker && (
            <span className="inline-flex px-1.5 py-0.5 bg-purple-100 text-purple-700 text-xs font-semibold rounded">
              Broker
            </span>
          )}
          {isBounced && (
            <span className="inline-flex items-center gap-1 px-1.5 py-0.5 bg-red-100 text-red-700 text-xs font-bold rounded">
              <AlertTriangle className="w-2.5 h-2.5" /> Bounce
            </span>
          )}
        </div>
      </td>
      <td className="px-3 py-3">
        <div className="flex items-center gap-1 text-xs text-gray-500 mb-0.5">
          <MapPin className="w-3 h-3" /> {supplier.region}
        </div>
        <div className="flex items-center gap-1 text-xs text-gray-500">
          <Mail className="w-3 h-3" />
          <span className="font-mono truncate max-w-[160px]">{supplier.contact}</span>
          {aliases.length > 0 && (
            <span
              className="inline-flex px-1 py-0 bg-gray-100 text-gray-500 text-xs rounded cursor-default"
              title={aliases.join('\n')}
            >
              +{aliases.length}
            </span>
          )}
        </div>
      </td>
      <td className="px-3 py-3">
        <div className="flex flex-wrap gap-1">
          {(supplier.subcategories || []).slice(0, 3).map(sc => (
            <span key={sc} className="inline-flex px-1.5 py-0.5 bg-gray-100 text-gray-600 text-xs rounded">
              {sc}
            </span>
          ))}
        </div>
      </td>
      <td className="px-3 py-3">
        <div className="flex flex-wrap gap-1">
          {(supplier.tags || []).map(tag => (
            <span key={tag} className={`inline-flex px-1.5 py-0.5 text-xs font-medium rounded ${TAG_COLORS[tag] ?? 'bg-gray-100 text-gray-600'}`}>
              {tag}
            </span>
          ))}
        </div>
      </td>
      <td className="px-3 py-3 text-right w-20">
        {supplier.matchScore != null ? (
          <span
            className={`inline-flex px-1.5 py-0.5 text-xs font-medium rounded ${
              supplier.matchScore >= 70 ? 'bg-green-100 text-green-700' :
              supplier.matchScore >= 45 ? 'bg-amber-100 text-amber-700' :
              'bg-gray-100 text-gray-500'
            }`}
            title={supplier.matchReasons?.join(' · ') || ''}
          >
            {supplier.matchScore}%
          </span>
        ) : (
          <span className="text-gray-300 text-xs">—</span>
        )}
      </td>
      <td className="px-3 py-3">
        <div className="flex flex-wrap gap-1">
          {(supplier.segments || []).length > 0 ? (
            (supplier.segments).map(seg => (
              <span key={seg} className={`inline-flex px-1.5 py-0.5 text-xs font-medium rounded ${getSegmentColor(seg)}`}>
                {seg}
              </span>
            ))
          ) : (
            <span className="text-gray-300 text-xs">—</span>
          )}
        </div>
      </td>
      <td className="px-2 py-3 w-20 text-right">
        {confirmDelete ? (
          <div className="flex items-center gap-1 justify-end">
            <span className="text-xs text-red-600 font-medium">Remove?</span>
            <button
              onClick={() => { onDelete(supplier.id); setConfirmDelete(false) }}
              className="text-xs font-semibold text-red-600 hover:underline"
            >Yes</button>
            <button
              onClick={() => setConfirmDelete(false)}
              className="text-xs text-gray-400 hover:underline"
            >No</button>
          </div>
        ) : (
          <div className="flex items-center gap-1 justify-end opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={() => onEdit(supplier)}
              title="Edit supplier"
              className="p-1 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-700"
            >
              <Edit2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setConfirmDelete(true)}
              title="Remove supplier"
              className="p-1 rounded hover:bg-red-50 text-gray-400 hover:text-red-600"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </td>
    </tr>
  )
}

// ── Category section (pre-solicitation) ──────────────────
function CategorySection({ category, suppliers, checked, onToggle, onEditSupplier, onDeleteSupplier }) {
  const [collapsed, setCollapsed] = useState(false)
  const dot          = CAT_DOTS[category] ?? 'bg-gray-400'
  const checkedCount = suppliers.filter(s => !s.bounce && checked[s.id]).length

  return (
    <div className="card overflow-hidden mb-3">
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="w-full flex items-center gap-3 px-4 py-3 bg-gray-50 hover:bg-gray-100 border-b border-gray-200 transition-colors text-left"
      >
        <span className={`w-3 h-3 rounded-full flex-shrink-0 ${dot}`} />
        <span className="font-semibold text-gray-800 text-sm flex-1">{category}</span>
        <span className="text-xs bg-gray-200 text-gray-600 font-semibold px-2 py-0.5 rounded-full">
          {checkedCount}/{suppliers.length} selected
        </span>
        <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${collapsed ? '-rotate-90' : ''}`} />
      </button>
      {!collapsed && (
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-gray-100">
              <th className="pl-4 pr-2 py-2 w-10" />
              <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Supplier</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Contact</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Subcategories</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Compliance</th>
              <th className="px-3 py-2 text-right text-xs font-medium text-gray-500 w-20">Score</th>
              <th className="px-3 py-2 text-left text-xs font-medium text-gray-500">Segments</th>
              <th className="px-2 py-2 w-20" />
            </tr>
          </thead>
          <tbody>
            {suppliers.map(sup => (
              <SupplierRow
                key={sup.id}
                supplier={sup}
                checked={!!checked[sup.id]}
                onToggle={onToggle}
                onEdit={onEditSupplier}
                onDelete={onDeleteSupplier}
              />
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}

// ── Solicited supplier row (post-solicitation) ────────────
// PORTAL-DEMO: full portal-aware signature
function SolicitedSupplierRow({ supplier, portalSub, bid, onSendReminder, onResolicit, onSwitchToEmail, awardNotifDate, onEditSupplier, onDeleteSupplier }) {
  const cfg     = STATUS_CFG[supplier.status] ?? STATUS_CFG.Awaiting
  const [confirmDelete, setConfirmDelete] = useState(false)
  const fmtDate = (d) => d ? new Date(d).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : '—'

  // PORTAL-DEMO: portal state vars
  // Portal channel only if supplier submitted pricing with at least one priced item
  const hasPortalSubmission = !!(portalSub?.pricedCount > 0)
  const realEmailCount      = (supplier.emails || []).filter(e => !e.isBounce && e.type !== 'bounce').length
  const hasEmailResponse    = realEmailCount > 0
  const hasPortal           = hasPortalSubmission  // kept for threadUrl / activity line below
  const channel             = hasPortalSubmission && hasEmailResponse ? 'Both'
                            : hasPortalSubmission ? 'Portal'
                            : 'Email'
  const threadUrl = portalSub?.threadId
    ? `${PORTAL_BASE}/submit/${bid?.id}/thread/${portalSub.threadId}`
    : null
  const canResolicit = ['No Bid', 'Awaiting', 'Bounced'].includes(supplier.status)

  return (
    <tr className="group border-b border-gray-100 dark:border-gray-700 hover:bg-[#F8FAFC] dark:hover:bg-[#253347] transition-colors">
      {/* Supplier name + email */}
      <td className="px-4 py-3">
        <div className="flex items-center gap-2">
          <p className="text-sm font-semibold text-gray-900">{supplier.supplierName}</p>
          {supplier.isBroker && (
            <span className="inline-flex px-1.5 py-0.5 bg-purple-100 text-purple-700 text-xs font-semibold rounded">Broker</span>
          )}
        </div>
        <p className="text-xs text-gray-500 font-mono mt-0.5">{supplier.supplierEmail}</p>
        {awardNotifDate && (
          <p className="text-xs text-emerald-600 font-medium mt-0.5">📧 Notified {awardNotifDate}</p>
        )}
        {/* PORTAL-DEMO: portal activity lines additive */}
        {hasPortal ? (
          <p className="text-xs text-emerald-600 font-medium mt-1 flex items-center gap-1">
            <Globe className="w-3 h-3" />
            {portalSub.messageCount} message{portalSub.messageCount !== 1 ? 's' : ''} · Last active: {fmtDate(portalSub.lastActive)}
          </p>
        ) : (
          <p className="text-xs text-gray-300 mt-1 flex items-center gap-1">
            <Globe className="w-3 h-3" />Portal not yet accessed
          </p>
        )}
      </td>

      {/* PORTAL-DEMO: channel badge column additive */}
      <td className="px-4 py-2 whitespace-nowrap">
        {channel === 'Both' ? (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-blue-100 text-blue-700 text-xs font-semibold rounded-full">
            <Mail className="w-3 h-3" /><Globe className="w-3 h-3" /> Both
          </span>
        ) : channel === 'Portal' ? (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full">
            <Globe className="w-3 h-3" /> Portal
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 text-gray-500 text-xs font-semibold rounded-full">
            <Mail className="w-3 h-3" /> Email
          </span>
        )}
      </td>

      {/* Status — read-only badge (set from Email Repo) */}
      <td className="px-4 py-3">
        <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full ${cfg.bg} ${cfg.text}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
          {cfg.icon} {cfg.label}
        </span>
      </td>

      <td className="px-4 py-3 text-xs text-gray-500">
        {realEmailCount > 0
          ? <span>{realEmailCount} email{realEmailCount > 1 ? 's' : ''}</span>
          : <span className="text-gray-300">—</span>
        }
      </td>
      <td className="px-4 py-3 text-xs text-gray-500">
        {fmtDate(supplier.lastActivity)}
      </td>
      <td className="px-4 py-3">
        {/* PORTAL-DEMO: all action buttons shown additively */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => onSwitchToEmail?.()}
            className="inline-flex items-center gap-1 text-xs font-semibold text-exl-orange hover:underline"
          >
            View <ArrowRight className="w-3 h-3" />
          </button>
          {hasPortal && threadUrl && (
            <a href={threadUrl} target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-lg border border-emerald-300 text-emerald-700 bg-emerald-50 hover:bg-emerald-100 transition-colors">
              <Globe className="w-3 h-3" /> Thread
            </a>
          )}
          {onSendReminder && (
            <button onClick={() => onSendReminder(supplier)}
              className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-lg border border-amber-300 text-amber-700 bg-amber-50 hover:bg-amber-100 transition-colors">
              <Bell className="w-3 h-3" /> Remind
            </button>
          )}
          {onResolicit && canResolicit && (
            <button onClick={() => onResolicit(supplier)}
              className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-lg border border-blue-300 text-blue-700 bg-blue-50 hover:bg-blue-100 transition-colors">
              <Send className="w-3 h-3" /> Resolicit
            </button>
          )}
          {/* Edit / Delete — hover-reveal */}
          <div className="flex items-center gap-0.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={() => onEditSupplier?.(supplier)}
              title="Edit supplier"
              className="p-1 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-700"
            >
              <Edit2 className="w-3.5 h-3.5" />
            </button>
            {!confirmDelete ? (
              <button
                onClick={() => setConfirmDelete(true)}
                title="Remove supplier"
                className="p-1 rounded hover:bg-red-50 text-gray-400 hover:text-red-600"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            ) : (
              <span className="flex items-center gap-1 text-xs ml-1">
                <span className="text-red-600 font-medium">Remove?</span>
                <button
                  onClick={() => { onDeleteSupplier?.(supplier.supplierId); setConfirmDelete(false) }}
                  className="text-red-600 font-semibold hover:underline"
                >Yes</button>
                <button onClick={() => setConfirmDelete(false)} className="text-gray-500 hover:underline">No</button>
              </span>
            )}
          </div>
        </div>
      </td>
    </tr>
  )
}

// ─────────────────────────────────────────────────────────
// Reminder Email Modal
// ─────────────────────────────────────────────────────────
function ReminderModal({ bid, supplier, onClose, onSent }) {
  const hour      = new Date().getHours()
  const greeting  = hour < 12 ? 'morning' : 'afternoon'
  const dueFmt    = bid.customerDue
    ? new Date(bid.customerDue).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
    : 'TBD'
  const portalUrl = `${PORTAL_BASE}/submit/${bid.id}`

  const defaultSubject = `Reminder: Pricing Request for ${bid.customer} — Response Due ${dueFmt}`
  const defaultBody    = `Good ${greeting},

This is a friendly reminder that we have not yet received your pricing response for ${bid.customer} (RFP ${bid.rfpNumber || bid.id}).

Please submit your pricing using our online portal:
→ ${portalUrl}

Using the portal ensures your submission is recorded immediately and allows for direct communication with our Bid COE team.

Response deadline: ${dueFmt}

If you are unable to respond, please let us know at your earliest convenience.

FoodCorp Bid COE
bids@foodcorp.com`

  const [subject, setSubject] = useState(defaultSubject)
  const [body,    setBody]    = useState(defaultBody)
  const [sending, setSending] = useState(false)
  const [error,   setError]   = useState(null)

  const handleSend = async () => {
    setSending(true)
    setError(null)
    try {
      const r = await fetch(`/api/bids/${bid.id}/emails`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          direction:     'outbound',
          supplierId:    supplier.supplierId,
          supplierName:  supplier.supplierName,
          supplierEmail: supplier.supplierEmail,
          from:          'bids@foodcorp.com',
          to:            supplier.supplierEmail,
          bcc:           [supplier.supplierEmail],
          subject, body,
          attachments:   [],
          tags:          ['reminder', 'portal-url'],
        }),
      })
      const d = await r.json()
      if (!r.ok) throw new Error(d.error || d.hint || 'Send failed')
      onSent(`Reminder sent to ${supplier.supplierName}`, supplier.supplierId)
    } catch (err) {
      setError(err.message)
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-white dark:bg-[#1E293B] w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 bg-exl-navy flex-shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <Bell className="w-4 h-4 text-amber-400" />
              <h3 className="text-white font-bold text-sm">Send Reminder</h3>
            </div>
            <p className="text-white/60 text-xs mt-0.5">To: {supplier.supplierName} · {supplier.supplierEmail}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="flex-1 min-h-0 overflow-y-auto divide-y divide-gray-100 dark:divide-gray-700">
          <div className="px-6 py-3">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1.5">Subject</p>
            <input value={subject} onChange={e => setSubject(e.target.value)}
              className="w-full text-sm font-medium outline-none bg-transparent border-0 focus:ring-0 dark:text-gray-200" />
          </div>
          <div className="px-6 py-4">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2">Message</p>
            <textarea rows={14} value={body} onChange={e => setBody(e.target.value)}
              className="w-full text-sm text-gray-700 dark:text-gray-300 outline-none resize-none leading-relaxed font-sans bg-transparent" />
          </div>
        </div>
        {error && (
          <div className="px-6 py-2.5 bg-red-50 dark:bg-red-900/20 border-t border-red-100 dark:border-red-800 flex items-center gap-2 text-xs text-red-700 dark:text-red-400 flex-shrink-0">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />{error}
          </div>
        )}
        <div className="px-6 py-4 flex gap-3 bg-gray-50 dark:bg-[#253347] border-t border-gray-200 dark:border-gray-700 flex-shrink-0">
          <button onClick={onClose} className="btn-secondary flex-1 text-sm">Cancel</button>
          <button onClick={handleSend} disabled={sending}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-exl-orange hover:bg-exl-orange/90 text-white font-semibold text-sm rounded-xl disabled:opacity-50">
            {sending ? <><Loader className="w-4 h-4 animate-spin" /> Sending…</> : <><Send className="w-4 h-4" /> Send Reminder</>}
          </button>
        </div>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────────────────
// Resolicit Modal
// ─────────────────────────────────────────────────────────
function ResolicitModal({ bid, supplier, onClose, onSent }) {
  const hour     = new Date().getHours()
  const greeting = hour < 12 ? 'morning' : 'afternoon'
  const dueFmt   = bid.customerDue
    ? new Date(bid.customerDue).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
    : 'TBD'
  const portalUrl = `${PORTAL_BASE}/submit/${bid.id}`

  const defaultSubject = `Re-Solicitation: ${bid.customer} — Updated Pricing Request`
  const defaultBody    = `Good ${greeting},

We are reaching out again regarding our pricing request for ${bid.customer} (RFP ${bid.rfpNumber || bid.id}).

We would like to give you another opportunity to submit pricing via our supplier portal:
→ ${portalUrl}

Updated deadline: ${dueFmt}

Please let us know if you have any questions.

FoodCorp Bid COE
bids@foodcorp.com`

  const [subject, setSubject] = useState(defaultSubject)
  const [body,    setBody]    = useState(defaultBody)
  const [sending, setSending] = useState(false)
  const [error,   setError]   = useState(null)

  const handleSend = async () => {
    setSending(true)
    setError(null)
    try {
      const r = await fetch(`/api/bids/${bid.id}/emails`, {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          direction:     'outbound',
          supplierId:    supplier.supplierId,
          supplierName:  supplier.supplierName,
          supplierEmail: supplier.supplierEmail,
          from:          'bids@foodcorp.com',
          to:            supplier.supplierEmail,
          bcc:           [supplier.supplierEmail],
          subject, body,
          attachments:   [],
          tags:          ['resolicitation', 'portal-url'],
        }),
      })
      const d = await r.json()
      if (!r.ok) throw new Error(d.error || d.hint || 'Send failed')
      onSent(`Re-solicitation sent to ${supplier.supplierName}`, supplier.supplierId)
    } catch (err) {
      setError(err.message)
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-white dark:bg-[#1E293B] w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between px-6 py-4 bg-exl-navy flex-shrink-0">
          <div>
            <div className="flex items-center gap-2">
              <Send className="w-4 h-4 text-blue-400" />
              <h3 className="text-white font-bold text-sm">Re-Solicitation Email</h3>
            </div>
            <p className="text-white/60 text-xs mt-0.5">To: {supplier.supplierName} · {supplier.supplierEmail}</p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
        <div className="flex-1 min-h-0 overflow-y-auto divide-y divide-gray-100 dark:divide-gray-700">
          <div className="px-6 py-3">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1.5">Subject</p>
            <input value={subject} onChange={e => setSubject(e.target.value)}
              className="w-full text-sm font-medium outline-none bg-transparent border-0 focus:ring-0 dark:text-gray-200" />
          </div>
          <div className="px-6 py-4">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-2">Message</p>
            <textarea rows={12} value={body} onChange={e => setBody(e.target.value)}
              className="w-full text-sm text-gray-700 dark:text-gray-300 outline-none resize-none leading-relaxed font-sans bg-transparent" />
          </div>
        </div>
        {error && (
          <div className="px-6 py-2.5 bg-red-50 dark:bg-red-900/20 border-t border-red-100 dark:border-red-800 flex items-center gap-2 text-xs text-red-700 dark:text-red-400 flex-shrink-0">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />{error}
          </div>
        )}
        <div className="px-6 py-4 flex gap-3 bg-gray-50 dark:bg-[#253347] border-t border-gray-200 dark:border-gray-700 flex-shrink-0">
          <button onClick={onClose} className="btn-secondary flex-1 text-sm">Cancel</button>
          <button onClick={handleSend} disabled={sending}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-exl-orange hover:bg-exl-orange/90 text-white font-semibold text-sm rounded-xl disabled:opacity-50">
            {sending ? <><Loader className="w-4 h-4 animate-spin" /> Sending…</> : <><Send className="w-4 h-4" /> Send Re-Solicitation</>}
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Add / Edit Supplier Panel ─────────────────────────────
function AddSupplierPanel({ bid, onAdded, onSelectExisting, onAddToList, editMode, initialSupplier, onUpdated, onCancelEdit }) {
  const isEdit = editMode && !!initialSupplier

  const [mode,            setMode]            = useState(isEdit ? 'form' : 'search')
  const [query,           setQuery]           = useState('')
  const [results,         setResults]         = useState([])
  const [total,           setTotal]           = useState(0)
  const [searching,       setSearching]       = useState(false)
  const [saving,          setSaving]          = useState(false)
  const [error,           setError]           = useState(null)
  const [successMsg,      setSuccessMsg]      = useState(null)
  const debounceRef = useRef(null)

  // Form fields
  const [name,            setName]            = useState(initialSupplier?.name || '')
  const [contactName,     setContactName]     = useState(initialSupplier?.contactName || '')
  const [primaryEmail,    setPrimaryEmail]    = useState(initialSupplier?.contact || '')
  const [additionalEmails, setAdditionalEmails] = useState(initialSupplier?.additionalEmails || [])
  const [phone,           setPhone]           = useState(initialSupplier?.phone || '')
  const [categories,      setCategories]      = useState(() => {
    if (initialSupplier?.categories?.length) return initialSupplier.categories
    if (initialSupplier?.category) return [initialSupplier.category]
    return ['Grocery']
  })
  const [subcats,         setSubcats]         = useState((initialSupplier?.subcategories || []).join(', '))
  const [region,          setRegion]          = useState(initialSupplier?.region || 'National')
  const [selectedSegs,    setSelectedSegs]    = useState(initialSupplier?.segments || [bid.segment].filter(Boolean))
  const [isBroker,        setIsBroker]        = useState(initialSupplier?.broker || false)
  const [tags,            setTags]            = useState((initialSupplier?.tags || []).join(', '))
  const [notes,           setNotes]           = useState(initialSupplier?.notes || '')

  // Web search state
  const [webResults,    setWebResults]    = useState([])
  const [webLoading,    setWebLoading]    = useState(false)
  const [webError,      setWebError]      = useState(null)
  const [webCategories, setWebCategories] = useState(bid?.primaryCategory ? [bid.primaryCategory] : ['Grocery'])
  const [webSegments,   setWebSegments]   = useState(bid?.segment ? [bid.segment] : [])
  const [webRegion,     setWebRegion]     = useState(bid?.region || 'National')
  const [webCompliance, setWebCompliance] = useState('')
  const [webKeywords,   setWebKeywords]   = useState('')

  const addAliasRow    = () => setAdditionalEmails(prev => [...prev, ''])
  const removeAlias    = (i) => setAdditionalEmails(prev => prev.filter((_, idx) => idx !== i))
  const updateAlias    = (i, val) => setAdditionalEmails(prev => prev.map((e, idx) => idx === i ? val : e))

  const handleSearch = (val) => {
    setQuery(val)
    setResults([])
    setTotal(0)
    clearTimeout(debounceRef.current)
    if (!val.trim() || val.length < 2) return
    debounceRef.current = setTimeout(async () => {
      setSearching(true)
      try {
        const res  = await fetch(`/api/suppliers/search?q=${encodeURIComponent(val)}&limit=20`)
        const data = await res.json()
        const items = Array.isArray(data) ? data : (data.results || [])
        setResults(items)
        setTotal(Array.isArray(data) ? items.length : (data.total ?? items.length))
      } catch { /* ignore */ }
      finally { setSearching(false) }
    }, 150)
  }

  const handleSelectSupplier = (supplier) => {
    setQuery(''); setResults([]); setTotal(0)
    onSelectExisting?.(supplier)
  }

  const handleWebSearch = async () => {
    setWebError(null)
    setWebResults([])
    setWebLoading(true)
    try {
      const res = await fetch('/api/web-search/suppliers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          categories: webCategories,
          segments: webSegments,
          region: webRegion,
          compliance: webCompliance,
          keywords: webKeywords,
          limit: 5,
        }),
      })
      if (res.status === 503) { setWebError('Web search is not configured on this server.'); return }
      if (!res.ok) throw new Error('Search failed')
      const data = await res.json()
      setWebResults(data.results || [])
      if ((data.results || []).length === 0) setWebError('No suppliers found. Try different keywords or category.')
    } catch (err) {
      setWebError('Search failed — please try again.')
    } finally {
      setWebLoading(false)
    }
  }

  const handleWebAddToForm = (s) => {
    setName(s.name || '')
    setPrimaryEmail(s.contactEmail || '')
    if (s.categories?.length) setCategories(s.categories)
    else if (s.category) setCategories([s.category])
    if (s.tags?.length) setTags(s.tags.join(', '))
    setNotes(s.description || '')
    if (s.segments?.length) setSelectedSegs(s.segments)
    setMode('form')
  }

  const handleWebQuickAdd = async (s) => {
    if (!s.contactEmail) return
    setSaving(true)
    try {
      const res = await fetch('/api/suppliers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: s.name,
          contact: s.contactEmail.toLowerCase(),
          categories: s.categories?.length ? s.categories : [s.category || 'Grocery'],
          category: s.categories?.[0] || s.category || 'Grocery',
          segments: s.segments || [],
          tags: s.tags || [],
          notes: s.description || '',
          region: 'National',
          broker: false,
          subcategories: [],
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || 'Save failed')
      setSuccessMsg(`✓ ${data.supplier.name} added to supplier database`)
      onAdded?.(data.supplier)
      setWebResults(prev => prev.filter(r => r.name !== s.name))
      setTimeout(() => setSuccessMsg(null), 3000)
    } catch (err) {
      setError(err.message)
    } finally {
      setSaving(false)
    }
  }

  const handleSave = async () => {
    setError(null)
    if (!name.trim())          return setError('Company name is required')
    if (!primaryEmail.trim())  return setError('Primary email is required')
    if (!primaryEmail.includes('@')) return setError('Enter a valid primary email address')
    const invalidAlias = additionalEmails.find(e => e.trim() && !e.includes('@'))
    if (invalidAlias) return setError(`Invalid alias email: ${invalidAlias}`)

    const payload = {
      name,
      contactName,
      contact:          primaryEmail.trim().toLowerCase(),
      additionalEmails: additionalEmails.map(e => e.trim().toLowerCase()).filter(Boolean),
      phone,
      categories,
      category:         categories[0] || 'Grocery',
      subcategories:    subcats.split(',').map(s => s.trim()).filter(Boolean),
      region,
      segments:         selectedSegs,
      broker:           isBroker,
      tags:             tags.split(',').map(s => s.trim()).filter(Boolean),
      notes,
    }

    setSaving(true)
    try {
      const url    = isEdit ? `/api/suppliers/${initialSupplier.id}` : '/api/suppliers'
      const method = isEdit ? 'PATCH' : 'POST'
      const res    = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(payload),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.detail || data.error || (isEdit ? 'Update failed' : 'Save failed'))

      if (isEdit) {
        setSuccessMsg(`✓ ${data.supplier.name} updated`)
        onUpdated?.(data.supplier)
        setTimeout(() => setSuccessMsg(null), 2500)
      } else {
        setSuccessMsg(`✓ ${data.supplier.name} added to supplier database`)
        onAdded?.(data.supplier)
        setName(''); setContactName(''); setPrimaryEmail(''); setAdditionalEmails([]); setPhone('')
        setCategories(['Grocery']); setSubcats(''); setRegion('National')
        setSelectedSegs([bid.segment].filter(Boolean)); setIsBroker(false)
        setTags(''); setNotes('')
        setTimeout(() => { setMode('search'); setSuccessMsg(null) }, 3000)
      }
    } catch (err) {
      setError(err.message)
    } finally {
      setSaving(false)
    }
  }

  const inputCls = 'w-full px-3 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange bg-white'
  const toggleSeg    = (s) => setSelectedSegs(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s])
  // prevent deselecting the last category — at least one must always be selected
  const toggleCat    = (c) => setCategories(prev => prev.includes(c) ? (prev.length > 1 ? prev.filter(x => x !== c) : prev) : [...prev, c])
  const toggleWebCat = (c) => setWebCategories(prev => prev.includes(c) ? (prev.length > 1 ? prev.filter(x => x !== c) : prev) : [...prev, c])
  const toggleWebSeg = (s) => setWebSegments(prev => prev.includes(s) ? prev.filter(x => x !== s) : [...prev, s])

  return (
    <div className={isEdit ? "flex flex-col h-full" : "card overflow-hidden"}>
      <div className={`flex items-center gap-3 px-5 py-4 border-b border-gray-100 bg-gray-50/60${isEdit ? ' flex-shrink-0' : ''}`}>
        <UserPlus className="w-4 h-4 text-exl-orange" />
        <h3 className="text-sm font-semibold text-gray-900">
          {isEdit ? `Edit Supplier — ${initialSupplier.name}` : 'Add Supplier to RFP'}
        </h3>
        {!isEdit && (
          <div className="ml-auto flex gap-1 bg-gray-200 rounded-lg p-0.5">
            <button
              onClick={() => { setMode('search'); setError(null) }}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${mode === 'search' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              Search Existing
            </button>
            <button
              onClick={() => { setMode('form'); setError(null) }}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${mode === 'form' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              Add New
            </button>
            <button
              onClick={() => { setMode('web'); setError(null); setWebError(null) }}
              className={`flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-md transition-colors ${mode === 'web' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
            >
              <Globe className="w-3 h-3" /> Find on Web
            </button>
          </div>
        )}
        {isEdit && (
          <button onClick={onCancelEdit} className="ml-auto text-gray-400 hover:text-gray-600 p-1 rounded-lg hover:bg-gray-100">
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      <div className={isEdit ? "px-5 py-4 flex-1 min-h-0 overflow-y-auto" : "px-5 py-4"}>
        {successMsg && (
          <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2.5 mb-4 text-sm text-emerald-700 font-medium">
            <CheckCircle className="w-4 h-4 flex-shrink-0" />
            {successMsg}
          </div>
        )}

        {mode === 'search' && !isEdit && (
          <div>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={query}
                onChange={e => handleSearch(e.target.value)}
                placeholder="Search by name, email, or category…"
                className="w-full pl-9 pr-4 py-2 text-sm border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange"
              />
              {searching && <Loader className="absolute right-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 animate-spin text-gray-400" />}
            </div>

            {results.length > 0 && (
              <div className="mt-2 border border-gray-200 rounded-xl overflow-hidden">
                {results.map(s => (
                  <div key={s.id} className="flex items-center gap-3 px-4 py-3 hover:bg-gray-50 border-b border-gray-100 last:border-0">
                    <span className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${CAT_DOTS[s.category] ?? 'bg-gray-400'}`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">{s.name}</p>
                      <p className="text-xs text-gray-500 font-mono truncate">{s.contact}</p>
                    </div>
                    <span className="text-xs text-gray-400 mr-1">{s.category}</span>
                    {s.bounce && (
                      <span className="text-xs font-bold text-red-600 bg-red-100 px-1.5 py-0.5 rounded mr-1">Bounce</span>
                    )}
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button
                        onClick={() => { onAddToList?.(s); setQuery(''); setResults([]); setTotal(0) }}
                        title="Add to matching supplier list"
                        className="p-1.5 rounded-lg hover:bg-emerald-50 text-gray-400 hover:text-emerald-600 transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleSelectSupplier(s)}
                        title="Compose solicitation email to this supplier"
                        className="p-1.5 rounded-lg hover:bg-orange-50 text-gray-400 hover:text-orange-600 transition-colors"
                      >
                        <Mail className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
                {total > results.length && (
                  <p className="text-xs text-gray-400 text-center py-2 border-t border-gray-100">
                    Showing {results.length} of {total.toLocaleString()} — refine your search
                  </p>
                )}
              </div>
            )}

            {query.length >= 2 && !searching && results.length === 0 && (
              <div className="mt-3 text-center py-6 border border-dashed border-gray-200 rounded-xl">
                <p className="text-sm text-gray-500 mb-2">No supplier found for "{query}"</p>
                <button
                  onClick={() => { setName(query); setMode('form') }}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-exl-orange hover:underline"
                >
                  <Plus className="w-3.5 h-3.5" /> Add "{query}" as new supplier
                </button>
              </div>
            )}

            {!query && (
              <p className="text-xs text-gray-400 mt-3 text-center">
                Type to search the supplier database, or{' '}
                <button onClick={() => setMode('form')} className="text-exl-orange hover:underline font-medium">
                  add a new supplier
                </button>
              </p>
            )}
          </div>
        )}

        {mode === 'web' && !isEdit && (
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1.5">
                Categories <span className="text-gray-400 font-normal">(select one or more)</span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {CATEGORIES.map(c => (
                  <button key={c} type="button" onClick={() => toggleWebCat(c)}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-full border transition-colors ${
                      webCategories.includes(c)
                        ? 'bg-exl-navy text-white border-exl-navy'
                        : 'bg-white dark:bg-[#253347] text-gray-600 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:border-exl-navy/50'
                    }`}
                  >{c}</button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1.5">
                Segments <span className="text-gray-400 font-normal">(optional)</span>
              </label>
              <div className="flex flex-wrap gap-1.5">
                {SEGMENTS.map(s => (
                  <button key={s} type="button" onClick={() => toggleWebSeg(s)}
                    className={`px-2.5 py-1 text-xs font-semibold rounded-full border transition-colors ${
                      webSegments.includes(s)
                        ? 'bg-exl-navy text-white border-exl-navy'
                        : 'bg-white dark:bg-[#253347] text-gray-600 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:border-exl-navy/50'
                    }`}
                  >{s}</button>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">Region</label>
                <select value={webRegion} onChange={e => setWebRegion(e.target.value)} className={inputCls}>
                  {REGIONS.map(r => <option key={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
                  Compliance <span className="text-gray-400 font-normal">(optional)</span>
                </label>
                <input
                  type="text"
                  value={webCompliance}
                  onChange={e => setWebCompliance(e.target.value)}
                  placeholder="e.g. Halal, CN, USDA Organic"
                  className={inputCls}
                />
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-medium text-gray-600 dark:text-gray-400 mb-1">
                  Keywords <span className="text-gray-400 font-normal">(optional)</span>
                </label>
                <input
                  type="text"
                  value={webKeywords}
                  onChange={e => setWebKeywords(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && !webLoading && handleWebSearch()}
                  placeholder="e.g. frozen entrees, local produce, distributor…"
                  className={inputCls}
                />
              </div>
            </div>

            <button
              onClick={handleWebSearch}
              disabled={webLoading}
              className="w-full flex items-center justify-center gap-2 py-2 text-sm font-semibold bg-exl-navy text-white rounded-lg hover:bg-blue-900 disabled:opacity-60 transition-colors"
            >
              {webLoading ? <Loader className="w-4 h-4 animate-spin" /> : <Globe className="w-4 h-4" />}
              {webLoading ? 'Searching the web…' : 'Search'}
            </button>

            {webError && (
              <p className="text-xs text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">{webError}</p>
            )}

            {webResults.length > 0 && (
              <div className="space-y-2">
                <p className="text-xs text-gray-500 font-medium">{webResults.length} result{webResults.length !== 1 ? 's' : ''} found</p>
                {webResults.map((s, i) => (
                  <div key={i} className="border border-gray-200 rounded-xl p-3 bg-white dark:bg-[#1E293B] dark:border-gray-700">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-gray-900 dark:text-gray-100 truncate">{s.name}</p>
                      </div>
                      <div className="flex flex-wrap gap-1 flex-shrink-0 justify-end">
                        {(s.categories?.length ? s.categories : [s.category || 'Grocery']).map(c => (
                          <span key={c} className="text-xs font-medium px-2 py-0.5 rounded-full bg-gray-100 dark:bg-[#253347] text-gray-700 dark:text-gray-300">{c}</span>
                        ))}
                      </div>
                    </div>
                    {s.tags?.length > 0 && (
                      <div className="flex flex-wrap gap-1 mb-1.5">
                        {s.tags.map(t => (
                          <span key={t} className="text-xs px-1.5 py-0.5 rounded bg-blue-50 dark:bg-blue-900/20 text-blue-700 dark:text-blue-400 border border-blue-100 dark:border-blue-800/40">{t}</span>
                        ))}
                      </div>
                    )}
                    {s.description && <p className="text-xs text-gray-500 dark:text-gray-400 mb-2 line-clamp-2">{s.description}</p>}
                    <div className="flex items-center gap-2">
                      {s.contactEmail ? (
                        <span className="flex items-center gap-1 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded px-2 py-0.5 font-mono">
                          <CheckCircle className="w-3 h-3" /> {s.contactEmail}
                        </span>
                      ) : (
                        <span className="text-xs text-gray-400 italic">Email not found</span>
                      )}
                      <div className="ml-auto flex items-center gap-1.5">
                        <button
                          onClick={() => handleWebAddToForm(s)}
                          className="text-xs px-2.5 py-1 border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-700 font-medium transition-colors"
                        >
                          Add to App
                        </button>
                        {s.contactEmail && (
                          <button
                            onClick={() => handleWebQuickAdd(s)}
                            disabled={saving}
                            className="text-xs px-2.5 py-1 bg-exl-orange text-white rounded-lg hover:bg-orange-600 font-medium transition-colors disabled:opacity-60"
                          >
                            Quick Add
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {(mode === 'form' || isEdit) && (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">
                  Company Name <span className="text-red-500">*</span>
                </label>
                <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="e.g. Tyson Foods Inc." className={inputCls} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Contact Name</label>
                <input type="text" value={contactName} onChange={e => setContactName(e.target.value)} placeholder="e.g. Jane Smith" className={inputCls} />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Phone</label>
                <input type="text" value={phone} onChange={e => setPhone(e.target.value)} placeholder="e.g. (555) 555-5555" className={inputCls} />
              </div>

              {/* ── Multi-email section ── */}
              <div className="col-span-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">
                  Primary Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  value={primaryEmail}
                  onChange={e => setPrimaryEmail(e.target.value)}
                  placeholder="e.g. bids@supplier.com"
                  className={inputCls}
                />
                {additionalEmails.map((alias, i) => (
                  <div key={i} className="flex gap-2 items-center mt-2">
                    <input
                      type="email"
                      value={alias}
                      onChange={e => updateAlias(i, e.target.value)}
                      placeholder={`Alias email ${i + 2} (e.g. jane@supplier.com)`}
                      className={`${inputCls} flex-1`}
                    />
                    <button
                      type="button"
                      onClick={() => removeAlias(i)}
                      className="flex-shrink-0 p-1.5 rounded-lg hover:bg-red-50 text-gray-400 hover:text-red-500 border border-gray-200"
                      title="Remove this email"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={addAliasRow}
                  className="mt-2 text-xs font-medium text-exl-orange hover:underline flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" /> Add another email
                </button>
              </div>

              <div className="col-span-2">
                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1.5">
                  Categories <span className="text-red-500">*</span>
                </label>
                <div className="flex flex-wrap gap-1.5">
                  {CATEGORIES.map(c => (
                    <button key={c} type="button" onClick={() => toggleCat(c)}
                      className={`px-2.5 py-1 text-xs font-semibold rounded-full border transition-colors ${
                        categories.includes(c)
                          ? 'bg-exl-navy text-white border-exl-navy'
                          : 'bg-white dark:bg-[#253347] text-gray-600 dark:text-gray-300 border-gray-300 dark:border-gray-600 hover:border-exl-navy/50'
                      }`}
                    >{c}</button>
                  ))}
                </div>
                {categories.length > 0 && (
                  <p className="text-xs text-gray-400 mt-1">Primary: <span className="font-medium text-gray-600 dark:text-gray-300">{categories[0]}</span></p>
                )}
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Region</label>
                <select value={region} onChange={e => setRegion(e.target.value)} className={inputCls}>
                  {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Subcategories <span className="font-normal text-gray-400 normal-case">(comma-separated)</span></label>
                <input type="text" value={subcats} onChange={e => setSubcats(e.target.value)} placeholder="e.g. Frozen Entrees, USDA Proteins" className={inputCls} />
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Segments</label>
                <div className="flex flex-wrap gap-1.5">
                  {SEGMENTS.map(s => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => toggleSeg(s)}
                      className={`px-2.5 py-1 text-xs font-semibold rounded-full border transition-colors ${
                        selectedSegs.includes(s)
                          ? 'bg-exl-navy text-white border-exl-navy'
                          : 'bg-white text-gray-600 border-gray-300 hover:border-exl-navy/50'
                      }`}
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Compliance Tags <span className="font-normal text-gray-400 normal-case">(comma-separated)</span></label>
                <input type="text" value={tags} onChange={e => setTags(e.target.value)} placeholder="e.g. CN, Buy American, Halal" className={inputCls} />
              </div>
              <div className="col-span-2">
                <label className="flex items-center gap-2.5 cursor-pointer">
                  <input type="checkbox" checked={isBroker} onChange={e => setIsBroker(e.target.checked)}
                    className="w-4 h-4 rounded border-gray-300 text-exl-orange focus:ring-exl-orange/30" />
                  <span className="text-sm text-gray-700 font-medium">This is a broker / food service sales rep</span>
                </label>
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">Internal Notes <span className="font-normal text-gray-400 normal-case">(optional)</span></label>
                <textarea rows={2} value={notes} onChange={e => setNotes(e.target.value)} placeholder="Any notes about this supplier…" className={`${inputCls} resize-none`} />
              </div>
            </div>

            {error && (
              <div className="flex items-center gap-2 text-xs text-red-700 bg-red-50 border border-red-200 rounded-lg px-3 py-2">
                <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" />{error}
              </div>
            )}

            {!isEdit && (
              <div className="flex gap-3 pt-1">
                <button
                  onClick={() => { setMode('search'); setError(null) }}
                  className="btn-secondary text-sm flex-shrink-0"
                >
                  Cancel
                </button>
                <Button
                  variant="primary"
                  size="md"
                  icon={saving ? undefined : CheckCircle}
                  loading={saving}
                  onClick={handleSave}
                  className="flex-1"
                >
                  {saving ? 'Saving…' : 'Add to Supplier Database'}
                </Button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Sticky footer — only in edit mode, always visible at bottom of drawer */}
      {isEdit && (
        <div className="flex gap-3 px-5 py-4 border-t border-gray-100 flex-shrink-0 bg-white dark:bg-[#1E293B]">
          <button
            onClick={onCancelEdit}
            className="btn-secondary text-sm flex-shrink-0"
          >
            Cancel
          </button>
          <Button
            variant="primary"
            size="md"
            icon={saving ? undefined : CheckCircle}
            loading={saving}
            onClick={handleSave}
            className="flex-1"
          >
            {saving ? 'Saving…' : 'Update Supplier'}
          </Button>
        </div>
      )}
    </div>
  )
}

// ── Bulk Award Notification Modal ────────────────────────
function BulkAwardModal({ bid, awardedSuppliers, onClose, onDone }) {
  const [selected,     setSelected]     = useState(() => new Set(awardedSuppliers.map(s => s.supplierId)))
  const [emailBody,    setEmailBody]    = useState(
    () => buildAwardEmailBody({ supplierName: '[Supplier Name]', customerName: bid.customer, bidId: bid.id })
  )
  const [attachments,  setAttachments]  = useState([])
  const [step,         setStep]         = useState('compose') // 'compose' | 'sending' | 'done'
  const [progress,     setProgress]     = useState([])        // [{supplierId, supplierName, state}]  state: 'pending'|'sending'|'done'|'error'
  const fileRef = useRef(null)

  const toggleAll = () => {
    if (selected.size === awardedSuppliers.length) setSelected(new Set())
    else setSelected(new Set(awardedSuppliers.map(s => s.supplierId)))
  }
  const toggle = (id) => setSelected(prev => {
    const next = new Set(prev)
    next.has(id) ? next.delete(id) : next.add(id)
    return next
  })

  const handleSend = async () => {
    const toSend = awardedSuppliers.filter(s => selected.has(s.supplierId))
    if (toSend.length === 0) return
    setProgress(toSend.map(s => ({ supplierId: s.supplierId, supplierName: s.supplierName, state: 'pending' })))
    setStep('sending')

    for (let i = 0; i < toSend.length; i++) {
      const s = toSend[i]
      setProgress(prev => prev.map(p => p.supplierId === s.supplierId ? { ...p, state: 'sending' } : p))

      try {
        const fd = new FormData()
        fd.append('supplierId', s.supplierId)
        fd.append('supplierName', s.supplierName)
        fd.append('supplierEmail', s.supplierEmail || s.emails?.[0]?.from || '')
        fd.append('to', s.supplierEmail || s.emails?.[0]?.from || '')
        fd.append('subject', buildAwardEmailSubject(bid))
        fd.append('body', emailBody.replace('[Supplier Name]', s.supplierName))
        attachments.forEach(f => fd.append('attachments', f))
        await fetch(`/api/bids/${bid.id}/send-award-email`, { method: 'POST', body: fd })
        setProgress(prev => prev.map(p => p.supplierId === s.supplierId ? { ...p, state: 'done' } : p))
      } catch {
        setProgress(prev => prev.map(p => p.supplierId === s.supplierId ? { ...p, state: 'error' } : p))
      }

      if (i < toSend.length - 1) await new Promise(r => setTimeout(r, 500))
    }

    // Persist awardNotificationSent on each supplier
    const sentIds = toSend.map(s => s.supplierId)
    try {
      await fetch(`/api/bids/${bid.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ awardNotificationSentIds: sentIds }),
      })
    } catch { /* best-effort */ }

    setStep('done')
    onDone(sentIds)
  }

  const todayLabel = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })

  return (
    <div className="fixed z-50 flex items-center justify-center" style={{ inset: 0, backgroundColor: 'rgba(0,0,0,0.5)' }}>
      <div className="bg-white dark:bg-[#1E293B] rounded-2xl shadow-2xl w-full max-w-2xl mx-4 flex flex-col max-h-[90vh]">

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 dark:border-gray-700 flex-shrink-0">
          <div className="flex items-center gap-2.5">
            <Trophy className="w-5 h-5 text-amber-500" />
            <h2 className="text-base font-bold text-gray-900 dark:text-gray-100">Send Award Notifications</h2>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="overflow-y-auto flex-1 min-h-0 px-6 py-4 space-y-5">

          {step === 'compose' && (
            <>
              {/* Supplier selection */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-semibold text-gray-700 dark:text-gray-300">Awarded Suppliers</p>
                  <button onClick={toggleAll} className="text-xs text-blue-600 dark:text-blue-400 hover:underline">
                    {selected.size === awardedSuppliers.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>
                <div className="border border-gray-200 dark:border-gray-700 rounded-xl divide-y divide-gray-100 dark:divide-gray-700 overflow-hidden">
                  {awardedSuppliers.map(s => (
                    <label key={s.supplierId} className="flex items-center gap-3 px-4 py-2.5 hover:bg-gray-50 dark:hover:bg-[#253347] cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selected.has(s.supplierId)}
                        onChange={() => toggle(s.supplierId)}
                        className="w-4 h-4 rounded accent-[#E05A2B]"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900 dark:text-gray-100 truncate">{s.supplierName}</p>
                        <p className="text-xs text-gray-500 dark:text-gray-400 truncate">{s.supplierEmail || '—'}</p>
                      </div>
                      {s.awardNotificationSent && (
                        <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium">📧 Already notified</span>
                      )}
                    </label>
                  ))}
                </div>
              </div>

              {/* Email body */}
              <div>
                <p className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Email Body</p>
                <textarea
                  value={emailBody}
                  onChange={e => setEmailBody(e.target.value)}
                  rows={8}
                  className="w-full text-sm border border-gray-200 dark:border-gray-600 rounded-xl px-3 py-2.5 resize-none focus:outline-none focus:ring-2 focus:ring-[#E05A2B]/30 focus:border-[#E05A2B] bg-white dark:bg-[#253347] dark:text-gray-200"
                />
              </div>

              {/* Attachments */}
              <div>
                <p className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-1.5">Attachments (shared for all suppliers)</p>
                {attachments.length > 0 && (
                  <ul className="mb-2 space-y-1">
                    {attachments.map((f, i) => (
                      <li key={i} className="flex items-center gap-2 text-xs bg-gray-50 dark:bg-[#253347] border border-gray-200 dark:border-gray-600 rounded-lg px-3 py-1.5">
                        <Paperclip className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
                        <span className="flex-1 truncate text-gray-700 dark:text-gray-300">{f.name}</span>
                        <button onClick={() => setAttachments(a => a.filter((_, j) => j !== i))} className="text-gray-400 hover:text-red-500">
                          <X className="w-3.5 h-3.5" />
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
                <button
                  onClick={() => fileRef.current?.click()}
                  className="flex items-center gap-1.5 text-xs font-medium text-gray-500 dark:text-gray-400 border border-dashed border-gray-300 dark:border-gray-600 rounded-lg px-3 py-2 hover:border-[#E05A2B] hover:text-[#E05A2B] transition-colors"
                >
                  <Paperclip className="w-3.5 h-3.5" /> Attach file
                </button>
                <input ref={fileRef} type="file" multiple className="hidden" onChange={e => {
                  setAttachments(a => [...a, ...Array.from(e.target.files)])
                  e.target.value = ''
                }} />
              </div>
            </>
          )}

          {step === 'sending' && (
            <div className="space-y-2">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">Sending notifications…</p>
              {progress.map(p => (
                <div key={p.supplierId} className="flex items-center gap-3 px-4 py-2.5 border border-gray-100 dark:border-gray-700 rounded-xl">
                  {p.state === 'done'    && <CheckCircle className="w-4 h-4 text-emerald-500 flex-shrink-0" />}
                  {p.state === 'sending' && <Loader2 className="w-4 h-4 text-blue-500 animate-spin flex-shrink-0" />}
                  {p.state === 'pending' && <span className="w-4 h-4 rounded-full border-2 border-gray-300 dark:border-gray-600 flex-shrink-0" />}
                  {p.state === 'error'   && <AlertTriangle className="w-4 h-4 text-red-500 flex-shrink-0" />}
                  <span className="text-sm text-gray-700 dark:text-gray-300">{p.supplierName}</span>
                </div>
              ))}
            </div>
          )}

          {step === 'done' && (
            <div className="text-center py-6">
              <div className="w-14 h-14 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center mx-auto mb-3">
                <Trophy className="w-7 h-7 text-emerald-600 dark:text-emerald-400" />
              </div>
              <p className="text-base font-bold text-gray-900 dark:text-gray-100 mb-1">Notifications Sent!</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                Award notifications sent to {progress.filter(p => p.state === 'done').length} supplier(s).
              </p>
              {progress.some(p => p.state === 'error') && (
                <p className="text-xs text-red-500 mt-1">
                  {progress.filter(p => p.state === 'error').length} failed — check SMTP config.
                </p>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="flex items-center justify-between px-6 py-4 border-t border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-[#253347] rounded-b-2xl flex-shrink-0">
          {step === 'compose' && (
            <>
              <span className="text-xs text-gray-500">{selected.size} supplier{selected.size !== 1 ? 's' : ''} selected</span>
              <div className="flex items-center gap-2">
                <button onClick={onClose} className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900 rounded-lg hover:bg-gray-200 transition-colors">Cancel</button>
                <button
                  onClick={handleSend}
                  disabled={selected.size === 0}
                  className="flex items-center gap-2 px-5 py-2 text-sm font-semibold text-white rounded-xl transition-colors disabled:opacity-40"
                  style={{ backgroundColor: '#E05A2B' }}
                >
                  <Trophy className="w-4 h-4" />
                  Send to {selected.size} Supplier{selected.size !== 1 ? 's' : ''}
                </button>
              </div>
            </>
          )}
          {step === 'sending' && (
            <span className="text-xs text-gray-500 mx-auto">Please wait…</span>
          )}
          {step === 'done' && (
            <button
              onClick={onClose}
              className="mx-auto px-6 py-2 text-sm font-semibold text-white rounded-xl"
              style={{ backgroundColor: '#1F3864' }}
            >
              Close
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

// ── Main SuppliersTab ─────────────────────────────────────
export default function SuppliersTab({ bid, latestEvent, onCompose, onSwitchToEmail }) {
  // Pre-solicitation matching state
  const [matched,         setMatched]         = useState(null)
  const [loadingMatch,    setLoadingMatch]     = useState(false)
  const [loadingMsg,      setLoadingMsg]       = useState('')
  const [matchError,      setMatchError]       = useState(null)
  const [checked,         setChecked]          = useState({})

  // Post-solicitation state
  const [solicitedData,   setSolicitedData]    = useState(null)   // { solicitation, suppliers[] }
  const [loadingSolicited,setLoadingSolicited] = useState(true)
  // PORTAL-DEMO: portal state vars
  const [portalSubs,   setPortalSubs]   = useState([])
  const [reminderCtx,  setReminderCtx]  = useState(null)
  const [resolicitCtx, setResolicitCtx] = useState(null)
  const [toast,           setToast]            = useState(null)

  // Bulk award notification state
  const [showBulkAward,   setShowBulkAward]   = useState(false)
  const [awardNotifiedIds, setAwardNotifiedIds] = useState(new Set())

  // Edit supplier state
  const [editingSupplier,  setEditingSupplier]  = useState(null)
  const supplierCacheRef = useRef({})  // per-session cache: { [supplierId]: fullSupplierObj }
  const [showMoreSuppliers, setShowMoreSuppliers] = useState(false)

  // PORTAL-TEMPLATE-START
  const [showTemplatePanel,    setShowTemplatePanel]    = useState(false)
  const [templates,            setTemplates]            = useState([])
  const [selectedTemplateId,   setSelectedTemplateId]   = useState(bid.portalConfig?.templateId || '')
  const [customFields,         setCustomFields]         = useState(bid.portalConfig?.customFields || [])
  const [addingField,          setAddingField]          = useState(false)
  const [newField,             setNewField]             = useState({ label: '', type: 'text', required: false })

  useEffect(() => {
    fetch('/api/bids/portal-templates')
      .then(r => {
        if (!r.ok) throw new Error('Failed')
        return r.json()
      })
      .then(data => setTemplates(Array.isArray(data) ? data : []))
      .catch(err => {
        console.error('Templates fetch error:', err)
        setTemplates([])
      })
  }, [])
  // PORTAL-TEMPLATE-END

  const hasSolicitation = !!solicitedData?.solicitation

  // Fetch solicitation/response data on mount
  // PORTAL-DEMO: parallel fetch — email + portal submissions
  const fetchSolicited = async () => {
    try {
      const [emailRes, portalRes] = await Promise.all([
        fetch(`/api/bids/${bid.id}/emails/by-supplier`),
        fetch(`/api/submit/${bid.id}/submissions`),
      ])
      const emailData  = await emailRes.json()
      const portalData = portalRes.ok ? await portalRes.json() : []
      setSolicitedData(emailData)
      setPortalSubs(Array.isArray(portalData) ? portalData : [])
    } catch { /* ignore */ }
    finally { setLoadingSolicited(false) }
  }

  useEffect(() => { fetchSolicited() }, [bid.id])

  // Refresh every 30 s and on window focus so supplier counts stay current
  useEffect(() => {
    const id = setInterval(fetchSolicited, 30_000)
    window.addEventListener('focus', fetchSolicited)
    return () => {
      clearInterval(id)
      window.removeEventListener('focus', fetchSolicited)
    }
  }, [bid.id])

  // ── Real-time: immediate refresh when another user changes a supplier status ──
  useEffect(() => {
    if (!latestEvent) return
    if (latestEvent.type === 'supplier_updated') {
      fetchSolicited()
    }
  }, [latestEvent])  // eslint-disable-line react-hooks/exhaustive-deps

  // Auto-dismiss toast after 3.5 s
  useEffect(() => {
    if (!toast) return
    const id = setTimeout(() => setToast(null), 3500)
    return () => clearTimeout(id)
  }, [toast])

  // ── Pre-solicitation handlers ──
  const handleFind = async () => {
    setLoadingMatch(true)
    setMatchError(null)
    setLoadingMsg('🤖 Running AI supplier matching...')
    const msgTimer = setTimeout(() => setLoadingMsg('⚡ Scoring by category, compliance & segment...'), 600)
    try {
      const [res] = await Promise.all([
        fetch('/api/suppliers/auto-populate', {
          method:  'POST',
          headers: { 'Content-Type': 'application/json' },
          body:    JSON.stringify({
            itemCategories: bid.itemCategories,
            segment:        bid.segment,
            complianceFlags: bid.complianceFlags || [],
          }),
        }),
        new Promise(r => setTimeout(r, 1200)), // minimum 1200ms
      ])
      const data = await res.json()
      const suppliers = data.matched || []
      setMatched(suppliers)
      const initChecked = {}
      suppliers.forEach(s => {
        // Auto-check strongly relevant suppliers (score >= 45); others visible but unchecked
        initChecked[s.id] = !s.bounce && (s.matchScore == null || s.matchScore >= 45)
      })
      setChecked(initChecked)
    } catch (err) {
      setMatchError(err.message)
    } finally {
      clearTimeout(msgTimer)
      setLoadingMatch(false)
      setLoadingMsg('')
    }
  }

  const handleToggle = (id) => setChecked(prev => ({ ...prev, [id]: !prev[id] }))

  const grouped = useMemo(() => {
    if (!matched) return {}
    const map = {}
    matched.forEach(s => {
      if (!map[s.category]) map[s.category] = []
      map[s.category].push(s)
    })
    return map
  }, [matched])

  const selectedSuppliers = matched ? matched.filter(s => !s.bounce && checked[s.id]) : []
  const selectedCount     = selectedSuppliers.length
  const categoryCount     = Object.keys(grouped).length

  // Save selected IDs to bid before composing (FIX 4 — pendingSuppliers)
  const handleCompose = async () => {
    try {
      await fetch(`/api/bids/${bid.id}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ pendingSupplierIds: selectedSuppliers.map(s => s.id) }),
      })
    } catch { /* best-effort */ }
    onCompose(selectedSuppliers)
  }

  // ── Post-solicitation handlers ──
  const awaitingSuppliers = (solicitedData?.suppliers ?? []).filter(s => s.status === 'Awaiting')

  const handleResolicitAwaiting = () => {
    if (awaitingSuppliers.length === 0) return
    const fakeSuppliers = awaitingSuppliers.map(s => ({
      id:      s.supplierId,
      name:    s.supplierName,
      contact: s.supplierEmail,
    }))
    onCompose(fakeSuppliers)
  }

  const handleViewThread = (supplier) => {
    // Switch to Email Repo tab — parent handles navigation
    onSwitchToEmail?.()
  }

  const handleStatusChange = async (supplierId, newStatus) => {
    // Optimistically update local state so stat cards recalculate immediately
    setSolicitedData(prev => ({
      ...prev,
      suppliers: (prev.suppliers || []).map(s =>
        s.supplierId === supplierId
          ? { ...s, status: newStatus, lastActivity: new Date().toISOString().split('T')[0] }
          : s
      ),
    }))
    setToast(`Status updated to ${newStatus}`)
    // Persist to backend then confirm from server
    try {
      await fetch(`/api/bids/${bid.id}/suppliers/${supplierId}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ status: newStatus }),
      })
      await fetchSolicited()
    } catch { /* best-effort — UI already updated */ }
  }

  const handleSupplierAdded = (newSupplier) => {
    setToast(`✓ ${newSupplier.name} added to supplier database`)
    setTimeout(() => setToast(null), 4000)
    fetchSolicited()
  }

  const handleAddToList = (supplier) => {
    setMatched(prev => {
      const current = prev || []
      if (current.find(s => s.id === supplier.id)) return current
      return [...current, { ...supplier, score: supplier.score ?? 50, matchReasons: supplier.matchReasons ?? [] }]
    })
    setChecked(prev => ({ ...prev, [supplier.id]: true }))
    setShowMoreSuppliers(true)  // expand section so user sees the addition
  }

  const handleEditSolicited = async (solicitedEntry) => {
    const id = solicitedEntry.supplierId
    if (supplierCacheRef.current[id]) {
      setEditingSupplier(supplierCacheRef.current[id])
      return
    }
    try {
      const res = await fetch(`/api/suppliers/${id}`)
      if (!res.ok) throw new Error()
      const data = await res.json()
      supplierCacheRef.current[id] = data
      setEditingSupplier(data)
    } catch {
      // Fallback to partial data from the solicited entry
      setEditingSupplier({
        id: solicitedEntry.supplierId,
        name: solicitedEntry.supplierName,
        contact: solicitedEntry.supplierEmail || solicitedEntry.email || '',
        additionalEmails: solicitedEntry.additionalEmails || [],
      })
    }
  }

  const handleSupplierUpdated = (updatedSupplier) => {
    supplierCacheRef.current[updatedSupplier.id] = updatedSupplier  // refresh cache
    if (matched) {
      setMatched(prev => prev.map(s => s.id === updatedSupplier.id ? { ...s, ...updatedSupplier } : s))
    }
    setEditingSupplier(null)
    setToast(`✓ ${updatedSupplier.name} updated`)
    setTimeout(() => setToast(null), 3500)
  }

  const handleSupplierDeleted = async (supplierId) => {
    try {
      const res = await fetch(`/api/suppliers/${supplierId}`, { method: 'DELETE' })
      if (!res.ok) {
        const d = await res.json().catch(() => ({}))
        setToast(`Delete failed: ${d.detail || res.statusText}`)
        return
      }
    } catch {
      setToast('Delete failed — network error')
      return
    }
    if (matched) {
      setMatched(prev => prev.filter(s => s.id !== supplierId))
      setChecked(prev => { const next = { ...prev }; delete next[supplierId]; return next })
    }
    setToast('Supplier removed')
    setTimeout(() => setToast(null), 3000)
  }

  // PORTAL-DEMO: reminder / resolicit handlers
  const handleReminderSent = (msg, supplierId) => {
    setReminderCtx(null)
    setToast(msg)
    if (supplierId) handleStatusChange(supplierId, 'Follow-up Sent')
    fetchSolicited()
  }
  const handleResolicitSent = (msg, supplierId) => {
    setResolicitCtx(null)
    setToast(msg)
    if (supplierId) handleStatusChange(supplierId, 'Follow-up Sent')
    fetchSolicited()
  }

  // ── Loading ──
  if (loadingSolicited) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader className="w-5 h-5 animate-spin text-exl-orange mr-3" />
        <span className="text-sm text-gray-500">Loading supplier data…</span>
      </div>
    )
  }

  // ─────────────────────────────────────────────────────────
  // POST-SOLICITATION VIEW
  // ─────────────────────────────────────────────────────────
  if (hasSolicitation) {
    const suppliers = solicitedData.suppliers
    const statusOrder = { Awarded: 1, Complete: 1, 'Under Consideration': 2, Responded: 3, 'Follow-up Sent': 4, 'Issues Found': 5, Awaiting: 6, Contacted: 7 }
    const sorted = [...suppliers].sort((a, b) => (statusOrder[a.status] ?? 5) - (statusOrder[b.status] ?? 5))

    const responded      = suppliers.filter(s => s.status === 'Responded' || s.status === 'Under Consideration' || s.status === 'Awarded' || s.status === 'Complete' || s.status === 'Follow-up Sent').length
    const issues         = suppliers.filter(s => s.status === 'Issues Found' || s.status === 'Issues' || s.hasIssues === true).length
    const awaiting       = suppliers.filter(s => !s.status || s.status === 'Awaiting' || s.status === 'Pending' || s.status === 'Solicited' || s.status === 'Contacted').length
    const awardedSuppliers        = suppliers.filter(s => s.status === 'Awarded' || s.status === 'Complete')
    const pendingAwardNotifications = awardedSuppliers.filter(s => !s.awardNotificationSent)

    // "Find More" section — filter out already-solicited suppliers from match results
    const solicitedIds = new Set(suppliers.map(s => s.supplierId))
    const filteredMatched = (matched || []).filter(s => !solicitedIds.has(s.id))
    const groupedFiltered = filteredMatched.reduce((acc, s) => {
      if (!acc[s.category]) acc[s.category] = []
      acc[s.category].push(s)
      return acc
    }, {})
    const selectedFromFiltered = filteredMatched.filter(s => !s.bounce && checked[s.id])

    return (
      <div className="space-y-6">
        {/* ── Section 1: Solicited Suppliers ── */}
        <div>
          {/* PORTAL-DEMO: portal URL chip additive */}
          <div className="mb-3">
            <PortalUrlChip bidId={bid.id} />
          </div>

          <div className="flex items-center justify-between mb-3">
            <div>
              <h2 className="text-base font-semibold text-gray-900">Solicited Suppliers</h2>
              <p className="text-xs text-gray-500 mt-0.5">
                Solicitation sent to {suppliers.length} supplier{suppliers.length !== 1 ? 's' : ''}
                {solicitedData.solicitation?.date
                  ? ` on ${new Date(solicitedData.solicitation.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`
                  : ''
                }
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={fetchSolicited}
                className="text-gray-400 hover:text-gray-600 p-1.5 rounded-lg hover:bg-gray-100"
                title="Refresh"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
              {pendingAwardNotifications.length > 0 && (
                <button
                  onClick={() => setShowBulkAward(true)}
                  className="flex items-center gap-2 text-sm font-semibold px-4 py-2 rounded-xl text-white transition-colors"
                  style={{ backgroundColor: '#16a34a' }}
                >
                  <Trophy className="w-4 h-4" />
                  Send Award Notifications ({pendingAwardNotifications.length})
                </button>
              )}
              {awaitingSuppliers.length > 0 && (
                <button
                  onClick={handleResolicitAwaiting}
                  className="btn-primary flex items-center gap-2 text-sm"
                >
                  <Send className="w-4 h-4" />
                  Re-solicit Awaiting ({awaitingSuppliers.length})
                </button>
              )}
            </div>
          </div>

          {/* PORTAL-TEMPLATE-START — portal config banner */}
          {!bid.portalConfig?.templateId ? (
            <div className="mb-4 p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Info size={15} className="text-blue-500 flex-shrink-0" />
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  Configure the supplier portal form before sending solicitations to collect the right information.
                </p>
              </div>
              <button
                onClick={() => setShowTemplatePanel(true)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-medium hover:bg-blue-700 whitespace-nowrap ml-3"
              >
                <Settings size={12} />
                Configure Now
              </button>
            </div>
          ) : (
            <div className="mb-4 p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle size={15} className="text-green-500 flex-shrink-0" />
                <p className="text-sm text-green-700 dark:text-green-300">
                  Portal form configured: <strong className="ml-1">{(templates || []).find(t => t.id === bid.portalConfig.templateId)?.name || bid.portalConfig.templateId}</strong>
                  <span className="text-green-500 ml-1">· {bid.portalConfig.customFields?.length || 0} custom fields</span>
                </p>
              </div>
              <button
                onClick={() => {
                  setSelectedTemplateId(bid.portalConfig?.templateId || '')
                  setCustomFields(bid.portalConfig?.customFields || [])
                  setShowTemplatePanel(true)
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 border border-green-300 dark:border-green-700 text-green-700 dark:text-green-300 rounded-lg text-xs font-medium hover:bg-green-100 whitespace-nowrap ml-3"
              >
                <Settings size={12} />
                Edit
              </button>
            </div>
          )}
          {/* PORTAL-TEMPLATE-END */}

          {/* Stats row */}
          <div className="grid grid-cols-3 gap-3 mb-4">
            {[
              { label: 'Responded',  count: responded, bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500' },
              { label: 'Issues',     count: issues,    bg: 'bg-amber-50',   text: 'text-amber-700',   dot: 'bg-amber-500'   },
              { label: 'Awaiting',   count: awaiting,  bg: 'bg-gray-50',    text: 'text-gray-600',    dot: 'bg-gray-400'    },
            ].map(s => (
              <div key={s.label} className={`${s.bg} border border-gray-200 rounded-xl px-4 py-3 flex items-center gap-3`}>
                <span className={`w-2.5 h-2.5 rounded-full ${s.dot}`} />
                <div>
                  <p className={`text-xl font-bold ${s.text}`}>{s.count}</p>
                  <p className="text-xs text-gray-500">{s.label}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Supplier table */}
          <div className="card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="sticky top-0 z-10">
                <tr className="bg-[#1F3864] text-white">
                  <th className="px-4 py-2.5 text-left text-xs font-semibold">Supplier</th>
                  {/* PORTAL-DEMO: channel column header additive */}
                  <th className="px-4 py-2.5 text-left text-xs font-semibold">Channel</th>
                  <th className="px-4 py-2.5 text-left text-xs font-semibold">
                    Status
                    <span className="ml-1 text-[10px] font-normal opacity-60" title="Updated automatically from Email Repository">· from Email Repo</span>
                  </th>
                  <th className="px-4 py-2.5 text-left text-xs font-semibold">Emails</th>
                  <th className="px-4 py-2.5 text-left text-xs font-semibold">Last Activity</th>
                  <th className="px-4 py-2.5 text-left text-xs font-semibold"></th>
                </tr>
              </thead>
              <tbody>
                {sorted.map(s => {
                  // PORTAL-DEMO: portalSub lookup
                  const portalSub = portalSubs.find(
                    p => p.supplierEmail?.toLowerCase() === s.supplierEmail?.toLowerCase()
                  ) ?? null
                  const todayLabel = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
                  const wasNotified = awardNotifiedIds.has(s.supplierId) || s.awardNotificationSent
                  return (
                  <SolicitedSupplierRow
                    key={s.supplierId}
                    supplier={s}
                    portalSub={portalSub}
                    bid={bid}
                    onSendReminder={setReminderCtx}
                    onResolicit={setResolicitCtx}
                    onSwitchToEmail={onSwitchToEmail}
                    awardNotifDate={wasNotified ? (s.awardNotificationSentAt ? new Date(s.awardNotificationSentAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) : todayLabel) : null}
                    onEditSupplier={handleEditSolicited}
                    onDeleteSupplier={handleSupplierDeleted}
                  />
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* ── Section 2: Find More Suppliers ── */}
        <div className="mt-2">
          <button
            onClick={() => setShowMoreSuppliers(v => !v)}
            className="flex items-center gap-2 text-sm font-semibold text-gray-700 hover:text-gray-900 mb-3"
          >
            <UserPlus className="w-4 h-4 text-[#E05A2B]" />
            Find More Suppliers
            {showMoreSuppliers
              ? <ChevronUp className="w-4 h-4 text-gray-400" />
              : <ChevronDown className="w-4 h-4 text-gray-400" />
            }
          </button>

          {showMoreSuppliers && (
            <div className="space-y-4">
              {/* Auto-populate */}
              <Button
                variant="primary"
                size="md"
                icon={loadingMatch ? undefined : Users}
                loading={loadingMatch}
                onClick={handleFind}
              >
                {loadingMatch ? (loadingMsg || 'Finding matches…') : 'Find Matching Suppliers'}
              </Button>
              {loadingMatch && loadingMsg && (
                <p className="text-xs text-gray-500 animate-pulse">{loadingMsg}</p>
              )}

              {/* Filtered match results */}
              {filteredMatched.length > 0 && (
                <div className="space-y-3">
                  <p className="text-xs text-gray-500">
                    {filteredMatched.length} match{filteredMatched.length !== 1 ? 'es' : ''} found — suppliers already contacted are hidden
                  </p>
                  {Object.entries(groupedFiltered).map(([cat, catSuppliers]) => (
                    <CategorySection
                      key={cat}
                      category={cat}
                      suppliers={catSuppliers}
                      checked={checked}
                      onToggle={handleToggle}
                      onEditSupplier={setEditingSupplier}
                      onDeleteSupplier={handleSupplierDeleted}
                    />
                  ))}
                  {selectedFromFiltered.length > 0 && (
                    <div className="flex items-center gap-3 pt-1">
                      <Button
                        variant="primary"
                        size="md"
                        icon={Mail}
                        onClick={() => onCompose(selectedFromFiltered)}
                      >
                        Prepare Solicitation Email ({selectedFromFiltered.length})
                      </Button>
                      <button onClick={() => setChecked({})} className="text-xs text-gray-500 hover:text-gray-700">
                        Clear selection
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* Search / Add new */}
              <AddSupplierPanel
                bid={bid}
                onAdded={handleSupplierAdded}
                onSelectExisting={(s) => onCompose([s])}
                onAddToList={handleAddToList}
              />
            </div>
          )}
        </div>

        {/* PORTAL-DEMO: reminder / resolicit modals */}
        {reminderCtx && (
          <ReminderModal bid={bid} supplier={reminderCtx}
            onClose={() => setReminderCtx(null)} onSent={handleReminderSent} />
        )}
        {resolicitCtx && (
          <ResolicitModal bid={bid} supplier={resolicitCtx}
            onClose={() => setResolicitCtx(null)} onSent={handleResolicitSent} />
        )}

        {/* Bulk award notification modal */}
        {showBulkAward && (
          <BulkAwardModal
            bid={bid}
            awardedSuppliers={awardedSuppliers}
            onClose={() => setShowBulkAward(false)}
            onDone={(sentIds) => {
              setAwardNotifiedIds(prev => new Set([...prev, ...sentIds]))
              setShowBulkAward(false)
              const todayLabel = new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
              setToast(`📧 Award notifications sent to ${sentIds.length} supplier${sentIds.length !== 1 ? 's' : ''}`)
            }}
          />
        )}

        {/* ── Toast ── */}
        {toast && (
          <div className="fixed top-5 right-6 z-50 bg-emerald-700 text-white text-sm font-semibold px-5 py-3 rounded-xl shadow-xl flex items-center gap-2.5">
            <CheckCircle className="w-4 h-4 flex-shrink-0" />{toast}
          </div>
        )}

        {/* Edit Supplier Drawer */}
        {editingSupplier && createPortal(
          <>
            <div className="fixed inset-0 bg-black/20 z-40" onClick={() => setEditingSupplier(null)} />
            <div className="fixed right-0 top-0 h-full w-[520px] bg-white dark:bg-[#1E293B] shadow-2xl z-50 flex flex-col overflow-hidden">
              <AddSupplierPanel
                key={editingSupplier.id}
                bid={bid}
                editMode
                initialSupplier={editingSupplier}
                onUpdated={handleSupplierUpdated}
                onCancelEdit={() => setEditingSupplier(null)}
              />
            </div>
          </>,
          document.body
        )}

        {/* PORTAL-TEMPLATE-START */}
        {showTemplatePanel && createPortal(
          <>
            <div
              className="fixed inset-0 bg-black/20 z-40"
              onClick={() => setShowTemplatePanel(false)}
            />
            <div className="fixed right-0 top-0 h-full w-96 bg-white dark:bg-[#1E293B] shadow-2xl z-50 flex flex-col">
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-white">Configure Portal Form</h3>
                  <p className="text-xs text-gray-500 mt-0.5">{bid.customer} · {bid.id}</p>
                </div>
                <button onClick={() => setShowTemplatePanel(false)}>
                  <X size={18} className="text-gray-400" />
                </button>
              </div>

              {/* Scrollable content */}
              <div className="flex-1 min-h-0 overflow-y-auto p-4">
                {/* Template selector */}
                <div className="mb-5">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider block mb-2">
                    Load Template
                  </label>
                  <select
                    value={selectedTemplateId}
                    onChange={(e) => {
                      const tmpl = templates.find(t => t.id === e.target.value)
                      setSelectedTemplateId(e.target.value)
                      if (tmpl) setCustomFields([...tmpl.customFields])
                    }}
                    className="w-full border border-gray-200 dark:border-gray-600 rounded-lg px-3 py-2 text-sm dark:bg-[#0F172A] dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-[#E05A2B]"
                  >
                    <option value="">— Select a template —</option>
                    {(templates || []).map(t => (
                      <option key={t.id} value={t.id}>{t.name} — {t.description}</option>
                    ))}
                  </select>
                </div>

                {/* Fields list */}
                <div className="mb-4">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider block mb-2">
                    Portal Form Fields
                  </label>

                  {/* Standard fields */}
                  <div className="mb-3">
                    <p className="text-xs text-gray-400 italic mb-2">Standard fields (always included):</p>
                    {['FOB $/cs', 'Delivered $/cs ★', 'Allowance $', 'PTV $', 'Dev Type', 'No Bid', 'Notes'].map(f => (
                      <div key={f} className="flex items-center gap-2 py-1.5 px-2 rounded text-sm text-gray-500 dark:text-gray-400">
                        <CheckCircle size={13} className="text-gray-300 flex-shrink-0" />
                        {f}
                      </div>
                    ))}
                  </div>

                  {/* Custom fields */}
                  {customFields.length > 0 && (
                    <div>
                      <p className="text-xs text-gray-400 italic mb-2">Custom fields ({customFields.length} added):</p>
                      {customFields.map((field, idx) => (
                        <div key={field.id || idx} className="flex items-center gap-2 py-2 px-2 rounded-lg bg-orange-50 dark:bg-orange-900/20 mb-1.5 group">
                          <GripVertical size={13} className="text-gray-300 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-700 dark:text-gray-300 truncate">{field.label}</p>
                            <p className="text-xs text-gray-400 capitalize">{field.type.replace('_', '/')} {field.required ? '· Required' : ''}</p>
                          </div>
                          <button
                            onClick={() => setCustomFields(prev => prev.filter((_, i) => i !== idx))}
                            className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-red-500 transition-all"
                          >
                            <X size={13} />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {customFields.length === 0 && !addingField && (
                    <p className="text-xs text-gray-400 italic py-2">No custom fields added yet.</p>
                  )}
                </div>

                {/* Add custom field */}
                {addingField ? (
                  <div className="border border-orange-200 dark:border-orange-800 rounded-lg p-3 mb-4 bg-orange-50 dark:bg-orange-900/20">
                    <p className="text-xs font-semibold text-gray-600 dark:text-gray-400 mb-2">New Custom Field</p>
                    <input
                      placeholder="Field label (e.g. Halal Certified?)"
                      value={newField.label}
                      onChange={e => setNewField(p => ({ ...p, label: e.target.value }))}
                      className="w-full border border-gray-200 dark:border-gray-600 rounded-lg px-3 py-1.5 text-sm dark:bg-[#0F172A] dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-[#E05A2B] mb-2"
                    />
                    <select
                      value={newField.type}
                      onChange={e => setNewField(p => ({ ...p, type: e.target.value }))}
                      className="w-full border border-gray-200 dark:border-gray-600 rounded-lg px-3 py-1.5 text-sm dark:bg-[#0F172A] dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-[#E05A2B] mb-2"
                    >
                      <option value="text">Text</option>
                      <option value="number">Number</option>
                      <option value="yes_no">Yes / No</option>
                      <option value="dropdown">Dropdown</option>
                      <option value="date">Date</option>
                    </select>
                    <label className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400 mb-3">
                      <input type="checkbox" checked={newField.required} onChange={e => setNewField(p => ({ ...p, required: e.target.checked }))} />
                      Required field
                    </label>
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          if (!newField.label.trim()) return
                          setCustomFields(prev => [...prev, {
                            id: newField.label.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, ''),
                            label: newField.label,
                            type: newField.type,
                            required: newField.required,
                            showInWorkingFile: true,
                            columnWidth: 100,
                          }])
                          setNewField({ label: '', type: 'text', required: false })
                          setAddingField(false)
                        }}
                        className="flex-1 px-3 py-1.5 bg-[#E05A2B] text-white rounded-lg text-xs font-medium hover:bg-[#C44E22]"
                      >
                        Add Field
                      </button>
                      <button
                        onClick={() => { setAddingField(false); setNewField({ label: '', type: 'text', required: false }) }}
                        className="px-3 py-1.5 border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 rounded-lg text-xs"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setAddingField(true)}
                    className="w-full flex items-center justify-center gap-2 px-3 py-2 border border-dashed border-gray-300 dark:border-gray-600 text-gray-500 dark:text-gray-400 rounded-lg text-sm hover:border-[#E05A2B] hover:text-[#E05A2B] transition-colors mb-4"
                  >
                    <Plus size={14} />
                    Add Custom Field
                  </button>
                )}
              </div>

              {/* Footer */}
              <div className="p-4 border-t border-gray-200 dark:border-gray-700">
                <button
                  onClick={async () => {
                    try {
                      await fetch(`/api/bids/${bid.id}/portal-config`, {
                        method: 'PATCH',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ templateId: selectedTemplateId, customFields }),
                      })
                      setShowTemplatePanel(false)
                      setToast(`✅ Portal form configured — ${customFields.length} custom field${customFields.length !== 1 ? 's' : ''} added`)
                    } catch {
                      setToast('❌ Failed to save config')
                    }
                  }}
                  className="w-full px-4 py-2.5 bg-[#E05A2B] text-white rounded-lg font-medium text-sm hover:bg-[#C44E22] transition-colors"
                >
                  Apply to RFP
                </button>
                <p className="text-xs text-gray-400 text-center mt-2">
                  Suppliers will see these fields when they open the portal
                </p>
              </div>
            </div>
          </>,
          document.body
        )}
        {/* PORTAL-TEMPLATE-END */}
      </div>
    )
  }

  // ─────────────────────────────────────────────────────────
  // PRE-SOLICITATION VIEW
  // ─────────────────────────────────────────────────────────
  return (
    <div className="space-y-6 min-h-[300px]">
      {/* PORTAL-TEMPLATE-START — portal config banner */}
      {!bid.portalConfig?.templateId ? (
        <div className="p-3 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Info size={15} className="text-blue-500 flex-shrink-0" />
            <p className="text-sm text-blue-700 dark:text-blue-300">
              Configure the supplier portal form before sending solicitations to collect the right information.
            </p>
          </div>
          <button
            onClick={() => setShowTemplatePanel(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 text-white rounded-lg text-xs font-medium hover:bg-blue-700 whitespace-nowrap ml-3"
          >
            <Settings size={12} />
            Configure Now
          </button>
        </div>
      ) : (
        <div className="p-3 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle size={15} className="text-green-500 flex-shrink-0" />
            <p className="text-sm text-green-700 dark:text-green-300">
              Portal form configured: <strong className="ml-1">{(templates || []).find(t => t.id === bid.portalConfig.templateId)?.name || bid.portalConfig.templateId}</strong>
              <span className="text-green-500 ml-1">· {bid.portalConfig.customFields?.length || 0} custom fields</span>
            </p>
          </div>
          <button
            onClick={() => setShowTemplatePanel(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 border border-green-300 dark:border-green-700 text-green-700 dark:text-green-300 rounded-lg text-xs font-medium hover:bg-green-100 whitespace-nowrap ml-3"
          >
            <Settings size={12} />
            Edit
          </button>
        </div>
      )}
      {/* PORTAL-TEMPLATE-END */}
      <div>
        {/* ── Top action bar ── */}
        <div className="flex items-center justify-between mb-5">
          <div>
            <h2 className="text-base font-semibold text-gray-900">Supplier Matching</h2>
            <p className="text-xs text-gray-500 mt-0.5">
              Auto-match suppliers based on RFP categories and segment
            </p>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Button
              variant="primary"
              size="md"
              icon={loadingMatch ? undefined : Users}
              loading={loadingMatch}
              onClick={handleFind}
            >
              {loadingMatch ? 'Finding suppliers…' : 'Find Matching Suppliers'}
            </Button>
            {loadingMatch && loadingMsg && (
              <p className="text-xs text-gray-500 animate-pulse">{loadingMsg}</p>
            )}
          </div>
        </div>

        {matchError && (
          <div className="bg-red-50 border border-red-200 rounded-xl px-4 py-3 text-sm text-red-700 mb-4">
            {matchError}
          </div>
        )}

        {!matched && !loadingMatch && (
          <div className="card">
            <EmptyState
              icon={Users}
              title="No suppliers added"
              description={`Search and add suppliers to solicit pricing. You can add multiple suppliers and send solicitation emails to all of them at once.${bid.itemCategories?.length ? ` Categories needed: ${bid.itemCategories.join(', ')}.` : ''}`}
              action={{ label: 'Find Matching Suppliers', icon: UserPlus, onClick: handleFind }}
              size="lg"
            />
          </div>
        )}

        {matched && (
          <>
            <div className="flex items-center justify-between bg-exl-navy/5 border border-exl-navy/10 rounded-xl px-4 py-3 mb-4">
              <p className="text-sm text-gray-700">
                <span className="font-bold text-exl-navy dark:text-blue-300">{selectedCount} suppliers selected</span>
                {' '}across{' '}
                <span className="font-bold text-exl-navy dark:text-blue-300">{categoryCount} categories</span>
                {matched.some(s => s.bounce) && (
                  <span className="ml-2 text-red-600 text-xs font-medium">
                    · {matched.filter(s => s.bounce).length} bounce(s) excluded
                  </span>
                )}
              </p>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => { const all = {}; matched.filter(s => !s.bounce).forEach(s => { all[s.id] = true }); setChecked(all) }}
                  className="text-xs text-exl-orange hover:underline"
                >Select all</button>
                <span className="text-gray-300">|</span>
                <button onClick={() => setChecked({})} className="text-xs text-gray-500 hover:underline">Clear</button>
              </div>
            </div>

            {Object.entries(grouped).map(([cat, sups]) => (
              <CategorySection
                key={cat}
                category={cat}
                suppliers={sups}
                checked={checked}
                onToggle={handleToggle}
                onEditSupplier={setEditingSupplier}
                onDeleteSupplier={handleSupplierDeleted}
              />
            ))}

            <div className="mt-5 flex items-center justify-between">
              <p className="text-sm text-gray-500">
                {selectedCount} of {matched.filter(s => !s.bounce).length} eligible suppliers selected
              </p>
              <Button
                variant="primary"
                size="md"
                icon={Mail}
                onClick={handleCompose}
                disabled={selectedCount === 0}
              >
                Prepare Solicitation Email
              </Button>
            </div>
          </>
        )}
      </div>

      {/* ── Add Supplier panel ── */}
      <AddSupplierPanel bid={bid} onAdded={handleSupplierAdded} onSelectExisting={(s) => onCompose([s])} onAddToList={handleAddToList} />

      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-700 text-white text-sm font-semibold px-5 py-3 rounded-xl shadow-xl flex items-center gap-2.5">
          <CheckCircle className="w-4 h-4 flex-shrink-0" />{toast}
        </div>
      )}

      {/* Edit Supplier Drawer */}
      {editingSupplier && createPortal(
        <>
          <div className="fixed inset-0 bg-black/20 z-40" onClick={() => setEditingSupplier(null)} />
          <div className="fixed right-0 top-0 h-full w-[520px] bg-white dark:bg-[#1E293B] shadow-2xl z-50 flex flex-col overflow-y-auto">
            <AddSupplierPanel
              key={editingSupplier.id}
              bid={bid}
              editMode
              initialSupplier={editingSupplier}
              onUpdated={handleSupplierUpdated}
              onCancelEdit={() => setEditingSupplier(null)}
            />
          </div>
        </>,
        document.body
      )}

      {/* PORTAL-TEMPLATE-START */}
      {showTemplatePanel && createPortal(
        <>
          <div
            className="fixed inset-0 bg-black/20 z-40"
            onClick={() => setShowTemplatePanel(false)}
          />
          <div className="fixed right-0 top-0 h-full w-96 bg-white dark:bg-[#1E293B] shadow-2xl z-50 flex flex-col">
            <div className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">Configure Portal Form</h3>
                <p className="text-xs text-gray-500 mt-0.5">{bid.customer} · {bid.id}</p>
              </div>
              <button onClick={() => setShowTemplatePanel(false)}>
                <X size={18} className="text-gray-400" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              <div className="mb-5">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider block mb-2">Load Template</label>
                <select
                  value={selectedTemplateId}
                  onChange={(e) => {
                    const tmpl = (templates || []).find(t => t.id === e.target.value)
                    setSelectedTemplateId(e.target.value)
                    if (tmpl) setCustomFields([...tmpl.customFields])
                  }}
                  className="w-full border border-gray-200 dark:border-gray-600 rounded-lg px-3 py-2 text-sm dark:bg-[#0F172A] dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-[#E05A2B]"
                >
                  <option value="">— Select a template —</option>
                  {(templates || []).map(t => (
                    <option key={t.id} value={t.id}>{t.name} — {t.description}</option>
                  ))}
                </select>
              </div>
              <div className="mb-4">
                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider block mb-2">Portal Form Fields</label>
                <div className="mb-3">
                  <p className="text-xs text-gray-400 italic mb-2">Standard fields (always included):</p>
                  {['FOB $/cs', 'Delivered $/cs ★', 'Allowance $', 'PTV $', 'Dev Type', 'No Bid', 'Notes'].map(f => (
                    <div key={f} className="flex items-center gap-2 py-1.5 px-2 rounded text-sm text-gray-500 dark:text-gray-400">
                      <CheckCircle size={13} className="text-gray-300 flex-shrink-0" />{f}
                    </div>
                  ))}
                </div>
                {customFields.length > 0 && (
                  <div>
                    <p className="text-xs text-gray-400 italic mb-2">Custom fields ({customFields.length} added):</p>
                    {customFields.map((field, idx) => (
                      <div key={field.id || idx} className="flex items-center gap-2 py-2 px-2 rounded-lg bg-orange-50 dark:bg-orange-900/20 mb-1.5 group">
                        <GripVertical size={13} className="text-gray-300 flex-shrink-0" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-700 dark:text-gray-300 truncate">{field.label}</p>
                          <p className="text-xs text-gray-400 capitalize">{field.type.replace('_', '/')} {field.required ? '· Required' : ''}</p>
                        </div>
                        <button
                          onClick={() => setCustomFields(prev => prev.filter((_, i) => i !== idx))}
                          className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-red-500 transition-all"
                        >
                          <X size={13} />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                {customFields.length === 0 && !addingField && (
                  <p className="text-xs text-gray-400 italic py-2">No custom fields added yet.</p>
                )}
              </div>
              {addingField ? (
                <div className="border border-orange-200 dark:border-orange-800 rounded-lg p-3 mb-4 bg-orange-50 dark:bg-orange-900/20">
                  <p className="text-xs font-semibold text-gray-600 dark:text-gray-400 mb-2">New Custom Field</p>
                  <input
                    placeholder="Field label (e.g. Halal Certified?)"
                    value={newField.label}
                    onChange={e => setNewField(p => ({ ...p, label: e.target.value }))}
                    className="w-full border border-gray-200 dark:border-gray-600 rounded-lg px-3 py-1.5 text-sm dark:bg-[#0F172A] dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-[#E05A2B] mb-2"
                  />
                  <select
                    value={newField.type}
                    onChange={e => setNewField(p => ({ ...p, type: e.target.value }))}
                    className="w-full border border-gray-200 dark:border-gray-600 rounded-lg px-3 py-1.5 text-sm dark:bg-[#0F172A] dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-[#E05A2B] mb-2"
                  >
                    <option value="text">Text</option>
                    <option value="number">Number</option>
                    <option value="yes_no">Yes / No</option>
                    <option value="dropdown">Dropdown</option>
                    <option value="date">Date</option>
                  </select>
                  <label className="flex items-center gap-2 text-xs text-gray-600 dark:text-gray-400 mb-3">
                    <input type="checkbox" checked={newField.required} onChange={e => setNewField(p => ({ ...p, required: e.target.checked }))} />
                    Required field
                  </label>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        if (!newField.label.trim()) return
                        setCustomFields(prev => [...prev, {
                          id: newField.label.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, ''),
                          label: newField.label,
                          type: newField.type,
                          required: newField.required,
                          showInWorkingFile: true,
                          columnWidth: 100,
                        }])
                        setNewField({ label: '', type: 'text', required: false })
                        setAddingField(false)
                      }}
                      className="flex-1 px-3 py-1.5 bg-[#E05A2B] text-white rounded-lg text-xs font-medium hover:bg-[#C44E22]"
                    >
                      Add Field
                    </button>
                    <button
                      onClick={() => { setAddingField(false); setNewField({ label: '', type: 'text', required: false }) }}
                      className="px-3 py-1.5 border border-gray-200 dark:border-gray-600 text-gray-600 dark:text-gray-400 rounded-lg text-xs"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => setAddingField(true)}
                  className="w-full flex items-center justify-center gap-2 px-3 py-2 border border-dashed border-gray-300 dark:border-gray-600 text-gray-500 dark:text-gray-400 rounded-lg text-sm hover:border-[#E05A2B] hover:text-[#E05A2B] transition-colors mb-4"
                >
                  <Plus size={14} />
                  Add Custom Field
                </button>
              )}
            </div>
            <div className="p-4 border-t border-gray-200 dark:border-gray-700">
              <button
                onClick={async () => {
                  try {
                    await fetch(`/api/bids/${bid.id}/portal-config`, {
                      method: 'PATCH',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ templateId: selectedTemplateId, customFields }),
                    })
                    setShowTemplatePanel(false)
                    setToast(`✅ Portal form configured — ${customFields.length} custom field${customFields.length !== 1 ? 's' : ''} added`)
                  } catch {
                    setToast('❌ Failed to save config')
                  }
                }}
                className="w-full px-4 py-2.5 bg-[#E05A2B] text-white rounded-lg font-medium text-sm hover:bg-[#C44E22] transition-colors"
              >
                Apply to Bid
              </button>
              <p className="text-xs text-gray-400 text-center mt-2">
                Suppliers will see these fields when they open the portal
              </p>
            </div>
          </div>
        </>,
        document.body
      )}
      {/* PORTAL-TEMPLATE-END */}
    </div>
  )
}
