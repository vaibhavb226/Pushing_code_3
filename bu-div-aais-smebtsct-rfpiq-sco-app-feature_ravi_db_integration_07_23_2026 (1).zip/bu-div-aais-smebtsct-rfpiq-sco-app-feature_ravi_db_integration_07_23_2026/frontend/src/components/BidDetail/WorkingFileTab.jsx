import React, { useState, useEffect, useMemo, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  FileSpreadsheet, Download, CheckCircle, AlertTriangle,
  XCircle, Loader, Brain, ChevronDown, ChevronRight,
  Settings, Plus, Trash2, X, Lock, Save,
} from 'lucide-react'
import { Button } from '../UI/Button'
import { EmptyState } from '../UI/EmptyState'
import { getUserColor, getInitials } from '../../utils/presenceColors'

// ── Category abbreviation map ─────────────────────────────
const CA_MAP = {
  'Protein':   'PROT',
  'Dairy':     'DAIRY',
  'Produce':   'PROD',
  'Bakery':    'BKRY',
  'Grocery':   'GROC',
  'Beverage':  'BEV',
  'Paper':     'PPR',
  'Broker':    'BRKR',
  'M/MA':      'M/MA',
  'M/MA+Grain':'M/MA+G',
  'Grain':     'GRAIN',
  'Fruit':     'FRUIT',
  'Snack':     'SNACK',
}
function getCa(cat) {
  return CA_MAP[cat] || (cat || '').slice(0, 5).toUpperCase() || '—'
}

// ── Color constants ───────────────────────────────────────
// Tailwind className variants (light + dark) — use these on <td>/<th> elements
const BLUE_CLS    = 'bg-[#EBF3FB] dark:bg-[#1a2f45]'
const YELLOW_CLS  = 'bg-[#FEFCE8] dark:bg-[#2a2000]'
const SUB_ROW_CLS = 'bg-[#F0F7FF] dark:bg-[#162030]'

// ── Excel export group palette (ARGB: 'FF' + hex) ─────────
// Mirrors the on-screen section colors: blue = Supplier, yellow = Internal,
// plus a slate tint for the Customer RFP group (which has no on-screen color).
const XLSX_GROUP_COLORS = {
  rfp:      { band: 'FF1F3864', header: 'FFE2E8F0', data: 'FFF1F5F9' },
  supplier: { band: 'FF1A6DB5', header: 'FFD6E8F7', data: 'FFEBF3FB' },
  internal: { band: 'FFB45309', header: 'FFFDF0D0', data: 'FFFEFCE8' },
}

// ── Default column configs ────────────────────────────────
const DEFAULT_SUPPLIER_COLUMNS = [
  { id: 'supcRight',     label: 'SUPC',        visible: true, fixed: true  },
  { id: 'brandRight',    label: 'Brand',       visible: true               },
  { id: 'descRight',     label: 'Description', visible: true, fixed: true  },
  { id: 'trueVendor',    label: 'True Vendor', visible: true, fixed: true  },
  { id: 'suppliedPrice', label: 'Net $/cs',    visible: true, fixed: true  },
  { id: 'devType',       label: 'Dev Type',    visible: true               },
  { id: 'notes',         label: 'Notes',       visible: true               },
  { id: 'allw',          label: 'ALLW $',      visible: true               },
  { id: 'dl',            label: 'DL $',        visible: true               },
  { id: 'priceCase',     label: 'Net $/Case',  visible: true               },
  { id: 'openReview',    label: 'Open Rev.',   visible: true               },
  { id: 'confidence',    label: 'Confidence',  visible: true, fixed: true  },
]

const DEFAULT_INTERNAL_COLUMNS = [
  { id: 'awardDecision',    label: 'Award Decision',    visible: true, type: 'dropdown', options: ['', 'Awarded', 'Pending', 'Rejected', 'Under Review'] },
  { id: 'internalNotes',    label: 'Internal Notes',    visible: true, type: 'text' },
  { id: 'pricingScore',     label: 'Pricing Score',     visible: true, type: 'number' },
  { id: 'followUpRequired', label: 'Follow-up Required',visible: true, type: 'dropdown', options: ['', 'Yes', 'No', 'In Progress'] },
]

// Force fixed columns to visible:true — heals stale saved configs where a user previously
// managed to hide a fixed column before this guard was added.
const enforceFixed = (cols) => cols.map(c => c.fixed ? { ...c, visible: true } : c)

// ── Dev type options ──────────────────────────────────────
const DEV_TYPE_OPTIONS = ['ALLW', 'DL', 'NOI', 'COST']

// ── Empty cell placeholder ────────────────────────────────
const EMPTY = <span className="text-gray-300 text-xs">—</span>

// ── Confidence badge ──────────────────────────────────────
function ConfidenceBadge({ confidence, approved }) {
  if (approved) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold">
        <CheckCircle className="w-3 h-3" /> Approved
      </span>
    )
  }
  if (!confidence && confidence !== 0) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 text-gray-500 rounded-full text-xs font-semibold">
        No Response
      </span>
    )
  }
  if (confidence >= 70) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-xs font-bold">
        <CheckCircle className="w-3 h-3" /> {confidence}%
      </span>
    )
  }
  if (confidence >= 40) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-amber-100 text-amber-700 rounded-full text-xs font-bold">
        <AlertTriangle className="w-3 h-3" /> {confidence}%
      </span>
    )
  }
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-red-100 text-red-700 rounded-full text-xs font-bold">
      <XCircle className="w-3 h-3" /> {confidence}%
    </span>
  )
}

// ── Dev type badge ────────────────────────────────────────
function DevTypeBadge({ type }) {
  if (!type) return <span className="text-gray-300 text-xs">—</span>
  const colours =
    type === 'ALLW' ? 'bg-emerald-100 text-emerald-700' :
    type === 'DL'   ? 'bg-blue-100 text-blue-700' :
    type === 'NOI'  ? 'bg-purple-100 text-purple-700' :
    'bg-gray-100 text-gray-600'
  return (
    <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-bold ${colours}`}>
      {type}
    </span>
  )
}

// ── Award Decision badge ──────────────────────────────────
function AwardBadge({ value }) {
  if (!value) return EMPTY
  const colours =
    value === 'Awarded'      ? 'bg-emerald-100 text-emerald-700' :
    value === 'Rejected'     ? 'bg-red-100 text-red-700' :
    value === 'Pending'      ? 'bg-amber-100 text-amber-700' :
    value === 'Under Review' ? 'bg-blue-100 text-blue-700' :
    'bg-gray-100 text-gray-600'
  return (
    <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${colours}`}>
      {value}
    </span>
  )
}

// ── Compliance pills ──────────────────────────────────────
function CompliancePills({ item }) {
  const pills = []
  if (item.buyAmerican)    pills.push(<span key="ba"  className="px-1 py-0.5 bg-red-100 text-red-700 text-xs rounded font-semibold">BA</span>)
  if (item.childNutrition) pills.push(<span key="cn"  className="px-1 py-0.5 bg-green-100 text-green-700 text-xs rounded font-semibold">CN</span>)
  if (item.pfsRequired)    pills.push(<span key="pfs" className="px-1 py-0.5 bg-purple-100 text-purple-700 text-xs rounded font-semibold">PFS</span>)
  if (item.wholeGrain)     pills.push(<span key="wg"  className="px-1 py-0.5 bg-teal-100 text-teal-700 text-xs rounded font-semibold">WG</span>)
  if (item.halal)          pills.push(<span key="hl"  className="px-1 py-0.5 bg-cyan-100 text-cyan-700 text-xs rounded font-semibold">HL</span>)
  if (item.kosher)         pills.push(<span key="ks"  className="px-1 py-0.5 bg-indigo-100 text-indigo-700 text-xs rounded font-semibold">KS</span>)
  return pills.length > 0
    ? <div className="flex flex-wrap gap-0.5">{pills}</div>
    : <span className="text-gray-300 text-xs">—</span>
}

// ── Excel export (styled, color-coded by column group) ─────
async function exportXlsx(lineItems, internalData, wfConfig, bidId, portalCustomFields = []) {
  const visSupCols = (wfConfig.supplierColumns || DEFAULT_SUPPLIER_COLUMNS).filter(c => c.visible)
  const visIntCols = (wfConfig.internalColumns || []).filter(c => c.visible)
  const portalCols = portalCustomFields.filter(f => f.showInWorkingFile)

  // RFP columns are fixed — never customised; defined here so RFP_END stays in sync automatically.
  const rfpHeaders = [
    'Item #', 'SUPC', 'MPC Code', 'UOM', 'Volume', 'Pack', 'Size',
    'Brand', 'Description', 'CA', 'CW', 'STK Type',
    'Buy American', 'CN', 'PFS', 'Whole Grain', 'Halal', 'Kosher',
  ]

  // Supplier column id → export label
  const SUP_LABELS = {
    supcRight:     'Supp. SUPC',
    brandRight:    'Supp. Brand',
    descRight:     'Supp. Description',
    trueVendor:    'True Vendor',
    suppliedPrice: 'Net $/cs',
    devType:       'Dev Type',
    notes:         'Notes',
    allw:          'ALLW ($)',
    dl:            'DL ($)',
    priceCase:     'Net $/Case',
    openReview:    'Open Review',
    confidence:    'Confidence',
  }

  const headers = [
    ...rfpHeaders,
    ...visSupCols.map(c => SUP_LABELS[c.id] || c.label),
    ...visIntCols.map(c => c.label),
    ...portalCols.map(c => c.label),
  ]

  // Supplier column id → cell value extractor. entry = supplierPricing row (null if no pricing yet).
  const supVal = (colId, entry, li) => {
    const price = entry ? (entry.unitPrice ?? entry.casePrice ?? null) : null
    switch (colId) {
      case 'supcRight':     return entry?.supplierSupc         || li.supc        || ''
      case 'brandRight':    return entry?.supplierBrand        || li.brand       || ''
      case 'descRight':     return entry?.supplierDescription  || li.description || ''
      case 'trueVendor':    return entry?.supplierName         ?? li.trueVendor  ?? ''
      case 'suppliedPrice': return price                       ?? li.suppliedPrice ?? ''
      case 'devType':       return entry?.devType              ?? li.devType     ?? ''
      case 'notes':         return entry?.notes                ?? li.notes       ?? ''
      case 'allw':          return entry?.allw                 ?? li.allw        ?? ''
      case 'dl':            return entry?.dl                   ?? li.dl          ?? ''
      case 'priceCase':     return entry?.priceCase            ?? li.priceCase   ?? ''
      case 'openReview':    return (entry?.openReview ?? li.openReview) ? 'Yes' : ''
      case 'confidence':    return entry ? (entry.confidenceScore ?? entry.confidence ?? '') : ''
      default:              return ''
    }
  }

  // Each line item expands into one row per supplier pricing entry so that all competing
  // supplier quotes appear in the export. Items with no supplier data produce a single row.
  const rows = lineItems.flatMap(li => {
    const pricing = li.supplierPricing || []
    const intV    = internalData[li.id] || {}

    // RFP columns are identical for every sub-row of the same item.
    const rfpCols = [
      li.bidItem, li.supc || '', li.mpcCode || '', li.unit || '', li.qty ?? '',
      li.pack || '', li.size || '', li.brand || '', li.description,
      getCa(li.category), li.cw || 'N', li.stkType || 'A',
      li.buyAmerican    ? 'Yes' : 'No',
      li.childNutrition ? 'Yes' : 'No',
      li.pfsRequired    ? 'Yes' : 'No',
      li.wholeGrain     ? 'Yes' : 'No',
      li.halal          ? 'Yes' : 'No',
      li.kosher         ? 'Yes' : 'No',
    ]
    const intCols = visIntCols.map(c => intV[c.id] ?? '')
    const prtCols = (entry) =>
      portalCols.map(f => entry?.customFields?.[f.fieldId] ?? li.customFields?.[f.fieldId] ?? '')

    if (pricing.length === 0) {
      return [[ ...rfpCols, ...visSupCols.map(c => supVal(c.id, null, li)), ...intCols, ...prtCols(null) ]]
    }

    return pricing.map(entry => [
      ...rfpCols,
      ...visSupCols.map(c => supVal(c.id, entry, li)),
      ...intCols,
      ...prtCols(entry),
    ])
  })

  // exceljs is heavy — load it only when the user actually exports.
  const ExcelJS = (await import('exceljs')).default
  const wb = new ExcelJS.Workbook()
  const ws = wb.addWorksheet('Working File', {
    views: [{ state: 'frozen', xSplit: 1, ySplit: 2 }],
  })

  // Band boundaries — derived from actual column arrays, never hardcoded numbers.
  const RFP_END   = rfpHeaders.length
  const SUP_END   = RFP_END + visSupCols.length
  const INT_END   = SUP_END + visIntCols.length
  const PRT_END   = INT_END + portalCols.length
  const totalCols = PRT_END
  const groupOf = (col) =>
    col <= RFP_END ? 'rfp' :
    col <= SUP_END ? 'supplier' :
    col <= INT_END ? 'internal' :
    'portal'
  // Portal columns reuse the blue supplier palette
  const GROUP_COLORS = { ...XLSX_GROUP_COLORS, portal: XLSX_GROUP_COLORS.supplier }
  const fill = (argb) => ({ type: 'pattern', pattern: 'solid', fgColor: { argb } })

  // Row 1 — bold colored group bands
  ws.mergeCells(1, 1, 1, RFP_END)
  ws.mergeCells(1, RFP_END + 1, 1, SUP_END)
  if (visIntCols.length) ws.mergeCells(1, SUP_END + 1, 1, INT_END)
  if (portalCols.length) ws.mergeCells(1, INT_END + 1, 1, PRT_END)
  const band = (col, text, key) => {
    const cell = ws.getCell(1, col)
    cell.value = text
    cell.fill = fill(GROUP_COLORS[key].band)
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' }, size: 11 }
    cell.alignment = { horizontal: 'center', vertical: 'middle' }
  }
  band(1, 'Customer RFP', 'rfp')
  band(RFP_END + 1, 'Supplier Responses', 'supplier')
  if (visIntCols.length) band(SUP_END + 1, 'Bid COE Internal', 'internal')
  if (portalCols.length) band(INT_END + 1, 'Portal Fields', 'portal')
  ws.getRow(1).height = 20

  // Row 2 — column headers, tinted per group
  const headerRow = ws.getRow(2)
  headers.forEach((h, i) => {
    const cell = headerRow.getCell(i + 1)
    cell.value = h
    cell.fill = fill(GROUP_COLORS[groupOf(i + 1)].header)
    cell.font = { bold: true, color: { argb: 'FF1E293B' }, size: 10 }
    cell.alignment = { vertical: 'middle', wrapText: true }
  })
  headerRow.height = 24

  // Data rows — soft group tint per cell; price columns formatted as currency
  const priceLabels = new Set(['Net $/cs', 'ALLW ($)', 'DL ($)', 'Net $/Case'])
  rows.forEach(r => {
    const row = ws.addRow(r)
    r.forEach((_, i) => {
      const cell = row.getCell(i + 1)
      cell.fill = fill(GROUP_COLORS[groupOf(i + 1)].data)
      cell.font = { size: 10, color: { argb: 'FF1E293B' } }
      if (priceLabels.has(headers[i])) {
        const num = parseFloat(cell.value)
        if (cell.value !== '' && cell.value != null && !Number.isNaN(num)) {
          cell.value = num
          cell.numFmt = '$#,##0.00'
        }
        cell.alignment = { horizontal: 'right' }
      }
    })
  })

  // Column widths (wider for text-heavy columns)
  const widthFor = (label) => {
    if (['Description', 'Supp. Description'].includes(label)) return 34
    if (['Notes', 'Internal Notes'].includes(label)) return 22
    if (['Brand', 'Supp. Brand', 'True Vendor', 'Award Decision', 'Follow-up Required', 'MPC Code'].includes(label)) return 16
    return 11
  }
  headers.forEach((h, i) => { ws.getColumn(i + 1).width = widthFor(h) })

  const buf  = await wb.xlsx.writeBuffer()
  const blob = new Blob([buf], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  })
  const url  = URL.createObjectURL(blob)
  const a    = document.createElement('a')
  a.href     = url
  a.download = `${bidId}_WorkingFile_${new Date().toISOString().split('T')[0]}.xlsx`
  a.click()
  URL.revokeObjectURL(url)
}

// ── Customize panel — single column row ───────────────────
function ColumnRow({ col, onToggle, onRename, onRemove }) {
  const [editing, setEditing] = useState(false)
  const [draft, setDraft]     = useState(col.label)
  const inputRef              = useRef(null)

  useEffect(() => { if (editing) inputRef.current?.focus() }, [editing])

  const commit = () => {
    if (draft.trim()) onRename(draft.trim())
    setEditing(false)
  }

  return (
    <div className="flex items-center gap-2 py-1.5 group">
      {/* Visible toggle — fixed columns always stay visible, show lock instead */}
      {col.fixed ? (
        <span
          className="flex-shrink-0 w-4 h-4 flex items-center justify-center text-gray-300"
          title="Fixed column — always visible"
        >
          <Lock className="w-3 h-3" />
        </span>
      ) : (
        <button onClick={onToggle} className="flex-shrink-0 w-4 h-4 flex items-center justify-center">
          {col.visible
            ? <div className="w-4 h-4 rounded border-2 border-exl-orange flex items-center justify-center" style={{ backgroundColor: '#E05A2B' }}>
                <CheckCircle className="w-2.5 h-2.5 text-white" style={{ strokeWidth: 3 }} />
              </div>
            : <div className="w-4 h-4 rounded border-2 border-gray-300" />
          }
        </button>
      )}

      {/* Label — click to rename */}
      {editing ? (
        <input
          ref={inputRef}
          value={draft}
          onChange={e => setDraft(e.target.value)}
          onBlur={commit}
          onKeyDown={e => { if (e.key === 'Enter') commit(); if (e.key === 'Escape') setEditing(false) }}
          className="flex-1 text-xs border-b outline-none bg-transparent"
          style={{ borderColor: '#E05A2B' }}
        />
      ) : (
        <span
          className={`flex-1 text-xs cursor-pointer transition-colors hover:text-exl-orange ${col.visible ? 'text-gray-700' : 'text-gray-400 line-through'}`}
          onClick={() => { setDraft(col.label); setEditing(true) }}
          title="Click to rename"
        >
          {col.label}
        </span>
      )}

      {col.fixed && <span className="text-xs text-gray-300 flex-shrink-0 italic">fixed</span>}
      {col.type  && !col.fixed && <span className="text-xs text-gray-300 flex-shrink-0">{col.type}</span>}

      {onRemove && (
        <button onClick={onRemove} className="flex-shrink-0 opacity-0 group-hover:opacity-100 transition-opacity" title="Remove column">
          <Trash2 className="w-3 h-3 text-red-400 hover:text-red-600" />
        </button>
      )}
    </div>
  )
}

// ── Add column form ───────────────────────────────────────
function AddColumnForm({ onAdd, onCancel }) {
  const [name, setName] = useState('')
  const [type, setType] = useState('text')

  return (
    <div className="mt-2 p-3 bg-gray-50 rounded-xl border border-gray-200">
      <input
        value={name}
        onChange={e => setName(e.target.value)}
        placeholder="Column name"
        autoFocus
        className="w-full text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 mb-2 outline-none"
        style={{ focusBorderColor: '#E05A2B' }}
        onFocus={e => e.target.style.borderColor = '#E05A2B'}
        onBlur={e => e.target.style.borderColor = ''}
        onKeyDown={e => { if (e.key === 'Enter' && name.trim()) onAdd(name.trim(), type) }}
      />
      <select
        value={type}
        onChange={e => setType(e.target.value)}
        className="w-full text-xs border border-gray-200 dark:border-gray-600 rounded-lg px-2.5 py-1.5 mb-2 outline-none bg-white dark:bg-[#253347] dark:text-gray-200"
      >
        <option value="text">Text</option>
        <option value="number">Number</option>
        <option value="dropdown">Dropdown</option>
      </select>
      <div className="flex gap-2">
        <button
          onClick={() => { if (name.trim()) onAdd(name.trim(), type) }}
          className="flex-1 py-1.5 rounded-lg text-xs font-semibold text-white"
          style={{ backgroundColor: '#E05A2B' }}
        >
          Add
        </button>
        <button
          onClick={onCancel}
          className="px-3 py-1.5 rounded-lg text-xs font-semibold text-gray-600 border border-gray-200 hover:bg-gray-50"
        >
          Cancel
        </button>
      </div>
    </div>
  )
}

// ── Customize Columns slide-in panel ─────────────────────
function CustomizePanel({ config, onClose, onSave }) {
  const [local, setLocal]     = useState(() => JSON.parse(JSON.stringify(config)))
  const [addingTo, setAddingTo] = useState(null) // 'supplierColumns' | 'internalColumns' | null

  const toggleCol = (section, id) =>
    setLocal(p => ({ ...p, [section]: p[section].map(c => c.id === id ? { ...c, visible: !c.visible } : c) }))

  const renameCol = (section, id, label) =>
    setLocal(p => ({ ...p, [section]: p[section].map(c => c.id === id ? { ...c, label } : c) }))

  const removeCol = (section, id) =>
    setLocal(p => ({ ...p, [section]: p[section].filter(c => c.id !== id) }))

  const addCol = (section, name, type) => {
    const id  = `custom_${Date.now()}`
    const col = { id, label: name, visible: true, type, custom: true }
    if (type === 'dropdown') col.options = ['', 'Option 1', 'Option 2', 'Option 3']
    setLocal(p => ({ ...p, [section]: [...p[section], col] }))
    setAddingTo(null)
  }

  return (
    <>
      {/* Dim backdrop */}
      <div className="fixed inset-0 bg-black/10 z-[9996]" onClick={onClose} />

      {/* Panel */}
      <div
        className="fixed right-0 top-0 h-full bg-white dark:bg-[#1E293B] shadow-2xl flex flex-col border-l border-gray-200 dark:border-gray-700"
        style={{ width: 340, zIndex: 9997 }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-200 flex-shrink-0">
          <div className="flex items-center gap-2">
            <Settings className="w-4 h-4" style={{ color: '#E05A2B' }} />
            <span className="font-semibold text-gray-900 text-sm">Customize Columns</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onSave(local)}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-white"
              style={{ backgroundColor: '#E05A2B' }}
            >
              Save
            </button>
            <button
              onClick={onClose}
              className="w-7 h-7 flex items-center justify-center rounded-lg hover:bg-gray-100 transition-colors"
            >
              <X className="w-4 h-4 text-gray-500" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 min-h-0 overflow-y-auto px-5 py-4">
          <p className="text-xs text-gray-400 mb-5">
            Click a column name to rename it. Uncheck to hide it from the table.
          </p>

          {/* Supplier Responses */}
          <div className="mb-6">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-3 h-3 rounded-sm border border-blue-200" style={{ backgroundColor: '#EBF3FB' }} />
              <p className="text-xs font-bold uppercase tracking-wide" style={{ color: '#1a6db5' }}>
                Supplier Responses
              </p>
            </div>

            {local.supplierColumns.map(col => (
              <ColumnRow
                key={col.id}
                col={col}
                onToggle={() => toggleCol('supplierColumns', col.id)}
                onRename={l => renameCol('supplierColumns', col.id, l)}
                onRemove={col.custom ? () => removeCol('supplierColumns', col.id) : null}
              />
            ))}

            {addingTo === 'supplierColumns' ? (
              <AddColumnForm
                onAdd={(name, type) => addCol('supplierColumns', name, type)}
                onCancel={() => setAddingTo(null)}
              />
            ) : (
              <button
                onClick={() => setAddingTo('supplierColumns')}
                className="flex items-center gap-1.5 text-xs mt-2 transition-colors hover:opacity-80"
                style={{ color: '#1a6db5' }}
              >
                <Plus className="w-3.5 h-3.5" /> Add column
              </button>
            )}
          </div>

          <hr className="border-gray-100 mb-5" />

          {/* Bid COE Internal */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-3 h-3 rounded-sm border border-amber-200" style={{ backgroundColor: '#FEFCE8' }} />
              <p className="text-xs font-bold uppercase tracking-wide" style={{ color: '#B45309' }}>
                Bid COE Internal
              </p>
            </div>

            {local.internalColumns.map(col => (
              <ColumnRow
                key={col.id}
                col={col}
                onToggle={() => toggleCol('internalColumns', col.id)}
                onRename={l => renameCol('internalColumns', col.id, l)}
                onRemove={col.custom ? () => removeCol('internalColumns', col.id) : null}
              />
            ))}

            {addingTo === 'internalColumns' ? (
              <AddColumnForm
                onAdd={(name, type) => addCol('internalColumns', name, type)}
                onCancel={() => setAddingTo(null)}
              />
            ) : (
              <button
                onClick={() => setAddingTo('internalColumns')}
                className="flex items-center gap-1.5 text-xs mt-2 transition-colors hover:opacity-80"
                style={{ color: '#B45309' }}
              >
                <Plus className="w-3.5 h-3.5" /> Add column
              </button>
            )}
          </div>
        </div>
      </div>
    </>
  )
}

// ── Working file row ──────────────────────────────────────
function WorkingFileRow({
  item, pricing, approved, onApprove, onCellSave,
  onSubRowSave, onDeleteItem, onRemoveSupplierPricing,
  visibleSupplierColIds, supplierColLabel,
  internalCols, internalValues, onInternalSave,
  portalCustomFields = [],
  remoteEditors = [],
  onCellFocus,
  onCellBlur,
}) {
  const hasSupplierPricing = (item.supplierPricing?.length ?? 0) > 0
  const conf         = hasSupplierPricing ? (item.confidence ?? null) : null
  const hasData      = hasSupplierPricing
  const needsApprove = hasData && !approved && conf !== null && conf >= 40 && conf < 70
  const needsReview  = hasData && !approved && conf !== null && conf < 40

  const supplierPricing = item.supplierPricing || []
  const [expanded, setExpanded] = useState(true)

  // ── Supplier-side inline edit state ──────────────────────
  const [editingField, setEditingField] = useState(null)
  const [draft, setDraft]               = useState('')
  const inputRef                        = useRef(null)

  // ── Internal-side inline edit state ──────────────────────
  const [intEditField, setIntEditField] = useState(null)
  const [intDraft, setIntDraft]         = useState('')
  const intInputRef                     = useRef(null)

  // ── Sub-row (supplierPricing[1+]) price edit state ────────
  // editingSubIdx: actual index in supplierPricing (= extraEntries idx + 1)
  const [editingSubIdx, setEditingSubIdx] = useState(null)
  const [subDraft, setSubDraft]           = useState('')
  const subInputRef                       = useRef(null)

  // ── Delete confirm state ──────────────────────────────────
  const [confirmDelete, setConfirmDelete] = useState(false)

  useEffect(() => {
    if (editingField && inputRef.current) {
      inputRef.current.focus()
      if (inputRef.current.select) inputRef.current.select()
    }
  }, [editingField])

  useEffect(() => {
    if (intEditField && intInputRef.current) {
      intInputRef.current.focus()
      if (intInputRef.current.select) intInputRef.current.select()
    }
  }, [intEditField])

  const startEdit = (field, val) => {
    setDraft(val != null ? String(val) : '')
    setEditingField(field)
    onCellFocus?.()
  }

  const commitSave = () => {
    if (!editingField) return
    const realField =
      editingField === 'supcRight'  ? 'supc'  :
      editingField === 'brandRight' ? 'brand' :
      editingField
    onCellSave(realField, draft)
    setEditingField(null)
    onCellBlur?.()
  }

  const cancelEdit  = () => { setEditingField(null); onCellBlur?.() }
  const handleKey   = (e) => {
    if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); commitSave() }
    else if (e.key === 'Escape') cancelEdit()
  }

  const startIntEdit = (colId, val) => {
    setIntDraft(val != null ? String(val) : '')
    setIntEditField(colId)
  }

  const commitIntSave = () => {
    if (!intEditField) return
    const col     = internalCols.find(c => c.id === intEditField)
    const value   = col?.type === 'number' ? (intDraft === '' ? null : Number(intDraft)) : intDraft
    onInternalSave(intEditField, value)
    setIntEditField(null)
  }

  const cancelIntEdit = () => setIntEditField(null)
  const handleIntKey  = (e) => {
    if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); commitIntSave() }
    else if (e.key === 'Escape') cancelIntEdit()
  }

  // ── Sub-row price edit handlers ───────────────────────────
  useEffect(() => {
    if (editingSubIdx != null && subInputRef.current) {
      subInputRef.current.focus()
      if (subInputRef.current.select) subInputRef.current.select()
    }
  }, [editingSubIdx])

  const startSubEdit = (actualIdx, val) => {
    setSubDraft(val != null ? String(val) : '')
    setEditingSubIdx(actualIdx)
  }
  const commitSubSave = () => {
    if (editingSubIdx == null) return
    const price = subDraft === '' ? null : Number(subDraft)
    onSubRowSave?.(editingSubIdx, price)
    setEditingSubIdx(null)
  }
  const cancelSubEdit = () => setEditingSubIdx(null)
  const handleSubKey  = (e) => {
    if (e.key === 'Enter' || e.key === 'Tab') { e.preventDefault(); commitSubSave() }
    else if (e.key === 'Escape') cancelSubEdit()
  }

  // ── Supplier data resolution ──────────────────────────────
  const firstEntry   = supplierPricing[0] || null
  const extraEntries = expanded ? supplierPricing.slice(1) : []

  const trueVendor    = firstEntry?.supplierName     ?? pricing?.supplier_name ?? item.trueVendor
  const netPriceVal   = firstEntry != null
    ? (firstEntry.unitPrice ?? firstEntry.casePrice ?? null)
    : (pricing?.supplied_price ?? null)
  const devTypeVal    = firstEntry?.devType           ?? pricing?.dev_type      ?? null
  const supplierBrand = firstEntry?.supplierBrand     ?? null
  const supplierDesc  = firstEntry?.supplierDescription ?? null
  const supplierNotes = firstEntry?.notes             ?? null

  const allPrices = supplierPricing
    .map(e => { const p = parseFloat(e.unitPrice ?? e.casePrice); return isNaN(p) ? null : p })
    .filter(p => p != null)
  const bestPrice  = allPrices.length >= 1 ? Math.min(...allPrices) : null
  const firstPrice = firstEntry != null
    ? (() => { const p = parseFloat(firstEntry.unitPrice ?? firstEntry.casePrice); return isNaN(p) ? null : p })()
    : null
  const firstIsBest = bestPrice !== null && firstPrice !== null && firstPrice === bestPrice

  // Helper: editable td for supplier side
  const editTd = (field, rawValue, displayContent, opts = {}) => {
    const { isBlue = true, type = 'text', options, className = '' } = opts
    const bgCls      = isBlue ? BLUE_CLS : ''
    const isEditing  = editingField === field

    if (isEditing) {
      if (type === 'dropdown') {
        return (
          <td key={field} className={`px-2 py-1 text-xs ${bgCls} ${className}`} style={{ borderBottom: '2px solid #E05A2B' }}>
            <select ref={inputRef} value={draft} onChange={e => setDraft(e.target.value)}
              onBlur={commitSave} onKeyDown={handleKey} className="w-full bg-transparent outline-none text-xs">
              <option value="">—</option>
              {options.map(o => <option key={o} value={o}>{o}</option>)}
            </select>
          </td>
        )
      }
      return (
        <td key={field} className={`px-2 py-1 text-xs ${bgCls} ${className}`} style={{ borderBottom: '2px solid #E05A2B' }}>
          <input ref={inputRef} type={type === 'number' ? 'number' : 'text'}
            step={type === 'number' ? '0.01' : undefined}
            value={draft} onChange={e => setDraft(e.target.value)}
            onBlur={commitSave} onKeyDown={handleKey}
            className="w-full bg-transparent outline-none text-xs min-w-[60px]" />
        </td>
      )
    }

    return (
      <td key={field}
        className={`px-2 py-2.5 text-xs cursor-pointer hover:bg-blue-50/60 dark:hover:bg-blue-900/20 transition-colors ${bgCls} ${className}`}
        onClick={() => startEdit(field, rawValue)} title="Click to edit">
        {displayContent ?? (rawValue != null && rawValue !== '' ? rawValue : EMPTY)}
      </td>
    )
  }

  // Visible supplier column check
  const vis = (id) => visibleSupplierColIds.has(id)

  // Number of visible supplier columns (for sub-row colSpan)
  const visSupplierCount = visibleSupplierColIds.size

  return (
    <>
    {/* ── MAIN ROW ── */}
    {/* remoteEditors: other users focused on this row — left accent stripe via box-shadow */}
    <tr
      className="border-b border-gray-100 dark:border-gray-700 hover:bg-[#F0F7FF] dark:hover:bg-[#253347] transition-colors"
      style={remoteEditors.length > 0 ? { boxShadow: `inset 3px 0 0 ${getUserColor(remoteEditors[0]).borderColor}` } : undefined}
      title={remoteEditors.length > 0 ? `${remoteEditors.join(', ')} ${remoteEditors.length === 1 ? 'is' : 'are'} here` : undefined}
    >

      {/* ── LEFT SIDE — Customer RFP (white, always shown) ── */}
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] font-mono text-gray-500 dark:text-gray-400 whitespace-nowrap text-xs sticky left-0 z-10 shadow-[2px_0_4px_rgba(0,0,0,0.04)]">
        {item.bidItem}
        {item._remoteConflict && (
          <span
            className="ml-1 text-amber-500 cursor-help"
            title="Modified by another user — your unsaved changes take priority. Save to apply yours."
          >⚠</span>
        )}
      </td>

      {editingField === 'supc' ? (
        <td className="px-2 py-1 bg-white dark:bg-[#1E293B] font-mono text-xs whitespace-nowrap" style={{ borderBottom: '2px solid #E05A2B' }}>
          <input ref={inputRef} value={draft} onChange={e => setDraft(e.target.value)}
            onBlur={commitSave} onKeyDown={handleKey}
            className="w-full bg-transparent outline-none font-mono text-xs min-w-[70px]" placeholder="Enter SUPC" />
        </td>
      ) : (
        <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] font-mono text-xs whitespace-nowrap cursor-pointer hover:bg-blue-50/60 dark:hover:bg-blue-900/20 transition-colors"
          onClick={() => startEdit('supc', item.supc)} title="Click to edit">
          {item.supc
            ? <span className="text-gray-700 dark:text-gray-300">{item.supc}</span>
            : <span className="text-gray-300 dark:text-gray-600 italic text-xs">TBD</span>}
        </td>
      )}

      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] font-mono text-gray-600 dark:text-gray-400 text-xs whitespace-nowrap">{item.mpcCode || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] text-gray-600 dark:text-gray-400 text-xs whitespace-nowrap">{item.unit || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] text-right font-semibold text-gray-700 dark:text-gray-300 text-xs">{item.qty?.toLocaleString() || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] text-gray-600 dark:text-gray-400 text-xs whitespace-nowrap">{item.pack || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] text-gray-600 dark:text-gray-400 text-xs whitespace-nowrap">{item.size || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] text-gray-700 dark:text-gray-300 text-xs whitespace-nowrap">{item.brand || EMPTY}</td>
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] max-w-[200px]">
        <p className="font-medium text-gray-900 dark:text-gray-100 text-xs truncate" title={item.description}>{item.description}</p>
      </td>
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] text-xs"><span className="font-semibold text-gray-600 dark:text-gray-400">{getCa(item.category)}</span></td>
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] text-center text-xs font-semibold text-gray-500 dark:text-gray-400">{item.cw || 'N'}</td>
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B] text-center text-xs font-semibold text-gray-500 dark:text-gray-400">{item.stkType || 'A'}</td>
      <td className="px-2 py-2.5 bg-white dark:bg-[#1E293B]"><CompliancePills item={item} /></td>

      {/* Divider: RFP → Supplier */}
      <td className="py-2.5 w-px bg-white dark:bg-[#1E293B]"><div className="w-px h-8 bg-gray-200 dark:bg-gray-600 mx-auto" /></td>

      {/* ── RIGHT SIDE — Supplier Responses (blue, configurable) ── */}

      {vis('supcRight') && editTd('supcRight', item.supc,
        item.supc
          ? <span className="font-mono text-gray-700">{item.supc}</span>
          : <span className="text-gray-300 italic">TBD</span>,
        { isBlue: true, className: 'px-2 w-[70px] whitespace-nowrap font-mono' }
      )}

      {vis('brandRight') && editTd('brandRight', supplierBrand,
        supplierBrand ? <span className="text-gray-800">{supplierBrand}</span> : null,
        { isBlue: true, className: 'px-2 w-[90px]' }
      )}

      {vis('descRight') && (
        <td className={`px-2 py-2.5 text-xs max-w-[180px] ${BLUE_CLS}`}>
          <p className="text-gray-700 dark:text-gray-300 truncate" title={supplierDesc || ''}>
            {supplierDesc
              ? supplierDesc.length > 30 ? supplierDesc.slice(0, 30) + '…' : supplierDesc
              : EMPTY}
          </p>
        </td>
      )}

      {vis('trueVendor') && (
        editingField === 'trueVendor' ? (
          <td className={`px-3 py-1 text-xs ${BLUE_CLS}`} style={{ borderBottom: '2px solid #E05A2B' }}>
            <input ref={inputRef} value={draft} onChange={e => setDraft(e.target.value)}
              onBlur={commitSave} onKeyDown={handleKey}
              className="w-full bg-transparent outline-none text-xs min-w-[80px]" placeholder="Enter vendor name" />
          </td>
        ) : (
          <td className={`px-3 py-2.5 text-xs cursor-pointer hover:bg-blue-50/60 dark:hover:bg-blue-900/20 transition-colors ${BLUE_CLS}`}
            onClick={() => startEdit('trueVendor', trueVendor)} title="Click to edit">
            <div className="flex items-center gap-1.5 flex-wrap">
              {trueVendor
                ? <span className="font-medium text-gray-800 dark:text-gray-200">{trueVendor}</span>
                : <span className="text-gray-400 dark:text-gray-500 italic">Awaiting</span>}
            </div>
          </td>
        )
      )}

      {vis('suppliedPrice') && (
        editingField === 'suppliedPrice' ? (
          <td className={`px-3 py-1 text-xs text-right ${BLUE_CLS}`} style={{ borderBottom: '2px solid #E05A2B' }}>
            <input ref={inputRef} type="number" step="0.01" value={draft}
              onChange={e => setDraft(e.target.value)} onBlur={commitSave} onKeyDown={handleKey}
              className="w-full bg-transparent outline-none text-xs text-right min-w-[60px]" placeholder="0.00" />
          </td>
        ) : (
          <td className={`px-3 py-2.5 text-right text-xs cursor-pointer hover:bg-blue-50/60 dark:hover:bg-blue-900/20 transition-colors ${BLUE_CLS}`}
            onClick={() => startEdit('suppliedPrice', netPriceVal)} title="Click to edit">
            <div className="flex items-center justify-end gap-1">
              {supplierPricing.length > 1 && (
                <button
                  onClick={e => { e.stopPropagation(); setExpanded(p => !p) }}
                  className="inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-blue-100 dark:bg-blue-900/40 text-blue-700 dark:text-blue-300 rounded-full text-xs font-semibold hover:bg-blue-200 dark:hover:bg-blue-800/40 transition-colors"
                >
                  {supplierPricing.length}
                  {expanded ? <ChevronDown className="w-2.5 h-2.5" /> : <ChevronRight className="w-2.5 h-2.5" />}
                </button>
              )}
              {firstIsBest && <span className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">Best</span>}
              <span className={`font-semibold ${firstIsBest ? 'text-emerald-700 dark:text-emerald-400' : 'text-gray-900 dark:text-gray-100'}`}>
                {netPriceVal != null ? `$${Number(netPriceVal).toFixed(2)}` : EMPTY}
              </span>
            </div>
          </td>
        )
      )}

      {vis('devType') && editTd('devType', devTypeVal,
        <DevTypeBadge type={devTypeVal} />,
        { isBlue: true, type: 'dropdown', options: DEV_TYPE_OPTIONS, className: 'px-3' }
      )}

      {vis('notes') && editTd('notes', supplierNotes,
        supplierNotes
          ? <span className="text-gray-600 truncate block max-w-[140px]" title={supplierNotes}>{supplierNotes}</span>
          : null,
        { isBlue: true, className: 'px-3 max-w-[160px]' }
      )}

      {vis('allw') && (
        <td className={`px-3 py-2.5 text-right text-emerald-700 dark:text-emerald-400 font-semibold text-xs ${BLUE_CLS}`}>
          {(firstEntry?.allw ?? pricing?.allw ?? item.allw) != null
            ? `$${Number(firstEntry?.allw ?? pricing?.allw ?? item.allw).toFixed(2)}` : EMPTY}
        </td>
      )}

      {vis('dl') && (
        <td className={`px-3 py-2.5 text-right text-blue-700 dark:text-blue-300 font-semibold text-xs ${BLUE_CLS}`}>
          {(firstEntry?.dl ?? pricing?.dl ?? item.dl) != null
            ? `$${Number(firstEntry?.dl ?? pricing?.dl ?? item.dl).toFixed(2)}` : EMPTY}
        </td>
      )}

      {vis('priceCase') && (
        <td className={`px-3 py-2.5 text-right font-bold text-xs text-exl-navy dark:text-blue-200 ${BLUE_CLS}`}>
          {(firstEntry?.priceCase ?? pricing?.price_case ?? item.priceCase) != null
            ? `$${Number(firstEntry?.priceCase ?? pricing?.price_case ?? item.priceCase).toFixed(2)}` : EMPTY}
        </td>
      )}

      {vis('openReview') && (
        <td className={`px-3 py-2.5 text-center text-xs font-semibold ${BLUE_CLS}`}>
          {firstEntry?.openReview === true || firstEntry?.openReview === 'Y' || pricing?.open_review === 'Y' || item.openReview === true
            ? <span className="text-amber-600 dark:text-amber-400">Y</span>
            : firstEntry?.openReview === 'N' || pricing?.open_review === 'N'
              ? <span className="text-gray-400 dark:text-gray-500">N</span>
              : EMPTY}
        </td>
      )}

      {vis('confidence') && (
        <td className={`px-3 py-2.5 ${BLUE_CLS}`}>
          <div className="flex items-center justify-end gap-1.5">
            <ConfidenceBadge confidence={conf} approved={approved} />
            {needsApprove && (
              <button onClick={() => onApprove(item.id)}
                className="px-2 py-0.5 bg-amber-500 hover:bg-amber-600 text-white text-xs font-bold rounded transition-colors">
                Approve
              </button>
            )}
            {needsReview && <span className="text-xs text-red-500 font-semibold">Review</span>}
          </div>
        </td>
      )}

      {/* PORTAL-TEMPLATE-START */}
      {portalCustomFields.map(field => {
        const value = firstEntry?.customFieldValues?.[field.id] || firstEntry?.customFields?.[field.id] || pricing?.customFieldValues?.[field.id] || pricing?.customFields?.[field.id] || ''
        return (
          <td key={field.id}
            className={`px-3 py-2.5 text-xs ${BLUE_CLS}`}
            style={{ minWidth: field.columnWidth || 100 }}>
            {value ? (
              field.type === 'yes_no' ? (
                <span className={value === 'Yes' ? 'text-green-600 dark:text-green-400 font-medium' : 'text-gray-400 dark:text-gray-500'}>
                  {value === 'Yes' ? '✓ Yes' : '✗ No'}
                </span>
              ) : (
                <span className="text-gray-700 dark:text-gray-300 truncate block" title={String(value)}>{value}</span>
              )
            ) : (
              <span className="text-gray-300 dark:text-gray-600">—</span>
            )}
          </td>
        )
      })}
      {/* PORTAL-TEMPLATE-END */}

      {/* ── Divider: Supplier → COE Internal ── */}
      {internalCols.length > 0 && (
        <td className={`py-2.5 w-px ${YELLOW_CLS}`}>
          <div className="w-px h-8 bg-amber-200 dark:bg-amber-800 mx-auto" />
        </td>
      )}

      {/* ── COE INTERNAL (yellow, configurable) ── */}
      {internalCols.map(col => {
        const rawVal  = internalValues?.[col.id] ?? ''
        const isEdit  = intEditField === col.id

        if (isEdit) {
          if (col.type === 'dropdown') {
            return (
              <td key={col.id} className={`px-2 py-1 text-xs ${YELLOW_CLS}`} style={{ borderBottom: '2px solid #E05A2B' }}>
                <select ref={intInputRef} value={intDraft} onChange={e => setIntDraft(e.target.value)}
                  onBlur={commitIntSave} onKeyDown={handleIntKey}
                  className="w-full bg-transparent outline-none text-xs">
                  {(col.options || []).map(o => <option key={o} value={o}>{o || '—'}</option>)}
                </select>
              </td>
            )
          }
          return (
            <td key={col.id} className={`px-2 py-1 text-xs ${YELLOW_CLS}`} style={{ borderBottom: '2px solid #E05A2B' }}>
              <input ref={intInputRef} type={col.type === 'number' ? 'number' : 'text'}
                step={col.type === 'number' ? '1' : undefined}
                value={intDraft} onChange={e => setIntDraft(e.target.value)}
                onBlur={commitIntSave} onKeyDown={handleIntKey}
                className="w-full bg-transparent outline-none text-xs min-w-[60px]" />
            </td>
          )
        }

        return (
          <td key={col.id}
            className={`px-3 py-2.5 text-xs cursor-pointer hover:bg-amber-50 dark:hover:bg-amber-900/20 transition-colors ${YELLOW_CLS}`}
            onClick={() => startIntEdit(col.id, rawVal)}
            title="Click to edit"
          >
            {col.id === 'awardDecision'
              ? (() => {
                  const syncedAward = supplierPricing.find(sp => sp.awardStatus === 'awarded')
                  if (syncedAward) return (
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold bg-teal-100 text-teal-700">
                      🏆 Awarded
                    </span>
                  )
                  return <AwardBadge value={rawVal} />
                })()
              : rawVal !== '' && rawVal != null
                ? <span className="text-gray-700">{String(rawVal)}</span>
                : EMPTY}
          </td>
        )
      })}

      {/* ── DELETE button cell — removes supplier pricing only, not the RFP item ── */}
      <td className="px-1 py-2 text-center bg-white dark:bg-[#1E293B]">
        {confirmDelete ? (
          <div className="flex items-center gap-1 justify-center">
            <button
              onClick={() => { setConfirmDelete(false); onRemoveSupplierPricing?.(0) }}
              className="px-1.5 py-0.5 text-xs font-semibold bg-red-600 hover:bg-red-700 text-white rounded transition-colors"
              title="Confirm remove"
            >
              Del
            </button>
            <button
              onClick={() => setConfirmDelete(false)}
              className="px-1.5 py-0.5 text-xs text-gray-500 hover:text-gray-800 border border-gray-300 rounded transition-colors"
              title="Cancel"
            >
              ✕
            </button>
          </div>
        ) : (
          <button
            onClick={() => setConfirmDelete(true)}
            className="p-1 text-gray-300 hover:text-red-500 rounded transition-colors"
            title="Remove supplier pricing"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        )}
      </td>
    </tr>

    {/* ── ADDITIONAL SUPPLIER SUB-ROWS ── */}
    {expanded && extraEntries.map((entry, idx) => {
      // actualIdx is the real index into supplierPricing (extraEntries is slice(1), so +1)
      const actualIdx = idx + 1
      const ep        = (() => { const p = parseFloat(entry.unitPrice ?? entry.casePrice); return isNaN(p) ? null : p })()
      const isBest    = bestPrice !== null && ep !== null && ep === bestPrice
      const isEditingSub = editingSubIdx === actualIdx
      return (
        <tr key={`sub-${item.id}-${idx}`} className={SUB_ROW_CLS} style={{ borderBottom: '1px solid #dbeafe' }}>
          {/* Spacer — left side (13 cols) + divider */}
          <td colSpan={14} className="bg-white dark:bg-[#1E293B]" style={{ borderBottom: '1px solid #f3f4f6' }} />

          {vis('supcRight') && (
            <td className={`px-2 py-2 text-xs font-mono ${SUB_ROW_CLS}`}>
              <span className="text-gray-300 italic">TBD</span>
            </td>
          )}
          {vis('brandRight') && (
            <td className={`px-2 py-2 text-xs ${SUB_ROW_CLS}`}>
              {entry.supplierBrand
                ? <span className="text-gray-700">{entry.supplierBrand}</span>
                : EMPTY}
            </td>
          )}
          {vis('descRight') && (
            <td className={`px-2 py-2 text-xs max-w-[180px] ${SUB_ROW_CLS}`}>
              <p className="text-gray-700 truncate" title={entry.supplierDescription || ''}>
                {entry.supplierDescription
                  ? entry.supplierDescription.length > 30
                    ? entry.supplierDescription.slice(0, 30) + '…'
                    : entry.supplierDescription
                  : EMPTY}
              </p>
            </td>
          )}
          {vis('trueVendor') && (
            <td className={`px-3 py-2 text-xs ${SUB_ROW_CLS}`}>
              <span className="font-medium text-gray-700">{entry.supplierName || EMPTY}</span>
            </td>
          )}
          {vis('suppliedPrice') && (
            isEditingSub ? (
              <td className={`px-2 py-1 text-xs ${SUB_ROW_CLS}`} style={{ borderBottom: '2px solid #E05A2B' }}>
                <input
                  ref={subInputRef}
                  type="number" step="0.01" min="0"
                  value={subDraft}
                  onChange={e => setSubDraft(e.target.value)}
                  onBlur={commitSubSave}
                  onKeyDown={handleSubKey}
                  className="w-full bg-transparent outline-none text-xs min-w-[60px] text-right"
                />
              </td>
            ) : (
              <td
                className={`px-3 py-2 text-right text-xs cursor-pointer hover:bg-blue-50/60 dark:hover:bg-blue-900/20 transition-colors ${SUB_ROW_CLS}`}
                onClick={() => startSubEdit(actualIdx, ep)}
                title="Click to edit"
              >
                <div className="flex items-center justify-end gap-1">
                  {isBest && <span className="text-xs text-emerald-600 font-semibold">Best</span>}
                  <span className={`font-semibold ${isBest ? 'text-emerald-700' : 'text-gray-700'}`}>
                    {ep != null ? `$${ep.toFixed(2)}` : EMPTY}
                  </span>
                </div>
              </td>
            )
          )}
          {vis('devType') && (
            <td className={`px-3 py-2 text-xs ${SUB_ROW_CLS}`}>
              <DevTypeBadge type={entry.devType} />
            </td>
          )}
          {vis('notes') && (
            <td className={`px-3 py-2 text-xs max-w-[160px] ${SUB_ROW_CLS}`}>
              {entry.notes
                ? <span className="text-gray-600 truncate block max-w-[140px]" title={entry.notes}>{entry.notes}</span>
                : EMPTY}
            </td>
          )}
          {/* allw/dl/priceCase/openReview — blank for sub-rows (aggregate/internal fields) */}
          {vis('allw')      && <td className={SUB_ROW_CLS} />}
          {vis('dl')        && <td className={SUB_ROW_CLS} />}
          {vis('priceCase') && <td className={SUB_ROW_CLS} />}
          {vis('openReview')&& <td className={SUB_ROW_CLS} />}
          {vis('confidence')&& (
            <td className={`px-3 py-2 ${SUB_ROW_CLS}`}>
              <div className="flex justify-end">
                <ConfidenceBadge confidence={entry.confidenceScore ?? null} approved={false} />
              </div>
            </td>
          )}

          {/* PORTAL-TEMPLATE-START — blank for sub-rows */}
          {portalCustomFields.map(field => <td key={field.id} className={SUB_ROW_CLS} />)}
          {/* PORTAL-TEMPLATE-END */}

          {/* COE internal — empty for sub-rows */}
          {internalCols.length > 0 && (
            <td colSpan={internalCols.length + 1} className={YELLOW_CLS} />
          )}
          {/* Delete column — remove this sub-row's supplier pricing entry */}
          <td className="px-1 bg-white dark:bg-[#1E293B]">
            <button
              onClick={() => onRemoveSupplierPricing?.(actualIdx)}
              className="p-1 text-gray-300 hover:text-red-500 rounded transition-colors"
              title="Remove this supplier pricing entry"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </td>
        </tr>
      )
    })}
    </>
  )
}

// ── Empty state ───────────────────────────────────────────
function WorkingFileEmptyState({ onUploadRFP }) {
  return (
    <EmptyState
      icon={FileSpreadsheet}
      title="No line items yet"
      description="Upload an Excel item list or RFP PDF in the RFP Documents section. BEX AI will automatically import all line items."
      action={{ label: 'Upload RFP with BEX AI', icon: Brain, onClick: onUploadRFP }}
      size="lg"
    />
  )
}

// ── Main WorkingFileTab ───────────────────────────────────
export default function WorkingFileTab({ bid, latestEvent, onCellFocus, onCellBlur }) {
  const navigate = useNavigate()
  const [lineItems,    setLineItems]    = useState([])
  const [loading,      setLoading]      = useState(true)
  const [toast,        setToast]        = useState(null)
  const [saveStatus,   setSaveStatus]   = useState(null)
  const [hasEdited,    setHasEdited]    = useState(false)
  const [approved,     setApproved]     = useState({})
  const [pricingMap,   setPricingMap]   = useState({})
  const [pendingEdits, setPendingEdits] = useState({})
  // lineId → list of user names currently editing that row (from presence_tab events)
  const [rowEditors, setRowEditors] = useState({})
  const saveTimerRef = useRef(null)

  // ── Column configuration state ────────────────────────────
  const [wfConfig, setWfConfig] = useState(() => {
    const saved = bid.workingFileConfig
    return {
      supplierColumns: enforceFixed(saved?.supplierColumns || DEFAULT_SUPPLIER_COLUMNS),
      internalColumns: saved?.internalColumns || DEFAULT_INTERNAL_COLUMNS,
    }
  })

  // ── Internal (COE) cell data per line item ─────────────────
  const [internalData, setInternalData] = useState({})

  // ── Customize panel visibility ────────────────────────────
  const [showCustomizePanel, setShowCustomizePanel] = useState(false)

  const showSaveStatus = (status) => {
    setSaveStatus(status)
    if (status === 'saved') {
      clearTimeout(saveTimerRef.current)
      saveTimerRef.current = setTimeout(() => setSaveStatus(null), 2000)
    }
  }

  // Fetch line items
  useEffect(() => {
    fetch(`/api/bids/${bid.id}/line-items`)
      .then(r => r.json())
      .then(data => {
        setLineItems(Array.isArray(data) ? data : [])

        const initApproved = {}
        const initPricing  = {}
        const initInternal = {}

        data.forEach(li => {
          if ((li.supplierPricing?.length ?? 0) > 0 && li.confidence != null && li.confidence >= 70) initApproved[li.id] = true
          if (li.suppliedPrice != null) {
            initPricing[li.id] = {
              supplier_name:  li.trueVendor || li.currentSupplier || '—',
              dev_type:       li.devType,
              supplied_price: li.suppliedPrice,
              allw:           li.allw,
              dl:             li.dl,
              price_case:     li.priceCase,
              open_review:    li.openReview ? 'Y' : 'N',
              confidence:     li.confidence,
            }
          }
          if (li.coeInternal) initInternal[li.id] = li.coeInternal
        })

        setApproved(initApproved)
        setPricingMap(initPricing)
        setInternalData(initInternal)
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [bid.id])

  // ── Real-time: merge incoming line item changes + track who's editing ──────
  useEffect(() => {
    if (!latestEvent) return
    const { type, lineId, fields } = latestEvent

    if (type === 'line_item_updated') {
      setLineItems(prev => prev.map(li => {
        if (li.id !== lineId) return li
        // If this row has unsaved local edits, mark conflict but don't overwrite
        if (pendingEdits[lineId]) return { ...li, _remoteConflict: true }
        return { ...li, ...fields, _remoteConflict: false }
      }))
    }
    if (type === 'line_item_deleted') {
      setLineItems(prev => prev.filter(li => li.id !== lineId))
    }
    // presence_tab with cellId tells us which row another user is focused on
    if (type === 'presence_tab' && latestEvent.tab === 'workingfile') {
      const user = latestEvent.user
      const cellId = latestEvent.cellId  // lineId of focused row, or null
      setRowEditors(prev => {
        const next = {}
        // Remove this user from all rows
        Object.keys(prev).forEach(k => {
          next[k] = (prev[k] || []).filter(u => u !== user)
        })
        // Add to their current row
        if (cellId) next[cellId] = [...(next[cellId] || []), user]
        return next
      })
    }
  }, [latestEvent])  // eslint-disable-line react-hooks/exhaustive-deps

  // ── Cell save handler (supplier side) — stages edits locally, no auto-save ────
  const handleCellSave = (lineId, field, value) => {
    const coerced = field === 'suppliedPrice' ? (value === '' ? null : Number(value)) : value

    // When supplierPricing[0] exists, the row derives trueVendor/netPrice/devType/notes
    // directly from supplierPricing[0], NOT from the flat li fields. We must update
    // supplierPricing[0] too, otherwise the display snaps back on re-render.
    const SP0 = {
      suppliedPrice: { unitPrice: coerced, casePrice: coerced },
      trueVendor:    { supplierName: value },
      devType:       { devType: value },
      notes:         { notes: value },
    }

    setLineItems(prev => prev.map(li => {
      if (li.id !== lineId) return li
      const updates = { [field]: coerced }
      if (SP0[field] && li.supplierPricing?.length > 0) {
        updates.supplierPricing = li.supplierPricing.map((entry, i) =>
          i === 0 ? { ...entry, ...SP0[field] } : entry
        )
      }
      return { ...li, ...updates }
    }))

    // Legacy pricingMap shadow — keep in sync
    if (field === 'trueVendor') {
      setPricingMap(prev => prev[lineId]
        ? { ...prev, [lineId]: { ...prev[lineId], supplier_name: value } }
        : prev)
    }
    if (field === 'suppliedPrice') {
      setPricingMap(prev => prev[lineId]
        ? { ...prev, [lineId]: { ...prev[lineId], supplied_price: coerced } }
        : prev)
    }
    if (field === 'devType') {
      setPricingMap(prev => prev[lineId]
        ? { ...prev, [lineId]: { ...prev[lineId], dev_type: value } }
        : prev)
    }

    // Stage for batch save — when supplierPricing[0] was updated, send the full array
    setPendingEdits(prev => {
      const existing = prev[lineId] || {}
      const currentItem = lineItems.find(li => li.id === lineId)
      if (SP0[field] && currentItem?.supplierPricing?.length > 0) {
        const basePricing = existing.supplierPricing ?? currentItem.supplierPricing ?? []
        const newPricing = basePricing.map((entry, i) =>
          i === 0 ? { ...entry, ...SP0[field] } : entry
        )
        return { ...prev, [lineId]: { ...existing, supplierPricing: newPricing } }
      }
      return { ...prev, [lineId]: { ...existing, [field]: coerced } }
    })
    setHasEdited(true)
  }

  // ── Sub-row price save handler (supplierPricing[idx].unitPrice) — staged ─────
  // actualIdx is the real index into supplierPricing (= extraEntries index + 1)
  const handleSubRowSave = (lineId, actualIdx, newPrice) => {
    const currentItem = lineItems.find(li => li.id === lineId)
    if (!currentItem) return
    const newPricing = (currentItem.supplierPricing || []).map((entry, i) =>
      i === actualIdx ? { ...entry, unitPrice: newPrice, casePrice: newPrice } : entry
    )
    setLineItems(prev => prev.map(li =>
      li.id === lineId ? { ...li, supplierPricing: newPricing } : li
    ))
    setPendingEdits(prev => ({
      ...prev,
      [lineId]: { ...(prev[lineId] || {}), supplierPricing: newPricing },
    }))
    setHasEdited(true)
  }

  // ── Delete line item handler ───────────────────────────────
  const handleDeleteItem = async (lineId) => {
    setLineItems(prev => prev.filter(li => li.id !== lineId))
    showSaveStatus('saving')
    try {
      await fetch(`/api/bids/${bid.id}/line-items/${lineId}`, { method: 'DELETE' })
      showSaveStatus('saved')
    } catch { showSaveStatus(null) }
  }

  // ── Remove one supplier pricing entry by index ─────────────
  const handleRemoveSupplierPricing = async (lineId, index) => {
    setLineItems(prev => prev.map(li => {
      if (li.id !== lineId) return li
      const newPricing = (li.supplierPricing || []).filter((_, i) => i !== index)
      const updates = { supplierPricing: newPricing }
      if (newPricing.length === 0) {
        Object.assign(updates, { trueVendor: null, suppliedPrice: null, devType: null, confidence: null, status: 'No Response' })
      } else if (index === 0) {
        const first = newPricing[0]
        Object.assign(updates, {
          trueVendor:    first.supplierName ?? null,
          suppliedPrice: first.unitPrice ?? first.casePrice ?? null,
          devType:       first.devType ?? null,
          confidence:    first.confidenceScore ?? null,
        })
      }
      return { ...li, ...updates }
    }))
    // When removing entry[0], clear both the legacy pricingMap shadow and the approved
    // flag — both are stale after entry[0] changes or all pricing is removed.
    if (index === 0) {
      setPricingMap(prev => {
        if (!prev[lineId]) return prev
        const next = { ...prev }
        delete next[lineId]
        return next
      })
      setApproved(prev => {
        if (!prev[lineId]) return prev
        const next = { ...prev }
        delete next[lineId]
        return next
      })
    }
    showSaveStatus('saving')
    try {
      await fetch(`/api/bids/${bid.id}/line-items/${lineId}/supplier-pricing?index=${index}`, { method: 'DELETE' })
      showSaveStatus('saved')
    } catch { showSaveStatus(null) }
  }

  // ── Internal cell save handler — staged ──────────────────
  const handleInternalSave = (lineId, colId, value) => {
    const updated = { ...(internalData[lineId] || {}), [colId]: value }
    setInternalData(prev => ({ ...prev, [lineId]: updated }))
    setPendingEdits(prev => ({
      ...prev,
      [lineId]: { ...(prev[lineId] || {}), coeInternal: updated },
    }))
    setHasEdited(true)
  }

  // ── Batch-save all staged edits ───────────────────────────
  const handleSaveAll = async () => {
    const entries = Object.entries(pendingEdits)
    if (entries.length === 0) return
    showSaveStatus('saving')
    try {
      await Promise.all(
        entries.map(([lineId, fields]) =>
          fetch(`/api/bids/${bid.id}/line-items/${lineId}`, {
            method:  'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify(fields),
          })
        )
      )
      setPendingEdits({})
      // Clear any conflict flags on rows that were just saved
      const savedIds = new Set(entries.map(([id]) => id))
      setLineItems(prev => prev.map(li =>
        savedIds.has(li.id) ? { ...li, _remoteConflict: false } : li
      ))
      showSaveStatus('saved')
    } catch {
      showSaveStatus(null)
      setToast('Save failed — please try again.')
    }
  }

  // ── Save column config to backend ─────────────────────────
  const saveConfig = async (newConfig) => {
    const safeConfig = {
      ...newConfig,
      supplierColumns: enforceFixed(newConfig.supplierColumns),
    }
    setWfConfig(safeConfig)
    setShowCustomizePanel(false)
    try {
      await fetch(`/api/bids/${bid.id}/working-file-config`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify(safeConfig),
      })
      setToast('Column configuration saved')
    } catch { /* silent */ }
  }

  // ── Derived values ────────────────────────────────────────
  const awardedCount = useMemo(() =>
    lineItems.filter(li => (li.supplierPricing || []).some(sp => sp.awardStatus === 'awarded')).length,
    [lineItems]
  )

  // ── Visible column helpers ────────────────────────────────
  const visibleSupplierCols    = useMemo(() => wfConfig.supplierColumns.filter(c => c.visible), [wfConfig])
  const visibleSupplierColIds  = useMemo(() => new Set(visibleSupplierCols.map(c => c.id)), [visibleSupplierCols])
  const supplierColLabel       = useMemo(() => Object.fromEntries(wfConfig.supplierColumns.map(c => [c.id, c.label])), [wfConfig])
  const visibleInternalCols    = useMemo(() => wfConfig.internalColumns.filter(c => c.visible), [wfConfig])

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <Loader className="w-6 h-6 animate-spin text-exl-orange" />
        <span className="ml-3 text-gray-500 text-sm">Loading working file…</span>
      </div>
    )
  }

  if (lineItems.length === 0) {
    return (
      <div className="card">
        <WorkingFileEmptyState onUploadRFP={() => navigate('/bex')} />
      </div>
    )
  }

  return (
    <div className="min-h-[400px]">
      {/* ── Customize Columns slide-in panel ── */}
      {showCustomizePanel && (
        <CustomizePanel
          config={wfConfig}
          onClose={() => setShowCustomizePanel(false)}
          onSave={saveConfig}
        />
      )}

      {/* ── Header ── */}
      <div className="flex items-center justify-between mb-1">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-base font-semibold text-gray-900">Working File</h2>
            {saveStatus === 'saving' && (
              <span className="text-xs text-gray-400 flex items-center gap-1">
                <Loader className="w-3 h-3 animate-spin" /> Saving…
              </span>
            )}
            {saveStatus === 'saved' && (
              <span className="text-xs text-emerald-600 flex items-center gap-1 font-medium">
                <CheckCircle className="w-3.5 h-3.5" /> Saved
              </span>
            )}
          </div>
          <p className="text-xs text-gray-500 mt-0.5">
            {lineItems.length} line items
            {' · '}
            {(() => {
              const src = lineItems[0]?._source || bid._lineItemSource
              if (src === 'excel') return 'Imported from Excel'
              if (src === 'pdf')   return 'Extracted from RFP PDF by AI'
              return bid.customer
            })()}
          </p>
          {Object.keys(pendingEdits).length > 0 ? (
            <p className="text-xs text-amber-600 dark:text-amber-400 mt-0.5">
              {Object.keys(pendingEdits).length} item{Object.keys(pendingEdits).length !== 1 ? 's' : ''} with unsaved changes
            </p>
          ) : !hasEdited ? (
            <p className="text-xs text-gray-400 mt-0.5 italic">Click any cell to edit, then Save Changes</p>
          ) : null}
        </div>
        <div className="flex items-center gap-2">
          {Object.keys(pendingEdits).length > 0 && (
            <button
              onClick={handleSaveAll}
              disabled={saveStatus === 'saving'}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-semibold text-white disabled:opacity-60 transition-opacity hover:opacity-90"
              style={{ backgroundColor: '#E05A2B' }}
            >
              <Save className="w-4 h-4" />
              Save {Object.keys(pendingEdits).length} change{Object.keys(pendingEdits).length !== 1 ? 's' : ''}
            </button>
          )}
          <Button
            variant="secondary"
            size="md"
            icon={Download}
            onClick={async () => {
              try {
                await exportXlsx(lineItems, internalData, wfConfig, bid.id, bid?.portalConfig?.customFields || [])
                setToast('Working file exported')
              } catch (e) {
                console.error('Export failed', e)
                setToast('Export failed')
              }
            }}
          >
            Export Excel
          </Button>
          <Button
            variant="ghost"
            size="md"
            icon={Settings}
            onClick={() => setShowCustomizePanel(true)}
          >
            Customize Columns
          </Button>
        </div>
      </div>

      {/* ── Summary bar ── */}
      {awardedCount > 0 && (
        <div className="flex items-center gap-4 bg-gray-50 dark:bg-[#1E293B] border border-gray-200 dark:border-gray-700 rounded-xl px-4 py-2.5 mb-4 text-sm mt-3">
          <span className="flex items-center gap-1.5 font-semibold text-teal-700">
            🏆 {awardedCount} of {lineItems.length} items awarded
          </span>
        </div>
      )}

      {/* ── Grid ── */}
      <div className="card overflow-hidden p-0">
        <div className="overflow-x-auto overflow-y-auto" style={{ maxHeight: 'calc(100vh - 280px)', contain: 'layout style', willChange: 'transform' }}>
          <table className="w-full text-xs min-w-[2200px]">
            <thead>
              {/* ── Section label row ── */}
              <tr className="border-b border-gray-100 sticky top-0 z-20">
                <th
                  colSpan={13}
                  className="px-3 py-1.5 text-left text-xs font-semibold text-gray-400 dark:text-gray-500 bg-gray-50 dark:bg-[#253347] tracking-wide uppercase"
                >
                  Customer RFP
                </th>
                <th className="bg-white dark:bg-[#1E293B] w-px" />
                <th
                  colSpan={visibleSupplierCols.length}
                  className={`px-3 py-1.5 text-left text-xs font-semibold tracking-wide uppercase text-[#1a6db5] dark:text-blue-300 ${BLUE_CLS}`}
                >
                  Supplier Responses
                </th>
                {visibleInternalCols.length > 0 && (
                  <>
                    <th className={`w-px ${YELLOW_CLS}`} />
                    <th
                      colSpan={visibleInternalCols.length}
                      className={`px-3 py-1.5 text-left text-xs font-semibold tracking-wide uppercase text-amber-700 dark:text-amber-400 ${YELLOW_CLS}`}
                    >
                      Bid COE Internal
                    </th>
                  </>
                )}
                <th className="w-8 bg-gray-50 dark:bg-[#253347]" />
              </tr>

              {/* ── Column header row ── */}
              <tr className="border-b-2 border-gray-200 sticky top-[30px] z-20">
                {/* Customer RFP — fixed */}
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-12 sticky left-0 z-30">Item #</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-400 bg-gray-50 w-20">
                  <span className="flex items-center gap-1" title="Internal product code — editable">
                    SUPC <span className="text-gray-300 text-xs font-normal italic">›item master</span>
                  </span>
                </th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-24">MPC Code</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-14">UOM</th>
                <th className="px-2 py-2.5 text-right font-semibold text-gray-500 bg-gray-50 w-16">Volume</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-16">Pack</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-20">Size</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-24">Brand</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 min-w-[160px]">Description</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-14">CA</th>
                <th className="px-2 py-2.5 text-center font-semibold text-gray-500 bg-gray-50 w-10">CW</th>
                <th className="px-2 py-2.5 text-center font-semibold text-gray-500 bg-gray-50 w-10">STK</th>
                <th className="px-2 py-2.5 text-left font-semibold text-gray-500 bg-gray-50 w-20">Flags</th>
                {/* Divider */}
                <th className="w-px bg-white dark:bg-[#1E293B]" />
                {/* Supplier Responses — configurable */}
                {visibleSupplierCols.map(col => {
                  const align =
                    col.id === 'suppliedPrice' || col.id === 'allw' || col.id === 'dl' || col.id === 'priceCase' ? 'text-right' :
                    col.id === 'openReview' || col.id === 'confidence' ? 'text-center' :
                    'text-left'
                  return (
                    <th key={col.id}
                      className={`px-2 py-2.5 font-semibold ${align} text-[#1a6db5] dark:text-blue-300 ${BLUE_CLS}`}>
                      {supplierColLabel[col.id] || col.label}
                    </th>
                  )
                })}
                {/* PORTAL-TEMPLATE-START */}
                {(bid?.portalConfig?.customFields || []).filter(f => f.showInWorkingFile).map(field => (
                  <th key={field.id}
                    className={`px-3 py-2.5 text-left font-semibold whitespace-nowrap text-[#1a6db5] dark:text-blue-300 ${BLUE_CLS}`}
                    style={{ minWidth: field.columnWidth || 100 }}>
                    {field.label}
                  </th>
                ))}
                {/* PORTAL-TEMPLATE-END */}
                {/* COE Internal — configurable */}
                {visibleInternalCols.length > 0 && <th className={`w-px ${YELLOW_CLS}`} />}
                {visibleInternalCols.map(col => (
                  <th key={col.id}
                    className={`px-3 py-2.5 text-left font-semibold whitespace-nowrap text-amber-700 dark:text-amber-400 ${YELLOW_CLS}`}>
                    {col.label}
                  </th>
                ))}
                {/* Delete column */}
                <th className="w-8 px-1 bg-gray-50 dark:bg-[#253347]" />
              </tr>
            </thead>
            <tbody>
              {lineItems.map(li => (
                <WorkingFileRow
                  key={li.id}
                  item={li}
                  pricing={pricingMap[li.id] ?? null}
                  approved={approved[li.id] ?? false}
                  onApprove={(id) => setApproved(prev => ({ ...prev, [id]: true }))}
                  onCellSave={(field, value) => handleCellSave(li.id, field, value)}
                  onSubRowSave={(actualIdx, newPrice) => handleSubRowSave(li.id, actualIdx, newPrice)}
                  onDeleteItem={() => handleDeleteItem(li.id)}
                  onRemoveSupplierPricing={(index) => handleRemoveSupplierPricing(li.id, index)}
                  visibleSupplierColIds={visibleSupplierColIds}
                  supplierColLabel={supplierColLabel}
                  internalCols={visibleInternalCols}
                  internalValues={internalData[li.id] || {}}
                  onInternalSave={(colId, value) => handleInternalSave(li.id, colId, value)}
                  portalCustomFields={(bid?.portalConfig?.customFields || []).filter(f => f.showInWorkingFile)}
                  remoteEditors={rowEditors[li.id] || []}
                  onCellFocus={() => onCellFocus?.(li.id)}
                  onCellBlur={onCellBlur}
                />
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ── Toast ── */}
      {toast && (
        <div className="fixed bottom-6 right-6 z-50 bg-emerald-700 text-white text-sm font-medium px-4 py-3 rounded-xl shadow-lg flex items-center gap-2">
          <CheckCircle className="w-4 h-4" /> {toast}
          <button onClick={() => setToast(null)} className="ml-2 opacity-70 hover:opacity-100">×</button>
        </div>
      )}
    </div>
  )
}
