import React, { useState, useEffect, useMemo, useRef } from 'react'
import { createPortal } from 'react-dom'
import { X, CheckCircle, AlertTriangle, XCircle, Loader, FileSpreadsheet, Info, FileText, Mail, Pencil, Flag } from 'lucide-react'

// ── Source badge ──────────────────────────────────────────
function SourceBadge({ sourceUsed, sourceFileName }) {
  if (sourceUsed === 'pdf' || sourceUsed === 'xlsx' || sourceUsed === 'csv') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-blue-700 bg-blue-50 border border-blue-200 px-2.5 py-1 rounded-full">
        <FileText className="w-3.5 h-3.5" />
        Prices extracted from {sourceUsed.toUpperCase()} — {sourceFileName || 'attachment'}
      </span>
    )
  }
  if (sourceUsed === 'email') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-full">
        <Mail className="w-3.5 h-3.5" />
        Prices extracted from email body (no attachment found on disk)
      </span>
    )
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-gray-500 bg-gray-100 border border-gray-200 px-2.5 py-1 rounded-full">
      ⚠ No source document found
    </span>
  )
}

// ── Confidence config ─────────────────────────────────────
const CONF_CFG = {
  high:   { label: 'High',     dot: 'bg-emerald-500', bar: 'bg-emerald-500', badge: 'bg-emerald-100 text-emerald-700', text: 'text-emerald-700' },
  medium: { label: 'Medium',   dot: 'bg-amber-400',   bar: 'bg-amber-400',   badge: 'bg-amber-100  text-amber-700',   text: 'text-amber-700'   },
  low:    { label: 'Low',      dot: 'bg-orange-500',  bar: 'bg-orange-500',  badge: 'bg-orange-100 text-orange-700',  text: 'text-orange-700'  },
  none:   { label: 'No Match', dot: 'bg-red-400',     bar: 'bg-red-400',     badge: 'bg-red-100    text-red-600',     text: 'text-red-600'     },
  manual: { label: 'Manual',   dot: 'bg-blue-500',    bar: 'bg-blue-500',    badge: 'bg-blue-100   text-blue-700',    text: 'text-blue-700'    },
}

function getConf(row) {
  if (row.matchSource === 'manual') return { score: 100, label: 'manual', cfg: CONF_CFG.manual }
  const score = row.confidenceScore ?? row.matchScore ?? 0
  // Always derive the label from the numeric score so the color/label and the shown
  // number can never disagree (row.confidence may be non-canonical: "High", "", a number…).
  const label = score >= 70 ? 'high' : score >= 40 ? 'medium' : 'low'
  return { score, label, cfg: CONF_CFG[label] ?? CONF_CFG.none }
}

// ── Bid Item Selector (per row) ───────────────────────────
// High AI match: pill + hover edit icon → click opens dropdown
// Medium/Low/None: dropdown always visible
// Manually matched: blue pill + hover edit icon
function BidItemSelector({ row, bidLineItems, onSelect }) {
  const [editing, setEditing] = useState(false)
  const { label } = getConf(row)
  const isManual   = row.matchSource === 'manual'
  const hasAIMatch = !!row.matchedDescription && !isManual
  // High confidence with no resolved match also shows dropdown immediately so user can pick
  const showImmediately = label === 'medium' || label === 'low'
                       || (label === 'high' && !hasAIMatch)

  // Group by category for <optgroup>
  const grouped = {}
  ;(bidLineItems || []).forEach(li => {
    const cat = li.category || 'Other'
    if (!grouped[cat]) grouped[cat] = []
    grouped[cat].push(li)
  })

  const handleChange = (e) => {
    const val = e.target.value
    if (!val) { onSelect(null) }
    else {
      // Resolve by the unique line-item id — bidItem can be numeric/zero-padded/duplicated,
      // which made strict-equality lookups silently miss and drop the selection.
      const li = (bidLineItems || []).find(item => String(item.id) === val)
      if (li) onSelect(li)
    }
    setEditing(false)
  }

  // ── Manually matched pill ─────────────────────────────────
  if (isManual && !editing) {
    return (
      <div className="group flex items-center gap-1.5 cursor-pointer" onClick={() => setEditing(true)}>
        <CheckCircle className="w-3 h-3 text-blue-500 flex-shrink-0" />
        <span className="text-xs font-semibold text-blue-700 truncate max-w-[130px]"
              title={row.matchedDescription}>
          {row.matchedBidItemNo} · {row.matchedDescription?.slice(0, 28)}
        </span>
        <Pencil className="w-2.5 h-2.5 text-gray-300 group-hover:text-blue-400 transition-colors flex-shrink-0" />
      </div>
    )
  }

  // ── High confidence AI match pill ────────────────────────
  if (!showImmediately && !editing && hasAIMatch) {
    const cfg = CONF_CFG[label] || CONF_CFG.high
    return (
      <div className="group flex items-center gap-1.5 cursor-pointer" onClick={() => setEditing(true)}>
        <span className={`w-2 h-2 rounded-full flex-shrink-0 ${cfg.dot}`} />
        <span className={`text-xs font-medium truncate max-w-[130px] ${cfg.text}`}
              title={row.matchedDescription}>
          {row.matchedBidItemNo} · {row.matchedDescription?.slice(0, 28)}
        </span>
        <Pencil className="w-2.5 h-2.5 text-gray-300 group-hover:text-gray-500 transition-colors flex-shrink-0" />
      </div>
    )
  }

  // ── Dropdown (medium / low / none / editing) ─────────────
  const borderCls = label === 'none'                    ? 'border-red-300 focus:ring-red-300'
                  : label === 'low'                     ? 'border-orange-300 focus:ring-orange-300'
                  : label === 'medium'                  ? 'border-amber-300 focus:ring-amber-300'
                  : (label === 'high' && !hasAIMatch)   ? 'border-amber-300 focus:ring-amber-300'
                  : 'border-blue-300 focus:ring-blue-400'  // editing

  const noMatchLabel = (label === 'high' || label === 'medium') && !hasAIMatch
    ? 'Select match…'
    : '— No match —'

  return (
    <select
      value={row.lineItemId || ''}
      onChange={handleChange}
      onBlur={() => setEditing(false)}
      // eslint-disable-next-line jsx-a11y/no-autofocus
      autoFocus={editing}
      className={`w-full text-xs px-2 py-1.5 border ${borderCls} rounded-lg
                  focus:outline-none focus:ring-1 bg-white cursor-pointer`}
    >
      <option value="">{noMatchLabel}</option>
      {Object.entries(grouped)
        .sort(([a], [b]) => a.localeCompare(b))
        .map(([cat, items]) => (
          <optgroup key={cat} label={`── ${cat} ──`}>
            {items.map(li => (
              <option key={li.id} value={li.id}>
                {li.bidItem} · {(li.description || '').slice(0, 45)}
              </option>
            ))}
          </optgroup>
        ))}
    </select>
  )
}

// ── Confidence cell ───────────────────────────────────────
function ConfidenceCell({ row }) {
  const { score, label, cfg } = getConf(row)
  const reasons = row.confidenceReasons || []
  const missed  = row.missedReasons    || []
  const hasTooltip = reasons.length > 0 || missed.length > 0
  const anchorRef = useRef(null)
  const [tipPos, setTipPos] = useState(null)

  const showTip = () => {
    if (!hasTooltip || !anchorRef.current) return
    const r = anchorRef.current.getBoundingClientRect()
    setTipPos({ top: r.top + window.scrollY, left: r.left + window.scrollX, width: r.width })
  }
  const hideTip = () => setTipPos(null)

  // Manual match — simplified blue badge, no bar
  if (label === 'manual') {
    return (
      <td className="px-3 py-2.5 min-w-[110px]">
        <span className="inline-flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded bg-blue-100 text-blue-700">
          <CheckCircle className="w-3 h-3" /> Manually matched
        </span>
        {row.aiSuggestedDesc && (
          <p className="text-xs text-gray-400 mt-0.5 line-through truncate"
             title={`AI suggested: ${row.aiSuggestedDesc}`}>
            AI: {row.aiSuggestedDesc?.slice(0, 22)}
          </p>
        )}
      </td>
    )
  }

  return (
    <td className="px-3 py-2.5 min-w-[110px]">
      <div ref={anchorRef} onMouseEnter={showTip} onMouseLeave={hideTip}>
        {/* Badge + score */}
        <div className="flex items-center gap-1.5 mb-1">
          <span className={`w-2 h-2 rounded-full flex-shrink-0 ${cfg.dot}`} />
          <span className={`text-xs font-semibold px-1.5 py-0.5 rounded ${cfg.badge}`}>
            {cfg.label}
          </span>
          <span className={`text-xs font-bold ml-auto ${cfg.text}`}>{score}</span>
        </div>
        {/* Progress bar */}
        <div className="w-full bg-gray-100 rounded-full h-1">
          <div className={`h-1 rounded-full transition-all ${cfg.bar}`}
               style={{ width: `${Math.min(100, score)}%` }} />
        </div>
      </div>
      {/* Portal tooltip — rendered at document.body to escape overflow:hidden ancestors */}
      {tipPos && hasTooltip && createPortal(
        <div
          className="pointer-events-none"
          style={{
            position: 'absolute',
            top:  tipPos.top - 8,
            left: tipPos.left,
            width: 256,
            transform: 'translateY(-100%)',
            zIndex: 99999,
          }}
        >
          <div className="bg-gray-900 text-white text-xs rounded-xl shadow-xl px-3 py-2.5">
            <p className="font-semibold mb-1.5 text-gray-200">
              Confidence{score != null ? `: ${score}/100` : ''}
            </p>
            <ul className="space-y-0.5">
              {reasons.map((r, i) => (
                <li key={`m${i}`} className="flex items-start gap-1.5">
                  <span className="text-emerald-400 flex-shrink-0">✓</span>
                  <span className="text-gray-300 leading-snug">{r}</span>
                </li>
              ))}
              {missed.map((r, i) => (
                <li key={`u${i}`} className="flex items-start gap-1.5">
                  <span className="text-gray-500 flex-shrink-0">✗</span>
                  <span className="text-gray-500 leading-snug">{r}</span>
                </li>
              ))}
            </ul>
          </div>
          <div className="w-2.5 h-2.5 bg-gray-900 rotate-45 ml-4 -mt-1.5 rounded-sm" />
        </div>,
        document.body
      )}
    </td>
  )
}

// ── Confidence + match summary ────────────────────────────
function MatchSummary({ rows }) {
  const counts  = { high: 0, medium: 0, low: 0, none: 0, manual: 0 }
  let totalScore = 0
  rows.forEach(r => {
    const { score, label } = getConf(r)
    counts[label] = (counts[label] || 0) + 1
    if (label !== 'manual') totalScore += score
  })
  const aiCount  = counts.high + counts.medium + counts.low
  const avgScore = aiCount > 0 ? Math.min(100, Math.round(totalScore / aiCount)) : 0

  return (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-gray-600">
      <span>
        <span className="font-semibold text-gray-800">{rows.length}</span> items extracted
        {aiCount > 0 && <>{' · '}Avg confidence: <span className="font-semibold text-gray-800">{avgScore}%</span></>}
      </span>
      <div className="flex items-center gap-3 flex-wrap">
        {['high','medium','low','none','manual'].map(lbl => {
          const n = counts[lbl] || 0
          if (!n) return null
          const cfg = CONF_CFG[lbl]
          return (
            <span key={lbl} className="flex items-center gap-1">
              <span className={`w-2 h-2 rounded-full flex-shrink-0 ${cfg.dot}`} />
              <span className={`font-semibold ${cfg.text}`}>{n}</span>
              <span className="text-gray-400">{cfg.label}</span>
            </span>
          )
        })}
      </div>
    </div>
  )
}

// ── Modal ─────────────────────────────────────────────────
export default function PricingExtractModal({ bid, result, onClose, onSaved }) {
  const isSchawns = result.isSchawnsFormat === true || result.contractType === 'Billback-Case Price'

  // Fetch bid line items for the dropdown
  const [bidLineItems, setBidLineItems] = useState([])
  useEffect(() => {
    if (!bid?.id) return
    fetch(`/api/bids/${bid.id}/line-items`)
      .then(r => r.ok ? r.json() : [])
      .then(items => setBidLineItems(Array.isArray(items) ? items : []))
      .catch(() => setBidLineItems([]))
  }, [bid?.id])

  // Initialise rows — track matchSource and auto-check by confidence
  const initialRows = (result.items || []).map(item => {
    const { label } = getConf(item)
    const autoCheck = label === 'high' || (!!item.lineItemId && label === 'medium')
    return {
      ...item,
      matchSource: 'ai',
      included:    autoCheck,
      netEdited:   item.unitPrice       != null ? String(item.unitPrice)
                 : item.netPrice        != null ? String(item.netPrice)
                 : item.commercialPrice != null ? String(item.commercialPrice)
                 : '',
      // Preserve original AI suggestion for tooltip if overridden later
      aiSuggestedDesc: item.matchedDescription || null,
    }
  })

  const [rows,               setRows]               = useState(initialRows)
  const [saving,             setSaving]             = useState(false)
  const [error,              setError]              = useState(null)
  const [markConsideration,  setMarkConsideration]  = useState(false)

  // ── Drag state ────────────────────────────────────────────
  const dragState = useRef({ dragging: false, startX: 0, startY: 0, origX: 0, origY: 0 })
  const [offset,  setOffset]  = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)

  const onHeaderMouseDown = (e) => {
    if (e.target.closest('button')) return   // don't drag when clicking × button
    dragState.current = { dragging: true, startX: e.clientX, startY: e.clientY, origX: offset.x, origY: offset.y }
    setIsDragging(true)
    e.preventDefault()
  }

  useEffect(() => {
    const onMouseMove = (e) => {
      if (!dragState.current.dragging) return
      setOffset({
        x: dragState.current.origX + e.clientX - dragState.current.startX,
        y: dragState.current.origY + e.clientY - dragState.current.startY,
      })
    }
    const onMouseUp = () => {
      dragState.current.dragging = false
      setIsDragging(false)
    }
    window.addEventListener('mousemove', onMouseMove)
    window.addEventListener('mouseup',   onMouseUp)
    return () => {
      window.removeEventListener('mousemove', onMouseMove)
      window.removeEventListener('mouseup',   onMouseUp)
    }
  }, [])

  // ── Row mutators ──────────────────────────────────────────
  const toggleRow  = (i)      => setRows(p => p.map((r, idx) => idx === i ? { ...r, included: !r.included } : r))
  const updateNet  = (i, val) => setRows(p => p.map((r, idx) => idx === i ? { ...r, netEdited: val }        : r))
  const toggleAll  = ()       => { const on = rows.every(r => r.included); setRows(p => p.map(r => ({ ...r, included: !on }))) }

  const updateMatch = (rowIdx, bidItem) => {
    setRows(p => p.map((r, idx) => {
      if (idx !== rowIdx) return r
      if (!bidItem) {
        // Clear — revert to AI state
        return { ...r, lineItemId: null, matchedDescription: null, matchedBidItemNo: null, matchSource: 'ai' }
      }
      return {
        ...r,
        lineItemId:          bidItem.id,
        matchedDescription:  bidItem.description,
        matchedBidItemNo:    bidItem.bidItem,
        matchSource:         'manual',
        confidence:          'manual',
        confidenceScore:     100,
        manuallyMatchedAt:   new Date().toISOString(),
        included:            true,   // auto-check when manually matched
      }
    }))
  }

  // ── Derived counts ────────────────────────────────────────
  const checkedCount     = rows.filter(r => r.included).length
  const savableCount     = rows.filter(r => r.included && r.lineItemId).length
  const unmatchedChecked = rows.filter(r => r.included && !r.lineItemId).length
  const hasLowUnchecked  = rows.some(r => {
    const { label } = getConf(r)
    return !r.included && (label === 'low' || label === 'none') && r.lineItemId
  })

  // Detect duplicate matches: multiple rows assigned to the same bid line item
  // Build a map of lineItemId → [rowIndices] for included rows that have a match
  const duplicateMap = useMemo(() => {
    const map = {}  // lineItemId → [rowIdx, ...]
    rows.forEach((r, i) => {
      if (!r.lineItemId || !r.included) return
      if (!map[r.lineItemId]) map[r.lineItemId] = []
      map[r.lineItemId].push(i)
    })
    // Keep only lineItemIds that appear more than once
    const dupes = {}
    Object.entries(map).forEach(([lid, idxs]) => {
      if (idxs.length > 1) dupes[lid] = idxs
    })
    return dupes   // { lineItemId: [rowIdx, rowIdx, ...] }
  }, [rows])

  // ── Save ──────────────────────────────────────────────────
  const handleSave = async () => {
    const selected = rows.filter(r => r.included)
    if (!selected.length) { setError('No items selected'); return }
    setSaving(true); setError(null)
    try {
      const currentItems = await fetch(`/api/bids/${bid.id}/line-items`).then(r => r.json())
      // Sequential (not parallel) to avoid PATCH race when multiple rows share the same lineItemId.
      // The backend also does append-merge, but serial writes make the ordering deterministic.
      for (const row of selected) {
        const deliveredPrice = parseFloat(row.netEdited) || null
        const suppliedPrice  = deliveredPrice ?? row.commercialPrice ?? null

        const newEntry = {
          supplierName:        result.supplierName,
          supplierEmail:       result.supplierEmail,
          // Supplier's own product data — stored separately from bid line item fields
          supplierBrand:       row.brand           || '',
          supplierDescription: row.description     || '',
          supplierItemNo:      row.supplierItemNo  || row.bidItemNo || '',
          casePrice:           suppliedPrice,
          unitPrice:           suppliedPrice,
          fobPrice:            row.fobPrice        ?? null,
          freightAmount:       row.freightAmount   ?? null,
          commercialPrice:     row.commercialPrice ?? null,
          ptvValue:            row.ptvValue        ?? null,
          devType:             row.devType         || null,
          notes:               row.notes           || '',
          extractedAt:         new Date().toISOString(),
          extractedFrom:       result.sourceUsed   || 'xlsx',
          sourceFileName:      result.sourceFileName || '',
          emailId:             result.emailId,
          contractType:        result.contractType  || '',
          validFrom:           result.validFrom     || '',
          validTo:             result.validTo       || '',
          confidence:          row.confidence       || null,
          confidenceScore:     row.confidenceScore  ?? null,
          matchSource:         row.matchSource      || 'ai',
          manuallyMatchedAt:   row.manuallyMatchedAt || null,
        }

        if (row.lineItemId) {
          // Send only the new entry — the backend PATCH handler appends/merges
          // into the existing supplierPricing array rather than replacing it.
          // This is safe for concurrent saves to the same line item.
          await fetch(`/api/bids/${bid.id}/line-items/${row.lineItemId}`, {
            method:  'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({
              trueVendor:      result.supplierName,
              suppliedPrice,
              status:          suppliedPrice != null ? 'Priced' : 'No Response',
              confidence:      row.confidenceScore ?? null,
              matchSource:     row.matchSource || 'ai',
              supplierPricing: [newEntry],   // backend appends — don't pre-merge here
            }),
          })
        }
      }
      // Create/update submission record in bids + bid_line_items (email extractions only)
      const savedRows = selected.filter(r => r.lineItemId)
      if (result.emailId && savedRows.length > 0) {
        fetch(`/api/submit/${bid.id}/submissions/from-extraction`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            supplierName:  result.supplierName,
            supplierEmail: result.supplierEmail || '',
            emailId:       result.emailId,
            pricingFile:   result.sourceFileName || '',
            lineItems: savedRows.map(row => ({
              id:          row.lineItemId,
              bidItem:     row.matchedBidItemNo || '',
              description: row.matchedDescription || row.description || '',
              casePrice:   parseFloat(row.netEdited) || null,
              unitPrice:   parseFloat(row.netEdited) || null,
              devType:     row.devType || null,
              noBid:       !row.netEdited,
            })),
          }),
        }).catch(err => console.warn('Submission record creation failed (non-critical):', err))
      }

      // Optionally flag supplier Under Consideration
      if (markConsideration) {
        try {
          const bidRes    = await fetch(`/api/bids/${bid.id}`)
          const latestBid = await bidRes.json()
          const today     = new Date().toISOString().split('T')[0]
          const supplierName = (result.supplierName || '').toLowerCase()
          const updatedSuppliers = (latestBid.solicitedSuppliers || []).map(s => {
            const nameMatch = s.supplierName?.toLowerCase().includes(supplierName) ||
                              supplierName.includes(s.supplierName?.toLowerCase() || '')
            const emailMatch = result.supplierEmail && s.email && s.email === result.supplierEmail
            if (!nameMatch && !emailMatch) return s
            return { ...s, inConsideration: true, status: 'In Consideration', lastActivity: today }
          })
          await fetch(`/api/bids/${bid.id}`, {
            method:  'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body:    JSON.stringify({ solicitedSuppliers: updatedSuppliers }),
          })
        } catch { /* best-effort */ }
      }

      onSaved(savableCount, result.supplierName, markConsideration)
    } catch (err) {
      setError(err.message)
    } finally {
      setSaving(false)
    }
  }

  // Show a "File" column when results came from multiple files
  const isMultiFile = result.multiFile === true || rows.some(r => r.sourceFile)
  const sourceFiles = isMultiFile ? [...new Set(rows.map(r => r.sourceFile).filter(Boolean))] : []

  // ── Render ────────────────────────────────────────────────
  return createPortal(
    <div style={{ position: 'fixed', top: 0, left: 0, width: '100vw', height: '100vh', backgroundColor: 'rgba(0,0,0,0.5)', zIndex: 9999, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '16px' }}>
      <div
        style={{ minWidth: '480px', minHeight: '300px', maxWidth: '90vw', maxHeight: '90vh', display: 'flex', flexDirection: 'column', resize: 'both', overflow: 'hidden', transform: `translate(${offset.x}px, ${offset.y}px)`, borderRadius: '1rem', boxShadow: '0 25px 50px -12px rgba(0,0,0,0.25)' }}
      >
      <div
        className="bg-white w-full rounded-2xl shadow-2xl flex flex-col"
        style={{ width: '100%', flex: '1 1 auto', minHeight: 0, overflow: 'hidden' }}
      >

        {/* Header — draggable */}
        <div
          className="flex items-center justify-between px-6 py-4 bg-exl-navy flex-shrink-0"
          style={{ cursor: isDragging ? 'grabbing' : 'grab' }}
          onMouseDown={onHeaderMouseDown}
        >
          <div>
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="w-4 h-4 text-exl-orange" />
              <h3 className="text-white font-bold text-sm">Pricing Extraction Preview</h3>
            </div>
            <p className="text-white/60 text-xs mt-0.5">
              Review AI-extracted pricing before saving to Working File
              {' · '}{result.supplierName}{' · '}{bid.id}
              {markConsideration && (
                <span className="text-[#E05A2B] font-semibold ml-1">· 🚩 Will be marked Under Consideration</span>
              )}
            </p>
          </div>
          <button onClick={onClose} className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 min-h-0 overflow-y-auto">

          {/* Source badge + match summary */}
          <div className="mx-6 mt-5 flex flex-col gap-2.5">
            <SourceBadge sourceUsed={result.sourceUsed} sourceFileName={result.sourceFileName} />

            {rows.length > 0 && (
              <div className="px-4 py-3 rounded-xl border border-gray-200 bg-gray-50/60">
                <MatchSummary rows={rows} />
              </div>
            )}

            {/* Schwan's contract info */}
            {isSchawns && result.contractType && (
              <div className="flex items-start gap-2.5 px-4 py-3 rounded-xl border"
                style={{ backgroundColor: '#EBF3FB', borderColor: '#BFD7EE' }}>
                <Info className="w-4 h-4 flex-shrink-0 mt-0.5 text-blue-600" />
                <p className="text-sm text-blue-900">
                  <span className="font-semibold">📊 {result.contractType}</span>
                  {result.validFrom && result.validTo && ` · Valid ${result.validFrom}–${result.validTo}`}
                  {` · ${rows.length} items`}
                  {result.analystName  && ` · ${result.analystName}`}
                  {result.analystPhone && ` · ${result.analystPhone}`}
                  {result.summary && <><br /><span className="text-blue-700 text-xs">{result.summary}</span></>}
                </p>
              </div>
            )}

            {/* Standard AI summary */}
            {!isSchawns && result.summary && (
              <div className="flex items-start gap-2.5 px-4 py-3 rounded-xl border"
                style={{ backgroundColor: '#EBF3FB', borderColor: '#BFD7EE' }}>
                <Info className="w-4 h-4 flex-shrink-0 mt-0.5 text-blue-600" />
                <p className="text-sm text-blue-900">{result.summary}</p>
              </div>
            )}
          </div>

          {/* Table */}
          <div className="px-6 pt-4 pb-2">
            {result.warning && rows.length > 0 && (
              <div className="mb-3 p-3 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-700 rounded-lg flex gap-2 text-xs text-amber-800 dark:text-amber-300">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span>{result.warning}</span>
              </div>
            )}
            {rows.length === 0 ? (
              <div className="text-center py-10 text-gray-400 text-sm">
                <p className="font-medium text-gray-500 dark:text-gray-400 mb-1">No priced items found in the source document</p>
                {result.error
                  ? <p className="text-xs text-red-500 mt-1 max-w-sm mx-auto break-words">{result.error}</p>
                  : result.documentNote
                    ? <p className="text-xs text-amber-600 dark:text-amber-400 mt-1 max-w-sm mx-auto break-words">{result.documentNote}</p>
                    : result.fileDiagnostics?.length > 0
                      ? <div className="mt-2 space-y-1">
                          {result.fileDiagnostics.map((d, i) => (
                            <p key={i} className={`text-xs max-w-sm mx-auto break-words ${d.error ? 'text-red-500' : 'text-amber-600 dark:text-amber-400'}`}>
                              <span className="font-medium">{d.file}:</span> {d.error || d.documentNote || d.warning}
                            </p>
                          ))}
                        </div>
                      : <p className="text-xs">Check that the attachment is a pricing document with item data.</p>
                }
              </div>
            ) : (
              <div className="border border-gray-200 rounded-xl overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200">
                      <th className="px-3 py-2.5 text-left w-8">
                        <input type="checkbox"
                          checked={rows.length > 0 && rows.every(r => r.included)}
                          onChange={toggleAll} className="rounded border-gray-300" />
                      </th>
                      {isSchawns ? (
                        <>
                          <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">RFP Item #</th>
                          <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">FC Code</th>
                          <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Description</th>
                          <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide">FOB $/cs</th>
                          <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide">Freight</th>
                          <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide">Delivered $/cs</th>
                          <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide">Qty</th>
                        </>
                      ) : (
                        <>
                          <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Description</th>
                          <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide">Supplier Item #</th>
                          <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide">Commercial $/cs</th>
                          <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide">PTV $</th>
                          <th className="px-3 py-2.5 text-right text-xs font-semibold text-gray-500 uppercase tracking-wide">Net $/cs</th>
                        </>
                      )}
                      {isMultiFile && (
                        <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide max-w-[120px]">
                          File
                        </th>
                      )}
                      <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide w-44">
                        Matched RFP Item
                      </th>
                      <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-500 uppercase tracking-wide min-w-[110px]">
                        Match Confidence
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {rows.map((row, i) => {
                      const isManualRow = row.matchSource === 'manual'
                      return (
                        <tr key={i} className={`transition-colors ${
                          row.included
                            ? isManualRow ? 'bg-blue-50/20' : 'bg-white'
                            : 'bg-gray-50 opacity-50'
                        }`}>
                          <td className="px-3 py-2.5">
                            <input type="checkbox" checked={row.included} onChange={() => toggleRow(i)} className="rounded border-gray-300" />
                          </td>

                          {isSchawns ? (
                            <>
                              <td className="px-3 py-2.5 font-mono text-xs font-semibold text-gray-700">{row.bidItemNo || '—'}</td>
                              <td className="px-3 py-2.5 font-mono text-xs text-gray-500">{row.syscoProductCode || '—'}</td>
                              <td className="px-3 py-2.5 text-xs text-gray-900 max-w-[180px]">
                                <p className="font-medium truncate" title={row.description}>{row.description}</p>
                                {row.notes && <p className="text-gray-400 text-xs truncate" title={row.notes}>{row.notes}</p>}
                              </td>
                              <td className="px-3 py-2.5 text-right text-xs text-gray-400">
                                {row.fobPrice != null ? `$${Number(row.fobPrice).toFixed(2)}` : '—'}
                              </td>
                              <td className="px-3 py-2.5 text-right text-xs text-gray-400">
                                {row.freightAmount != null ? `$${Number(row.freightAmount).toFixed(2)}` : '—'}
                              </td>
                              <td className="px-3 py-2.5">
                                <div className="flex items-center gap-1 justify-end">
                                  <span className="text-xs text-gray-400">$</span>
                                  <input type="number" step="0.01" min="0" value={row.netEdited}
                                    onChange={e => updateNet(i, e.target.value)}
                                    className="w-20 px-2 py-1 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange text-right"
                                    placeholder="0.00" />
                                </div>
                              </td>
                              <td className="px-3 py-2.5 text-right text-xs text-gray-500">
                                {row.quantity != null ? Number(row.quantity).toLocaleString() : '—'}
                              </td>
                            </>
                          ) : (
                            <>
                              <td className="px-3 py-2.5 text-xs text-gray-900 max-w-[180px]">
                                <p className="font-medium truncate" title={row.description}>{row.description}</p>
                                {row.notes && <p className="text-gray-400 text-xs truncate" title={row.notes}>{row.notes}</p>}
                              </td>
                              <td className="px-3 py-2.5 font-mono text-xs text-gray-500">{row.supplierItemNo || '—'}</td>
                              <td className="px-3 py-2.5 text-right text-xs text-gray-500">
                                {row.commercialPrice != null ? `$${Number(row.commercialPrice).toFixed(2)}` : '—'}
                              </td>
                              <td className="px-3 py-2.5 text-right text-xs text-gray-500">
                                {row.ptvValue != null ? `$${Number(row.ptvValue).toFixed(2)}` : '—'}
                              </td>
                              <td className="px-3 py-2.5">
                                <div className="flex items-center gap-1 justify-end">
                                  <span className="text-xs text-gray-400">$</span>
                                  <input type="number" step="0.01" min="0" value={row.netEdited}
                                    onChange={e => updateNet(i, e.target.value)}
                                    className="w-20 px-2 py-1 text-xs border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange text-right"
                                    placeholder="0.00" />
                                </div>
                              </td>
                            </>
                          )}

                          {/* Source file — shown for multi-file extraction results */}
                          {isMultiFile && (
                            <td className="px-3 py-2.5 max-w-[120px]">
                              {row.sourceFile ? (
                                <span className="inline-flex items-center gap-1 text-xs text-gray-500 truncate max-w-full" title={row.sourceFile}>
                                  <FileSpreadsheet className="w-3 h-3 flex-shrink-0 text-emerald-500" />
                                  <span className="truncate">{row.sourceFile}</span>
                                </span>
                              ) : (
                                <span className="text-xs text-gray-400">—</span>
                              )}
                            </td>
                          )}

                          {/* Matched bid item — editable */}
                          {(() => {
                            const isDupe = row.lineItemId && duplicateMap[row.lineItemId]?.length > 1
                            return (
                              <td className={`px-3 py-2.5 w-44 ${isManualRow ? 'border-l-2 border-l-blue-400' : ''}`}>
                                <BidItemSelector
                                  row={row}
                                  bidLineItems={bidLineItems}
                                  onSelect={(bidItem) => updateMatch(i, bidItem)}
                                />
                                {isDupe && (
                                  <p className="mt-1 text-xs text-amber-600 flex items-center gap-0.5">
                                    <AlertTriangle className="w-3 h-3 flex-shrink-0" />
                                    Shared match — both saved
                                  </p>
                                )}
                              </td>
                            )
                          })()}

                          {/* Confidence */}
                          <ConfidenceCell row={row} />
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Duplicate match notice */}
          {Object.keys(duplicateMap).length > 0 && (
            <div className="mx-6 mb-2 px-4 py-2.5 bg-amber-50 border border-amber-200 rounded-xl">
              <p className="text-xs font-semibold text-amber-700">
                <AlertTriangle className="w-3.5 h-3.5 inline mr-1" />
                {Object.keys(duplicateMap).length} RFP item{Object.keys(duplicateMap).length > 1 ? 's' : ''} matched by multiple supplier items — all will be saved as separate pricing options.
              </p>
            </div>
          )}

          {/* Low confidence note */}
          {hasLowUnchecked && (
            <div className="mx-6 mb-2 px-4 py-2.5 bg-orange-50 border border-orange-200 rounded-xl">
              <p className="text-xs font-semibold text-orange-700">
                <AlertTriangle className="w-3.5 h-3.5 inline mr-1" />
                Low confidence items are unchecked by default — review and manually match before saving.
              </p>
            </div>
          )}

          {/* Unmatched items warning — updates in real-time */}
          {unmatchedChecked > 0 && (
            <div className="mx-6 mb-4 px-4 py-3 bg-amber-50 border border-amber-200 rounded-xl">
              <p className="text-xs font-semibold text-amber-700 mb-0.5">
                <AlertTriangle className="w-3.5 h-3.5 inline mr-1" />
                {unmatchedChecked} item{unmatchedChecked !== 1 ? 's' : ''} still have no RFP line match — use the dropdown to manually assign.
              </p>
              <p className="text-xs text-amber-600">
                {rows.filter(r => r.included && !r.lineItemId).map(r => r.description).join(' · ')}
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        {error && (
          <div className="px-6 py-2 bg-red-50 border-t border-red-100 text-xs text-red-700 flex items-center gap-2 flex-shrink-0">
            <XCircle className="w-4 h-4 flex-shrink-0" />{error}
          </div>
        )}
        <div className="px-6 py-4 border-t border-gray-200 bg-gray-50/60 flex-shrink-0">
          {/* Consideration checkbox row */}
          <div className="mb-3">
            <label className="inline-flex items-center gap-2 cursor-pointer select-none group">
              <input
                type="checkbox"
                checked={markConsideration}
                onChange={e => setMarkConsideration(e.target.checked)}
                className="w-3.5 h-3.5 rounded border-gray-300 cursor-pointer"
                style={{ accentColor: '#E05A2B' }}
              />
              {markConsideration && <Flag className="w-3.5 h-3.5 text-[#E05A2B]" fill="#E05A2B" />}
              <span className="text-xs text-gray-500 group-hover:text-gray-700 transition-colors">
                Mark <span className="font-semibold">{result.supplierName}</span> Under Consideration after saving
              </span>
            </label>
          </div>

          <div className="flex items-center justify-between">
            <p className="text-xs text-gray-500">
              <span className="font-semibold text-gray-700">{checkedCount}</span> of{' '}
              <span className="font-semibold text-gray-700">{rows.length}</span> selected
              {savableCount !== checkedCount && (
                <span className="text-amber-600 ml-1">({savableCount} will be saved)</span>
              )}
            </p>
            <div className="flex gap-3">
              <button onClick={onClose} className="btn-secondary text-sm px-5">Cancel</button>
              <button onClick={handleSave} disabled={saving || checkedCount === 0}
                className="flex items-center gap-2 px-5 py-2 bg-exl-orange hover:bg-exl-orange/90 text-white text-sm font-semibold rounded-xl transition-colors disabled:opacity-40">
                {saving
                  ? <><Loader className="w-4 h-4 animate-spin" /> Saving…</>
                  : <><FileSpreadsheet className="w-4 h-4" /> Save to Working File</>
                }
              </button>
            </div>
          </div>
        </div>
      </div>
      </div>
    </div>
  , document.body)
}
