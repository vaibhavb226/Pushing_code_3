import React, { useState, useEffect } from 'react'
import { useParams, useNavigate, useSearchParams, useLocation } from 'react-router-dom'
import {
  ArrowLeft, Users, FileSpreadsheet, Mail, LayoutDashboard,
  MapPin, Loader, CheckCircle, Trash2,
} from 'lucide-react'
import { Button } from '../UI/Button'
import { Badge } from '../UI/Badge'
import staticBids from '../../data/bids.json'
import OverviewTab    from './OverviewTab'
import SuppliersTab   from './SuppliersTab'
import EmailComposer  from './EmailComposer'
import EmailRepoTab   from './EmailRepoTab'
import WorkingFileTab from './WorkingFileTab'
import { SEGMENT_CONFIG, STATUS_CONFIG, getSuppliersContacted } from '../../utils/bidUtils'
import { useBidStream } from '../../hooks/useBidStream'
import { usePresence, getTabSessionId } from '../../hooks/usePresence'
import { getUserColor, getInitials } from '../../utils/presenceColors'

function getStoredUserName() {
  try {
    const raw = localStorage.getItem('rfpaiq_user')
    if (!raw) return 'Bid COE'
    const parsed = JSON.parse(raw)
    return parsed?.user?.name || parsed?.user?.email || 'Bid COE'
  } catch {
    return 'Bid COE'
  }
}

// ── Tab definitions ───────────────────────────────────────
const TABS = [
  { id: 'overview',    label: 'Overview',      icon: LayoutDashboard },
  { id: 'emailrepo',   label: 'Email Repo',    icon: Mail },
  { id: 'workingfile', label: 'Working File',  icon: FileSpreadsheet },
  { id: 'suppliers',   label: 'Supplier List', icon: Users },
]

// ── Delete confirmation modal ─────────────────────────────
function DeleteBidModal({ bid, onCancel, onConfirm, deleting }) {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-[#1E293B] rounded-2xl shadow-2xl w-full max-w-md overflow-hidden max-h-[90vh] flex flex-col">
        <div className="px-6 py-5 flex-1 min-h-0 overflow-y-auto">
          <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-xl flex items-center justify-center mb-4">
            <Trash2 className="w-6 h-6 text-red-600" />
          </div>
          <h3 className="text-lg font-bold text-gray-900 mb-2">Delete RFP?</h3>
          <p className="text-sm text-gray-600 leading-relaxed">
            This will permanently delete{' '}
            <span className="font-mono font-semibold text-gray-900">{bid.id}</span> —{' '}
            <span className="font-semibold">{bid.customer}</span>{' '}
            and all associated line items and emails. This cannot be undone.
          </p>
        </div>
        <div className="px-6 pb-5 flex gap-3 flex-shrink-0">
          <Button variant="secondary" onClick={onCancel} disabled={deleting} className="flex-1">
            Cancel
          </Button>
          <Button
            variant="danger"
            icon={Trash2}
            loading={deleting}
            onClick={onConfirm}
            className="flex-1"
          >
            {deleting ? 'Deleting…' : 'Delete RFP'}
          </Button>
        </div>
      </div>
    </div>
  )
}

// ── Bid header banner ─────────────────────────────────────
function BidHeader({ bid, onDeleteClick }) {
  const segCfg    = SEGMENT_CONFIG[bid.segment] ?? { headerBg: 'bg-exl-navy', icon: '📋' }
  const statusCfg = STATUS_CONFIG[bid.status]   ?? STATUS_CONFIG['Active']

  return (
    <div className={`${segCfg.headerBg} rounded-xl px-6 py-5 mb-6`}>
      <div className="flex items-start justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xl">{segCfg.icon}</span>
            <span className="text-white/70 text-sm font-medium">{bid.segment}</span>
            <span className="text-white/40">·</span>
            <span className="text-white/70 font-mono text-sm">{bid.id}</span>
          </div>
          <h1 className="text-xl font-bold text-white">{bid.customer}</h1>
          <div className="flex items-center gap-3 mt-2">
            <span className="text-white/70 text-sm flex items-center gap-1">
              <MapPin className="w-3.5 h-3.5" />
              OpCo <span className="font-mono font-bold text-white">{bid.opco}</span> — {bid.opcoName}
            </span>
            <span className="text-white/40">·</span>
            <span className="text-white/70 text-sm">{bid.region}</span>
          </div>
        </div>
        <div className="flex flex-col items-end gap-2">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-semibold bg-white/20 text-white">
              <span className={`w-2 h-2 rounded-full ${statusCfg.dot}`} />
              {bid.status}
            </span>

            <button
              onClick={onDeleteClick}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold border border-red-300/60 text-red-200 hover:bg-red-600/30 hover:text-white transition-colors"
              title="Delete this RFP"
            >
              <Trash2 className="w-3 h-3" /> Delete
            </button>
          </div>
          <div className="text-white/60 text-xs">{bid.items} line items</div>
        </div>
      </div>
    </div>
  )
}

// Collapses duplicate viewer names for the "Also viewing" strip.
// e.g. ['Morgan Davis', 'Morgan Davis', 'Alice'] → 'Morgan Davis (×2), Alice'
function collapseViewers(viewers) {
  const counts = {}
  viewers.forEach(v => { counts[v] = (counts[v] || 0) + 1 })
  return Object.entries(counts)
    .map(([name, count]) => count > 1 ? `${name} (×${count})` : name)
    .join(', ')
}

// ── Main BidDetail page ───────────────────────────────────
export default function BidDetail() {
  const { id }           = useParams()
  const navigate         = useNavigate()
  const [searchParams]   = useSearchParams()

  // Active tab — read from ?tab= URL param (used by "Create Working File" flow)
  const [activeTab, setActiveTab]     = useState(searchParams.get('tab') || 'overview')

  // Auto-open edit form — triggered by ?edit=1 from three-dot menu on BidCard
  const autoEdit = searchParams.get('edit') === '1'

  // Email composer state — lives here so it can replace the whole content area
  const [composing, setComposing]     = useState(false)
  const [composeSuppliers, setComposeSuppliers] = useState([])

  // Delete bid state
  const [showDelete, setShowDelete]   = useState(false)
  const [deleting,   setDeleting]     = useState(false)

  const handleDeleteBid = async () => {
    setDeleting(true)
    try {
      const res = await fetch(`/api/bids/${id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Delete failed')
      const data = await res.json()
      navigate('/', { state: { deleted: { bidId: id, removed: data.removed } } })
    } catch {
      setDeleting(false)
      setShowDelete(false)
    }
  }

  // Bid data — static JSON as instant placeholder, API always fetched for live data
  const [bid,      setBid]      = useState(() => staticBids.find(b => b.id === id) || null)
  const [loading,  setLoading]  = useState(!staticBids.find(b => b.id === id))
  const [notFound, setNotFound] = useState(false)

  useEffect(() => {
    const hasStaticBid = staticBids.some(b => b.id === id)
    if (!hasStaticBid) setLoading(true)   // only show spinner when no placeholder available
    fetch(`/api/bids/${id}`)
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data) setBid(data)                        // replace placeholder with live data
        else if (!hasStaticBid) setNotFound(true)     // only 404 if we had nothing to show
      })
      .catch(() => { if (!hasStaticBid) setNotFound(true) })  // keep static placeholder on error
      .finally(() => setLoading(false))
  }, [id])

  // Email count — supplier conversation count (matches the "All" filter in EmailRepoTab)
  const [emailCount, setEmailCount] = useState(null)
  useEffect(() => {
    if (!id) return
    fetch(`/api/bids/${id}/emails/by-supplier`)
      .then(r => r.ok ? r.json() : {})
      .then(data => setEmailCount((data.suppliers || []).length))
      .catch(() => setEmailCount(0))
  }, [id])

  // ── Real-time collaboration ───────────────────────────────
  const [viewers,     setViewers]     = useState([])
  const [latestEvent, setLatestEvent] = useState(null)
  // tab → list of user names on that tab
  const [tabPresence, setTabPresence] = useState({})
  // which row/cell the current user is focused on (for presence reporting)
  const [focusedCellId, setFocusedCellId] = useState(null)
  const userName = getStoredUserName()
  const selfSessionId = getTabSessionId()

  // Report our location to the global presence registry
  usePresence(userName, bid?.id, activeTab, focusedCellId)

  useBidStream(bid?.id, userName, (event) => {
    setLatestEvent(event)
    if (event.type === 'viewers') {
      setViewers((event.viewers || []).filter(u => u !== userName))
    }
    if (event.type === 'presence') {
      if (event.action === 'left' && event.sessionId) {
        // Remove exactly this session from tabPresence — avoids wiping other open
        // tabs of the same user when one closes.
        setTabPresence(prev => {
          const next = {}
          Object.keys(prev).forEach(t => {
            next[t] = (prev[t] || []).filter(s => s.sessionId !== event.sessionId)
          })
          return next
        })
      }
      setViewers(prev =>
        event.action === 'joined'
          ? [...new Set([...prev, event.user])].filter(u => u !== userName)
          : prev.filter(u => u !== event.user)
      )
    }
    if (event.type === 'bid_updated') {
      setBid(prev => prev ? { ...prev, ...event.fields } : prev)
    }
    if (event.type === 'presence_tab' && event.sessionId !== selfSessionId) {
      setTabPresence(prev => {
        // Each session is tracked individually so same user in multiple tabs
        // each gets their own avatar on the tab bar.
        const sid = event.sessionId ?? event.user  // fallback for old-format events
        const next = {}
        Object.keys(prev).forEach(t => {
          next[t] = (prev[t] || []).filter(s => s.sessionId !== sid)
        })
        if (event.tab) {
          next[event.tab] = [...(next[event.tab] || []), { name: event.user, sessionId: sid, lastSeen: Date.now() }]
        }
        return next
      })
    }
  })

  // Purge stale tabPresence entries — safety net for missed presence.left events.
  // Heartbeats fire every 30s; entries not refreshed in 90s are from closed tabs.
  useEffect(() => {
    const id = setInterval(() => {
      setTabPresence(prev => {
        const cutoff = Date.now() - 90_000
        const next = {}
        Object.keys(prev).forEach(t => {
          next[t] = (prev[t] || []).filter(s => (s.lastSeen ?? 0) > cutoff)
        })
        return next
      })
    }, 60_000)
    return () => clearInterval(id)
  }, [])

  // ── Loading state ──
  if (loading) {
    return (
      <div className="flex items-center justify-center py-32">
        <Loader className="w-6 h-6 animate-spin text-exl-orange" />
        <span className="ml-3 text-gray-500 text-sm">Loading RFP…</span>
      </div>
    )
  }

  // ── Not found ──
  if (notFound || !bid) {
    return (
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <p className="text-lg font-semibold text-gray-600 mb-2">RFP not found</p>
        <p className="text-sm text-gray-400 mb-4">No RFP with ID <code className="font-mono">{id}</code></p>
        <Button variant="primary" onClick={() => navigate('/')}>← Back to Bid Queue</Button>
      </div>
    )
  }

  // ── Email Composer (full-page replacement) ──
  if (composing) {
    return (
      <div className="max-w-screen-xl mx-auto">
        <EmailComposer
          bid={bid}
          selectedSuppliers={composeSuppliers}
          onCancel={() => setComposing(false)}
          onSent={(count) => {
            setComposing(false)
            setActiveTab('emailrepo')
            // Optimistically update local bid status
            setBid(prev => prev ? { ...prev, status: 'Solicitation', suppliersContacted: count } : prev)
          }}
        />
      </div>
    )
  }

  return (
    <div className="max-w-screen-xl mx-auto">

      {/* ── Back nav ── */}
      <button
        onClick={() => navigate('/')}
        className="flex items-center gap-2 text-sm text-gray-500 hover:text-exl-navy font-medium mb-4 transition-colors group"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
        Bid Queue
      </button>

      {/* ── Bid header ── */}
      <BidHeader bid={bid} onDeleteClick={() => setShowDelete(true)} />

      {/* ── Presence strip — shown when other users are viewing this bid ── */}
      {viewers.length > 0 && (
        <div className="flex items-center gap-2 px-3 py-1.5 mb-3 rounded-lg bg-blue-50 dark:bg-blue-900/20 text-xs text-blue-700 dark:text-blue-300">
          <span>👁</span>
          <span>Also viewing: {collapseViewers(viewers)}</span>
        </div>
      )}

      {/* ── Tab bar ── */}
      <div className="border-b border-gray-200 dark:border-gray-700 mb-6">
        <nav className="flex gap-0">
          {TABS.map(({ id: tabId, label, icon: Icon }) => {
            const tabUsers = tabPresence[tabId] || []
            return (
              <button
                key={tabId}
                onClick={() => setActiveTab(tabId)}
                className={`
                  flex items-center gap-2 px-5 py-3 text-sm font-medium border-b-2 transition-all duration-150
                  ${activeTab === tabId
                    ? 'border-[#E05A2B] text-[#E05A2B]'
                    : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:border-gray-300 dark:hover:border-gray-600'
                  }
                `}
              >
                <Icon className="w-4 h-4" />
                {label}
                {tabId === 'emailrepo' && emailCount !== null && emailCount > 0 && (
                  <span className="ml-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 text-xs font-semibold px-1.5 py-0.5 rounded-full">
                    {emailCount}
                  </span>
                )}
                {tabId === 'suppliers' && (bid.solicitedSuppliers?.length ?? 0) > 0 && (
                  <span className="ml-1 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 text-xs font-semibold px-1.5 py-0.5 rounded-full">
                    {bid.solicitedSuppliers.length}
                  </span>
                )}
                {/* Presence avatars for other sessions on this tab (one per browser tab, same user can appear multiple times) */}
                {tabUsers.slice(0, 3).map(s => {
                  const c = getUserColor(s.name)
                  return (
                    <span
                      key={s.sessionId}
                      title={s.name}
                      className={`w-4 h-4 rounded-full ${c.bg} ${c.text} flex items-center justify-center text-[8px] font-bold flex-shrink-0`}
                    >
                      {getInitials(s.name)[0]}
                    </span>
                  )
                })}
              </button>
            )
          })}
        </nav>
      </div>

      {/* ── Tab content ── */}
      {/* getTabClass: heavy-content tabs use opacity-only to avoid translateY reflow */}
      {activeTab === 'overview' && (
        <div key="overview" className="tab-panel">
          <OverviewTab
            bid={bid}
            onBidUpdate={(updatedBid) => setBid(updatedBid)}
            autoEdit={autoEdit}
          />
        </div>
      )}

      {activeTab === 'suppliers' && (
        <div key="suppliers" className="tab-panel-fade">
          <SuppliersTab
            bid={bid}
            latestEvent={latestEvent}
            onCompose={(suppliers) => {
              setComposeSuppliers(suppliers)
              setComposing(true)
            }}
            onSwitchToEmail={() => setActiveTab('emailrepo')}
          />
        </div>
      )}

      {activeTab === 'workingfile' && (
        <div key="workingfile" className="tab-panel-fade">
          <WorkingFileTab
            bid={bid}
            latestEvent={latestEvent}
            onCellFocus={(lineId) => setFocusedCellId(lineId)}
            onCellBlur={() => setFocusedCellId(null)}
          />
        </div>
      )}

      {activeTab === 'emailrepo' && (
        <div key="emailrepo" className="tab-panel">
          <EmailRepoTab
            bid={bid}
            latestEvent={latestEvent}
            onSwitchTab={setActiveTab}
            onResponseLogged={() => {
              fetch(`/api/bids/${id}/emails/by-supplier`)
                .then(r => r.ok ? r.json() : {})
                .then(data => setEmailCount((data.suppliers || []).length))
                .catch(() => {})
            }}
          />
        </div>
      )}

      {/* ── Delete confirmation modal ── */}
      {showDelete && (
        <DeleteBidModal
          bid={bid}
          onCancel={() => setShowDelete(false)}
          onConfirm={handleDeleteBid}
          deleting={deleting}
        />
      )}
    </div>
  )
}
