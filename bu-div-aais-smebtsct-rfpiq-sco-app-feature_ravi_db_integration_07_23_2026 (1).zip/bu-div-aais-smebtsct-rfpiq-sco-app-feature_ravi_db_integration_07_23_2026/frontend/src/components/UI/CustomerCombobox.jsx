import { useState, useEffect, useRef } from 'react';

/**
 * Searchable customer dropdown.
 *
 * Props:
 *   value        — currently selected customer name (display)
 *   customerId   — currently selected customer id
 *   onChange(id, name) — called when user picks or creates a customer
 *   placeholder  — input placeholder text
 *   className    — extra classes on the wrapper div
 *   disabled     — disable the input
 */
export default function CustomerCombobox({
  value = '',
  customerId = '',
  onChange,
  placeholder = 'Search or create customer…',
  className = '',
  disabled = false,
}) {
  const [inputVal, setInputVal]   = useState(value);
  const [customers, setCustomers] = useState([]);
  const [filtered, setFiltered]   = useState([]);
  const [open, setOpen]           = useState(false);
  const [loading, setLoading]     = useState(false);
  const [creating, setCreating]   = useState(false);
  const wrapRef = useRef(null);

  // Load full customer list once on mount
  useEffect(() => {
    let cancelled = false;
    fetch('/api/customers')
      .then(r => r.ok ? r.json() : [])
      .then(data => { if (!cancelled) setCustomers(Array.isArray(data) ? data : []); })
      .catch(() => {});
    return () => { cancelled = true; };
  }, []);

  // Keep display text in sync when parent changes value prop
  useEffect(() => { setInputVal(value); }, [value]);

  // Filter client-side as user types
  useEffect(() => {
    const q = inputVal.trim().toLowerCase();
    if (!q) {
      setFiltered(customers.slice(0, 50));
    } else {
      setFiltered(customers.filter(c => c.name.toLowerCase().includes(q)));
    }
  }, [inputVal, customers]);

  // Close dropdown on outside click
  useEffect(() => {
    function handler(e) {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const exactMatch = customers.find(
    c => c.name.toLowerCase() === inputVal.trim().toLowerCase()
  );
  const showCreate = inputVal.trim() && !exactMatch;

  function handleSelect(customer) {
    setInputVal(customer.name);
    setOpen(false);
    onChange?.(customer.id, customer.name);
  }

  async function handleCreate() {
    const name = inputVal.trim();
    if (!name) return;
    setCreating(true);
    try {
      const res = await fetch('/api/customers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name }),
      });
      if (!res.ok) throw new Error('Failed to create customer');
      const created = await res.json();
      setCustomers(prev => [...prev, created].sort((a, b) => a.name.localeCompare(b.name)));
      setInputVal(created.name);
      setOpen(false);
      onChange?.(created.id, created.name);
    } catch {
      // silently leave input as-is on error
    } finally {
      setCreating(false);
    }
  }

  return (
    <div ref={wrapRef} className={`relative ${className}`}>
      <input
        type="text"
        value={inputVal}
        disabled={disabled}
        placeholder={placeholder}
        autoComplete="off"
        className="w-full border border-gray-300 dark:border-gray-600 rounded-md px-3 py-2 text-sm
                   bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                   focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:opacity-50"
        onChange={e => {
          setInputVal(e.target.value);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onKeyDown={e => {
          if (e.key === 'Escape') setOpen(false);
          if (e.key === 'Enter') {
            e.preventDefault();
            if (showCreate) handleCreate();
            else if (filtered.length === 1) handleSelect(filtered[0]);
          }
        }}
      />

      {open && (filtered.length > 0 || showCreate) && (
        <ul className="absolute z-50 mt-1 w-full max-h-60 overflow-y-auto rounded-md border
                       border-gray-200 dark:border-gray-600 bg-white dark:bg-gray-800 shadow-lg text-sm">
          {filtered.map(c => (
            <li
              key={c.id}
              className={`px-3 py-2 cursor-pointer hover:bg-blue-50 dark:hover:bg-blue-900/30
                         ${c.id === customerId ? 'font-semibold text-blue-600 dark:text-blue-400' : 'text-gray-800 dark:text-gray-200'}`}
              onMouseDown={() => handleSelect(c)}
            >
              {c.name}
            </li>
          ))}
          {showCreate && (
            <li
              className="px-3 py-2 cursor-pointer text-blue-600 dark:text-blue-400 hover:bg-blue-50 dark:hover:bg-blue-900/30 border-t border-gray-100 dark:border-gray-700 font-medium"
              onMouseDown={handleCreate}
            >
              {creating ? 'Creating…' : `+ Create "${inputVal.trim()}"`}
            </li>
          )}
        </ul>
      )}
    </div>
  );
}
