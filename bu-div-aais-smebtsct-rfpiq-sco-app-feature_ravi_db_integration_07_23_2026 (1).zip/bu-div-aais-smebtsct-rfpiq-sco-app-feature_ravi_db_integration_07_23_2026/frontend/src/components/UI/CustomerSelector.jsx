import { useState, useEffect, useRef } from 'react'
import { Search, Plus, Pencil, Trash2, X, ChevronDown, Loader, Building2 } from 'lucide-react'
import CreateCustomerModal from './CreateCustomerModal'

/**
 * Lazy-loading customer search + CRUD selector.
 *
 * Customers are fetched the first time the dropdown opens — never on mount.
 *
 * Props:
 *   value        — selected customer name (display string)
 *   customerId   — selected customer id
 *   onChange(id, name)  — called when selection changes
 *   placeholder  — placeholder text for the search input
 *   disabled
 */
export default function CustomerSelector({
  value = '',
  customerId = '',
  onChange,
  placeholder = 'Search customers…',
  disabled = false,
}) {
  const [open, setOpen]           = useState(false)
  const [query, setQuery]         = useState('')
  const [customers, setCustomers] = useState([])
  const [loaded, setLoaded]       = useState(false)
  const [loading, setLoading]     = useState(false)

  // Modal states
  const [showCreate, setShowCreate]   = useState(false)
  const [editTarget, setEditTarget]   = useState(null)  // customer object to edit
  const [deleteTarget, setDeleteTarget] = useState(null) // customer id pending confirm
  const [deleting, setDeleting]       = useState(false)

  const wrapRef   = useRef(null)
  const inputRef  = useRef(null)

  // ── Lazy fetch — only on first open ──────────────────────────
  const fetchCustomers = async () => {
    if (loaded) return
    setLoading(true)
    try {
      const res = await fetch('/api/customers')
      const data = res.ok ? await res.json() : []
      setCustomers(Array.isArray(data) ? data : [])
      setLoaded(true)
    } catch {
      setCustomers([])
    } finally {
      setLoading(false)
    }
  }

  // ── Open / close ──────────────────────────────────────────────
  const openDropdown = () => {
    if (disabled) return
    setOpen(true)
    setQuery('')
    fetchCustomers()
    setTimeout(() => inputRef.current?.focus(), 50)
  }

  const closeDropdown = () => {
    setOpen(false)
    setQuery('')
    setDeleteTarget(null)
  }

  // Close on outside click
  useEffect(() => {
    const handler = (e) => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) closeDropdown()
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [])

  // ── Filtered list ─────────────────────────────────────────────
  const filtered = query.trim()
    ? customers.filter(c => c.name.toLowerCase().includes(query.toLowerCase()))
    : customers

  // ── Select a customer ─────────────────────────────────────────
  const handleSelect = (c) => {
    onChange?.(c.id, c.name)
    closeDropdown()
  }

  // ── Clear selection ───────────────────────────────────────────
  const handleClear = (e) => {
    e.stopPropagation()
    onChange?.('', '')
  }

  // ── Delete ────────────────────────────────────────────────────
  const handleDelete = async (c) => {
    if (deleteTarget !== c.id) { setDeleteTarget(c.id); return }
    setDeleting(true)
    try {
      const res = await fetch(`/api/customers/${c.id}`, { method: 'DELETE' })
      if (res.ok || res.status === 204) {
        setCustomers(prev => prev.filter(x => x.id !== c.id))
        if (customerId === c.id) onChange?.('', '')
        setDeleteTarget(null)
      }
    } catch { /* leave UI unchanged */ }
    finally { setDeleting(false) }
  }

  // ── After create / edit ───────────────────────────────────────
  const handleSaved = (saved) => {
    setCustomers(prev => {
      const existing = prev.findIndex(c => c.id === saved.id)
      if (existing >= 0) {
        const next = [...prev]
        next[existing] = saved
        return next.sort((a, b) => a.name.localeCompare(b.name))
      }
      return [...prev, saved].sort((a, b) => a.name.localeCompare(b.name))
    })
    onChange?.(saved.id, saved.name)
    setShowCreate(false)
    setEditTarget(null)
    closeDropdown()
  }

  // ── Display chip when a customer is selected ──────────────────
  const hasValue = Boolean(value)

  return (
    <>
      <div ref={wrapRef} className="relative">
        {/* ── Trigger ── */}
        <button
          type="button"
          onClick={openDropdown}
          disabled={disabled}
          className={`w-full flex items-center gap-2 px-3 py-2 text-sm border rounded-lg transition-colors text-left
            ${open
              ? 'border-exl-orange ring-2 ring-exl-orange/30'
              : 'border-gray-200 dark:border-gray-600 hover:border-gray-300 dark:hover:border-gray-500'}
            bg-white dark:bg-[#253347] dark:text-gray-200 disabled:opacity-50`}
        >
          {hasValue
            ? <><Building2 className="w-3.5 h-3.5 text-exl-orange flex-shrink-0" /><span className="flex-1 truncate font-medium">{value}</span></>
            : <span className="flex-1 text-gray-400">{placeholder}</span>
          }
          <div className="flex items-center gap-1 ml-auto flex-shrink-0">
            {hasValue && (
              <span
                role="button"
                onClick={handleClear}
                className="p-0.5 rounded hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-400 hover:text-gray-600"
              >
                <X className="w-3 h-3" />
              </span>
            )}
            <ChevronDown className={`w-3.5 h-3.5 text-gray-400 transition-transform ${open ? 'rotate-180' : ''}`} />
          </div>
        </button>

        {/* ── Dropdown ── */}
        {open && (
          <div className="absolute z-40 mt-1 w-full rounded-xl border border-gray-200 dark:border-gray-600 bg-white dark:bg-[#1E293B] shadow-xl overflow-hidden">

            {/* Search row */}
            <div className="flex items-center gap-2 px-3 py-2 border-b border-gray-100 dark:border-gray-700">
              <Search className="w-3.5 h-3.5 text-gray-400 flex-shrink-0" />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Type to filter…"
                className="flex-1 text-sm bg-transparent outline-none dark:text-gray-200 placeholder-gray-400"
                onKeyDown={e => e.key === 'Escape' && closeDropdown()}
              />
              {loading && <Loader className="w-3.5 h-3.5 text-gray-400 animate-spin" />}
            </div>

            {/* Customer list */}
            <ul className="max-h-56 overflow-y-auto">
              {filtered.length === 0 && !loading && (
                <li className="px-3 py-3 text-xs text-gray-400 text-center">
                  {query ? 'No customers match your search' : 'No customers yet'}
                </li>
              )}
              {filtered.map(c => (
                <li
                  key={c.id}
                  className={`group flex items-center gap-2 px-3 py-2.5 hover:bg-gray-50 dark:hover:bg-[#253347] cursor-pointer
                    ${c.id === customerId ? 'bg-orange-50 dark:bg-orange-900/20' : ''}`}
                >
                  {/* Name — clicking selects */}
                  <span
                    onClick={() => handleSelect(c)}
                    className={`flex-1 text-sm truncate ${c.id === customerId ? 'font-semibold text-exl-orange' : 'text-gray-800 dark:text-gray-200'}`}
                  >
                    {c.name}
                    {c.segment && <span className="ml-1.5 text-[10px] text-gray-400">{c.segment}</span>}
                  </span>

                  {/* Action buttons — visible on hover */}
                  <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                    {/* Edit */}
                    <button
                      onClick={(e) => { e.stopPropagation(); setEditTarget(c) }}
                      className="p-1 rounded hover:bg-blue-100 dark:hover:bg-blue-900/30 text-gray-400 hover:text-blue-600"
                      title="Edit customer"
                    >
                      <Pencil className="w-3 h-3" />
                    </button>

                    {/* Delete — requires confirmation click */}
                    {deleteTarget === c.id ? (
                      <span className="flex items-center gap-1">
                        <span className="text-[10px] text-red-500 font-medium">Delete?</span>
                        <button
                          onClick={(e) => { e.stopPropagation(); handleDelete(c) }}
                          disabled={deleting}
                          className="px-1.5 py-0.5 text-[10px] font-bold rounded bg-red-500 hover:bg-red-600 text-white disabled:opacity-50"
                        >
                          {deleting ? '…' : 'Yes'}
                        </button>
                        <button
                          onClick={(e) => { e.stopPropagation(); setDeleteTarget(null) }}
                          className="px-1.5 py-0.5 text-[10px] font-bold rounded bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 text-gray-700 dark:text-gray-300"
                        >
                          No
                        </button>
                      </span>
                    ) : (
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDelete(c) }}
                        className="p-1 rounded hover:bg-red-100 dark:hover:bg-red-900/30 text-gray-400 hover:text-red-500"
                        title="Delete customer"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </li>
              ))}
            </ul>

            {/* Add new footer */}
            <div className="border-t border-gray-100 dark:border-gray-700">
              <button
                onClick={() => { setShowCreate(true) }}
                className="w-full flex items-center gap-2 px-3 py-2.5 text-sm font-medium text-exl-orange hover:bg-orange-50 dark:hover:bg-orange-900/20 transition-colors"
              >
                <Plus className="w-4 h-4" />
                Add New Customer
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ── Create modal ── */}
      {showCreate && (
        <CreateCustomerModal
          onClose={() => setShowCreate(false)}
          onSaved={handleSaved}
        />
      )}

      {/* ── Edit modal ── */}
      {editTarget && (
        <CreateCustomerModal
          customerId={editTarget.id}
          initialData={editTarget}
          onClose={() => setEditTarget(null)}
          onSaved={handleSaved}
        />
      )}
    </>
  )
}
