import React from 'react'

export const EmptyState = ({
  icon: Icon,
  title,
  description,
  action,
  secondaryAction,
  size = 'md',
}) => (
  <div className={`
    flex flex-col items-center justify-center text-center
    ${size === 'sm' ? 'py-8 px-4' :
      size === 'lg' ? 'py-20 px-8' : 'py-16 px-6'}
  `}>
    {Icon && (
      <div className="w-16 h-16 rounded-2xl bg-gray-50 dark:bg-[#253347] border border-gray-100 dark:border-gray-700 flex items-center justify-center mb-4">
        <Icon size={28} className="text-gray-300 dark:text-gray-600" strokeWidth={1.5} />
      </div>
    )}
    <h3 className="text-base font-semibold text-gray-700 dark:text-gray-300 mb-1">{title}</h3>
    {description && (
      <p className="text-sm text-gray-400 dark:text-gray-500 max-w-xs leading-relaxed mb-5">
        {description}
      </p>
    )}
    {(action || secondaryAction) && (
      <div className="flex items-center gap-3">
        {action && (
          <button
            onClick={action.onClick}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium bg-[#E05A2B] text-white hover:bg-[#C44E22] transition-colors"
          >
            {action.icon && <action.icon size={14} />}
            {action.label}
          </button>
        )}
        {secondaryAction && (
          <button
            onClick={secondaryAction.onClick}
            className="text-sm text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300 transition-colors"
          >
            {secondaryAction.label}
          </button>
        )}
      </div>
    )}
  </div>
)
