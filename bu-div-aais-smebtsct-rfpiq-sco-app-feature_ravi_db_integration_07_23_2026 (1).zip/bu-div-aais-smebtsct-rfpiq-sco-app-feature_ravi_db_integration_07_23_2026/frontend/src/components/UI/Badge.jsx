import React from 'react'

const badgeVariants = {
  success: 'bg-green-100  text-green-800  dark:bg-green-900/40  dark:text-green-300',
  warning: 'bg-amber-100  text-amber-700  dark:bg-amber-900/40  dark:text-amber-300',
  danger:  'bg-red-100    text-red-600    dark:bg-red-900/40    dark:text-red-300',
  info:    'bg-blue-100   text-blue-700   dark:bg-blue-900/40   dark:text-blue-300',
  neutral: 'bg-gray-100   text-gray-600   dark:bg-gray-700      dark:text-gray-300',
  orange:  'bg-orange-50  text-[#E05A2B]  dark:bg-orange-900/20 dark:text-orange-300',
  navy:    'bg-blue-50    text-[#1F3864]  dark:bg-blue-900/40   dark:text-blue-300',
  purple:  'bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300',
}

export const Badge = ({
  variant = 'neutral',
  dot,
  children,
  className = '',
}) => (
  <span className={`
    inline-flex items-center gap-1.5
    px-2 py-0.5 rounded-full
    text-xs font-medium
    ${badgeVariants[variant]}
    ${className}
  `}>
    {dot && (
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
    )}
    {children}
  </span>
)
