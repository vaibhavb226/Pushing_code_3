import { useState } from 'react'
import { X, Building2, Loader, AlertTriangle } from 'lucide-react'

const SEGMENTS   = ['K-12', 'DoD', 'University', 'Healthcare', 'Restaurant', 'Lodging', 'Government']
const REGIONS    = ['Northeast', 'Southeast', 'Midwest', 'Mountain', 'Southwest', 'Northwest', 'National']
const CUST_TYPES = ['School District', 'Military', 'University', 'Hospital', 'Restaurant Chain', 'Hotel Chain', 'Government Agency', 'Other']

const inputCls = (err) =>
  `w-full px-3 py-2 text-sm border rounded-lg focus:outline-none focus:ring-2 transition-colors dark:text-gray-200
   ${err
     ? 'border-red-400 bg-red-50 dark:bg-red-900/20 focus:ring-red-200 focus:border-red-500'
     : 'border-gray-200 dark:border-gray-600 bg-white dark:bg-[#253347] focus:ring-exl-orange/30 focus:border-exl-orange'}`

function FormField({ label, required, error, children }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wide mb-1.5">
        {label}{required && <span className="text-red-500 ml-0.5">*</span>}
      </label>
      {children}
      {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
    </div>
  )
}

function SectionHeader({ children }) {
  return (
    <p className="text-xs font-bold text-exl-navy dark:text-blue-300 uppercase tracking-wider pt-1 pb-0.5 border-b border-gray-100 dark:border-gray-700">
      {children}
    </p>
  )
}

const EMPTY = {
  name: '', contactPerson: '', email: '', phone: '',
  address: '', city: '', state: '', zipCode: '', country: 'US',
  customerType: '', segment: '', opco: '', opcoName: '', region: '', status: 'Active',
}

/**
 * Modal for creating OR editing a customer.
 *
 * Props:
 *   initialData  — if provided, pre-populates the form for edit mode
 *   customerId   — if provided along with initialData, sends PUT instead of POST
 *   onClose()                — close without saving
 *   onSaved(customer)        — called with the created/updated customer {id, name, ...}
 */
export default function CreateCustomerModal({ initialData, customerId, onClose, onSaved }) {
  const isEdit = Boolean(customerId && initialData)

  const [form, setForm]       = useState(initialData ? { ...EMPTY, ...initialData } : EMPTY)
  const [errors, setErrors]   = useState({})
  const [saving, setSaving]   = useState(false)
  const [apiError, setApiError] = useState(null)

  const update = (field, val) => {
    setForm(f => ({ ...f, [field]: val }))
    if (errors[field]) setErrors(e => ({ ...e, [field]: null }))
  }

  const validate = () => {
    const errs = {}
    if (!form.name.trim()) errs.name = 'Organization name is required'
    return errs
  }

  const handleSave = async () => {
    const errs = validate()
    if (Object.keys(errs).length) { setErrors(errs); return }

    setSaving(true)
    setApiError(null)
    try {
      const url    = isEdit ? `/api/customers/${customerId}` : '/api/customers'
      const method = isEdit ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (!res.ok) {
        const body = await res.json().catch(() => ({}))
        throw new Error(body.detail || `HTTP ${res.status}`)
      }
      const saved = await res.json()
      onSaved(saved)
    } catch (err) {
      setApiError(err.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-white dark:bg-[#1E293B] w-full max-w-2xl rounded-2xl shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">

        {/* ── Header ── */}
        <div className="flex items-center justify-between px-6 py-4 bg-exl-navy flex-shrink-0">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-exl-orange" />
            <h3 className="text-white font-bold text-sm">
              {isEdit ? 'Edit Customer' : 'Add Customer'}
            </h3>
            {isEdit && (
              <span className="text-white/50 text-xs font-mono">{customerId}</span>
            )}
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* ── Body ── */}
        <div className="flex-1 min-h-0 overflow-y-auto px-6 py-5 space-y-5">

          {/* Organization */}
          <SectionHeader>Organization</SectionHeader>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField label="Organization Name" required error={errors.name}>
              <input
                type="text"
                value={form.name}
                onChange={e => update('name', e.target.value)}
                placeholder="e.g. Arapahoe Charter School District"
                className={inputCls(errors.name)}
                autoFocus
              />
            </FormField>
            <FormField label="Customer Type">
              <select value={form.customerType} onChange={e => update('customerType', e.target.value)} className={inputCls(null)}>
                <option value="">— Select —</option>
                {CUST_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </FormField>
          </div>

          {/* Contact */}
          <SectionHeader>Primary Contact</SectionHeader>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <FormField label="Contact Person">
              <input type="text" value={form.contactPerson} onChange={e => update('contactPerson', e.target.value)}
                placeholder="Full name" className={inputCls(null)} />
            </FormField>
            <FormField label="Email">
              <input type="email" value={form.email} onChange={e => update('email', e.target.value)}
                placeholder="contact@org.edu" className={inputCls(null)} />
            </FormField>
            <FormField label="Phone">
              <input type="tel" value={form.phone} onChange={e => update('phone', e.target.value)}
                placeholder="(555) 000-0000" className={inputCls(null)} />
            </FormField>
          </div>

          {/* Address */}
          <SectionHeader>Address</SectionHeader>
          <div className="space-y-3">
            <FormField label="Street Address">
              <input type="text" value={form.address} onChange={e => update('address', e.target.value)}
                placeholder="123 Main St" className={inputCls(null)} />
            </FormField>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <FormField label="City">
                <input type="text" value={form.city} onChange={e => update('city', e.target.value)}
                  placeholder="City" className={inputCls(null)} />
              </FormField>
              <FormField label="State">
                <input type="text" value={form.state} onChange={e => update('state', e.target.value)}
                  placeholder="CO" maxLength={2} className={inputCls(null)} />
              </FormField>
              <FormField label="ZIP Code">
                <input type="text" value={form.zipCode} onChange={e => update('zipCode', e.target.value)}
                  placeholder="80002" className={inputCls(null)} />
              </FormField>
              <FormField label="Country">
                <input type="text" value={form.country} onChange={e => update('country', e.target.value)}
                  placeholder="US" className={inputCls(null)} />
              </FormField>
            </div>
          </div>

          {/* Classification */}
          <SectionHeader>Classification</SectionHeader>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <FormField label="Segment">
              <select value={form.segment} onChange={e => update('segment', e.target.value)} className={inputCls(null)}>
                <option value="">— Select —</option>
                {SEGMENTS.map(s => <option key={s} value={s}>{s}</option>)}
              </select>
            </FormField>
            <FormField label="Region">
              <select value={form.region} onChange={e => update('region', e.target.value)} className={inputCls(null)}>
                <option value="">— Select —</option>
                {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
              </select>
            </FormField>
            <FormField label="Status">
              <select value={form.status} onChange={e => update('status', e.target.value)} className={inputCls(null)}>
                <option value="Active">Active</option>
                <option value="Inactive">Inactive</option>
              </select>
            </FormField>
            <FormField label="OpCo Code">
              <input type="text" value={form.opco} onChange={e => update('opco', e.target.value)}
                placeholder="e.g. 016" className={inputCls(null)} />
            </FormField>
            <FormField label="OpCo Name">
              <input type="text" value={form.opcoName} onChange={e => update('opcoName', e.target.value)}
                placeholder="e.g. FoodCorp Boston" className={inputCls(null)} />
            </FormField>
          </div>
        </div>

        {/* ── Error banner ── */}
        {apiError && (
          <div className="px-6 py-2.5 bg-red-50 dark:bg-red-900/20 border-t border-red-100 dark:border-red-800 flex items-center gap-2 text-xs text-red-700 dark:text-red-400 flex-shrink-0">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />{apiError}
          </div>
        )}

        {/* ── Footer ── */}
        <div className="px-6 py-4 flex gap-3 bg-gray-50 dark:bg-[#253347] border-t border-gray-200 dark:border-gray-700 flex-shrink-0">
          <button onClick={onClose} className="btn-secondary flex-1 text-sm">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 bg-exl-orange hover:bg-exl-orange/90 text-white font-semibold text-sm rounded-xl disabled:opacity-50"
          >
            {saving
              ? <><Loader className="w-4 h-4 animate-spin" />{isEdit ? 'Saving…' : 'Creating…'}</>
              : <><Building2 className="w-4 h-4" />{isEdit ? 'Save Changes' : 'Save Customer'}</>}
          </button>
        </div>
      </div>
    </div>
  )
}
