import React from 'react'
import ReactDOM from 'react-dom/client'
import { createBrowserRouter, RouterProvider } from 'react-router-dom'
import App from './App.jsx'
import './index.css'

// Use createBrowserRouter (data router) so useBlocker works in any component.
// The wildcard route delegates all path matching to App's internal <Routes>.
const router = createBrowserRouter([
  { path: '*', element: <App /> },
])

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>,
)
