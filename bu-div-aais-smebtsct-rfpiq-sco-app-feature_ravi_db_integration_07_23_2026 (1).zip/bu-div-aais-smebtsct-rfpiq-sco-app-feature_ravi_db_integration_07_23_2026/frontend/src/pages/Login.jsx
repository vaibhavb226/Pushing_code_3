import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Sun, Moon } from 'lucide-react'
import { useTheme } from '../context/ThemeContext'

// ── Shake keyframe ────────────────────────────────────────
const SHAKE_STYLE = `
  @keyframes rfpaiq-shake {
    0%, 100% { transform: translateX(0); }
    10%, 30%, 50%, 70%, 90% { transform: translateX(-8px); }
    20%, 40%, 60%, 80% { transform: translateX(8px); }
  }
  .rfpaiq-shake { animation: rfpaiq-shake 0.45s ease-in-out; }
`

// ── Dummy users ───────────────────────────────────────────
const USERS = {
  'morgan.davis@foodcorp.com': {
    password: 'FoodCorpBid2026',
    name:     'Morgan Davis',
    title:    'Bid COE Manager',
    initials: 'MD',
  },
  'jamie.lee@foodcorp.com': {
    password: 'FoodCorpBid2026',
    name:     'Jamie Lee',
    title:    'Bid COE Analyst',
    initials: 'JL',
  },
  'taylor.smith@foodcorp.com': {
    password: 'FoodCorpBid2026',
    name:     'Taylor Smith',
    title:    'Bid COE Coordinator',
    initials: 'TS',
  },
}

export default function Login() {
  const navigate        = useNavigate()
  const { isDark, toggleTheme } = useTheme()
  const [email,    setEmail]    = useState('')
  const [password, setPassword] = useState('')
  const [error,    setError]    = useState('')
  const [shaking,  setShaking]  = useState(false)
  const [loading,  setLoading]  = useState(false)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    // Simulate a brief network delay for realism
    await new Promise(r => setTimeout(r, 600))

    const match = USERS[email.trim().toLowerCase()]
    if (match && match.password === password) {
      localStorage.setItem('rfpaiq_user', JSON.stringify({
        loggedIn: true,
        user: {
          name:     match.name,
          title:    match.title,
          email:    email.trim().toLowerCase(),
          initials: match.initials,
        },
      }))
      navigate('/bids', { replace: true })
    } else {
      setLoading(false)
      setError('Invalid email or password')
      setPassword('')
      // Trigger shake then remove class so it can replay
      setShaking(true)
      setTimeout(() => setShaking(false), 500)
    }
  }

  return (
    <>
      <style>{SHAKE_STYLE}</style>

      {/* Full-page navy background */}
      <div
        className="min-h-screen flex flex-col items-center justify-center px-4"
        style={{ backgroundColor: '#1F3864' }}
      >
        {/* Orange accent bar at very top */}
        <div
          className="fixed top-0 left-0 right-0 h-1"
          style={{ backgroundColor: '#E05A2B' }}
        />

        {/* Dark mode toggle — top right */}
        <button
          onClick={toggleTheme}
          className="fixed top-4 right-4 w-8 h-8 rounded-full flex items-center justify-center transition-colors"
          style={{ backgroundColor: 'rgba(255,255,255,0.12)', color: 'rgba(255,255,255,0.7)' }}
          title={isDark ? 'Switch to light mode' : 'Switch to dark mode'}
        >
          {isDark ? <Sun size={15} /> : <Moon size={15} />}
        </button>

        {/* Login card */}
        <div
          className={`w-full max-w-[400px] bg-white dark:bg-[#1E293B] dark:border dark:border-gray-700 rounded-2xl shadow-2xl overflow-hidden ${shaking ? 'rfpaiq-shake' : ''}`}
        >
          {/* Card header band */}
          <div
            className="px-8 pt-8 pb-6 text-center"
          >
            {/* FoodCorp logo */}
            <div className="flex justify-center mb-4">
              <div
                className="flex items-center justify-center px-5 py-2.5 rounded-xl shadow-sm border border-gray-100"
                style={{ backgroundColor: 'white', minWidth: 140 }}
              >
                <img
                  src="/FoodCorp-Logo.jpg"
                  alt="FoodCorp"
                  style={{ height: 40, objectFit: 'contain' }}
                  onError={e => {
                    e.currentTarget.style.display = 'none'
                    e.currentTarget.nextSibling.style.display = 'block'
                  }}
                />
                <span
                  style={{ display: 'none', fontWeight: 800, color: '#1F3864', fontSize: '20px', letterSpacing: '0.05em' }}
                >
                  FOODCORP
                </span>
              </div>
            </div>

            <h1
              className="text-2xl font-bold leading-tight"
              style={{ color: '#1F3864' }}
            >
              FoodCorp RFP AIQ
            </h1>
            <p className="text-sm text-gray-400 mt-1">
              Bid COE — Contract Customer Procurement
            </p>
          </div>

          {/* Divider */}
          <div className="mx-8 border-t border-gray-100" />

          {/* Form */}
          <form onSubmit={handleSubmit} className="px-8 py-6 space-y-4">
            {/* Error message */}
            {error && (
              <div className="flex items-center gap-2 bg-red-50 border border-red-200 text-red-700 text-sm px-3 py-2.5 rounded-xl">
                <span className="text-base leading-none">⚠</span>
                {error}
              </div>
            )}

            {/* Email */}
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@foodcorp.com"
                required
                autoFocus
                className="w-full px-4 py-2.5 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:border-transparent transition-all"
                style={{ '--tw-ring-color': 'rgba(31,56,100,0.3)' }}
              />
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1.5 uppercase tracking-wide">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••••••"
                required
                className="w-full px-4 py-2.5 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:border-transparent transition-all"
                style={{ '--tw-ring-color': 'rgba(31,56,100,0.3)' }}
              />
            </div>

            {/* Sign In button */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl text-white text-sm font-semibold transition-all disabled:opacity-70 disabled:cursor-wait mt-2"
              style={{ backgroundColor: '#E05A2B' }}
            >
              {loading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                  </svg>
                  Signing in…
                </span>
              ) : (
                'Sign In'
              )}
            </button>
          </form>

          {/* Footer — EXL logo */}
          <div className="px-8 pb-7">
            <hr style={{ border: 'none', borderTop: '1px solid #E5E7EB', margin: '16px 0 14px 0' }} />
            <div style={{ textAlign: 'center' }}>
              <img
                src="/exl_logo.png"
                alt="EXL Service"
                style={{ height: '48px', width: 'auto', display: 'block', margin: '0 auto 0 auto', opacity: 0.85 }}
              />
              <p style={{ fontSize: '11px', color: '#6B7280', margin: '0', letterSpacing: '0.3px' }}>
                Exlservice.com™ · © 2026
              </p>
            </div>
          </div>
        </div>

        {/* Version tag below card */}
        <p className="text-blue-400/40 text-xs mt-6">
          FoodCorp RFP AIQ · v1.0 · Confidential
        </p>
      </div>
    </>
  )
}
