#!/bin/bash
set -e  # Exit on any error

# =============================================================================
# Sysco RFP AIQ Deployment Script
# =============================================================================
# This script automates the deployment process to the production server
# Based on manual steps documented in hosting_flow.txt
# =============================================================================

# Configuration Variables
DEPLOY_USER="ravi345863"
DEPLOY_GROUP="users"
DEPLOY_BASE="/opt/sysco"
APP_NAME="sysco-rfp-aiq-main"
APP_DIR="${DEPLOY_BASE}/${APP_NAME}"
ENV_SOURCE="/opt/sysco/env_file/.env"
PM2_APP_NAME="backend"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# =============================================================================
# Helper Functions
# =============================================================================

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

check_command() {
    if ! command -v $1 &> /dev/null; then
        log_error "$1 is not installed"
        exit 1
    fi
}

# =============================================================================
# Deployment Steps
# =============================================================================

log_info "====================================================================="
log_info "Starting Sysco RFP AIQ Deployment"
log_info "====================================================================="
log_info "User: $(whoami)"
log_info "Timestamp: $(date '+%Y-%m-%d %H:%M:%S')"
log_info "Directory: $(pwd)"

# Step 1: Check required commands
log_info "Step 1: Checking required dependencies..."
check_command npm
check_command pm2
check_command nginx
log_info "✓ All dependencies found"

# Step 2: Stop existing PM2 process if runn ing
log_info "Step 2: Stopping existing backend process..."
if pm2 list | grep -q "${PM2_APP_NAME}"; then
    pm2 stop ${PM2_APP_NAME} || log_warn "Could not stop ${PM2_APP_NAME}"
    pm2 delete ${PM2_APP_NAME} || log_warn "Could not delete ${PM2_APP_NAME}"
    log_info "✓ Stopped existing backend process"
else
    log_info "✓ No existing backend process found"
fi

# Step 3: Remove old application directory
log_info "Step 3: Removing old application directory..."
if [ -d "${APP_DIR}" ]; then
    sudo rm -rf "${APP_DIR}"
    log_info "✓ Removed old directory: ${APP_DIR}"
else
    log_info "✓ No old directory to remove"
fi

# Step 4: Copy application files to APP_DIR
log_info "Step 4: Moving application files to ${APP_DIR}..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
log_info "Script source directory: ${SCRIPT_DIR}"
sudo mkdir -p "${DEPLOY_BASE}"
if [ "${SCRIPT_DIR}" != "${APP_DIR}" ]; then
    sudo cp -r "${SCRIPT_DIR}/." "${APP_DIR}"
    log_info "✓ Files copied to ${APP_DIR}"
else
    log_info "✓ Already in ${APP_DIR}, no copy needed"
fi

# Step 5: Ownership is set AFTER npm build (see end of Step 7) so node_modules get correct owner
log_info "Step 5: Ownership will be applied after frontend build..."

# Step 6: Copy environment file
log_info "Step 6: Copying environment configuration..."
if [ -f "${ENV_SOURCE}" ]; then
    sudo cp "${ENV_SOURCE}" "${APP_DIR}/backend_py/.env"
    log_info "✓ Environment file copied to ${APP_DIR}/backend_py/.env"
else
    log_warn "Environment file not found: ${ENV_SOURCE}, skipping..."
fi

# Step 7: Build Frontend
log_info "Step 7: Building frontend..."
cd "${APP_DIR}/frontend"
log_info "Installing frontend dependencies..."
npm install
log_info "Building frontend production bundle..."
npm run build
log_info "✓ Frontend built successfully"

# Fix ownership after npm build — node_modules are now included
log_info "Step 5 (deferred): Setting correct ownership on ${APP_DIR}..."
sudo chown -R ${DEPLOY_USER}:${DEPLOY_GROUP} "${APP_DIR}"
log_info "✓ Ownership set to ${DEPLOY_USER}:${DEPLOY_GROUP}"

# Step 8: Test and Restart Nginx
log_info "Step 8: Restarting Nginx..."
sudo nginx -t
if [ $? -eq 0 ]; then
    sudo systemctl restart nginx
    log_info "✓ Nginx restarted successfully"
else
    log_error "Nginx configuration test failed"
    exit 1
fi

# Step 9: Setup Python Virtual Environment
log_info "Step 9: Setting up Python backend..."
cd "${APP_DIR}/backend_py"

if [ ! -d ".venv" ]; then
    log_info "Creating Python virtual environment..."
    python3 -m venv .venv
    log_info "✓ Virtual environment created at ${APP_DIR}/backend_py/.venv"
fi

log_info "Installing/updating Python dependencies..."
"${APP_DIR}/backend_py/.venv/bin/pip" install -r requirements.txt
log_info "✓ Python dependencies installed"

# Step 10: Start Backend with PM2
# Use the venv Python binary with -m uvicorn — PM2 cannot run Python scripts directly
log_info "Step 10: Starting backend with PM2..."
pm2 start "${APP_DIR}/backend_py/.venv/bin/python" \
  --name "${PM2_APP_NAME}" \
  --cwd "${APP_DIR}/backend_py" \
  -- -m uvicorn main:app --host 0.0.0.0 --port 3001

# Save PM2 process list
pm2 save
log_info "✓ Backend started and PM2 configuration saved"

# Step 11: Setup PM2 Startup (if needed)
log_info "Step 11: Configuring PM2 startup..."
USER_HOME=$(getent passwd ${DEPLOY_USER} | cut -d: -f6)
if [ -z "${USER_HOME}" ]; then
    USER_HOME="/home/${DEPLOY_USER}"
fi
# Pre-create .pm2 as the deploy user so PM2 startup doesn't create it as root
sudo -u ${DEPLOY_USER} mkdir -p "${USER_HOME}/.pm2"
sudo env PATH=$PATH:/usr/bin /usr/local/lib/node_modules/pm2/bin/pm2 startup systemd -u ${DEPLOY_USER} --hp ${USER_HOME} || log_warn "PM2 startup already configured"

# Step 12: Verify Deployment
log_info "Step 12: Verifying deployment..."
sleep 3
if pm2 list | grep -q "${PM2_APP_NAME}.*online"; then
    log_info "✓ Backend process is running"
else
    log_error "Backend process failed to start"
    pm2 logs ${PM2_APP_NAME} --lines 20
    exit 1
fi

# Display status
log_info "====================================================================="
log_info "Deployment Summary"
log_info "====================================================================="
pm2 list
log_info ""
log_info "Nginx Status:"
sudo systemctl status nginx --no-pager | head -n 5
log_info "====================================================================="
log_info "✓ DEPLOYMENT COMPLETED SUCCESSFULLY"
log_info "====================================================================="
log_info "Backend API: http://localhost:3001"
log_info "====================================================================="

exit 0