# FoodCorp RFP AIQ — Bid Management Platform

> **EXL Service | FoodCorp | July 2026 | CONFIDENTIAL**
> AI-powered Bid Management Platform for FoodCorp's Bid Center of Excellence (Bid COE).

---

## Quick Start

### Node.js backend (original)

#### Prerequisites
- Node.js 18+, npm 9+
- Anthropic API key (`ANTHROPIC_API_KEY` in `backend/.env`)

```bash
# Backend (port 3001)
cd backend && npm install && npm run dev

# Frontend (port 5173) — new terminal
cd frontend && npm install && npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

---

### Python backend (production — Cloud Run)

#### Prerequisites
- Python 3.12+
- GCP project with Secret Manager enabled
- PostgreSQL reachable via PSC endpoint IP

```bash
cd backend_py
pip install -r requirements.txt

# Copy env template — fill in non-secret values only
cp .env.example .env

# Secrets (ANTHROPIC_API_KEY, EMAIL_APP_PASSWORD, MS_CLIENT_SECRET, DB_USER, DB_PASS, etc.)
# are loaded automatically from GCP Secret Manager when GCP_PROJECT is set in .env.
# For local dev without SM access, uncomment and set the values directly in .env.

uvicorn main:app --reload --port 3001
```

Swagger docs: [http://localhost:3001/api/docs](http://localhost:3001/api/docs)

---

## Project Structure

```
sysco-bid-poc/
├── frontend/                    # React 18 + Tailwind CSS + Vite
│   ├── src/
│   │   ├── components/
│   │   │   ├── BidQueue/        # Session 2 — Dashboard + segment filter
│   │   │   ├── BidDetail/       # Session 2 — 4-tab bid detail view
│   │   │   ├── SupplierList/    # Session 3 — OP3A + OP3B auto-populate
│   │   │   ├── WorkingFile/     # Session 4 — OP7 + OP8 two-step import
│   │   │   ├── EmailRepo/       # Session 5 — OP5 email thread
│   │   │   ├── DocumentVault/   # Session 5 — OP6 document repository
│   │   │   └── BexAI/           # Session 3 — OP2 RFP parser
│   │   ├── data/                # Dummy JSON files (see below)
│   │   ├── hooks/               # Custom React hooks
│   │   ├── utils/               # Helpers (CSV export, formatting, etc.)
│   │   ├── App.jsx              # Routing + sidebar layout
│   │   ├── main.jsx
│   │   └── index.css            # Tailwind + custom classes
│   ├── index.html
│   ├── vite.config.js
│   ├── tailwind.config.js
│   └── package.json
│
├── backend/                     # Node.js + Express
│   ├── routes/
│   │   ├── bids.js              # GET /api/bids, GET /api/bids/:id
│   │   ├── suppliers.js         # GET /api/suppliers, POST /api/suppliers/auto-populate
│   │   ├── rfpParser.js         # POST /api/parse-rfp (BEX AI — OP2)
│   │   ├── pricing.js           # POST /api/extract-pricing (OP7)
│   │   ├── emails.js            # GET /api/emails, POST /api/emails/log
│   │   └── documents.js         # GET /api/documents
│   ├── data/                    # Same 6 JSON files as frontend/src/data/
│   ├── uploads/                 # Temp upload dir (gitignored)
│   ├── server.js
│   └── package.json
│
├── .env.example                 # Environment variable template
├── .gitignore
└── README.md
```

---

## Dummy Data Files

All data is fictional. **No real client data is stored.**

| File | Records | Description |
|------|---------|-------------|
| `bids.json` | 15 bids | K-12, DoD, University, Healthcare, Restaurant, Lodging, Government. Primary demo: **BID-106** (Arapahoe Charter School) |
| `suppliers.json` | 20 suppliers | Acxion, Mars Ben's, Super Bakery, General Mills, Dole, J&J Snack, Pepsico, Campbell, NFG, Midamar, Michael Foods, Kikkoman, Affinity Sales, Lake & Cincinnati, DDReckner, CORE, Tyson, Heartland (bounced), Land O Lakes, SW Paper |
| `lineItems.json` | 28 items | CPS SY 2025-26 Assorted Foods list — Fluid Milk, Fruit, Grain, Snack, M/MA, M/MA+Grain. All compliance flags included. |
| `emailThreads.json` | 6 emails | E1 solicitation outbound → E2 Acxion/Mars Ben's response → E3 Super Bakery response → E4 General Mills → E5 Midamar re-solicit → E6 Midamar confirmation |
| `pricingData.json` | 12 records | Acxion Quote #27037, Super Bakery #OH-2026-06991, plus Dole, Midamar, General Mills, NFG, J&J pricing with ALLW/DL deviations and confidence scores |
| `documents.json` | 10 docs | RFPs, supplier quotes, compliance certs, spec sheets. Organised by supplier category. |

---

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/health` | Health check — confirms Anthropic key is set |
| GET | `/api/bids` | All bids (filter: `?segment=K-12&status=Solicitation`) |
| GET | `/api/bids/:id` | Single bid by ID |
| GET | `/api/suppliers` | All suppliers (filter: `?category=Protein&segment=K-12`) |
| POST | `/api/suppliers/auto-populate` | OP3A — Match suppliers to bid item categories |
| POST | `/api/parse-rfp` | OP2 — BEX AI: parse uploaded RFP (or `?demo=true`) |
| POST | `/api/extract-pricing` | OP7 — AI pricing extraction (or `?demo=true`) |
| GET | `/api/emails` | All emails (filter: `?bidId=BID-106`) |
| POST | `/api/emails/log` | Log a sent solicitation email |
| GET | `/api/documents` | All documents (filter: `?bidId=&supplier=&category=`) |

---

## Email Setup (Gmail SMTP)

> **Applies to the Node.js backend only.** The Python backend (`backend_py/`) uses **Microsoft
> Graph only** (the Gmail provider was removed July 9, 2026) — configure `MS_TENANT_ID`,
> `MS_CLIENT_ID`, `MS_CLIENT_SECRET`, `MS_MAILBOX_USER_ID` instead; see `backend_py/README.md`.

Solicitation emails are sent via Gmail SMTP using Nodemailer. Follow these steps to configure a sending address:

### 1 — Create a dedicated Gmail account

Create a Gmail account specifically for the POC (e.g. `sysco.bid.poc@gmail.com`). Do **not** use a personal or corporate Gmail account.

### 2 — Enable 2-Step Verification

1. Sign in to the Gmail account
2. Go to **Google Account → Security**
3. Under "How you sign in to Google", enable **2-Step Verification**

### 3 — Generate an App Password

1. Go to **Google Account → Security → 2-Step Verification**
2. Scroll to the bottom → click **App passwords**
3. Select app: **Mail** | Select device: **Other (custom name)** → type `FoodCorp BID POC`
4. Click **Generate** — copy the 16-character password (shown once)

### 4 — Configure credentials

**Node backend** — add to `backend/.env`:
```env
EMAIL_FROM=demo@foodcorp.com
EMAIL_APP_PASSWORD=xxxx xxxx xxxx xxxx   # 16-char App Password (spaces OK)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
```

**Python backend (Cloud Run)** — does **not** use Gmail. It sends via Microsoft Graph; store
`MS_TENANT_ID` / `MS_CLIENT_ID` / `MS_CLIENT_SECRET` in GCP Secret Manager and set
`MS_MAILBOX_USER_ID`. See `backend_py/README.md` for details.

### 5 — Verify at startup

When the backend starts, you should see:
```
📧 Email SMTP: ✅ Connected — demo@foodcorp.com
```

If you see `⚠️ Not configured`, double-check the App Password — it must be a Google App Password, **not** your regular Gmail password.

### Notes
- Gmail SMTP uses **STARTTLS** on port 587 (not SSL on 465)
- All supplier emails go to **BCC** — recipients cannot see each other
- The `To:` field is set to the sender address (Gmail requires a To)
- In the POC, attachment filenames are listed in the email body; real file attachments are Phase 2
- Gmail free accounts allow ~500 emails/day; upgrade to Google Workspace for production use

---

## Anthropic System Prompts

### BEX AI — RFP Parser (OP2)
Extracts bid metadata + all line items from uploaded RFP documents. Returns structured JSON with compliance flags, supplier targeting recommendations, and parsing confidence score.

**File combination behaviour:**

| Files uploaded | Line items source | Metadata source |
|---|---|---|
| PDF + Excel | Excel only | PDF |
| PDF only, items in PDF | PDF | PDF |
| PDF only, no items | `[]` (no hallucination) | PDF |
| Excel only | Excel | sparse / null |

Key prompt rules (in `backend_py/routers/prompts.py`):
- When Excel is present: items come from Excel **exclusively** — PDF is metadata-only
- Never hallucinate items; missing fields are `null` not guessed

### AI Pricing Extraction (OP7 + OP8)
Matches supplier pricing documents to RFP line items using SUPC exact match + description fuzzy match + attribute matching. Returns confidence scores (≥90% green, 75-89% amber, <75% red + manual review).

### Q&A Response Drafter
Drafts professional responses to supplier questions about bid requirements (Buy American Act Section 4.2, CN labels, PFS documentation).

---

## Recent Changes (July 2026)

### Whole Grain, Halal, Kosher Compliance Flags — August 2026

Added three new per-item compliance boolean fields (`whole_grain`, `halal`, `kosher`) to the BEX extraction pipeline. Previously these certifications appeared only in the metadata-level `compliance_flags` free-text array but had no structured per-item DB columns.

- **`bex_schemas.py`** — new `Optional[bool]` fields on `BEXLineItem`
- **`prompts.py`** — 4 prompts updated: `BEX_SYSTEM_PROMPT`, `BEX_USER_PDF_WITH_ITEMS`, `EXCEL_STRUCTURE_LOCATOR_SYSTEM`, `EXCEL_CHUNK_MAP_SYSTEM`; column abbreviations `WG / HL / KS` added alongside existing `CN / BA / PFS / ES`
- **`rfp_parser.py`** — `build_line_item()` maps snake_case → camelCase (`wholeGrain`, `halal`, `kosher`)
- **`pg_line_items_repo.py`** — `_to_app`, `_to_db`, all three SQL statements updated; positional params `$24–$26` now carry the new flags, shifting subsequent params to `$27–$38`
- **`migrations/add_whole_grain_halal_kosher.sql`** — run once to add the 3 columns to existing DBs
- **`services/sql_agent/schema.py`** — `SCHEMA_SUMMARY` updated so the RFP AIQ SQL agent knows the columns exist

> SOX stays metadata-only — it is a financial/contract-level compliance, not a per-item food attribute.

---

### Report Email, RFP Duplicate Detection, Solicitation Attachments — July 21, 2026 (Session 10)

**Dynamic report email sent as HTML attachment (`backend_py/routers/reports.py`):**

`POST /api/reports/send-email` now generates a live HTML report at send time instead of sending the static template as the body. On every send: all bids are loaded, response rates computed from `solicitedSuppliers`, a IIFE script is injected to update the 5 KPI card values and the "Bids Requiring Immediate Attention" table, and the result is written to a temp file and sent as a `.html` file attachment. Email body becomes a short plain-text note. Temp file is cleaned up in a `finally` block.

**RFP duplicate detection via filename hash (pre-parse, before the LLM is called):**

SHA-256 of the combined filename string (`"rfp.pdf+items.xlsx"`, or just `"rfp.pdf"` for single file) — first 8 hex chars used as the fingerprint. Hash is computed in the frontend on file select (`crypto.subtle.digest` + `TextEncoder`), a lightweight `GET /api/parse-rfp/check-hash?hash=` endpoint is called immediately, and the result is shown inline:

- Spinner while checking
- Red error banner + "Open Bid →" link if a duplicate is found — Extract button is disabled
- Grey "RFP ID will be `RFP-{hash}`" chip if no duplicate

The hash is returned from `POST /api/parse-rfp` as `rfpFileHash` and used as the Bid ID in Step 2 — AI-extracted `metadata.bid_id` from the file content is intentionally ignored. `POST /api/bids` validates uniqueness as a second safety guard and returns HTTP 409 if the hash collides.

**Solicitation attachments now appear in Email Repo:**

When a solicitation email is sent with RFP/Item List files checked in the EmailComposer, the stored email record in `emailThreads.json` previously always had `"attachments": []`. Fixed: `create_bid_email` in `backend_py/routers/bids.py` now stores plain filename strings (`.split("/")[-1]`) for outbound emails; `backend/routes/bids.js` has matching parity. The Email Repo tab's existing filename-pill rendering handles the legacy string format correctly.

---

### Email Repo Filter Bugs — July 21, 2026 (Session 9)

**"Responded" count drops to 0 after running "Check for Issues" (`backend_py`):**

`PATCH /api/bids/{bid_id}/emails/{email_id}/analysis` had a side-effect: when the AI analysis flagged pricing file problems it wrote `"Issues Found"` to `solicitedSuppliers[].status`. This is wrong — "Issues Found" means email delivery failure (bounce), not a content problem with the pricing file. A supplier who submitted a file with issues is still "Responded". The `SOLICITED_OVERRIDE` logic in the frontend then permanently overrode the thread-derived "Responded" status, collapsing the Responded count. Fix: the analysis endpoint now only saves `analysisResult` to the email record — zero side effects on bid/supplier status. Also fixed: `GET .../emails/by-supplier` no longer derives "Issues Found" from `analysisResult`; only `isBounce: true` triggers that status. Same fix applied to `backend/routes/bids.js`.

**Email Repo filter pill mismatches and stale state (`EmailRepoTab.jsx`):**

- "Responded" filter included `'Issues Found'` — bounce suppliers appeared in the Responded view
- Awaiting filter predicate was `status === 'Awaiting'` but the count included `null` and `'Contacted'` — mismatch fixed
- `isLatest` prop assigned to oldest email instead of newest — newest email now starts expanded
- `handleToggleInConsideration` unflag hardcoded `'Responded'` even for `'Awarded'`/`'Complete'` — now preserves existing status
- `handleMarkAwarded` read stale `bid.completedSuppliers` prop — now uses fresh `latestBid.completedSuppliers`

---

### Extract Pricing Dark Mode + `message_id` AttributeError — July 21, 2026 (Session 8)

**`msg.message_id` AttributeError — ALL outbound emails failing (`backend_py`):**

Critical regression introduced in Session 7 when `message_id` was removed from `EmailMessage` dataclass. Two return statements in `msgraph_provider.py` still referenced `msg.message_id`: `_draft_and_send` (line 252) and `_create_reply_and_send` (line 336). Every outbound email threw `AttributeError`, producing spurious `isBounce: True` records instead of sending. Fix: replaced `msg.message_id or ""` with `""` on both lines. Two spurious bounce records also removed from `emailThreads.json`. No callers use the `messageId` return key — all callers only read `graphInternetMessageId`.

**Extract Pricing button not visible in dark mode (`EmailRepoTab.jsx`):**

Two locations fixed:
- Location A (EmailBubble action bar): added `dark:bg-[#1E293B] dark:border-blue-400 dark:text-blue-300 dark:hover:bg-blue-400 dark:hover:text-gray-900`
- Location B (amber "pricing file detected" banner): added `dark:bg-amber-900/20 dark:border-amber-700/50` on container; `dark:text-amber-300` on label

---

### GCS URL Display + Refresh Feedback + Poller Crash + Pricing Extract — July 21, 2026

**GCS URL showing in email attachment pills (frontend):**

When a bid has GCS-backed uploaded files (`gs://bucket/…/bidId_RFP.pdf`), the EmailComposer attachment checklist was displaying the full URI instead of the filename. Fix: `{a}` → `{a.split('/').pop()}` in `EmailComposer.jsx` line 300. The full URI is still passed to the backend (needed for GCS download); only the display is changed.

**Email Repo refresh button has no visual feedback (frontend):**

Clicking the `RefreshCw` icon in Email Repo header called `fetchData()` directly with no loading state — the button appeared idle during the fetch. Added `isRefreshing` state + `handleRefresh` wrapper in `EmailRepoTab.jsx`. The icon now spins orange while the fetch is in flight and the button is disabled to prevent double-clicks.

**Poller crash: `'NoneType' object is not subscriptable` + bounce suppliers stuck "Awaiting" (`backend_py`):**

Root cause: when `_extract_recipient_block` was added to `email_poller.py` (for the per-recipient bounce body fix), the `return { bounceCode, bounceReason, recipients, … }` dict from `_parse_bounce` was accidentally indented inside `_extract_recipient_block` — after that function's own `return` — making it dead code. `_parse_bounce` returned `None` implicitly; `bounce_info["recipients"]` in `_handle_matched` then raised `TypeError`. Every poll cycle that encountered an NDR crashed silently, so bounce emails were never written and suppliers stayed "Awaiting". Fix: moved the return dict back to the end of `_parse_bounce` (properly dedented), and removed the dead code from `_extract_recipient_block`.

> After applying this fix: delete `backend_py/data/pollState.json` and restart the backend. The poller will do a 72-hour cold-start lookback and re-process the NDRs, updating supplier statuses to "Issues Found".

**Pricing extraction `settings is not defined` (`backend_py`):**

`_extract_generic_pricing` in `bids.py` referenced bare `settings.llm_max_tokens` but `settings` was never assigned in scope. Fix: `settings.llm_max_tokens` → `get_settings().llm_max_tokens` (matches the pattern used in `analyse_response.py` and `rfp_parser.py`; `get_settings` was already imported at line 33).

**Dark mode — `text-exl-navy` headings and stat numbers invisible:**

`text-exl-navy` (`#1F3864`) is invisible on dark backgrounds. Added `dark:text-white` to all page-level `<h1>` headings and `dark:text-blue-300` to section headings and stat card values:

| File | Element | Fix |
|------|---------|-----|
| `BidQueue/StatCards.jsx` | "Active RFPs" card value + icon | `accent` prop → `dark:text-blue-300` |
| `DocumentVault/index.jsx` | `<h1>`, stat values | `dark:text-white` / `dark:text-blue-300` |
| `BidQueue/index.jsx` | `<h1>` "Bid Queue" | `dark:text-white` |
| `BexAI/index.jsx` | `<h1>`, "Unsaved Files" `<h2>` | `dark:text-white` / `dark:text-blue-300` |
| `OverviewTab.jsx` | `InfoRow` `<h3>`, "RFP Documents" `<h3>` | `dark:text-blue-300` |

---

### Email Threading + Bounce Body + Dark Mode — July 21, 2026

**Email threading re-fix (`backend_py`):**

The `createReply`-based Graph threading had silently broken again. Three separate bugs identified and fixed:

- `_get_last_internet_message_id` in `bids.py` never received `supplier_email` — the email-address fallback branch was dead code at all three call sites (solicitation follow-up, portal-reply, re-solicit). Fixed: all call sites now pass `supplier_email=body.get("to", "")`.
- Extended the fallback to also scan outbound records by `supplierEmail` field regardless of `supplierId` — fixes mass-BCC solicitation records where `supplierId` may be null.
- `msgraph_provider.py` `_create_reply_and_send` now also searches `SentItems` folder when the main mailbox search returns no match — Exchange indexes sent mail reliably there.
- Removed dead code: `_generate_smtp_message_id()`, `_get_thread_smtp_ids()` in `bids.py`; `in_reply_to`, `references`, `message_id` fields on `EmailMessage` dataclass in `base.py` (superseded by `in_reply_to_internet_message_id`).

**Bounce email body shows only the relevant recipient (`backend_py`):**

Previously, each supplier's bounce record in Email Repo displayed the full Exchange NDR listing every failed `@demo-*.test` address. Two-part fix:
- Backend (`email_poller.py`): `_extract_recipient_block()` helper slices the per-recipient NDR paragraph for each supplier in the fan-out loop, replacing the full NDR text as the record `body`.
- Frontend (`EmailRepoTab.jsx`): the `<pre>` body block is now guarded by `isBounce` — bounce emails show "Delivery failure details shown above." instead of rendering the raw body.

**Dark mode — comprehensive UI fixes (frontend):**

All components with hardcoded `bg-white` or inline `style={{ backgroundColor }}` objects (which cannot have `dark:` Tailwind variants) were updated. Five component files fixed:

| Component | Coverage |
|-----------|----------|
| `WorkingFileTab.jsx` | Converted `BLUE_BG`, `YELLOW_BG`, `SUB_ROW_BG` inline style constants to `dark:bg-[...]` Tailwind class strings; RFP white cells, supplier blue cells, COE yellow cells, sub-rows, Customize Columns panel |
| `EmailRepoTab.jsx` | EmailBubble cards (inbound/outbound), SolicitationDetail, SupplierThread header/action bar, LogResponse/FollowUp/PortalReply modals, outer shell, filter pills, bounce banner |
| `SuppliersTab.jsx` | ReminderModal, ResolicitModal, BulkAwardModal — backgrounds, dividers, textarea/input, footer bars |
| `BidCard.jsx` | DeleteBidModal, three-dot dropdown menu items and separator |
| `OverviewTab.jsx` | File grid cards, upload drawer panel + header/footer, all edit form inputs (`inputCls`), read-only Bid ID field, timeline circles, stat mini-cards |

Dark color system used: `dark:bg-[#1E293B]` (card/panel), `dark:bg-[#253347]` (secondary/header), `dark:bg-[#1a2f45]` (blue section), `dark:bg-[#2a2000]` (yellow section), `dark:bg-[#162030]` (sub-row).

---

### FoodCorp Rebrand + Chat AIQ Parity — July 20–21, 2026

**FoodCorp rebrand (frontend + Python backend + data files):**
All Sysco branding replaced with FoodCorp across the full app. EXL Service branding (logos, "Powered by EXL Service", `bg-exl-orange` tokens) is unchanged — EXL is the vendor/builder.

- Login credentials updated to `morgan.davis@foodcorp.com`, `jamie.lee@foodcorp.com`, `taylor.smith@foodcorp.com` / `FoodCorpBid2026`
- Logo: `FoodCorp-Logo.jpg`; sidebar subtitle changed to **"Bid Management Platform"**
- COE email address: `bids@foodcorp.com` (was `COE.BIDS@sysco.com`)
- OpCo names: `FoodCorp [City]` in bids.json; `FC Code` replacing `Sysco Code` / SUPC in Working File UI
- All AI system prompts updated (prompts.py, ai_chat.py); SMTP Message-ID domain `@foodcorp.bid`
- Data files: bids.json opcoNames, documents.json uploadedBy names, lineItems.json MPC codes, suppliers.json demo contacts, emailThreads.json from/to/body, unmatchedEmails.json
- Report renamed: `FoodCorp_Bid_Pipeline_Report.html`
- Node.js backend (`backend/`) left completely unchanged

**Chat AIQ Python parity (`backend_py/routers/ai_chat.py`):**
- `_build_system_prompt()` rewritten to match the Node.js reference: assembles `[BIDS SUMMARY]`, `[SUPPLIER ACTIVITY]`, `[DOCUMENT VAULT]`, `[RECENT EMAIL ACTIVITY]`, `[DOCUMENT VAULT CONTENTS]` (text extracted from first 10 uploaded files), and `[LAKEVIEW HISTORICAL DATA]` sections
- Lakeview multi-year XLSX moved to `backend_py/data/` (was in gitignored `uploads/`) so the AIQ context is always populated
- Sidebar "Chat with AIQ" button now toggles: orange when drawer is open, closes on second click

---

### Inbox Poller Bounce Fan-Out + UTF-8 BOM Fix — July 20, 2026 (`backend_py`)

Fixed two bugs in the Exchange NDR (bounce) processing pipeline and a startup crash caused by a BOM-encoded data file.

**Bug 1 — Exchange NDR bodies use `<mailto:email>` format for failed recipients**

The angle-bracket regex `<([a-zA-Z0-9...]+@...)>` was skipping `<mailto:email>` links because `:` is not in the character class. Exchange relay addresses in the diagnostic section *were* captured, so `recipients` appeared non-empty — silently preventing the `_ANY_EMAIL_RE` last-resort from running. Fixed: `<(?:mailto:)?([...]+@...)>`.

**Bug 2 — Fallback wrote duplicate records on every poll cycle**

When no solicited supplier matched, the `wrote == 0` fallback created a new `supplierId: null` record unconditionally. Each 15-second poll cycle duplicated it, inflating the badge count past 20. Fixed: fallback now checks the same `(uid, recipient)` dedup set used by the main fan-out loop.

**UTF-8 BOM crash** (`repositories/base.py`)

PowerShell 5.1 saves files with UTF-8 BOM by default. Any JSON data file written by a PS cleanup script crashed `json.loads()` at backend startup. Fixed: `encoding="utf-8"` → `encoding="utf-8-sig"` in `_read()` — transparent on clean files, silently strips BOM when present.

Files changed: `services/email_poller.py`, `repositories/base.py`.

---

### RFP Extraction Overhaul — Chunked LLM Mapping with PDF Compliance Context (`backend_py`)

`POST /api/parse-rfp` was reworked so large, messy, multi-sheet RFP files parse accurately without
dropping rows or losing per-item compliance flags. Previously the whole Excel/PDF was truncated
(~50k chars) and fed to one LLM call, which lost rows, mis-detected headers, and discarded
compliance flags from Excel-path parses (they live in the PDF, not Excel columns).

**Excel — LLM structure locator + parallel chunked mapping** (`services/excel_structurer.py`):
- One cheap locator call on a 15-row sample identifies per sheet: `is_item_sheet`,
  `header_row_index` (semantic — handles title/notes rows above the real header), and `column_map`.
  Junk sheets (terms, instructions) are skipped automatically.
- Data rows are split into **100-row chunks** and each chunk is mapped by the LLM **in parallel**
  (`asyncio.gather` + `Semaphore(6)`). Each chunk receives a **stable prefix** — the header row +
  the PDF compliance context — enabling Gemini 2.5 implicit caching and per-item CN/BA/PFS/ES.
- Per-chunk deterministic fallback if the LLM fails: rows are never lost.

**PDF compliance context** — one upfront `_extract_pdf_context()` call (`PDF_CONTEXT_EXTRACTION_SYSTEM`)
extracts `metadata` + a compact `compliance_context` (per-item flag table rows or global prose rules).
This context rides as the stable prefix in every Excel chunk call, so the LLM cross-references the
RFP exactly as the old combined-context call did.

**PDF extraction** (`services/pdf_structurer.py`):
- Per page: `page.find_tables()` emitted as TSV **and** full `get_text("text")` — both always kept.
- `PDF_CHAR_LIMIT` optional: set a number to cap, or leave empty to read the entire PDF.
- Large PDFs are page-chunked and parsed concurrently.

**Bug fix (July 16):** the locator's `header_row_index` was silently discarded when the column map
didn't include a field keyed exactly `"description"` (e.g. "Item Name", "Product", "Commodity"),
forcing the keyword fallback on every parse. The over-strict guard was removed.

> The `/api/parse-rfp` response contract is unchanged (`{ metadata, line_items, supplier_targeting,
> parsing_warnings, … }`). Node.js backend untouched.

### Portal Attachment & Confidence Fixes (`backend_py`)

**Portal file upload now works end-to-end:**
- Pricing files uploaded via `/submit/:bidId` now appear as attachments in the Email Repo tab — root cause was a FastAPI multipart field name mismatch (`pricingFile` sent by frontend vs `pricing_file` looked up by backend). Fixed with `File(None, alias="pricingFile")`.
- Follow-up messages sent from the portal thread view now correctly save body text and attachments — `post_message` was expecting a JSON body but the frontend posts `multipart/form-data`. Refactored to `Form(...)` fields + `UploadFile`.

**Pricing extraction confidence scores are more lenient:**
- Base score of +10 for any matched item (was 0)
- Word-length floor lowered from >4 to >2 chars so short words ("egg", "oil") contribute
- Fuzzy blend ratio shifted from 70/30 to 60/40 (fuzzy score has more influence)
- Fuzzy match threshold lowered from 0.3 to 0.2 (more items get a fallback match)
- LLM prompt updated to explicitly prefer 60–80 scores for same-category matches

### Email System — Outbound Threading & CC (`backend_py`)

All 9 email send paths (solicitation, reply, re-solicit, reminder, bounce re-solicit, award single/bulk, portal-reply, auto-reminder) now support:

- **CC to additional contacts** — `additionalEmails` on each `solicitedSuppliers` entry is CC'd on every individual send
- **SMTP tracking headers** — every outbound email gets a synthetic `smtpMessageId` stored on its `emailThreads.json` record; used for UI thread ordering and `In-Reply-To` correlation stored as `x-foodcorp-bid-*` custom headers (MS Graph only accepts `x-` prefixed `internetMessageHeaders`)
- **Non-blocking sends** — `create_bid_email` dispatches via FastAPI `BackgroundTasks`; returns 201 immediately; API-level failures write a bounce record with `isBounce: true` instead of returning HTTP 502
- **`EmailMessage` dataclass** (`services/email/base.py`): new optional fields `cc`, `in_reply_to`, `references`, `message_id`

> **MS Graph constraint:** Standard RFC 2822 headers (`Message-ID`, `In-Reply-To`, `References`) cannot be set via `internetMessageHeaders` — Graph rejects them with HTTP 400. Supplier-side thread grouping currently relies on the `Re:` subject prefix. True thread linking requires the two-step draft+send API (deferred).

### Supplier Portal Parity (`backend_py/routers/submissions.py`)

23 gaps between the Python and Node.js portal implementations were fixed:

| Area | Key fixes |
|------|-----------|
| Submission record | `phone`, `dlCount`, `allwCount`, `otherPricedCount` now stored; initial message created in `messages[]` |
| Pricing count | `deliveredPrice` and `fobPrice` now included in `pricedCount` logic |
| emailThreads mirror | Subject, `from`, `to`, tags, body, and attachments now match Node.js format |
| Channel tracking | `solicitedSuppliers[].channel` set to `"Portal"` or `"Both"` on submission |
| Status guard | Only `Awaiting → Responded` (was too broad) |
| Follow-up mirror | Includes `supplierId`, `confirmationId`, `analysisResult`, correct subject/tags |
| Email gate | Always required on `GET /thread/:threadId` — 401 if absent, 403 if wrong (was skippable) |
| Response field | `POST /message` returns `success: true` (was `ok: true`) |

---

## Development Sessions

| Session | Status | Focus |
|---------|--------|-------|
| **Session 1** | ✅ Complete | Project setup + all 6 dummy data files |
| **Session 2** | ✅ Complete | Bid Queue dashboard + segment filter + BidDetail tabs |
| **Session 3** | ✅ Complete | Supplier List auto-populate + BEX AI tab |
| **Session 4** | ✅ Complete | Working File two-step import + pricing extraction |
| **Session 5** | ✅ Complete | Email Repo + Document Vault + Python backend |
| **Python backend** | ✅ Active | FastAPI port — Cloud Run production target |
| **Session 5** | ✅ Complete | FoodCorp rebrand + Chat AIQ parity + portal / email fixes |
| **Session 6** | ✅ Complete | Email threading re-fix + bounce body per-recipient + full dark mode |
| **Session 7** | ✅ Complete | GCS URL display + refresh feedback + poller crash + pricing extract fix + nav dark mode |
| **Session 8** | ✅ Complete | Extract pricing dark mode + `message_id` AttributeError fix |
| **Session 9** | ✅ Complete | Email Repo filter bugs — Responded count, filter mismatches, stale state |
| **Session 10** | ✅ Complete | Report email as live HTML attachment + RFP dedup via filename hash + solicitation attachments |

---

## Brand Colors

| Color | Hex | Usage |
|-------|-----|-------|
| EXL Orange | `#E05A2B` | Primary buttons, titles, accents |
| EXL Navy | `#1F3864` | Sidebar, headers |

---

## Key Terminology

| Term | Definition |
|------|-----------|
| ALLW | Allowance — off-invoice discount from manufacturer |
| DL | Delivered Cost — manufacturer guarantees delivered price |
| BEX | Bid Extraction System — replaced by this AI tool |
| Bid COE | Center of Excellence — FoodCorp's bid management team |
| CN | Child Nutrition — USDA cert required for K-12 |
| PFS | Product Formulation Statement — proves CN compliance |
| WGR | Whole Grain Rich — USDA NSLP requirement (≥51% whole grain by weight, K-12 grain items) |
| Halal | Dietary law certification — required for DoD and Healthcare bids |
| Kosher | Jewish dietary law certification — required for certain Healthcare and Government bids |
| SOX | Sarbanes-Oxley — drives supplier acknowledgement requirement (contract-level, not per-item) |
| OpCo | Operating Company — regional distribution center |
| FC Code | FoodCorp internal product code (assigned from item master post-award) |

---

*Document prepared by EXL Service | FoodCorp Bid COE Team | July 2026 | CONFIDENTIAL*
