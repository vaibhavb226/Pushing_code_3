import { config as dotenvConfig } from 'dotenv'
dotenvConfig({ override: true })
import express from 'express'
import cors from 'cors'
import { readFileSync, writeFileSync, createReadStream, statSync, existsSync, readdirSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join, extname } from 'path'

// Routes
import bidsRouter            from './routes/bids.js'
import suppliersRouter       from './routes/suppliers.js'
import rfpParserRouter       from './routes/rfpParser.js'
import pricingRouter         from './routes/pricing.js'
import emailsRouter          from './routes/emails.js'
import documentsRouter       from './routes/documents.js'
import analyseResponseRouter from './routes/analyseResponse.js'
import aiRouter             from './routes/ai.js'
import submissionsRouter     from './routes/submissions.js'

// Services
import { verifyEmailConfig }  from './services/emailService.js'
import { startEmailPoller, runPoll } from './services/emailPoller.js'
import { ensureBounceDemo }          from './services/demoData.js'
import { parseLineItemsFromExcel, parseLineItemsFromPDF } from './services/lineItemParser.js'

// ── Category → supplier-category mapping (mirrors suppliers.js auto-populate) ──
const CATEGORY_MAP = {
  'Fluid Milk': ['Dairy'],
  'Fruit':      ['Produce', 'Broker'],
  'Grain':      ['Bakery', 'Grocery', 'Broker'],
  'Snack':      ['Grocery', 'Bakery', 'Broker'],
  'M/MA':       ['Protein', 'Broker'],
  'M/MA+Grain': ['Protein', 'Bakery', 'Broker'],
  'Produce':    ['Produce', 'Broker'],
  'Protein':    ['Protein', 'Broker'],
  'Dairy':      ['Dairy'],
  'Bakery':     ['Bakery', 'Broker'],
  'Grocery':    ['Grocery', 'Broker'],
  'Beverage':   ['Beverage'],
  'Paper':      ['Paper'],
}

// ── Backfill: for any bid with uploadedRfpPath/uploadedItemListPath but no uploadedFiles ──
function backfillUploadedFiles(__dirnameServer) {
  try {
    const DATA    = join(__dirnameServer, 'data')
    const bids    = JSON.parse(readFileSync(join(DATA, 'bids.json'), 'utf8'))

    const fmt = (bytes) => {
      if (!bytes) return '—'
      if (bytes < 1024) return `${bytes} B`
      if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`
      return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
    }
    const sizeOf = (rel) => {
      try { return fmt(statSync(join(__dirnameServer, rel)).size) } catch { return '—' }
    }
    const MIME_MAP = {
      pdf:  'application/pdf',
      xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      xls:  'application/vnd.ms-excel',
      csv:  'text/csv',
      docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    }

    let changed = false

    for (const bid of bids) {
      // Skip if already has uploadedFiles entries
      if (bid.uploadedFiles && bid.uploadedFiles.length > 0) continue
      // Skip if no file paths at all
      if (!bid.uploadedRfpPath && !bid.uploadedItemListPath) continue

      const files = []

      if (bid.uploadedRfpPath && existsSync(join(__dirnameServer, bid.uploadedRfpPath))) {
        const filename = bid.uploadedRfpPath.split('/').pop()
        files.push({
          id:         `FILE-${bid.id}-RFP`,
          name:       filename,
          type:       'RFP Document',
          mimetype:   'application/pdf',
          size:       sizeOf(bid.uploadedRfpPath),
          uploadedAt: bid.intakeDate || new Date().toISOString().split('T')[0],
          path:       bid.uploadedRfpPath,
        })
      }

      if (bid.uploadedItemListPath && existsSync(join(__dirnameServer, bid.uploadedItemListPath))) {
        const filename = bid.uploadedItemListPath.split('/').pop()
        const ext      = filename.split('.').pop().toLowerCase()
        files.push({
          id:         `FILE-${bid.id}-ITEMS`,
          name:       filename,
          type:       'Item List',
          mimetype:   MIME_MAP[ext] || 'application/octet-stream',
          size:       sizeOf(bid.uploadedItemListPath),
          uploadedAt: bid.intakeDate || new Date().toISOString().split('T')[0],
          path:       bid.uploadedItemListPath,
        })
      }

      if (files.length > 0) {
        bid.uploadedFiles = files
        changed = true
        console.log(`[BackfillFiles] ${bid.id} (${bid.customer}): backfilled ${files.length} file(s)`)
      }
    }

    if (changed) {
      writeFileSync(join(DATA, 'bids.json'), JSON.stringify(bids, null, 2))
      console.log('[BackfillFiles] bids.json updated ✅')
    } else {
      console.log('[BackfillFiles] No bids needed file backfill')
    }
  } catch (err) {
    console.warn('[BackfillFiles] Failed:', err.message)
  }
}

// ── Backfill: for any bid with a Solicitation email but no solicitedSuppliers ──
function backfillSolicitedSuppliers(__dirnameServer) {
  try {
    const DATA = join(__dirnameServer, 'data')
    const bids      = JSON.parse(readFileSync(join(DATA, 'bids.json'),      'utf8'))
    const emails    = JSON.parse(readFileSync(join(DATA, 'emailThreads.json'), 'utf8'))
    const suppliers = JSON.parse(readFileSync(join(DATA, 'suppliers.json'), 'utf8'))

    // Build email-to-supplier map for fast lookup
    const emailToSupplier = {}
    suppliers.forEach(s => { emailToSupplier[s.contact.toLowerCase()] = s })

    let changed = false
    const today = new Date().toISOString().split('T')[0]

    for (const bid of bids) {
      // Skip if already has suppliers OR has a solicitation date (prevents overwrite on restart)
      if ((bid.solicitedSuppliers && bid.solicitedSuppliers.length > 0) || bid.lastSolicitationDate) continue

      // Find this bid's outbound solicitation email
      const solEmail = emails.find(e =>
        e.bidId     === bid.id &&
        e.direction === 'outbound' &&
        Array.isArray(e.tags) && e.tags.includes('Solicitation')
      )
      if (!solEmail) continue

      const bccList = Array.isArray(solEmail.bcc) ? solEmail.bcc : []
      const solDate = solEmail.date?.split('T')[0] || today

      // Try matching BCC emails to suppliers.json
      let matched = bccList
        .map(email => emailToSupplier[String(email).toLowerCase().trim()])
        .filter(Boolean)

      if (matched.length === 0) {
        console.log(`[Backfill] ${bid.id}: BCC had no supplier matches — skipping (only actual BCC recipients are tracked)`)
      }

      if (matched.length > 0) {
        bid.solicitedSuppliers = matched.map(s => ({
          supplierId:    s.id,
          supplierName:  s.name,
          email:         s.contact.toLowerCase(),
          category:      s.category || '',
          solicitedDate: solDate,
          lastActivity:  solDate,
        }))
        bid.suppliersContacted = bid.solicitedSuppliers.length
        if (!bid.lastSolicitationDate) bid.lastSolicitationDate = solDate
        changed = true
        console.log(`[Backfill] ${bid.id} (${bid.customer}): saved ${matched.length} solicitedSuppliers`)
      }
    }

    if (changed) {
      writeFileSync(join(DATA, 'bids.json'), JSON.stringify(bids, null, 2))
      console.log('[Backfill] bids.json updated ✅')
    } else {
      console.log('[Backfill] No bids needed backfill')
    }
  } catch (err) {
    console.warn('[Backfill] Failed:', err.message)
  }
}

const __dirname = dirname(fileURLToPath(import.meta.url))

// ── Backfill: fix email records where attachments are plain strings ──
// For each inbound email that has attachments stored as string[] (old IMAP
// poller format), check if a file with that name already exists in uploads/.
// If it does, upgrade the record to the object format and set pricingFilePath.
// Emails where the file was never saved to disk are left unchanged — they will
// fall back to body-text extraction, which is already the current behaviour.
function backfillEmailAttachments(__dirnameServer) {
  try {
    const EMAILS_PATH = join(__dirnameServer, 'data', 'emailThreads.json')
    const UPLOADS     = join(__dirnameServer, 'uploads')
    const emails      = JSON.parse(readFileSync(EMAILS_PATH, 'utf8'))
    let   changed     = false

    for (const email of emails) {
      if (!Array.isArray(email.attachments) || email.attachments.length === 0) continue
      // Skip if already in new object format
      if (email.attachments.every(a => typeof a === 'object' && a !== null && a.originalName)) continue

      const upgraded = []
      let   firstPricingPath = email.pricingFilePath || null

      for (const att of email.attachments) {
        const name = typeof att === 'string' ? att : (att?.originalName || att?.name || '')
        if (!name) { upgraded.push(att); continue }

        // Try to find the file on disk (exact name or bid-prefixed variants)
        const candidates = [
          join(UPLOADS, name),
          join(UPLOADS, `${email.bidId}_${name}`),
          join(UPLOADS, `${email.bidId}-${name}`),
        ]
        const found = candidates.find(p => existsSync(p)) || null

        if (found) {
          const savedName = found.split(/[\\/]/).pop()
          const obj = {
            originalName: name,
            savedName,
            path:         `uploads/${savedName}`,
            mimeType:     name.endsWith('.pdf') ? 'application/pdf'
                          : name.match(/\.xlsx?$/i) ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                          : 'application/octet-stream',
          }
          upgraded.push(obj)
          // Set pricingFilePath to first PDF/XLSX found
          if (!firstPricingPath && /\.(pdf|xlsx|xls|csv)$/i.test(name)) {
            firstPricingPath = obj.path
          }
          changed = true
          console.log(`[BackfillAttachments] ${email.id}: "${name}" → found at ${savedName}`)
        } else {
          // File not on disk — keep as-is (body fallback will be used)
          upgraded.push(typeof att === 'string' ? att : att)
        }
      }

      email.attachments = upgraded
      if (firstPricingPath && !email.pricingFilePath) {
        email.pricingFilePath = firstPricingPath
        changed = true
      }
    }

    if (changed) {
      writeFileSync(EMAILS_PATH, JSON.stringify(emails, null, 2))
      console.log('[BackfillAttachments] emailThreads.json updated ✅')
    } else {
      console.log('[BackfillAttachments] No email attachment records needed upgrading')
    }
  } catch (err) {
    console.warn('[BackfillAttachments] Failed:', err.message)
  }
}
const app = express()
const PORT = process.env.PORT || 3001

// Middleware
const allowedOrigins = [
  'http://localhost:5173',
  'http://localhost:4173',
  'http://rfp-aiq.exlservice.com:5173',
  'http://rfp-aiq.supplier.exlservice.com:5173',
]
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin)) {
      callback(null, true)
    } else {
      callback(new Error('Not allowed by CORS'))
    }
  },
  credentials: true,
}))
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true }))

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    service: 'Sysco RFP AIQ Backend',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    anthropicConfigured: !!process.env.ANTHROPIC_API_KEY,
  })
})

// API Routes
app.use('/api/bids',             bidsRouter)
app.use('/api/suppliers',        suppliersRouter)
app.use('/api/parse-rfp',        rfpParserRouter)
app.use('/api/extract-pricing',  pricingRouter)
app.use('/api/emails',           emailsRouter)
app.use('/api/documents',        documentsRouter)
app.use('/api/analyse-response', analyseResponseRouter)
app.use('/api/ai',               aiRouter)
app.use('/api/submit',           submissionsRouter)   // public supplier portal

// ── File serving ─────────────────────────────────────────
const FILE_MIME = {
  '.pdf':  'application/pdf',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.xls':  'application/vnd.ms-excel',
  '.csv':  'text/csv',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
}

function serveFile(req, res, disposition) {
  // Sanitise filename — no path traversal
  const filename = req.params.filename.replace(/[/\\]/g, '')
  const filepath = join(__dirname, 'uploads', filename)
  if (!existsSync(filepath)) return res.status(404).json({ error: 'File not found' })
  const ext  = extname(filename).toLowerCase()
  const mime = FILE_MIME[ext] || 'application/octet-stream'
  res.setHeader('Content-Type', mime)
  res.setHeader('Content-Disposition', `${disposition}; filename="${filename}"`)
  createReadStream(filepath).pipe(res)
}

app.get('/api/files/:filename/view',     (req, res) => serveFile(req, res, 'inline'))
app.get('/api/files/:filename/download', (req, res) => serveFile(req, res, 'attachment'))

// ── Email attachment download ───────────────────────────────
// GET /api/files/:bidId/attachments/:filename
// Serves a file from uploads/, resolving both:
//   • exact saved name  (timestamp_Original.pdf)
//   • original display name  (Original.pdf → finds timestamp_Original.pdf)
const ATTACHMENT_MIME = {
  '.pdf':  'application/pdf',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.xls':  'application/vnd.ms-excel',
  '.csv':  'text/csv',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.jpeg': 'image/jpeg',
}

app.get('/api/files/:bidId/attachments/:filename', (req, res) => {
  try {
    const rawName  = decodeURIComponent(req.params.filename)
    const safeName = rawName.replace(/[/\\]/g, '')  // no path traversal

    const UPLOADS  = join(__dirname, 'uploads')
    let   diskPath = join(UPLOADS, safeName)
    let   displayName = safeName

    if (!existsSync(diskPath)) {
      // Search for timestamp-prefixed variant: "1749420000000_Original.pdf"
      const all   = existsSync(UPLOADS) ? readdirSync(UPLOADS) : []
      const match = all.find(f =>
        f === safeName ||
        f.endsWith(`_${safeName}`) ||
        f.endsWith(`-${safeName}`)
      )
      if (match) {
        diskPath    = join(UPLOADS, match)
        displayName = safeName          // browser saves with original name
      } else {
        console.warn(`[AttachmentDL] Not found: "${safeName}"`)
        return res.status(404).json({ error: `Attachment not found: ${safeName}` })
      }
    }

    const ext  = extname(safeName).toLowerCase()
    const mime = ATTACHMENT_MIME[ext] || 'application/octet-stream'
    res.setHeader('Content-Type', mime)
    res.setHeader('Content-Disposition', `attachment; filename="${displayName}"`)
    console.log(`[AttachmentDL] ${req.params.bidId}: ${safeName} → ${diskPath}`)
    createReadStream(diskPath).pipe(res)
  } catch (err) {
    console.error('[AttachmentDL] error:', err.message)
    res.status(500).json({ error: err.message })
  }
})

// ── Manual poll trigger (for testing) ────────────────────
app.get('/api/email/poll-now', async (req, res) => {
  console.log('[Poll] Manual trigger via /api/email/poll-now')
  try {
    const result = await runPoll()
    res.json({ ok: true, ...result, timestamp: new Date().toISOString() })
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message })
  }
})

// 404 fallback
app.use((req, res) => {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.path}` })
})

// Error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err)
  res.status(500).json({ error: err.message || 'Internal server error' })
})

// ── Auto-reminder scheduler ───────────────────────────────
// Runs hourly. For each bid with autoReminder.enabled:
//   - Skip if no solicitation sent, or bid not in Solicitation status
//   - For each supplier with no portal submission and no email response
//     (status === 'Awaiting') and solicitation was X+ days ago:
//     → send reminder email via Nodemailer + log to emailThreads.json
async function runAutoReminders() {
  const DATA = join(__dirname, 'data')
  try {
    const bids        = JSON.parse(readFileSync(join(DATA, 'bids.json'), 'utf8'))
    const emails      = JSON.parse(readFileSync(join(DATA, 'emailThreads.json'), 'utf8'))
    const submissions = (() => { try { return JSON.parse(readFileSync(join(DATA, 'submissions.json'), 'utf8')) } catch { return {} } })()
    const { sendEmail } = await import('./services/emailService.js')
    const PORTAL_BASE   = process.env.PORTAL_BASE_URL || 'http://rfp-aiq.supplier.exlservice.com:5173'
    const now           = Date.now()
    const MS_PER_DAY    = 86400000
    const MIN_GAP_DAYS  = 3   // don't send more than once every 3 days per bid

    for (const bid of bids) {
      const ar = bid.autoReminder
      if (!ar?.enabled) continue
      if (bid.status !== 'Solicitation') continue

      // Find the solicitation email for this bid
      const solEmail = emails.find(e =>
        e.bidId === bid.id && e.direction === 'outbound' && (e.tags || []).includes('Solicitation')
      )
      if (!solEmail) continue

      const solDate     = new Date(solEmail.date).getTime()
      const daysSinceSol = (now - solDate) / MS_PER_DAY
      if (daysSinceSol < (ar.daysAfterSolicitation ?? 3)) continue

      // Respect min gap since last reminder
      if (ar.lastReminderSent) {
        const daysSinceLast = (now - new Date(ar.lastReminderSent).getTime()) / MS_PER_DAY
        if (daysSinceLast < MIN_GAP_DAYS) continue
      }

      // Collect portal submission emails for this bid
      const portalEmails = new Set(
        (submissions[bid.id] || []).map(s => s.supplierEmail.toLowerCase())
      )

      // Collect suppliers who have already responded via email
      const respondedEmails = new Set(
        emails
          .filter(e => e.bidId === bid.id && e.direction === 'inbound')
          .map(e => (e.supplierEmail || '').toLowerCase())
      )

      // Target: solicited suppliers who haven't responded at all
      const targets = (bid.solicitedSuppliers || []).filter(s => {
        const em = s.email?.toLowerCase()
        return em && !portalEmails.has(em) && !respondedEmails.has(em) && s.status === 'Awaiting'
      })

      if (targets.length === 0) continue

      const dueFmt    = bid.customerDue
        ? new Date(bid.customerDue).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })
        : 'TBD'
      const portalUrl = `${PORTAL_BASE}/submit/${bid.id}`
      const hour      = new Date().getHours()
      const greeting  = hour < 12 ? 'morning' : 'afternoon'

      for (const sup of targets) {
        const body = `Good ${greeting},

This is a friendly reminder that we have not yet received your pricing response for ${bid.customer} (Bid ${bid.id}).

Please submit your pricing using our online portal:
→ ${portalUrl}

Response deadline: ${dueFmt}

If you are unable to respond, please let us know at your earliest convenience.

Sysco Bid COE
COE.BIDS@sysco.com`

        try {
          await sendEmail({
            to:      sup.email,
            bcc:     [sup.email],
            subject: `Reminder: Pricing Request for ${bid.customer} — Response Due ${dueFmt}`,
            body,
            attachmentNames: [],
            attachmentPaths: [],
          })
          // Log to emailThreads.json
          const newEmail = {
            id:            `E-${Date.now()}-auto`,
            bidId:         bid.id,
            direction:     'outbound',
            supplierId:    sup.supplierId || null,
            supplierName:  sup.supplierName,
            supplierEmail: sup.email,
            from:          'COE.BIDS@sysco.com',
            to:            sup.email,
            bcc:           [sup.email],
            subject:       `Reminder: Pricing Request for ${bid.customer} — Response Due ${dueFmt}`,
            body,
            date:          new Date().toISOString(),
            attachments:   [],
            tags:          ['reminder', 'auto', 'portal-url'],
            read:          true,
            analysisResult: null,
          }
          emails.push(newEmail)
          console.log(`[Auto-Reminder] Sent to: ${sup.email} for bid: ${bid.id}`)
        } catch (mailErr) {
          console.warn(`[Auto-Reminder] Failed for ${sup.email} / ${bid.id}: ${mailErr.message}`)
        }
      }

      // Update lastReminderSent + supplier statuses
      const bidIdx = bids.findIndex(b => b.id === bid.id)
      if (bidIdx !== -1) {
        bids[bidIdx].autoReminder.lastReminderSent = new Date().toISOString()
        const targetEmails = new Set(targets.map(t => t.email?.toLowerCase()))
        ;(bids[bidIdx].solicitedSuppliers || []).forEach(s => {
          if (targetEmails.has(s.email?.toLowerCase())) s.status = 'Follow-up Sent'
        })
      }
    }

    // Persist changes
    writeFileSync(join(DATA, 'bids.json'), JSON.stringify(bids, null, 2))
    writeFileSync(join(DATA, 'emailThreads.json'), JSON.stringify(emails, null, 2))
    // Re-assert demo data in case the write above stomped it
    ensureBounceDemo()
  } catch (err) {
    console.warn('[Auto-Reminder] Scheduler error:', err.message)
  }
}

// ── Startup backfill: auto-parse line items from uploaded files ──
// For each bid that has uploaded files but NO line items, try to
// parse from the best available file (Excel first, then PDF).
async function backfillLineItemsFromFiles(__dirnameServer) {
  try {
    const DATA      = join(__dirnameServer, 'data')
    const UPLOADS   = join(__dirnameServer, 'uploads')
    const bids      = JSON.parse(readFileSync(join(DATA, 'bids.json'), 'utf8'))
    const lineItems = JSON.parse(readFileSync(join(DATA, 'lineItems.json'), 'utf8'))
    const itemsByBid = {}
    lineItems.forEach(li => { itemsByBid[li.bidId] = (itemsByBid[li.bidId] || 0) + 1 })

    let backfilled = 0
    for (const bid of bids) {
      if ((itemsByBid[bid.id] || 0) > 0) continue  // already has items
      if (!bid.uploadedFiles?.length && !bid.uploadedItemListPath && !bid.uploadedRfpPath) continue

      // Collect candidate files — Excel preferred over PDF
      const candidates = []
      for (const f of (bid.uploadedFiles || [])) {
        if (!f.path) continue
        const full = join(__dirnameServer, f.path)
        if (!existsSync(full)) continue
        if (/\.xlsx?$/i.test(f.path)) candidates.unshift({ path: full, type: 'excel' })
        else if (/\.pdf$/i.test(f.path)) candidates.push({ path: full, type: 'pdf' })
      }
      // Also check legacy path fields
      if (!candidates.length && bid.uploadedItemListPath) {
        const full = join(__dirnameServer, bid.uploadedItemListPath)
        if (existsSync(full)) candidates.unshift({ path: full, type: 'excel' })
      }
      if (!candidates.length && bid.uploadedRfpPath) {
        const full = join(__dirnameServer, bid.uploadedRfpPath)
        if (existsSync(full)) candidates.push({ path: full, type: 'pdf' })
      }

      if (!candidates.length) continue

      const { path: filePath, type } = candidates[0]
      console.log(`[BackfillLineItems] ${bid.id}: parsing from ${type.toUpperCase()} → ${filePath}`)
      const items = type === 'excel'
        ? await parseLineItemsFromExcel(bid.id, filePath)
        : await parseLineItemsFromPDF(bid.id, filePath)

      if (items.length > 0) backfilled++
    }

    if (backfilled > 0) {
      console.log(`[BackfillLineItems] Parsed line items for ${backfilled} bid(s) ✅`)
    } else {
      console.log('[BackfillLineItems] No bids needed line item backfill')
    }
  } catch (err) {
    console.warn('[BackfillLineItems] Failed:', err.message)
  }
}

app.listen(PORT, async () => {
  console.log(`\n🚀 Sysco RFP AIQ Backend running on http://localhost:${PORT}`)
  console.log(`📋 Health: http://localhost:${PORT}/api/health`)
  console.log(`🔑 Anthropic API: ${process.env.ANTHROPIC_API_KEY ? '✅ Configured' : '❌ Missing — add to .env'}`)
  await verifyEmailConfig()
  backfillSolicitedSuppliers(__dirname)
  backfillUploadedFiles(__dirname)
  backfillEmailAttachments(__dirname)
  await backfillLineItemsFromFiles(__dirname)
  ensureBounceDemo()
  startEmailPoller()
  // Hourly auto-reminder scheduler (no cron library needed)
  setInterval(runAutoReminders, 60 * 60 * 1000)
  console.log('[Auto-Reminder] Hourly scheduler started ✅')
  console.log(`\n⚡ POC DEMO MODE — No real client data\n`)
})
