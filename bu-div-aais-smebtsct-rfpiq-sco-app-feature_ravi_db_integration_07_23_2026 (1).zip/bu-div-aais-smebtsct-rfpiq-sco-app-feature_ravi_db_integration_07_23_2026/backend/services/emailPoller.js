// ============================================================
// emailPoller.js — IMAP inbox poller (every 15 s in dev)
// Matches inbound replies to bids by subject line, saves them
// to emailThreads.json, and updates solicitedSuppliers status.
// ============================================================

import { ImapFlow }    from 'imapflow'
import { simpleParser } from 'mailparser'
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join }  from 'path'
import { ensureBounceDemo } from './demoData.js'

const __filename  = fileURLToPath(import.meta.url)
const __dirname   = dirname(__filename)
const DATA        = join(__dirname, '../data')
const UPLOADS_DIR = join(__dirname, '../uploads')

// ── File helpers ──────────────────────────────────────────
const loadJ  = (f)    => JSON.parse(readFileSync(join(DATA, f), 'utf8'))
const saveJ  = (f, d) => writeFileSync(join(DATA, f), JSON.stringify(d, null, 2))
const loadUM = ()     => {
  try { return JSON.parse(readFileSync(join(DATA, 'unmatchedEmails.json'), 'utf8')) } catch { return [] }
}
const saveUM = (d) => writeFileSync(join(DATA, 'unmatchedEmails.json'), JSON.stringify(d, null, 2))

// ── Strip reply/forward prefixes ──────────────────────────
function cleanSubject(sub = '') {
  return sub.replace(/^((re|fw|fwd|sv|tr|rép|aw|vs|ant)\s*:\s*)+/gi, '').trim()
}

// ── Bounce detection ─────────────────────────────────────
const BOUNCE_FROM    = /mailer-daemon|postmaster|mail-daemon/i
const BOUNCE_SUBJECT = /delivery status notification|mail delivery failed|undeliverable|returned mail|delivery failure|failure notice|could not be delivered/i

function detectBounce(fromEmail, subject) {
  return BOUNCE_FROM.test(fromEmail) || BOUNCE_SUBJECT.test(subject)
}

// Parse original recipient address from bounce body
function extractBounceRecipient(body = '') {
  const patterns = [
    /Final-Recipient:.*?rfc822;\s*([^\s\r\n]+)/i,
    /Original-Recipient:.*?rfc822;\s*([^\s\r\n]+)/i,
    /failed recipient[:\s]+([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})/i,
    /(?:to|rcpt to)[:\s<]+([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})/i,
  ]
  for (const re of patterns) {
    const m = body.match(re)
    if (m?.[1]) return m[1].toLowerCase().trim()
  }
  // Fallback: first email-looking string that isn't ownEmail / mailer-daemon domain
  const emails = body.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g) || []
  return emails.find(e => !BOUNCE_FROM.test(e) && !e.includes('mailer-daemon')) || null
}

// ── Match email subject to a bid ─────────────────────────
// Strategy 1: Bid ID appears anywhere in cleaned subject
//   - Handles: B2600042, BID-106, BID-B2500019
// Strategy 2: Cleaned subject contains full solicitation subject
// Strategy 3: All significant words from customer name present
function matchBidFromSubject(subject, bids, threads) {
  const clean    = cleanSubject(subject)
  const cleanLow = clean.toLowerCase()

  // 1. Explicit bid ID anywhere in subject — broadened pattern
  //    Matches: B2600042, BID-106, BID-B2500019, B25xxxxx
  const idPattern = /\b(B[A-Z0-9]{5,}|BID-[A-Z0-9]+(?:-[A-Z0-9]+)*)\b/gi
  let m
  while ((m = idPattern.exec(clean)) !== null) {
    const candidate = m[1]
    const bid = bids.find(b => b.id.toLowerCase() === candidate.toLowerCase())
    if (bid) {
      console.log(`[Poll] ✓ Bid match via ID: ${bid.id} (matched "${candidate}")`)
      return { bid, method: 'bid_id' }
    }
  }

  // Also do a plain string search for any bid ID in the subject
  for (const bid of bids) {
    if (cleanLow.includes(bid.id.toLowerCase())) {
      console.log(`[Poll] ✓ Bid match via string search: ${bid.id}`)
      return { bid, method: 'bid_id_string' }
    }
  }

  // 2. Strip prefixes from stored solicitation subjects and look for match
  const sols = threads.filter(e =>
    e.direction === 'outbound' && (e.tags || []).includes('Solicitation')
  )
  for (const sol of sols) {
    const solClean = cleanSubject(sol.subject || '').toLowerCase()
    if (solClean.length > 6 && cleanLow.includes(solClean)) {
      const bid = bids.find(b => b.id === sol.bidId)
      if (bid) {
        console.log(`[Poll] ✓ Bid match via solicitation subject: ${bid.id}`)
        return { bid, method: 'subject_match' }
      }
    }
  }

  // 3. Customer name words (all 4+ char words must appear in subject)
  for (const bid of bids) {
    const words = bid.customer.split(/\s+/).filter(w => w.length >= 4)
    if (words.length >= 2 && words.every(w => cleanLow.includes(w.toLowerCase()))) {
      console.log(`[Poll] ✓ Bid match via customer name: ${bid.id} (${bid.customer})`)
      return { bid, method: 'customer_name' }
    }
  }

  return null
}

// ── Auto-update solicitedSuppliers status ─────────────────
function updateSolicitedStatus(bids, bidId, fromEmail, newStatus) {
  const bidIdx = bids.findIndex(b => b.id === bidId)
  if (bidIdx === -1) return bids

  const ss   = bids[bidIdx].solicitedSuppliers || []
  const sIdx = ss.findIndex(s => s.email.toLowerCase() === fromEmail.toLowerCase())
  if (sIdx === -1) {
    console.log(`[Poll] Supplier ${fromEmail} not in solicitedSuppliers for ${bidId} — status not updated`)
    return bids
  }

  const ORDER = { Awaiting: 0, Responded: 1, 'Issues Found': 2, 'Follow-up Sent': 3 }
  const cur   = ORDER[ss[sIdx].status] ?? 0
  const next  = ORDER[newStatus]       ?? 0
  if (next > cur) {
    ss[sIdx].status       = newStatus
    ss[sIdx].lastActivity = new Date().toISOString().split('T')[0]
    bids[bidIdx].solicitedSuppliers = ss
    console.log(`[Poll] ✓ Status updated: ${ss[sIdx].supplierName} → ${newStatus}`)
  } else {
    console.log(`[Poll] Status unchanged (${ss[sIdx].status} → ${newStatus} not an advance)`)
  }
  return bids
}

// ── Process one message ───────────────────────────────────
async function processMessage(client, uid, bids, suppliers, threads, ownEmail) {
  const msg = await client.fetchOne(uid, { source: true }, { uid: true })
  if (!msg?.source) {
    console.log(`[Poll] uid ${uid}: no source — skipping`)
    return null
  }

  const parsed = await simpleParser(msg.source)

  const fromEmail = (parsed.from?.value?.[0]?.address || '').toLowerCase().trim()
  const fromName  =  parsed.from?.value?.[0]?.name    || ''
  const subject   =  parsed.subject || '(no subject)'
  const body      = (parsed.text    || '').slice(0, 10_000)
  const date      = (parsed.date    || new Date()).toISOString()

  console.log(`[Poll] Processing uid ${uid}: from=${fromEmail} subject="${subject}"`)

  // Skip self-sent
  if (fromEmail === ownEmail.toLowerCase()) {
    console.log(`[Poll] Skipping self-sent email from ${fromEmail}`)
    return null
  }

  // ── Handle bounce-back messages ───────────────────────────
  if (detectBounce(fromEmail, subject)) {
    console.log(`[Poll] Bounce detected from ${fromEmail}: "${subject}"`)
    const originalRecipient = extractBounceRecipient(body)
    let bounceBid   = null
    let bounceSupplier = null

    if (originalRecipient) {
      const allBids = loadJ('bids.json')
      for (const bid of allBids) {
        const ss = bid.solicitedSuppliers || []
        const match = ss.find(s => (s.email || s.supplierEmail || '').toLowerCase() === originalRecipient)
        if (match) { bounceBid = bid; bounceSupplier = match; break }
      }
    }

    const bounceRecord = {
      id:               `E-BOUNCE-${Date.now()}-${uid}`,
      direction:        'inbound',
      type:             'bounce',
      isBounce:         true,
      bidId:            bounceBid?.id  || null,
      supplierId:       bounceSupplier?.supplierId || null,
      supplierName:     bounceSupplier?.supplierName || 'Unknown Supplier',
      supplierEmail:    originalRecipient || '',
      from:             fromEmail,
      to:               originalRecipient || ownEmail,
      bcc:              [],
      subject,
      body:             body.slice(0, 2000),
      date,
      attachments:      [],
      tags:             ['bounce', 'delivery-failure'],
      bounceCode:       (body.match(/(\d{3}\s+\d+\.\d+\.\d+)/)?.[1] || '').trim() || null,
      bounceReason:     (body.match(/(?:reason|diagnostic[- ]code)[:\s]+(.+)/i)?.[1] || '').slice(0, 200).trim() || 'Delivery failed',
      originalRecipient,
      read:             false,
      analysisResult:   null,
      autoMatched:      true,
    }

    if (bounceBid) {
      const allThreads = loadJ('emailThreads.json')
      allThreads.push(bounceRecord)
      saveJ('emailThreads.json', allThreads)

      // Mark supplier Issues Found
      let allBids = loadJ('bids.json')
      const bIdx = allBids.findIndex(b => b.id === bounceBid.id)
      if (bIdx !== -1 && bounceSupplier) {
        const ss = allBids[bIdx].solicitedSuppliers || []
        const sIdx = ss.findIndex(s => (s.email || s.supplierEmail || '').toLowerCase() === originalRecipient)
        if (sIdx !== -1 && !['Issues Found', 'Awarded', 'Complete'].includes(ss[sIdx].status)) {
          ss[sIdx].status    = 'Issues Found'
          ss[sIdx].hasIssues = true
          ss[sIdx].issueType = 'bounce'
          ss[sIdx].bouncedAt = date
          ss[sIdx].lastActivity = date.split('T')[0]
          allBids[bIdx].solicitedSuppliers = ss
          saveJ('bids.json', allBids)
          console.log(`[Poll] ✓ Bounce: marked ${ss[sIdx].supplierName} as Issues Found in ${bounceBid.id}`)
        }
      }
      return { matched: true, bidId: bounceBid.id, method: 'bounce', from: fromEmail }
    } else {
      const um = loadUM()
      um.push(bounceRecord)
      saveUM(um)
      console.log(`[Poll] Bounce with no bid match — saved to unmatchedEmails.json`)
      return { matched: false, from: fromEmail, subject, isBounce: true }
    }
  }

  // ── Save attachment content to disk ───────────────────────
  // Store as objects with both originalName and savedName so
  // extract-pricing can resolve the file path reliably.
  if (!existsSync(UPLOADS_DIR)) mkdirSync(UPLOADS_DIR, { recursive: true })

  const savedAttachments = []
  for (const att of (parsed.attachments || [])) {
    if (!att.filename) continue
    // Sanitize: keep alphanumerics, dots, hyphens, underscores
    const sanitized = att.filename
      .replace(/[^a-zA-Z0-9._-]/g, '_')
      .replace(/_{2,}/g, '_')
    const savedName = `${Date.now()}_${sanitized}`
    const savedPath = join(UPLOADS_DIR, savedName)

    if (att.content && Buffer.isBuffer(att.content) && att.content.length > 0) {
      try {
        writeFileSync(savedPath, att.content)
        savedAttachments.push({
          originalName: att.filename,
          savedName,
          path:         `uploads/${savedName}`,
          mimeType:     att.contentType || 'application/octet-stream',
          size:         att.content.length,
        })
        console.log(`[Poll] Saved attachment: ${att.filename} → ${savedName} (${att.content.length} bytes)`)
      } catch (saveErr) {
        console.warn(`[Poll] Failed to write attachment ${att.filename}:`, saveErr.message)
        savedAttachments.push({ originalName: att.filename })
      }
    } else {
      // Content not available (inline image, stub, etc.) — record name only
      console.log(`[Poll] Attachment ${att.filename} has no content buffer — name only`)
      savedAttachments.push({ originalName: att.filename })
    }
  }
  // Keep plain string list for legacy display use
  const attachmentNames = savedAttachments.map(a => a.originalName)

  // Supplier lookup
  const supplier = suppliers.find(s => s.contact.toLowerCase() === fromEmail)
  if (supplier) {
    console.log(`[Poll] Supplier identified: ${supplier.name} (${supplier.id})`)
  } else {
    console.log(`[Poll] Sender ${fromEmail} not found in suppliers.json`)
  }

  // Bid matching
  const bidMatch = matchBidFromSubject(subject, bids, threads)
  if (!bidMatch) {
    console.log(`[Poll] No bid match for subject: "${subject}" → saving to unmatchedEmails.json`)
  }

  // Set pricingFilePath to first saved PDF/XLSX/CSV so extract-pricing
  // can resolve it without any guesswork
  const pricingAtt = savedAttachments.find(
    a => a.savedName && /\.(pdf|xlsx|xls|csv)$/i.test(a.originalName)
  )

  const record = {
    id:              `E-${Date.now()}-${uid}`,
    direction:       'inbound',
    bidId:           bidMatch?.bid.id    || null,
    supplierId:      supplier?.id        || null,
    supplierName:    supplier?.name      || fromName || fromEmail,
    supplierEmail:   fromEmail,
    from:            fromName ? `"${fromName}" <${fromEmail}>` : fromEmail,
    to:              ownEmail,
    bcc:             [],
    subject,
    body,
    date,
    // Store as objects (originalName + savedName + path) for new emails;
    // extract-pricing handles both this format and the legacy string format.
    attachments:     savedAttachments.length > 0 ? savedAttachments : [],
    pricingFilePath: pricingAtt ? pricingAtt.path : null,
    tags:            ['Response'],
    read:            false,
    analysisResult:  null,
    autoMatched:     true,
    requiresReview:  !bidMatch,
  }

  if (bidMatch) {
    record.matchMethod = bidMatch.method

    // Save to emailThreads.json
    const allThreads = loadJ('emailThreads.json')
    allThreads.push(record)
    saveJ('emailThreads.json', allThreads)
    console.log(`[Poll] ✓ Saved to emailThreads.json (id: ${record.id}, bid: ${bidMatch.bid.id})`)

    // Update bid: solicitedSuppliers status + responsesReceived
    let allBids = loadJ('bids.json')
    allBids = updateSolicitedStatus(allBids, bidMatch.bid.id, fromEmail, 'Responded')
    const bIdx = allBids.findIndex(b => b.id === bidMatch.bid.id)
    if (bIdx !== -1) {
      allBids[bIdx].responsesReceived = (allBids[bIdx].responsesReceived || 0) + 1
      console.log(`[Poll] responsesReceived for ${bidMatch.bid.id} → ${allBids[bIdx].responsesReceived}`)
    }
    saveJ('bids.json', allBids)

    if (attachmentNames.length > 0) {
      console.log(`[Poll] Attachments: ${attachmentNames.join(', ')}`)
    }

    return { matched: true, bidId: bidMatch.bid.id, method: bidMatch.method, from: fromEmail }
  } else {
    const um = loadUM()
    um.push(record)
    saveUM(um)
    return { matched: false, from: fromEmail, subject }
  }
}

// ── Core poll function (exported for manual trigger) ──────
let _polling = false

export async function runPoll() {
  if (_polling) {
    console.log('[Poll] Already running — skipped')
    return { skipped: true, total: 0, matched: 0, unmatched: 0 }
  }
  _polling = true

  const user = process.env.EMAIL_FROM || ''
  const pass = (process.env.EMAIL_APP_PASSWORD || '').replace(/\s/g, '')
  const host = process.env.EMAIL_IMAP_HOST || 'imap.gmail.com'

  console.log(`[Poll] Starting inbox check for ${user} on ${host}:993`)

  const client = new ImapFlow({
    host,
    port:   993,
    secure: true,
    auth:   { user, pass },
    logger: false,
  })

  let total = 0, matched = 0, unmatched = 0

  try {
    await client.connect()
    console.log('[Poll] ✓ IMAP connected')

    const lock = await client.getMailboxLock('INBOX')
    try {
      const bids      = loadJ('bids.json')
      const suppliers = loadJ('suppliers.json')
      const threads   = loadJ('emailThreads.json')

      const uids = await client.search({ seen: false }, { uid: true })
      total = uids.length
      console.log(`[Poll] Found ${total} unread message${total !== 1 ? 's' : ''}`)

      for (const uid of uids) {
        try {
          const result = await processMessage(client, uid, bids, suppliers, threads, user)
          if (result?.matched)  matched++
          else if (result)      unmatched++
          // Mark as read regardless of match result
          await client.messageFlagsAdd({ uid }, ['\\Seen'], { uid: true })
          console.log(`[Poll] uid ${uid} marked as read`)
        } catch (msgErr) {
          console.warn(`[Poll] Error processing uid ${uid}:`, msgErr.message)
        }
      }
    } finally {
      lock.release()
    }

    await client.logout()
    console.log('[Poll] ✓ IMAP disconnected cleanly')

  } catch (err) {
    // Log ALL IMAP errors — no silent suppression
    console.error('[Poll] ✗ IMAP error:', err.message)
    if (err.message?.includes('AUTHENTICATIONFAILED') || err.message?.includes('Invalid credentials')) {
      console.error('[Poll] ✗ Check EMAIL_FROM and EMAIL_APP_PASSWORD in .env')
      console.error('[Poll] ✗ Ensure IMAP is enabled in Gmail Settings → Forwarding and POP/IMAP')
    }
  } finally {
    _polling = false
  }

  console.log(`[Poll] Done — ${total} new, ${matched} matched, ${unmatched} unmatched`)
  ensureBounceDemo()
  return { total, matched, unmatched }
}

// ── Start recurring poller ────────────────────────────────
export function startEmailPoller() {
  const user = process.env.EMAIL_FROM || ''
  const pass = (process.env.EMAIL_APP_PASSWORD || '').replace(/\s/g, '')

  if (!user || !pass) {
    console.log('[Poll] Skipped — EMAIL_FROM or EMAIL_APP_PASSWORD not set in .env')
    return
  }

  const INTERVAL = 15_000 // 15 seconds for testing (change to 60_000 for production)

  console.log(`[Poll] Starting — polling every ${INTERVAL / 1000}s for ${user}`)
  runPoll()                          // immediate first poll
  setInterval(runPoll, INTERVAL)
}
