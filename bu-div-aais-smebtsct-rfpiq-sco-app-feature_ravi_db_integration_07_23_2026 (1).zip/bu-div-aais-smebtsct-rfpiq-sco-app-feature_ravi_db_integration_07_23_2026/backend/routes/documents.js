import express from 'express'
import multer from 'multer'
import { readFileSync, writeFileSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join, extname } from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))
const router = express.Router()
const upload = multer({ dest: join(__dirname, '../uploads/') })

const DOCS_PATH = join(__dirname, '../data/documents.json')
const loadDocs = () => JSON.parse(readFileSync(DOCS_PATH, 'utf8'))
const saveDocs = (docs) => writeFileSync(DOCS_PATH, JSON.stringify(docs, null, 2))

// GET /api/documents — list with optional filters
router.get('/', (req, res) => {
  const docs = loadDocs()
  const { bidId, supplier, category, tag, search, type } = req.query
  let filtered = docs

  if (bidId && bidId !== 'ALL') {
    filtered = filtered.filter(d => d.bidId === bidId || d.bidId === 'ALL')
  }
  if (supplier) {
    filtered = filtered.filter(d => d.supplier.toLowerCase().includes(supplier.toLowerCase()))
  }
  if (category) {
    filtered = filtered.filter(d =>
      d.supplierCategory === category || d.documentType === category
    )
  }
  if (type) {
    filtered = filtered.filter(d => d.documentType === type)
  }
  if (tag) {
    filtered = filtered.filter(d => d.tags.includes(tag))
  }
  if (search) {
    const q = search.toLowerCase()
    filtered = filtered.filter(d =>
      d.fileName.toLowerCase().includes(q) ||
      d.supplier.toLowerCase().includes(q) ||
      (d.bidId || '').toLowerCase().includes(q) ||
      d.tags.some(t => t.toLowerCase().includes(q)) ||
      (d.description || '').toLowerCase().includes(q)
    )
  }
  res.json(filtered)
})

// GET /api/documents/:id — single document
router.get('/:id', (req, res) => {
  const docs = loadDocs()
  const doc = docs.find(d => d.id === req.params.id)
  if (!doc) return res.status(404).json({ error: 'Document not found' })
  res.json(doc)
})

// POST /api/documents/upload — upload a new document
router.post('/upload', upload.single('file'), (req, res) => {
  try {
    const { supplier, bidId, documentType, tags, supplierCategory, description } = req.body
    const file = req.file

    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' })
    }

    const ext = extname(file.originalname).toLowerCase()
    const fileType = ext === '.pdf' ? 'pdf' : ext === '.xlsx' || ext === '.xls' ? 'xlsx' : 'other'

    const docs = loadDocs()
    const newId = `DOC-${String(docs.length + 1).padStart(3, '0')}-${Date.now()}`

    const newDoc = {
      id:                 newId,
      fileName:           file.originalname,
      fileType,
      sizeKb:             Math.max(1, Math.round(file.size / 1024)),
      supplier:           supplier  || 'Unknown Supplier',
      supplierId:         null,
      supplierCategory:   supplierCategory || null,
      bidId:              bidId || 'ALL',
      documentType:       documentType || 'Filing',
      tags:               tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [],
      uploadDate:         new Date().toISOString().split('T')[0],
      uploadedBy:         'COE User',
      status:             'Filed',
      extractionConfidence: null,
      description:        description || '',
      linkedLineItems:    [],
    }

    docs.push(newDoc)
    saveDocs(docs)

    res.json({ success: true, document: newDoc })

  } catch (err) {
    console.error('Document upload error:', err)
    res.status(500).json({ error: err.message })
  }
})

// PATCH /api/documents/:id/vault — toggle savedToVault
router.patch('/:id/vault', (req, res) => {
  try {
    const docs = loadDocs()
    const idx  = docs.findIndex(d => d.id === req.params.id)
    if (idx === -1) return res.status(404).json({ error: 'Document not found' })
    docs[idx].status = docs[idx].status === 'Extracted' ? 'Filed' : 'Extracted'
    saveDocs(docs)
    res.json({ success: true, document: docs[idx] })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

export default router
