import express from 'express'
import Anthropic from '@anthropic-ai/sdk'
import multer from 'multer'
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'
import { createRequire } from 'module'
import * as XLSX from 'xlsx'
import { parseLineItemsFromExcel, parseLineItemsFromPDF } from '../services/lineItemParser.js'

const require = createRequire(import.meta.url)
const pdfParse = require('pdf-parse')

const __dirname = dirname(fileURLToPath(import.meta.url))
const router    = express.Router()
const UPLOADS_DIR = join(__dirname, '../uploads')
if (!existsSync(UPLOADS_DIR)) mkdirSync(UPLOADS_DIR, { recursive: true })

// ── Save a buffer to uploads/ and return the relative path ─
function saveTempFile(buffer, suffix) {
  const fname = `temp_${Date.now()}_${suffix}`
  writeFileSync(join(UPLOADS_DIR, fname), buffer)
  return `uploads/${fname}`
}

// ── Use memory storage so we get file.buffer directly ─────
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 }, // 25 MB max
})

// ── BEX AI system prompt ──────────────────────────────────
const BEX_SYSTEM_PROMPT = `You are BEX AI — Sysco's intelligent RFP parsing engine. You will receive two sections: a PDF document (for bid metadata) and an Excel item list (for individual line items).

CRITICAL RULES:
1. Every data row in the Excel = exactly ONE separate line_item object. Never group, merge, or summarise rows.
2. If the Excel has 33 data rows, your line_items array MUST have exactly 33 entries.
3. Extract bid metadata (customer_name, bid_id, due dates, segment, opco) from the PDF ONLY.
4. For each Excel row, map every column you can find to the schema fields below.
5. Do NOT extract or include SUPC — that is Sysco's internal code assigned later, not from the customer RFP.
6. Return ONLY valid JSON. No markdown, no code fences, no explanation text.
7. CRITICAL: Return ONLY the raw JSON object. Do NOT wrap in markdown code blocks. Do NOT add any explanation before or after. Start your response with { and end with }.

Required JSON schema:
{
  "metadata": {
    "bid_id": "string or null",
    "customer_name": "string or null",
    "segment": "K-12 | DoD | University | Healthcare | Restaurant | Lodging | Government | null",
    "opco_code": "3-digit string or null",
    "opco_name": "string or null",
    "region": "string or null",
    "customer_due_date": "YYYY-MM-DD or null",
    "compliance_flags": ["Child Nutrition","Buy American","PFS","SOX","Halal","Kosher"],
    "total_items": 0,
    "parsing_confidence": 0
  },
  "line_items": [
    {
      "line_number": "string — item/line number from the Excel",
      "mpc_code": "string or null — MPC CODE or manufacturer product code from the Excel",
      "uom": "string — unit of measure e.g. Case, Bags, EA",
      "volume": 0,
      "pack": "string or null — pack count only e.g. '100', '6', '144'",
      "size": "string or null — size description only e.g. '2 OZ', '5 LB', '10 CN', '#10 CAN'",
      "brand": "string or null — brand name e.g. SYS CLS, IMPFRSH, HORMEL",
      "description": "string — full item description",
      "category": "string — classify as one of: Protein, Dairy, Produce, Bakery, Grocery, Beverage, Paper",
      "storage": "Dry | Cooler | Freezer | null",
      "buy_american": false,
      "child_nutrition": false,
      "exact_spec": false,
      "pfs_required": false,
      "coding_notes": "string"
    }
  ],
  "supplier_targeting": {
    "categories_needed": ["string"],
    "compliance_requirements": ["string"],
    "recommended_outreach_segments": ["string"]
  },
  "parsing_warnings": ["string"]
}`

// ── PDF text extractor (uses buffer directly) ─────────────
async function extractPdfText(buffer) {
  const data = await pdfParse(buffer)
  return data.text || ''
}

// ── Excel text extractor (buffer → structured row text) ───
function extractExcelText(buffer) {
  const workbook  = XLSX.read(buffer, { type: 'buffer' })
  const sheetName = workbook.SheetNames[0]
  const sheet     = workbook.Sheets[sheetName]

  // sheet_to_json with header:1 gives raw rows as arrays
  const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '' })

  if (rows.length === 0) return { text: '', dataRowCount: 0 }

  // First non-empty row as header
  const headerRow = rows.find(r => r.some(c => String(c).trim() !== '')) || rows[0]
  const headerIdx = rows.indexOf(headerRow)
  const dataRows  = rows
    .slice(headerIdx + 1)
    .filter(r => r.some(c => String(c).trim() !== ''))

  const headerStr = headerRow.map(c => String(c).trim()).join(' | ')
  const rowLines  = dataRows.map((r, i) =>
    `Row ${i + 1}: ${r.map(c => String(c).trim()).join(' | ')}`
  )

  const text = `Headers: ${headerStr}\n${rowLines.join('\n')}`
  return { text, dataRowCount: dataRows.length }
}

// ── Demo fallback ─────────────────────────────────────────
function buildDemoParseResult(lineItemsPath) {
  const lineItems    = JSON.parse(readFileSync(lineItemsPath, 'utf8'))
  const bid106Items  = lineItems.filter(li => li.bidId === 'BID-106')
  return {
    metadata: {
      bid_id: null, customer_name: null, segment: 'K-12',
      opco_code: null, opco_name: null, region: null,
      customer_due_date: null,
      compliance_flags: ['Child Nutrition', 'Buy American', 'PFS'],
      total_items: bid106Items.length, parsing_confidence: 94,
    },
    line_items: bid106Items.map(li => ({
      line_number:    li.bidItem,
      mpc_code:       li.mpcCode || li.mfgCode || '',
      brand:          li.brand || '',
      description:    li.description,
      category:       li.category,
      pack:           li.pack || '',
      size:           li.size || '',
      uom:            li.unit,
      volume:         li.qty,
      storage:        li.storage || null,
      buy_american:   li.buyAmerican,
      child_nutrition:li.childNutrition,
      exact_spec:     li.exactSpec,
      pfs_required:   li.pfsRequired,
      coding_notes:   '',
    })),
    supplier_targeting: {
      categories_needed: ['Dairy', 'Produce', 'Grocery', 'Bakery', 'Protein', 'Beverage'],
      compliance_requirements: [
        'Child Nutrition label required for all CN items',
        'Buy American Act documentation',
        'Product Formulation Statements for CN-eligible items',
      ],
      recommended_outreach_segments: [
        'K-12 approved supplier list',
        'USDA-compliant manufacturers',
        'Halal-certified protein suppliers',
      ],
    },
    parsing_warnings: ['Demo mode — upload a real RFP PDF or Excel to parse live data'],
  }
}

// ── Bulletproof JSON extractor ────────────────────────────
function extractJSON(rawText) {
  if (!rawText || typeof rawText !== 'string') {
    throw new Error('Empty response from AI')
  }

  let text = rawText.trim()

  // Remove markdown code fences (all variants)
  text = text.replace(/^```json\s*/i, '')
  text = text.replace(/^```\s*/i, '')
  text = text.replace(/\s*```$/i, '')
  text = text.trim()

  // Try direct parse first
  try {
    return JSON.parse(text)
  } catch (e1) {
    // Try to extract JSON object — handles trailing text after closing }
    const objMatch = text.match(/\{[\s\S]*\}/)
    if (objMatch) {
      try {
        return JSON.parse(objMatch[0])
      } catch (e2) {}
    }

    // Try to find JSON array
    const arrMatch = text.match(/\[[\s\S]*\]/)
    if (arrMatch) {
      try {
        return JSON.parse(arrMatch[0])
      } catch (e3) {}
    }

    // Log the raw response for debugging
    console.error('[BEX Parse] Raw AI response (first 500 chars):', text.substring(0, 500))
    throw new Error(
      'AI response could not be parsed as JSON. Raw response logged to console.'
    )
  }
}

// ── POST /api/parse-rfp ───────────────────────────────────
router.post('/',
  upload.fields([
    { name: 'pdf',   maxCount: 1 },
    { name: 'excel', maxCount: 1 },
  ]),
  async (req, res) => {
    try {
      const { demo }  = req.body
      const lineItemsPath = join(__dirname, '../data/lineItems.json')
      const pdfFile   = req.files?.pdf?.[0]
      const excelFile = req.files?.excel?.[0]

      // ── Save uploaded files to disk FIRST (before any processing) ──
      // This ensures files are available for email attachment even if parse
      // later falls back to demo mode or fails with an error.
      let tempPdfPath   = null
      let tempExcelPath = null
      try {
        if (pdfFile) {
          tempPdfPath = saveTempFile(pdfFile.buffer, 'rfp.pdf')
          console.log('[BEX] Saved RFP PDF  →', tempPdfPath)
        }
        if (excelFile) {
          const ext = (excelFile.originalname || 'items.xlsx').split('.').pop().toLowerCase()
          tempExcelPath = saveTempFile(excelFile.buffer, `items.${ext}`)
          console.log('[BEX] Saved item list →', tempExcelPath)
        }
      } catch (saveErr) {
        console.warn('[BEX] Could not save uploaded files:', saveErr.message)
      }

      // Capture original filenames + sizes for downstream use
      const pdfOriginalName   = pdfFile?.originalname   || null
      const excelOriginalName = excelFile?.originalname || null
      const pdfSize           = pdfFile?.size           || null
      const excelSize         = excelFile?.size         || null
      const fileMeta = { tempPdfPath, tempExcelPath, pdfOriginalName, excelOriginalName, pdfSize, excelSize }

      // Demo mode: no files uploaded, or explicit demo flag
      if (demo === 'true' || (!pdfFile && !excelFile)) {
        return res.json({ ...buildDemoParseResult(lineItemsPath), ...fileMeta })
      }

      // ── Extract text from uploaded files ──────────────
      let pdfText   = ''
      let excelText = ''
      let dataRowCount = 0
      const warnings = []

      if (pdfFile) {
        try {
          pdfText = await extractPdfText(pdfFile.buffer)
        } catch (err) {
          warnings.push(`PDF extraction failed: ${err.message}`)
        }
      }

      if (excelFile) {
        try {
          const result = extractExcelText(excelFile.buffer)
          excelText    = result.text
          dataRowCount = result.dataRowCount
        } catch (err) {
          warnings.push(`Excel extraction failed: ${err.message}`)
        }
      }

      // No API key → return demo with warning (but still include temp paths)
      if (!process.env.ANTHROPIC_API_KEY) {
        const result = buildDemoParseResult(lineItemsPath)
        result.parsing_warnings.unshift(
          'ANTHROPIC_API_KEY not configured — returning demo data. Add your key to .env to enable live parsing.'
        )
        return res.json({ ...result, ...fileMeta })
      }

      // No usable text extracted → fall back to demo
      if (!pdfText && !excelText) {
        const result = buildDemoParseResult(lineItemsPath)
        result.parsing_warnings.unshift(
          'Could not extract text from the uploaded file(s) — returning demo data.'
        )
        return res.json({ ...result, ...fileMeta })
      }

      // ── Build separated prompt for Claude ─────────────
      let userPrompt = ''

      if (pdfText) {
        userPrompt += `PDF CONTENT (use for bid metadata ONLY — extract customer_name, bid_id, segment, opco, region, due dates, compliance requirements from here):\n${pdfText.slice(0, 40000)}\n\n`
      }

      if (excelText) {
        userPrompt += `EXCEL ITEM LIST (extract ALL individual line items from here):\n${excelText.slice(0, 50000)}\n\n`
        userPrompt += `CRITICAL: The Excel has ${dataRowCount} data rows. Your line_items array MUST contain exactly ${dataRowCount} separate objects — one per row. Do NOT group rows by category.`
      } else if (pdfText) {
        userPrompt += `Extract all line items AND bid metadata from the PDF above.`
      }

      // ── Call Anthropic API ─────────────────────────────
      const client  = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
      const message = await client.messages.create({
        model:      process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5',
        max_tokens: 8000,
        system:     BEX_SYSTEM_PROMPT,
        messages:   [{ role: 'user', content: userPrompt }],
      })

      // ── Debug: log the full API response object ───────
      console.log('=== ANTHROPIC API RESPONSE ===')
      console.log('Stop reason:', message?.stop_reason)
      console.log('Content blocks:', message?.content?.length)
      console.log('Content types:', message?.content?.map(c => c.type))
      console.log('=== END API RESPONSE ===')

      // ── Extract and parse the response ────────────────
      const raw = message.content[0].text
      console.log('=== RAW ANTHROPIC RESPONSE ===')
      console.log('Type:', typeof raw)
      console.log('Length:', raw?.length)
      console.log('First 500 chars:')
      console.log(raw?.substring(0, 500))
      console.log('Last 200 chars:')
      console.log(raw?.substring(raw.length - 200))
      console.log('=== END RAW RESPONSE ===')


      let parsed
      try {
        parsed = extractJSON(raw)
      } catch (jsonErr) {
        console.error('[BEX] JSON parse failed:', jsonErr.message)
        throw new Error(`Parse error — ${jsonErr.message}`)
      }

      // Append any extraction warnings
      if (warnings.length > 0) {
        parsed.parsing_warnings = [...(parsed.parsing_warnings || []), ...warnings]
      }

      res.json({ ...parsed, ...fileMeta })

    } catch (err) {
      console.error('BEX parse error:', err)
      res.status(500).json({
        error: err.message,
        hint:  err instanceof SyntaxError
          ? 'AI returned invalid JSON — try again or use demo mode'
          : 'Parsing failed — check server logs',
      })
    }
  }
)

// ── Shared line-item builder ──────────────────────────────
// Used by both /create and bids.js POST /api/bids
export function buildLineItem(li, bidId, idx) {
  return {
    id:              `LI-${bidId}-${String(idx + 1).padStart(3, '0')}`,
    bidId,
    bidItem:         String(li.line_number || (idx + 1)).padStart(4, '0'),
    mpcCode:         li.mpc_code    || li.mfg_code || '',   // MPC = manufacturer product code from RFP
    brand:           li.brand       || '',
    description:     li.description || '',
    pack:            li.pack        || '',
    size:            li.size        || '',
    unit:            li.uom         || '',                   // UOM (Case, Bags, EA…)
    category:        li.category    || '',
    qty:             Number(li.volume ?? li.est_qty) || 0,  // volume from RFP
    storage:         li.storage     || '',
    cw:              'N',                                    // Contract Warehouse — default N
    stkType:         'A',                                    // Stock type — default A
    buyAmerican:     Boolean(li.buy_american),
    childNutrition:  Boolean(li.child_nutrition),
    pfsRequired:     Boolean(li.pfs_required),
    exactSpec:       Boolean(li.exact_spec),
    rfpPopulated:    true,
    // Right side — filled from supplier responses
    trueVendor:      null,
    suppliedPrice:   null,
    allw:            null,
    dl:              null,
    priceCase:       null,
    devType:         null,
    openReview:      false,
    status:          'No Response',
    confidence:      null,
  }
}

// ── POST /api/parse-rfp/create ────────────────────────────
router.post('/create', async (req, res) => {
  try {
    const { metadata = {}, line_items = [] } = req.body

    const bidsPath      = join(__dirname, '../data/bids.json')
    const lineItemsPath = join(__dirname, '../data/lineItems.json')

    const today   = new Date()
    const yymmdd  = today.toISOString().slice(2, 10).replace(/-/g, '')
    const bidId   = metadata.bid_id?.trim() || `RFP-${yymmdd}-${String(Math.floor(Math.random() * 900) + 100)}`

    let internalDue = metadata.customer_due_date || null
    if (internalDue) {
      const d = new Date(internalDue)
      d.setDate(d.getDate() - 7)
      internalDue = d.toISOString().split('T')[0]
    }

    const newBid = {
      id:                 bidId,
      customer:           metadata.customer_name || 'New Customer',
      opco:               metadata.opco_code     || '000',
      opcoName:           metadata.opco_name     || 'Sysco OpCo',
      region:             metadata.region        || 'Unknown',
      segment:            metadata.segment       || 'K-12',
      status:             'Active',
      intakeDate:         today.toISOString().split('T')[0],
      customerDue:        metadata.customer_due_date || '',
      internalDue:        internalDue || '',
      bidRelease:         today.toISOString().split('T')[0],
      items:              line_items.length,
      suppliersContacted: 0,
      responsesReceived:  0,
      solicitedSuppliers: [],
      compliance:         metadata.compliance_flags || [],
      itemCategories:     [...new Set(line_items.map(li => li.category).filter(Boolean))],
    }

    const bids = JSON.parse(readFileSync(bidsPath, 'utf8'))
    if (!bids.find(b => b.id === bidId)) {
      bids.push(newBid)
      writeFileSync(bidsPath, JSON.stringify(bids, null, 2))
    }

    if (line_items.length > 0) {
      const existing = JSON.parse(readFileSync(lineItemsPath, 'utf8'))
      const filtered = existing.filter(li => li.bidId !== bidId)
      const newItems = line_items.map((li, i) => buildLineItem(li, bidId, i))
      filtered.push(...newItems)
      writeFileSync(lineItemsPath, JSON.stringify(filtered, null, 2))
    } else {
      // BEX AI returned no items — fall back to direct file parsing.
      // Priority: Excel > PDF (Excel overwrites PDF result if both present).
      // tempPdfPath / tempExcelPath are relative paths under uploads/.
      const uploadsDir = join(__dirname, '../uploads')
      if (metadata.tempPdfPath) {
        const pdfFull = join(uploadsDir, metadata.tempPdfPath.replace(/^uploads[\\/]/, ''))
        if (existsSync(pdfFull)) {
          console.log(`[rfpParser/create] No AI items — trying PDF fallback: ${pdfFull}`)
          await parseLineItemsFromPDF(bidId, pdfFull)
        }
      }
      if (metadata.tempExcelPath) {
        const xlsFull = join(uploadsDir, metadata.tempExcelPath.replace(/^uploads[\\/]/, ''))
        if (existsSync(xlsFull)) {
          console.log(`[rfpParser/create] No AI items — trying Excel fallback (overwrites PDF): ${xlsFull}`)
          await parseLineItemsFromExcel(bidId, xlsFull)
        }
      }
    }

    // Re-read final item count (fallback parsers may have added items)
    const finalItems   = JSON.parse(readFileSync(lineItemsPath, 'utf8')).filter(li => li.bidId === bidId)
    const finalCount   = finalItems.length
    if (finalCount !== line_items.length) {
      // Keep bid.items in sync
      const bids = JSON.parse(readFileSync(bidsPath, 'utf8'))
      const bi   = bids.findIndex(b => b.id === bidId)
      if (bi !== -1 && bids[bi].items !== finalCount) {
        bids[bi].items = finalCount
        bids[bi].itemCategories = [...new Set(finalItems.map(li => li.category).filter(Boolean))]
        writeFileSync(bidsPath, JSON.stringify(bids, null, 2))
      }
    }

    res.json({ success: true, bidId, bid: newBid, itemCount: finalCount })

  } catch (err) {
    console.error('Create bid error:', err)
    res.status(500).json({ error: err.message })
  }
})

export default router
