import express from 'express'
import { readFileSync, writeFileSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))
const router = express.Router()

const SUPPLIERS_PATH = join(__dirname, '../data/suppliers.json')
const loadSuppliers  = () => JSON.parse(readFileSync(SUPPLIERS_PATH, 'utf8'))
const saveSuppliers  = (d) => writeFileSync(SUPPLIERS_PATH, JSON.stringify(d, null, 2))

// GET /api/suppliers — all suppliers (with optional filters)
router.get('/', (req, res) => {
  const suppliers = loadSuppliers()
  const { category, segment, region, excludeBounced } = req.query
  let filtered = suppliers
  if (category) filtered = filtered.filter(s => s.category === category)
  if (segment) filtered = filtered.filter(s => s.segments.includes(segment))
  if (region) filtered = filtered.filter(s => s.region === region || s.region === 'National')
  if (excludeBounced === 'true') filtered = filtered.filter(s => !s.bounce)
  res.json(filtered)
})

// POST /api/suppliers/auto-populate — OP3A + OP3B
// Body: { itemCategories: [...], segment: "K-12", opco: "019" }
router.post('/auto-populate', (req, res) => {
  const suppliers = loadSuppliers()
  const { itemCategories = [], segment } = req.body

  // Map item categories to supplier categories
  const categoryMap = {
    'Fluid Milk': ['Dairy'],
    'Fruit': ['Produce', 'Broker'],
    'Grain': ['Bakery', 'Grocery', 'Broker'],
    'Snack': ['Grocery', 'Bakery', 'Broker'],
    'M/MA': ['Protein', 'Broker'],
    'M/MA+Grain': ['Protein', 'Bakery', 'Broker'],
    'Produce': ['Produce', 'Broker'],
    'Protein': ['Protein', 'Broker'],
    'Dairy': ['Dairy'],
    'Bakery': ['Bakery', 'Broker'],
    'Grocery': ['Grocery', 'Broker'],
    'Beverage': ['Beverage'],
    'Paper': ['Paper'],
  }

  const neededCategories = new Set()
  itemCategories.forEach(ic => {
    const mapped = categoryMap[ic] || []
    mapped.forEach(c => neededCategories.add(c))
  })

  // Always include Brokers
  neededCategories.add('Broker')

  let matched = suppliers.filter(s =>
    neededCategories.has(s.category) &&
    (!segment || s.segments.includes(segment) || s.segments.includes('All'))
  )

  res.json({
    matched,
    totalMatched: matched.length,
    bounced: matched.filter(s => s.bounce).length,
    categoriesNeeded: [...neededCategories],
  })
})

// GET /api/suppliers/search?q=term — typeahead search by name/email/category
router.get('/search', (req, res) => {
  const q = (req.query.q || '').toLowerCase().trim()
  if (!q || q.length < 2) return res.json([])
  const suppliers = loadSuppliers()
  const results = suppliers.filter(s =>
    s.name.toLowerCase().includes(q) ||
    (s.contact || '').toLowerCase().includes(q) ||
    (s.category || '').toLowerCase().includes(q) ||
    (s.subcategories || []).some(sc => sc.toLowerCase().includes(q))
  )
  res.json(results.slice(0, 10))
})

// POST /api/suppliers — create a new supplier
router.post('/', (req, res) => {
  try {
    const {
      name, contactName, contact, phone,
      category, subcategories, region,
      segments, broker, tags, notes,
    } = req.body

    if (!name?.trim())    return res.status(400).json({ error: 'name is required' })
    if (!contact?.trim()) return res.status(400).json({ error: 'contact (email) is required' })
    if (!contact.includes('@')) return res.status(400).json({ error: 'contact must be a valid email address' })

    const suppliers = loadSuppliers()

    // Check for duplicate email
    const dup = suppliers.find(s => s.contact.toLowerCase() === contact.toLowerCase().trim())
    if (dup) return res.status(409).json({ error: `A supplier with this email already exists: ${dup.name}` })

    // Auto-generate ID: SM-XXX (max existing SM number + 1)
    const maxNum = suppliers.reduce((mx, s) => {
      const m = (s.id || '').match(/^SM-(\d+)$/)
      return m ? Math.max(mx, parseInt(m[1], 10)) : mx
    }, 0)
    const newId = `SM-${String(maxNum + 1).padStart(3, '0')}`

    const newSupplier = {
      id:            newId,
      name:          name.trim(),
      contactName:   contactName?.trim() || '',
      contact:       contact.trim().toLowerCase(),
      phone:         phone?.trim() || '',
      category:      category || 'Grocery',
      subcategories: Array.isArray(subcategories) ? subcategories : [],
      region:        region || 'National',
      segments:      Array.isArray(segments) ? segments : [],
      broker:        Boolean(broker),
      tags:          Array.isArray(tags) ? tags : [],
      notes:         notes?.trim() || '',
      bounce:        false,
    }

    suppliers.push(newSupplier)
    saveSuppliers(suppliers)

    res.status(201).json({ success: true, supplier: newSupplier })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

export default router
