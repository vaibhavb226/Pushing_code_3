import express from 'express'
import Anthropic from '@anthropic-ai/sdk'
import multer from 'multer'
import { readFileSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'
import { createRequire } from 'module'
import * as XLSX from 'xlsx'

const require   = createRequire(import.meta.url)
const pdfParse  = require('pdf-parse')

const __dirname = dirname(fileURLToPath(import.meta.url))
const router    = express.Router()
const upload    = multer({ dest: join(__dirname, '../uploads/') })

// ── Bulletproof JSON extractor ────────────────────────────
function extractJSON(rawText) {
  if (!rawText || typeof rawText !== 'string') {
    throw new Error('Empty response from AI')
  }

  let text = rawText.trim()

  // Remove markdown code fences
  text = text.replace(/^```json\s*/i, '')
  text = text.replace(/^```\s*/i, '')
  text = text.replace(/\s*```$/i, '')
  text = text.trim()

  // Try direct parse first
  try {
    return JSON.parse(text)
  } catch (e1) {
    // Try to extract JSON object
    const objMatch = text.match(/\{[\s\S]*\}/)
    if (objMatch) {
      try { return JSON.parse(objMatch[0]) } catch (e2) {}
    }
    // Try JSON array
    const arrMatch = text.match(/\[[\s\S]*\]/)
    if (arrMatch) {
      try { return JSON.parse(arrMatch[0]) } catch (e3) {}
    }
    console.error('[Analyse Parse] Raw AI response (first 500 chars):', text.substring(0, 500))
    throw new Error('AI response could not be parsed as JSON. Raw response logged to console.')
  }
}

// ── System prompt ─────────────────────────────────────────
const ANALYSE_PROMPT = `You are a Sysco pricing response analyser. Read this supplier pricing document and extract:
1. All priced items — for each item: item_code, description, pack, qty, del_price (delivered price), allw (allowance amount if present, null if none), allw_type (ALLW or DL or null), guarantee_date
2. Issues found: missing_items (items unclear or missing), format_issues (prices missing or unclear), expired_pricing (guarantee date past or unclear), non_compliant (may not meet CN or Buy American requirements)

Return ONLY valid JSON, no markdown, no preamble. CRITICAL: Start your response with { and end with }. No explanation before or after.
{
  "priced_items": [
    {
      "item_code": "string or null",
      "description": "string",
      "pack": "string or null",
      "qty": 0,
      "del_price": 0.0,
      "allw": null,
      "allw_type": "ALLW|DL|null",
      "guarantee_date": "YYYY-MM-DD or null"
    }
  ],
  "issues": {
    "missing_items": [],
    "format_issues": [],
    "expired_pricing": [],
    "non_compliant": []
  },
  "supplier_name": "string",
  "quote_reference": "string or null",
  "valid_through": "YYYY-MM-DD or null"
}`

// ── Supported extensions ──────────────────────────────────
const SUPPORTED_EXTS = ['pdf', 'xlsx', 'xls', 'csv']

// ── Text extractors ───────────────────────────────────────
async function extractPdfText(filePath) {
  const buffer = readFileSync(filePath)
  const data   = await pdfParse(buffer)
  return data.text
}

function extractExcelText(filePath) {
  // Read as buffer so XLSX doesn't need the file extension to detect format.
  // Multer's dest mode saves files with randomised names and no extension,
  // so XLSX.readFile() (which guesses format from extension) always fails here.
  const buffer = readFileSync(filePath)
  const wb = XLSX.read(buffer, { type: 'buffer' })
  return wb.SheetNames.map(name => {
    const sheet = wb.Sheets[name]
    // sheet_to_json with header:1 gives array-of-arrays; join as TSV for AI
    const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: '', raw: false })
    const text = rows
      .filter(row => row.some(cell => String(cell).trim() !== ''))
      .map(row => row.join('\t'))
      .join('\n')
    return `--- Sheet: ${name} ---\n${text}`
  }).join('\n\n')
}

function extractCsvText(filePath) {
  const raw = readFileSync(filePath, 'utf8')
  return raw
}

// ── Demo fallback ─────────────────────────────────────────
function buildDemoAnalysis(supplierName) {
  return {
    priced_items: [
      { item_code: '7190735', description: "Ben's Original Brown Rice", pack: '6/36 OZ', qty: 85,  del_price: 22.50, allw: 3.50, allw_type: 'ALLW', guarantee_date: '2027-06-30' },
      { item_code: '5630101', description: 'Ultra Maize Muffin WG',    pack: '72/1.7 OZ', qty: 144, del_price: 30.14, allw: null, allw_type: 'DL',   guarantee_date: '2027-01-31' },
      { item_code: '5630202', description: 'WG Pumpkin Bread Slice',    pack: '72/1.7 OZ', qty: 144, del_price: 45.52, allw: null, allw_type: 'DL',   guarantee_date: '2027-01-31' },
    ],
    issues: {
      missing_items:   ['Item 0005 - Whole Grain Crackers: no pricing submitted'],
      format_issues:   [],
      expired_pricing: [],
      non_compliant:   [],
    },
    supplier_name:   supplierName || 'Demo Supplier',
    quote_reference: 'DEMO-QUOTE-001',
    valid_through:   '2027-01-31',
  }
}

// ── POST /api/analyse-response ────────────────────────────
router.post('/', upload.single('file'), async (req, res) => {
  try {
    const file         = req.file
    const supplierName = req.body.supplierName || ''

    // Demo mode — no file uploaded
    if (!file) {
      return res.json(buildDemoAnalysis(supplierName))
    }

    const ext = (file.originalname || '').split('.').pop().toLowerCase()

    // ── File type guard ───────────────────────────────────
    if (!SUPPORTED_EXTS.includes(ext)) {
      return res.status(422).json({
        error: `Unsupported file type ".${ext}". Please upload XLSX, XLS, CSV, or PDF.`,
      })
    }

    // ── Extract text from file ────────────────────────────
    let docText = ''
    try {
      if (ext === 'pdf') {
        docText = await extractPdfText(file.path)
      } else if (ext === 'csv') {
        docText = extractCsvText(file.path)
      } else {
        // xlsx / xls — read as buffer (avoids extension-detection failure)
        docText = extractExcelText(file.path)
      }
    } catch (extractErr) {
      console.error('[Analyse] File parsing failed:', {
        filename: file.originalname,
        mimetype: file.mimetype,
        size:     file.size,
        ext,
        error:    extractErr.message,
      })
      return res.status(422).json({
        error: `Could not read "${file.originalname}" — ${extractErr.message}. Check that the file is not password-protected or corrupted.`,
      })
    }

    if (!docText.trim()) {
      return res.status(422).json({ error: 'File appears to be empty — no text could be extracted.' })
    }

    // ── Demo mode — no API key ────────────────────────────
    if (!process.env.ANTHROPIC_API_KEY) {
      return res.json(buildDemoAnalysis(supplierName))
    }

    // ── Call Anthropic ────────────────────────────────────
    const client  = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
    const message = await client.messages.create({
      model:      process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5',
      max_tokens: 8000,
      system:     ANALYSE_PROMPT,
      messages:   [{ role: 'user', content: `Supplier: ${supplierName}\n\nDocument:\n${docText.slice(0, 60000)}` }],
    })

    const raw = message.content[0].text
    res.json(extractJSON(raw))

  } catch (err) {
    console.error('[Analyse] Unhandled error:', err)
    res.status(500).json({ error: err.message })
  }
})

export default router
