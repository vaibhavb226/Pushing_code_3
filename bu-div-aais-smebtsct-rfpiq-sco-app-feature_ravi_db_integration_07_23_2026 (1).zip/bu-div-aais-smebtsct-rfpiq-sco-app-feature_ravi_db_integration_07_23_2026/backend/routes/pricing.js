import express from 'express'
import Anthropic from '@anthropic-ai/sdk'
import { readFileSync, writeFileSync } from 'fs'
import { fileURLToPath } from 'url'
import { dirname, join } from 'path'

const __dirname = dirname(fileURLToPath(import.meta.url))
const router    = express.Router()

const LINE_ITEMS_PATH = join(__dirname, '../data/lineItems.json')
const PRICING_PATH    = join(__dirname, '../data/pricingData.json')

const loadLineItems = () => JSON.parse(readFileSync(LINE_ITEMS_PATH, 'utf8'))
const saveLineItems = (d) => writeFileSync(LINE_ITEMS_PATH, JSON.stringify(d, null, 2))
const loadPricing   = () => JSON.parse(readFileSync(PRICING_PATH,    'utf8'))

// ── Bulletproof JSON extractor ────────────────────────────
function extractJSON(rawText) {
  if (!rawText || typeof rawText !== 'string') {
    throw new Error('Empty response from AI')
  }

  let text = rawText.trim()

  // Remove markdown code fences
  text = text.replace(/^```json\s*/i, '')
  text = text.replace(/^```\s*/i, '')
  text = text.replace(/\s*```$/i, '')
  text = text.trim()

  // Try direct parse first
  try {
    return JSON.parse(text)
  } catch (e1) {
    // Try to extract JSON object
    const objMatch = text.match(/\{[\s\S]*\}/)
    if (objMatch) {
      try { return JSON.parse(objMatch[0]) } catch (e2) {}
    }
    // Try JSON array
    const arrMatch = text.match(/\[[\s\S]*\]/)
    if (arrMatch) {
      try { return JSON.parse(arrMatch[0]) } catch (e3) {}
    }
    console.error('[Pricing Parse] Raw AI response (first 500 chars):', text.substring(0, 500))
    throw new Error('AI response could not be parsed as JSON. Raw response logged to console.')
  }
}

// ── System prompt ─────────────────────────────────────────
const EXTRACT_PROMPT = `You are a Sysco working file population engine. Match each supplier priced item to the correct RFP line item. Use SUPC if available, otherwise use fuzzy description matching plus pack size and category. For each match return exactly the fields below. Return ONLY a valid JSON array, no markdown, no preamble. CRITICAL: Start your response with [ and end with ]. No explanation before or after.
[
  {
    "rfp_line_id": "string (the id field of the matched RFP line item)",
    "matched_supc": "string or null",
    "supplier_name": "string",
    "supplied_price": number,
    "allw": "number or null",
    "dl": "number or null",
    "dev_type": "ALLW|DL|null",
    "price_case": number,
    "open_review": "Y|N",
    "confidence": number,
    "match_method": "supc_exact|description_fuzzy|no_match",
    "notes": "string"
  }
]`

// ── Demo matching (no AI) ─────────────────────────────────
// Maps pricingData records onto lineItems by SUPC
function buildDemoMatches(lineItems, pricingRows) {
  const matched = []
  const pricedSUPCs = new Set(pricingRows.map(p => p.supc))

  lineItems.forEach(li => {
    const priceRec = pricingRows.find(p => p.supc === li.supc)
    if (priceRec) {
      const allw      = priceRec.allowance   || null
      const dl        = priceRec.dlPrice     || null
      const devType   = allw ? 'ALLW' : dl ? 'DL' : null
      const priceCase = allw
        ? +(priceRec.suppliedPrice - allw).toFixed(2)
        : priceRec.suppliedPrice

      matched.push({
        rfp_line_id:    li.id,
        matched_supc:   priceRec.supc,
        supplier_name:  priceRec.supplierName,
        supplied_price: priceRec.suppliedPrice,
        allw,
        dl,
        dev_type:       devType,
        price_case:     priceCase,
        open_review:    priceRec.confidence < 90 ? 'Y' : 'N',
        confidence:     priceRec.confidence,
        match_method:   'supc_exact',
        notes:          priceRec.notes || '',
      })
    }
  })

  return matched
}

// ── POST /api/extract-pricing ─────────────────────────────
// Body: { bidId }
// Reads pricingData.json for that bid → calls Anthropic → returns matched array
router.post('/', async (req, res) => {
  try {
    const { bidId } = req.body
    if (!bidId) return res.status(400).json({ error: 'bidId required' })

    const allLineItems = loadLineItems()
    const lineItems    = allLineItems.filter(li => li.bidId === bidId)
    const pricingData  = loadPricing().filter(p => p.bidId === bidId)

    if (pricingData.length === 0) {
      return res.json([])   // no responses logged yet
    }

    // Demo / no API key → do deterministic SUPC matching
    if (!process.env.ANTHROPIC_API_KEY) {
      const matches = buildDemoMatches(lineItems, pricingData)
      return res.json(matches)
    }

    // Call Anthropic for intelligent matching
    const client  = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
    const message = await client.messages.create({
      model:      process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5',
      max_tokens: 8192,
      system:     EXTRACT_PROMPT,
      messages:   [{
        role:    'user',
        content: `RFP Line Items for ${bidId}:\n${JSON.stringify(lineItems, null, 2)}\n\nSupplier Pricing Responses:\n${JSON.stringify(pricingData, null, 2)}`,
      }],
    })

    const raw = message.content[0].text
    const matches = extractJSON(raw)
    res.json(matches)

  } catch (err) {
    console.error('Extract-pricing error:', err)
    res.status(500).json({ error: err.message })
  }
})

export default router
