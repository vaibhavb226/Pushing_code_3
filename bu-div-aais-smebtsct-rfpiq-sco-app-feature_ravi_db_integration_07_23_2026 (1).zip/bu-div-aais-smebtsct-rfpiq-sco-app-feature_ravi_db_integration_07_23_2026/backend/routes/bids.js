import express from 'express'
import { readFileSync, writeFileSync, renameSync, existsSync, mkdirSync, statSync, readdirSync, unlinkSync, createReadStream } from 'fs'
import { fileURLToPath } from 'url'
import { createRequire } from 'module'
import { dirname, join, extname } from 'path'
import multer from 'multer'
import Anthropic from '@anthropic-ai/sdk'
import * as XLSX from 'xlsx'
import { buildLineItem } from './rfpParser.js'
import { sendEmail } from '../services/emailService.js'
import { buildAwardEmailSubject, buildAwardEmailBody } from '../utils/awardEmailTemplate.js'
import { autoParseLineItems } from '../services/lineItemParser.js'

const _require  = createRequire(import.meta.url)
const pdfParse  = _require('pdf-parse')

// ── Robust JSON extractor (strips markdown fences, handles trailing text) ──
function extractJSON(rawText) {
  if (!rawText || typeof rawText !== 'string') throw new Error('Empty AI response')
  let text = rawText.trim()
    .replace(/^```json\s*/i, '').replace(/^```\s*/i, '').replace(/\s*```$/i, '').trim()
  try { return JSON.parse(text) } catch { /* fall through */ }
  const obj = text.match(/\{[\s\S]*\}/)
  if (obj) try { return JSON.parse(obj[0]) } catch { /* fall through */ }
  const arr = text.match(/\[[\s\S]*\]/)
  if (arr) try { return JSON.parse(arr[0]) } catch { /* fall through */ }
  throw new Error('Could not parse AI response as JSON')
}

const __dirname = dirname(fileURLToPath(import.meta.url))
const router = express.Router()

const BIDS_PATH             = join(__dirname, '../data/bids.json')
const PORTAL_TEMPLATES_PATH = join(__dirname, '../data/portalTemplates.json')
const LINE_ITEMS_PATH  = join(__dirname, '../data/lineItems.json')
const EMAILS_PATH      = join(__dirname, '../data/emailThreads.json')
const SUPPLIERS_PATH   = join(__dirname, '../data/suppliers.json')
const DOCUMENTS_PATH   = join(__dirname, '../data/documents.json')
const PRICING_PATH     = join(__dirname, '../data/pricingData.json')
const UPLOADS_DIR      = join(__dirname, '../uploads')
if (!existsSync(UPLOADS_DIR)) mkdirSync(UPLOADS_DIR, { recursive: true })

const loadBids       = () => JSON.parse(readFileSync(BIDS_PATH, 'utf8'))
const saveBids       = (d) => writeFileSync(BIDS_PATH, JSON.stringify(d, null, 2))
const loadLineItems  = () => JSON.parse(readFileSync(LINE_ITEMS_PATH, 'utf8'))
const saveLineItems  = (d) => writeFileSync(LINE_ITEMS_PATH, JSON.stringify(d, null, 2))
const loadEmails     = () => JSON.parse(readFileSync(EMAILS_PATH, 'utf8'))
const saveEmails     = (d) => writeFileSync(EMAILS_PATH, JSON.stringify(d, null, 2))
const loadSuppliers  = () => JSON.parse(readFileSync(SUPPLIERS_PATH, 'utf8'))
const loadDocs       = () => { try { return JSON.parse(readFileSync(DOCUMENTS_PATH, 'utf8')) } catch { return [] } }
const saveDocs       = (d) => writeFileSync(DOCUMENTS_PATH, JSON.stringify(d, null, 2))
const loadPricing    = () => { try { return JSON.parse(readFileSync(PRICING_PATH, 'utf8')) } catch { return [] } }
const savePricing    = (d) => writeFileSync(PRICING_PATH, JSON.stringify(d, null, 2))

// ── File size formatter ───────────────────────────────────
function formatFileSize(bytes) {
  if (!bytes) return '—'
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

// ── Get file size from disk (for backfill) ────────────────
function fileSizeFromDisk(relPath) {
  try {
    const abs = join(__dirname, '..', relPath)
    return formatFileSize(statSync(abs).size)
  } catch { return '—' }
}

// ── Bounce detection (mirrors emailPoller.js) ─────────────
const BOUNCE_FROM_RE    = /mailer-daemon|postmaster|mail-daemon/i
const BOUNCE_SUBJECT_RE = /delivery status notification|mail delivery failed|undeliverable|returned mail|delivery failure|failure notice|could not be delivered/i

function extractBounceDetails(bodyText = '') {
  const dsnPatterns = [
    /Final-Recipient:.*?rfc822;\s*([^\s\r\n]+)/i,
    /Original-Recipient:.*?rfc822;\s*([^\s\r\n]+)/i,
    /failed\s+recipient[:\s]+([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})/i,
    /(?:to|rcpt\s+to)[:\s<]+([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})/i,
  ]
  let originalRecipient = null
  for (const re of dsnPatterns) {
    const m = bodyText.match(re)
    if (m?.[1]) { originalRecipient = m[1].toLowerCase().trim(); break }
  }
  if (!originalRecipient) {
    const m = bodyText.match(/<([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})>/)
    if (m?.[1] && !BOUNCE_FROM_RE.test(m[1])) originalRecipient = m[1].toLowerCase()
  }
  if (!originalRecipient) {
    const all = bodyText.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g) || []
    originalRecipient = all.find(e => !BOUNCE_FROM_RE.test(e)) || null
  }
  const codeM      = bodyText.match(/\b(5\d{2}(?:\s+[\d.]+)?)\b/)
  const bounceCode = codeM ? codeM[1].trim() : null
  const reasonM    = bodyText.match(/(user\s*does\s*not\s*exist|mailbox\s*not\s*found|no\s*such\s*user)/i)
  const reasonFallback = bodyText.match(/(?:reason|diagnostic[- ]code)[:\s]+(.+)/i)
  const bounceReason   =
    (reasonM?.[1]) ||
    (reasonFallback?.[1]?.slice(0, 200).trim()) ||
    'Delivery failure'
  return { bounceCode, bounceReason, originalRecipient }
}

// ── MIME type map ─────────────────────────────────────────
const MIME_MAP = {
  '.pdf':  'application/pdf',
  '.xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  '.xls':  'application/vnd.ms-excel',
  '.csv':  'text/csv',
  '.docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
}

// ── Multer for additional document uploads ────────────────
const docUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 25 * 1024 * 1024 },
})

// ── GET /api/bids ─────────────────────────────────────────
router.get('/', (req, res) => {
  const bids = loadBids()
  const { segment, status } = req.query
  let filtered = bids
  if (segment) filtered = filtered.filter(b => b.segment === segment)
  if (status)  filtered = filtered.filter(b => b.status  === status)
  res.json(filtered)
})

// ── GET /api/bids/:id ─────────────────────────────────────
router.get('/:id', (req, res) => {
  const bid = loadBids().find(b => b.id === req.params.id)
  if (!bid) return res.status(404).json({ error: 'Bid not found' })
  res.json(bid)
})

// ── POST /api/bids ────────────────────────────────────────
// Create a new bid + optional line items (called by Step 2 Bid Details form)
router.post('/', (req, res) => {
  try {
    const {
      id: reqId, customer, opco, opcoName, region, segment, status,
      intakeDate, bidRelease, customerDue, internalDue,
      notes, items, suppliersContacted, responsesReceived,
      compliance, itemCategories, lineItems,
      tempPdfPath, tempExcelPath,
      pdfOriginalName, excelOriginalName, pdfSize, excelSize,
      rfpFileHash,
    } = req.body

    if (!customer)    return res.status(400).json({ error: 'customer is required' })
    if (!segment)     return res.status(400).json({ error: 'segment is required' })
    if (!customerDue) return res.status(400).json({ error: 'customerDue is required' })

    const today  = new Date().toISOString().split('T')[0]
    const yymmdd = today.replace(/-/g, '').slice(2)
    const bidId  = reqId?.trim() || `RFP-${yymmdd}-${String(Math.floor(Math.random() * 900) + 100)}`

    const bids = loadBids()
    if (bids.find(b => b.id === bidId)) {
      return res.status(409).json({ error: `Bid ID "${bidId}" already exists — choose a different ID` })
    }
    if (rfpFileHash) {
      const dup = bids.find(b => b.rfpFileHash === rfpFileHash)
      if (dup) {
        return res.status(409).json({ detail: { message: 'RFP file already exists', existingBidId: dup.id } })
      }
    }

    // ── Rename temp upload files to bid-specific names ────
    const UPLOADS_DIR = join(__dirname, '../uploads')
    let uploadedRfpPath       = null
    let uploadedItemListPath  = null

    const tryRename = (tempRel, destFilename) => {
      if (!tempRel) return null
      try {
        const src  = join(__dirname, '..', tempRel)
        const dest = join(UPLOADS_DIR, destFilename)
        if (existsSync(src)) {
          renameSync(src, dest)
          return `uploads/${destFilename}`
        }
      } catch (e) {
        console.warn('[Bids] Could not rename temp file:', e.message)
      }
      return null
    }

    if (tempPdfPath) {
      uploadedRfpPath = tryRename(tempPdfPath, `${bidId}_RFP.pdf`)
    }
    if (tempExcelPath) {
      const ext = (tempExcelPath.split('.').pop() || 'xlsx').toLowerCase()
      uploadedItemListPath = tryRename(tempExcelPath, `${bidId}_ItemList.${ext}`)
    }

    // ── Build uploadedFiles array ─────────────────────────
    const uploadedFiles = []
    if (uploadedRfpPath) {
      uploadedFiles.push({
        id:         `FILE-${bidId}-RFP`,
        name:       pdfOriginalName || `${bidId}_RFP.pdf`,
        type:       'RFP Document',
        mimetype:   'application/pdf',
        size:       pdfSize ? formatFileSize(Number(pdfSize)) : fileSizeFromDisk(uploadedRfpPath),
        uploadedAt: today,
        path:       uploadedRfpPath,
      })
    }
    if (uploadedItemListPath) {
      const ext = extname(uploadedItemListPath).slice(1) || 'xlsx'
      uploadedFiles.push({
        id:         `FILE-${bidId}-ITEMS`,
        name:       excelOriginalName || `${bidId}_ItemList.${ext}`,
        type:       'Item List',
        mimetype:   MIME_MAP[`.${ext}`] || 'application/octet-stream',
        size:       excelSize ? formatFileSize(Number(excelSize)) : fileSizeFromDisk(uploadedItemListPath),
        uploadedAt: today,
        path:       uploadedItemListPath,
      })
    }

    const newBid = {
      id:                 bidId,
      customer:           customer  || 'New Customer',
      opco:               opco      || '000',
      opcoName:           opcoName  || 'Sysco OpCo',
      region:             region    || 'Unknown',
      segment:            segment   || 'K-12',
      status:             status    || 'Active',
      intakeDate:         intakeDate  || today,
      bidRelease:         bidRelease  || today,
      customerDue:        customerDue || '',
      internalDue:        internalDue || '',
      notes:              notes       || '',
      items:              items ?? (Array.isArray(lineItems) ? lineItems.length : 0),
      suppliersContacted: suppliersContacted ?? 0,
      responsesReceived:  responsesReceived  ?? 0,
      solicitedSuppliers: [],
      compliance:         Array.isArray(compliance)     ? compliance     : [],
      itemCategories:     Array.isArray(itemCategories) ? itemCategories : [],
      uploadedRfpPath,
      uploadedItemListPath,
      uploadedFiles,
      rfpFileHash:        rfpFileHash || null,
    }

    bids.push(newBid)
    saveBids(bids)

    // ── Auto-add to documents.json ────────────────────────
    if (uploadedFiles.length > 0) {
      const docs = loadDocs()
      const complianceTags = Array.isArray(compliance) ? compliance.slice(0, 2) : []
      for (const f of uploadedFiles) {
        docs.push({
          id:           `DOC-${bidId}-${f.type === 'RFP Document' ? 'RFP' : 'ITEMS'}`,
          fileName:     f.name,
          fileType:     extname(f.name).slice(1).toLowerCase() || 'pdf',
          sizeKb:       null,
          supplier:     'Customer RFP',
          supplierId:   null,
          supplierCategory: null,
          bidId,
          documentType: f.type,
          tags:         [segment || 'K-12', ...complianceTags].filter(Boolean),
          uploadDate:   today,
          uploadedBy:   'BEX AI Upload',
          status:       'Filed',
          filePath:     f.path,
        })
      }
      saveDocs(docs)
    }

    let lineItemsCreated = 0
    if (Array.isArray(lineItems) && lineItems.length > 0) {
      const existing  = loadLineItems()
      const filtered  = existing.filter(li => li.bidId !== bidId)
      const newItems  = lineItems.map((li, i) => buildLineItem(li, bidId, i))
      filtered.push(...newItems)
      saveLineItems(filtered)
      lineItemsCreated = newItems.length
    }

    res.status(201).json({ success: true, bid: newBid, bidId, lineItemsCreated })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── PATCH /api/bids/:id ───────────────────────────────────
// Update bid fields (status, suppliersContacted, responsesReceived …)
router.patch('/:id', (req, res) => {
  try {
    const bids = loadBids()
    const idx  = bids.findIndex(b => b.id === req.params.id)
    if (idx === -1) return res.status(404).json({ error: 'Bid not found' })

    const prevSuppliers = bids[idx].solicitedSuppliers || []

    // Handle awardNotificationSentIds — mark matching solicitedSuppliers entries
    if (Array.isArray(req.body.awardNotificationSentIds)) {
      const sentIds = new Set(req.body.awardNotificationSentIds)
      const now = new Date().toISOString()
      bids[idx].solicitedSuppliers = (bids[idx].solicitedSuppliers || []).map(s =>
        sentIds.has(s.supplierId)
          ? { ...s, awardNotificationSent: true, awardNotificationSentAt: s.awardNotificationSentAt || now }
          : s
      )
      const { awardNotificationSentIds: _omit, ...restBody } = req.body
      bids[idx] = { ...bids[idx], ...restBody }
    } else {
      bids[idx] = { ...bids[idx], ...req.body }
    }
    saveBids(bids)

    // Sync award status to line items when a supplier transitions to/from Awarded
    if (req.body.solicitedSuppliers) {
      const today = new Date().toISOString().split('T')[0]
      const lineItems = loadLineItems()
      let changed = false
      req.body.solicitedSuppliers.forEach(s => {
        const prev = prevSuppliers.find(p => p.supplierId === s.supplierId)
        const nowAwarded  = s.status === 'Awarded' || s.status === 'Complete'
        const wasAwarded  = prev && (prev.status === 'Awarded' || prev.status === 'Complete')
        if (nowAwarded === wasAwarded) return  // no change, skip
        lineItems.forEach(li => {
          if (li.bidId !== req.params.id) return
          if (!Array.isArray(li.supplierPricing)) return
          li.supplierPricing = li.supplierPricing.map(sp => {
            const nameMatch = sp.supplierName?.toLowerCase().includes(s.supplierId.toLowerCase()) ||
                              s.supplierId.toLowerCase().includes((sp.supplierName || '').toLowerCase().split(' ')[0])
            const emailMatch = sp.supplierEmail && s.supplierEmail && sp.supplierEmail === s.supplierEmail
            if (!nameMatch && !emailMatch) return sp
            changed = true
            return nowAwarded
              ? { ...sp, awardStatus: 'awarded', awardedAt: today }
              : { ...sp, awardStatus: null, awardedAt: null }
          })
        })
      })
      if (changed) saveLineItems(lineItems)
    }

    res.json({ success: true, bid: bids[idx] })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── PATCH /api/bids/:bidId/working-file-config ───────────
router.patch('/:bidId/working-file-config', (req, res) => {
  try {
    const bids = loadBids()
    const idx  = bids.findIndex(b => b.id === req.params.bidId)
    if (idx === -1) return res.status(404).json({ error: 'Bid not found' })
    bids[idx].workingFileConfig = req.body
    saveBids(bids)
    res.json({ success: true })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── GET /api/bids/:bidId/files ────────────────────────────
router.get('/:bidId/files', (req, res) => {
  const bid = loadBids().find(b => b.id === req.params.bidId)
  if (!bid) return res.status(404).json({ error: 'Bid not found' })
  res.json(bid.uploadedFiles || [])
})

// ── POST /api/bids/:bidId/files ───────────────────────────
// Upload an additional document and attach it to the bid
router.post('/:bidId/files', docUpload.single('file'), (req, res) => {
  try {
    const { bidId } = req.params
    const bids = loadBids()
    const idx  = bids.findIndex(b => b.id === bidId)
    if (idx === -1) return res.status(404).json({ error: 'Bid not found' })
    if (!req.file)  return res.status(400).json({ error: 'No file uploaded' })

    const today    = new Date().toISOString().split('T')[0]
    const docType  = req.body.docType  || 'Other'
    const notes    = req.body.notes    || ''
    const origName = req.file.originalname || 'document'
    const ext      = extname(origName).toLowerCase() || '.pdf'
    const ts       = Date.now()
    const safeName = `${bidId}_${docType.replace(/\s+/g, '_')}_${ts}${ext}`
    const destPath = join(UPLOADS_DIR, safeName)

    // Write buffer to uploads/
    writeFileSync(destPath, req.file.buffer)

    const fileRecord = {
      id:         `FILE-${bidId}-${ts}`,
      name:       origName,
      type:       docType,
      mimetype:   req.file.mimetype || MIME_MAP[ext] || 'application/octet-stream',
      size:       formatFileSize(req.file.size),
      uploadedAt: today,
      path:       `uploads/${safeName}`,
      notes,
    }

    // Add to bid
    bids[idx].uploadedFiles = [...(bids[idx].uploadedFiles || []), fileRecord]
    saveBids(bids)

    // Add to documents.json
    const docs = loadDocs()
    docs.push({
      id:           fileRecord.id,
      fileName:     origName,
      fileType:     ext.slice(1) || 'pdf',
      sizeKb:       null,
      supplier:     'Internal Upload',
      supplierId:   null,
      supplierCategory: null,
      bidId,
      documentType: docType,
      tags:         [bids[idx].segment || 'K-12'].filter(Boolean),
      uploadDate:   today,
      uploadedBy:   'Manual Upload',
      status:       'Filed',
      notes,
      filePath:     fileRecord.path,
    })
    saveDocs(docs)

    // ── Auto-parse line items from uploaded file ───────────
    // Run for Item List and RFP doc types — in background (non-blocking)
    // Excel overwrites PDF if both are eventually uploaded (priority: Excel > PDF)
    const parseTriggerTypes = ['Item List', 'RFP', 'RFP Document']
    if (parseTriggerTypes.includes(docType) || /\.(xlsx?|pdf)$/i.test(ext)) {
      setImmediate(async () => {
        try {
          const parsed = await autoParseLineItems(
            bidId,
            { originalname: origName, mimetype: req.file.mimetype },
            destPath,
          )
          if (parsed.length > 0) {
            console.log(`[BidUpload] ${bidId}: auto-parsed ${parsed.length} line items from "${origName}"`)
          }
        } catch (parseErr) {
          console.warn(`[BidUpload] ${bidId}: line item auto-parse failed:`, parseErr.message)
        }
      })
    }

    res.status(201).json({ success: true, file: fileRecord })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── GET /api/bids/:bidId/files/:filename/view ─────────────
// Serve uploaded file inline (browser View)
router.get('/:bidId/files/:filename/view', (req, res) => {
  const filename = req.params.filename.replace(/[/\\]/g, '')
  const filepath = join(UPLOADS_DIR, filename)
  if (!existsSync(filepath)) return res.status(404).json({ error: 'File not found' })
  const ext  = extname(filename).toLowerCase()
  const mime = MIME_MAP[ext] || 'application/octet-stream'
  res.setHeader('Content-Type', mime)
  res.setHeader('Content-Disposition', `inline; filename="${filename}"`)
  createReadStream(filepath).pipe(res)
})

// ── GET /api/bids/:bidId/files/:filename/download ─────────
// Serve uploaded file as attachment (browser Download)
router.get('/:bidId/files/:filename/download', (req, res) => {
  const filename = req.params.filename.replace(/[/\\]/g, '')
  const filepath = join(UPLOADS_DIR, filename)
  if (!existsSync(filepath)) return res.status(404).json({ error: 'File not found' })
  const ext  = extname(filename).toLowerCase()
  const mime = MIME_MAP[ext] || 'application/octet-stream'
  res.setHeader('Content-Type', mime)
  res.setHeader('Content-Disposition', `attachment; filename="${filename}"`)
  createReadStream(filepath).pipe(res)
})

// ── GET /api/bids/:bidId/line-items ───────────────────────
router.get('/:bidId/line-items', (req, res) => {
  const all = loadLineItems()
  res.json(all.filter(li => li.bidId === req.params.bidId))
})

// ── PATCH /api/bids/:bidId/line-items/:lineId ─────────────
router.patch('/:bidId/line-items/:lineId', (req, res) => {
  try {
    const all = loadLineItems()
    const idx = all.findIndex(li => li.id === req.params.lineId && li.bidId === req.params.bidId)
    if (idx === -1) return res.status(404).json({ error: 'Line item not found' })

    // Pull out supplierPricing from the body so we can merge rather than replace
    const { supplierPricing: incomingPricing, ...otherFields } = req.body

    // Merge all scalar / non-pricing fields.
    // Accepted fields include: supc, brand, trueVendor, notes, suppliedPrice,
    // devType, allw, dl, priceCase, openReview, confidence, status, itemMaster, etc.
    all[idx] = { ...all[idx], ...otherFields }

    // Smart-merge supplierPricing: APPEND/UPDATE, never overwrite the full array.
    // This prevents the race condition where two items mapped to the same bid line
    // item each write in parallel — the second write used to erase the first.
    if (incomingPricing !== undefined) {
      const existing = Array.isArray(all[idx].supplierPricing)
        ? [...all[idx].supplierPricing]
        : []
      const entries = Array.isArray(incomingPricing) ? incomingPricing : [incomingPricing]

      for (const entry of entries) {
        // Deduplicate key: same supplier + supplierItemNo is the most specific;
        // fall back to same supplier + emailId (single-item email extractions).
        const dupeIdx = existing.findIndex(p => {
          const sameSupplier = p.supplierName === entry.supplierName
          if (!sameSupplier) return false
          // Match on supplierItemNo when both have it (e.g. two Tyson SKUs)
          if (entry.supplierItemNo && p.supplierItemNo) {
            return p.supplierItemNo === entry.supplierItemNo
          }
          // Fall back to emailId match (avoids duplicate from re-extracting same email)
          if (entry.emailId && p.emailId) {
            return p.emailId === entry.emailId
          }
          return false
        })

        if (dupeIdx >= 0) {
          existing[dupeIdx] = entry   // update in-place
        } else {
          existing.push(entry)        // new entry — append
        }
      }

      all[idx].supplierPricing = existing
      console.log(`[LineItems] PATCH ${req.params.lineId}: supplierPricing now ${existing.length} entries`)
    }

    saveLineItems(all)
    res.json({ success: true, lineItem: all[idx] })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── GET /api/bids/:bidId/emails/by-supplier ───────────────
// Returns emails grouped by supplier with computed status.
router.get('/:bidId/emails/by-supplier', (req, res) => {
  try {
    const bidId    = req.params.bidId
    const allEmails  = loadEmails().filter(e => e.bidId === bidId)
    const suppliers  = loadSuppliers()
    const bid        = loadBids().find(b => b.id === bidId)
    if (!bid) return res.status(404).json({ error: 'Bid not found' })

    const completedSuppliers = bid.completedSuppliers || []
    // Build a lookup of manually-overridden statuses from solicitedSuppliers
    const manualStatusMap = {}
    ;(bid.solicitedSuppliers || []).forEach(s => {
      if (s.supplierId && s.status) manualStatusMap[s.supplierId] = s.status
    })

    // Find solicitation email (first outbound + Solicitation tag)
    const solicitation = allEmails.find(e =>
      e.direction === 'outbound' && (e.tags || []).includes('Solicitation')
    ) || null

    // Build set of contacted emails from solicitation BCC
    const contactedEmails = new Set(
      (solicitation?.bcc || []).map(e => String(e).toLowerCase().trim())
    )

    // Group non-solicitation emails by supplierId
    const emailsBySupplierId = {}
    allEmails.forEach(e => {
      if (!e.supplierId) return
      if (!emailsBySupplierId[e.supplierId]) emailsBySupplierId[e.supplierId] = []
      emailsBySupplierId[e.supplierId].push(e)
    })

    // Collect all relevant supplier IDs
    const relevantIds = new Set()
    suppliers.forEach(s => {
      if (contactedEmails.has(s.contact.toLowerCase())) relevantIds.add(s.id)
    })
    Object.keys(emailsBySupplierId).forEach(id => relevantIds.add(id))
    // Also include suppliers explicitly saved to bid.solicitedSuppliers
    ;(bid.solicitedSuppliers || []).forEach(ss => { if (ss.supplierId) relevantIds.add(ss.supplierId) })

    const supplierRows = []
    for (const supplierId of relevantIds) {
      const sup = suppliers.find(s => s.id === supplierId)
      if (!sup) continue

      const supEmails = (emailsBySupplierId[supplierId] || [])
        .sort((a, b) => new Date(a.date) - new Date(b.date))

      const inbound  = supEmails.filter(e => e.direction === 'inbound')
      const outbound = supEmails.filter(e => e.direction === 'outbound')

      // ── Status logic ──
      let status = 'Awaiting'
      if (completedSuppliers.includes(supplierId)) {
        status = 'Awarded'
      } else if (inbound.length > 0) {
        const firstInboundDate = new Date(inbound[0].date)
        const hasFollowUp = outbound.some(out => new Date(out.date) > firstInboundDate)
        if (hasFollowUp) {
          status = 'Follow-up Sent'
        } else {
          status = 'Responded'
        }
      }
      // Manual overrides from solicitedSuppliers take precedence for these statuses
      const MANUAL_OVERRIDE_STATUSES = ['Awarded', 'Complete', 'No Bid', 'Bounced', 'Issues Found', 'Under Consideration', 'In Consideration']
      if (manualStatusMap[supplierId] && MANUAL_OVERRIDE_STATUSES.includes(manualStatusMap[supplierId])) {
        status = manualStatusMap[supplierId]
      }

      // Issue count from latest inbound
      const latestIn   = inbound[inbound.length - 1]
      const issueCount = latestIn?.analysisResult?.issues
        ? Object.values(latestIn.analysisResult.issues).reduce((s, a) => s + (a?.length || 0), 0)
        : 0

      const lastActivity = supEmails.length > 0
        ? supEmails.reduce((mx, e) => new Date(e.date) > new Date(mx) ? e.date : mx, supEmails[0].date)
        : null

      const solicitedEntry = (bid.solicitedSuppliers || []).find(s => s.supplierId === supplierId)
      supplierRows.push({
        supplierId:    sup.id,
        supplierName:  sup.name,
        supplierEmail: sup.contact,
        isBroker:      sup.broker || false,
        status,
        emailCount:    supEmails.length,
        lastActivity,
        issueCount,
        emails:        supEmails,
        awardNotificationSent:   solicitedEntry?.awardNotificationSent   ?? false,
        awardNotificationSentAt: solicitedEntry?.awardNotificationSentAt ?? null,
      })
    }

    // Sort: Responded / Issues / Follow-up first, then Awaiting
    const ORDER = { 'Issues Found': 0, 'Follow-up Sent': 1, Responded: 2, Awarded: 3, Complete: 3, Awaiting: 4 }
    supplierRows.sort((a, b) => (ORDER[a.status] ?? 5) - (ORDER[b.status] ?? 5))

    res.json({ solicitation, suppliers: supplierRows })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── GET /api/bids/:bidId/emails ───────────────────────────
router.get('/:bidId/emails', (req, res) => {
  const emails = loadEmails()
  res.json(emails.filter(e => e.bidId === req.params.bidId))
})

// ── POST /api/bids/:bidId/emails ──────────────────────────
// For outbound: sends real email via Gmail SMTP, then persists to emailThreads.json.
// For inbound:  persists directly (manual log of a received email).
router.post('/:bidId/emails', async (req, res) => {
  try {
    const { direction, from, to, bcc, subject, body, attachments, tags,
            supplierId, supplierName, supplierEmail, pricingFilePath,
            supplierContacts,
            isBounce: callerIsBounce } = req.body   // supplierContacts: [{supplierId, supplierName, email, category}]

    let smtpResult = null

    // ── Real send for outbound emails ──────────────────
    if (direction === 'outbound' || !direction) {
      // Build real attachment paths from the bid record
      const bid = loadBids().find(b => b.id === req.params.bidId)
      const attachmentPaths = []
      for (const field of ['uploadedRfpPath', 'uploadedItemListPath']) {
        const rel = bid?.[field]
        if (rel) {
          attachmentPaths.push({
            filename: rel.split('/').pop(),
            path:     join(__dirname, '..', rel),
          })
        }
      }

      try {
        smtpResult = await sendEmail({
          to:              to  || '',
          bcc:             Array.isArray(bcc) ? bcc : [],
          subject:         subject || '',
          body:            body    || '',
          attachmentNames: Array.isArray(attachments) ? attachments : [],
          attachmentPaths,
        })
      } catch (sendErr) {
        // Never silently fail — return the SMTP error clearly
        return res.status(502).json({
          error: sendErr.message,
          hint:  'Email was NOT sent or saved. Fix the error above and try again.',
        })
      }
    }

    // ── Persist to emailThreads.json ───────────────────
    const emails = loadEmails()
    const newEmail = {
      id:            `E-${Date.now()}`,
      bidId:         req.params.bidId,
      direction:     direction      || 'outbound',
      supplierId:    supplierId     || null,
      supplierName:  supplierName   || null,
      supplierEmail: supplierEmail  || null,
      from:          from           || process.env.EMAIL_FROM || 'COE.BIDS@sysco.com',
      to:            to             || '',
      bcc:           Array.isArray(bcc) ? bcc : [],
      subject:       subject        || '',
      body:          body           || '',
      date:          new Date().toISOString(),
      attachments:     direction === 'outbound' && Array.isArray(attachments)
        ? attachments.filter(Boolean).map(a => String(a).split('/').pop())
        : (Array.isArray(attachments) ? attachments : []),
      pricingFilePath: pricingFilePath || null,    // disk path saved by file upload step
      tags:            Array.isArray(tags) ? tags : [],
      read:            true,
      analysisResult:  null,
      ...(smtpResult ? { messageId: smtpResult.messageId } : {}),
    }
    // ── Bounce detection for inbound emails ────────────────────────────
    const isBounceFlag = direction === 'inbound' &&
      (Boolean(callerIsBounce) || BOUNCE_FROM_RE.test(from || '') || BOUNCE_SUBJECT_RE.test(subject || ''))

    if (isBounceFlag) {
      const bd = extractBounceDetails(body || '')
      newEmail.isBounce          = true
      newEmail.bounceCode        = req.body.bounceCode        || bd.bounceCode
      newEmail.bounceReason      = req.body.bounceReason      || bd.bounceReason
      newEmail.originalRecipient = req.body.originalRecipient || bd.originalRecipient
      if (!Array.isArray(newEmail.tags)) newEmail.tags = []
      if (!newEmail.tags.includes('bounce')) newEmail.tags.push('bounce')
    }

    emails.push(newEmail)
    saveEmails(emails)

    // ── If this is an inbound email, auto-update supplier status ──────
    if (direction === 'inbound') {
      if (isBounceFlag) {
        // Bounce → mark the ORIGINAL RECIPIENT's supplier entry as "Issues Found"
        const targetEmail = (newEmail.originalRecipient || supplierEmail || '').toLowerCase()
        if (targetEmail) {
          try {
            const allBids = loadBids()
            const bIdx    = allBids.findIndex(b => b.id === req.params.bidId)
            if (bIdx !== -1) {
              const ss   = allBids[bIdx].solicitedSuppliers || []
              const sIdx = ss.findIndex(s => s.email.toLowerCase() === targetEmail)
              if (sIdx !== -1 && !['Awarded', 'Complete'].includes(ss[sIdx].status)) {
                ss[sIdx].status       = 'Issues Found'
                ss[sIdx].hasIssues    = true
                ss[sIdx].issueType    = 'bounce'
                ss[sIdx].lastActivity = new Date().toISOString().split('T')[0]
                allBids[bIdx].solicitedSuppliers = ss
                saveBids(allBids)
              }
            }
          } catch (statusErr) {
            console.warn('[Bids] Could not update bounce supplier status:', statusErr.message)
          }
        }
      } else if (supplierEmail || newEmail.supplierEmail) {
        // Normal inbound reply → Awaiting → Responded
        const inboundEmail = supplierEmail || newEmail.supplierEmail
        try {
          const allBids = loadBids()
          const bIdx    = allBids.findIndex(b => b.id === req.params.bidId)
          if (bIdx !== -1) {
            const ss   = allBids[bIdx].solicitedSuppliers || []
            const sIdx = ss.findIndex(s => s.email.toLowerCase() === inboundEmail.toLowerCase())
            if (sIdx !== -1 && (ss[sIdx].status === 'Awaiting' || !ss[sIdx].status)) {
              ss[sIdx].status       = 'Responded'
              ss[sIdx].lastActivity = new Date().toISOString().split('T')[0]
              allBids[bIdx].solicitedSuppliers = ss
              saveBids(allBids)
            }
          }
        } catch (statusErr) {
          console.warn('[Bids] Could not update supplier status:', statusErr.message)
        }
      }
    }

    // ── If this is an outbound Follow-up, update status → "Follow-up Sent" ──
    if (
      (direction === 'outbound' || !direction) &&
      Array.isArray(tags) && tags.includes('Follow-up') &&
      (supplierEmail || newEmail.supplierEmail)
    ) {
      try {
        const fupEmail = supplierEmail || newEmail.supplierEmail
        const allBids  = loadBids()
        const bIdx     = allBids.findIndex(b => b.id === req.params.bidId)
        if (bIdx !== -1) {
          const ss   = allBids[bIdx].solicitedSuppliers || []
          const sIdx = ss.findIndex(s => s.email.toLowerCase() === fupEmail.toLowerCase())
          if (sIdx !== -1 &&
              (ss[sIdx].status === 'Responded' || ss[sIdx].status === 'Issues Found')) {
            ss[sIdx].status       = 'Follow-up Sent'
            ss[sIdx].lastActivity = new Date().toISOString().split('T')[0]
            allBids[bIdx].solicitedSuppliers = ss
            saveBids(allBids)
          }
        }
      } catch { /* best-effort */ }
    }

    // ── If this is a solicitation, save solicitedSuppliers to bid ──
    const isSolicitation =
      (direction === 'outbound' || !direction) &&
      Array.isArray(tags) && tags.includes('Solicitation')

    if (isSolicitation) {
      try {
        const today       = new Date().toISOString().split('T')[0]
        const allSuppliers = loadSuppliers()
        const bccList      = Array.isArray(bcc) ? bcc : []
        const bccSet       = new Set(bccList.map(e => String(e).toLowerCase().trim()))

        let newSolicited = []

        if (Array.isArray(supplierContacts) && supplierContacts.length > 0) {
          // Prefer explicit supplier list passed from the frontend (most accurate)
          newSolicited = supplierContacts.map(sc => ({
            supplierId:    sc.supplierId,
            supplierName:  sc.supplierName,
            email:         (sc.email || '').toLowerCase(),
            category:      sc.category || '',
            status:        'Awaiting',
            solicitedDate: today,
            lastActivity:  today,
          }))
        } else {
          // Fall back: match BCC emails to suppliers.json
          newSolicited = allSuppliers
            .filter(s => bccSet.has(s.contact.toLowerCase()))
            .map(s => ({
              supplierId:    s.id,
              supplierName:  s.name,
              email:         s.contact.toLowerCase(),
              category:      s.category || '',
              status:        'Awaiting',
              solicitedDate: today,
              lastActivity:  today,
            }))
        }

        if (newSolicited.length > 0) {
          const bids    = loadBids()
          const bidIdx  = bids.findIndex(b => b.id === req.params.bidId)
          if (bidIdx !== -1) {
            const existing    = bids[bidIdx].solicitedSuppliers || []
            const existingIds = new Set(existing.map(s => s.supplierId))
            const merged      = [...existing, ...newSolicited.filter(s => !existingIds.has(s.supplierId))]
            bids[bidIdx].solicitedSuppliers    = merged
            bids[bidIdx].suppliersContacted    = merged.length
            bids[bidIdx].lastSolicitationDate  = today
            if (bids[bidIdx].status === 'Active') bids[bidIdx].status = 'Solicitation'
            saveBids(bids)
            console.log(`[Bids] Saved ${newSolicited.length} solicited suppliers to ${req.params.bidId} (total: ${merged.length})`)
          }
        }
      } catch (solErr) {
        console.warn('[Bids] Could not save solicitedSuppliers:', solErr.message)
      }
    }

    res.json({
      success:        true,
      email:          newEmail,
      sent:           !!smtpResult,
      recipientCount: smtpResult?.recipientCount ?? 0,
      attachedCount:  smtpResult?.attachedCount  ?? 0,
      messageId:      smtpResult?.messageId ?? null,
    })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── PATCH /api/bids/:bidId/suppliers/:supplierId ──────────
// Manual status override for a single solicited supplier
router.patch('/:bidId/suppliers/:supplierId', (req, res) => {
  try {
    const { status, notes } = req.body
    if (!status) return res.status(400).json({ error: 'status is required' })

    const bids   = loadBids()
    const bidIdx = bids.findIndex(b => b.id === req.params.bidId)
    if (bidIdx === -1) return res.status(404).json({ error: 'Bid not found' })

    const ss   = bids[bidIdx].solicitedSuppliers || []
    const sIdx = ss.findIndex(s => s.supplierId === req.params.supplierId)
    if (sIdx === -1) return res.status(404).json({ error: 'Supplier not in bid solicitation list' })

    ss[sIdx].status       = status
    ss[sIdx].lastActivity = new Date().toISOString().split('T')[0]
    if (notes !== undefined) ss[sIdx].notes = notes

    bids[bidIdx].solicitedSuppliers = ss
    saveBids(bids)
    res.json({ success: true, supplier: ss[sIdx] })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── POST /api/bids/:bidId/send-award-email ────────────────
const awardUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 10 * 1024 * 1024 } })
router.post('/:bidId/send-award-email', awardUpload.array('attachments'), async (req, res) => {
  try {
    const { supplierId, supplierName, supplierEmail, to, subject, body, awardedItems } = req.body
    if (!supplierId) return res.status(400).json({ error: 'supplierId required' })

    const bids   = loadBids()
    const bid    = bids.find(b => b.id === req.params.bidId)
    if (!bid) return res.status(404).json({ error: 'Bid not found' })

    const today   = new Date().toISOString().split('T')[0]

    // Use edited values from frontend if provided, otherwise build from shared template
    const emailTo      = to      || supplierEmail || `${supplierId}@supplier.com`
    const emailSubject = subject || buildAwardEmailSubject(bid)
    const emailBody    = body    || buildAwardEmailBody({
      supplierName:  supplierName || 'Supplier',
      customerName:  bid.customer || bid.customerName || '',
      bidId:         bid.id,
    })

    // Attempt SMTP first so we can capture delivery status in the thread record
    const files = req.files || []
    let deliveryStatus = 'not_configured'
    try {
      if (process.env.EMAIL_FROM && emailTo.includes('@')) {
        const nodemailer = (await import('nodemailer')).default
        const transporter = nodemailer.createTransport({
          host:   process.env.EMAIL_HOST  || 'smtp.gmail.com',
          port:   Number(process.env.EMAIL_PORT) || 587,
          secure: false,
          auth: {
            user: process.env.EMAIL_FROM,
            pass: (process.env.EMAIL_APP_PASSWORD || '').replace(/\s/g, ''),
          },
        })
        await transporter.sendMail({
          from:        process.env.EMAIL_FROM,
          to:          emailTo,
          subject:     emailSubject,
          text:        emailBody,
          attachments: files.map(f => ({ filename: f.originalname, content: f.buffer, contentType: f.mimetype })),
        })
        console.log(`[Award Email] Sent to ${emailTo} with ${files.length} attachment(s)`)
        deliveryStatus = 'sent'
      }
    } catch (smtpErr) {
      deliveryStatus = 'failed'
      console.warn('[Award Email] SMTP send failed (email still logged):', smtpErr.message)
    }

    // Record award email as a thread entry with delivery outcome
    const emails = loadEmails()
    const newEmail = {
      id:             `award-${supplierId}-${Date.now()}`,
      bidId:          req.params.bidId,
      direction:      'outbound',
      from:           'COE.BIDS@sysco.com',
      to:             emailTo,
      subject:        emailSubject,
      body:           emailBody,
      date:           today,
      supplierEmail:  supplierEmail || null,
      supplierId:     supplierId,
      tags:           ['Award Notification'],
      awardEmail:     true,
      deliveryStatus,
    }
    emails.push(newEmail)
    saveEmails(emails)

    // Mark awardNotificationSent on the supplier entry
    const ssIdx = (bid.solicitedSuppliers || []).findIndex(s => s.supplierId === supplierId)
    if (ssIdx !== -1) {
      bid.solicitedSuppliers[ssIdx].awardNotificationSent   = true
      bid.solicitedSuppliers[ssIdx].awardNotificationSentAt = today
      saveBids(bids)
    }

    res.json({ success: true, email: newEmail, attachments: files.length })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── PATCH /api/bids/:bidId/emails/:emailId/analysis ───────
// Save AI analysis result to an email and auto-update status
router.patch('/:bidId/emails/:emailId/analysis', (req, res) => {
  try {
    const { analysisResult } = req.body
    const emails = loadEmails()
    const idx    = emails.findIndex(e => e.id === req.params.emailId && e.bidId === req.params.bidId)
    if (idx === -1) return res.status(404).json({ error: 'Email not found' })

    emails[idx].analysisResult = analysisResult
    saveEmails(emails)

    res.json({ success: true, email: emails[idx] })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── DELETE /api/bids/:id ──────────────────────────────────
// Cascading delete — removes bid + all linked data + uploaded files
router.delete('/:id', (req, res) => {
  try {
    const bidId = req.params.id
    const results = { lineItems: 0, emails: 0, pricing: 0, documents: 0, files: 0, errors: [] }

    // 1. Remove from bids.json
    const bids = loadBids()
    const bidExists = bids.find(b => b.id === bidId)
    if (!bidExists) return res.status(404).json({ error: 'Bid not found' })
    saveBids(bids.filter(b => b.id !== bidId))

    // 2. Remove line items
    const lineItems = loadLineItems()
    const remainingItems = lineItems.filter(li => li.bidId !== bidId)
    results.lineItems = lineItems.length - remainingItems.length
    saveLineItems(remainingItems)

    // 3. Remove emails
    const emails = loadEmails()
    const remainingEmails = emails.filter(e => e.bidId !== bidId)
    results.emails = emails.length - remainingEmails.length
    saveEmails(remainingEmails)

    // 4. Remove pricing data
    const pricing = loadPricing()
    const remainingPricing = pricing.filter(p => p.bidId !== bidId)
    results.pricing = pricing.length - remainingPricing.length
    savePricing(remainingPricing)

    // 5. Remove documents
    const docs = loadDocs()
    const remainingDocs = docs.filter(d => d.bidId !== bidId && d.bidId !== 'ALL')
    // Note: documents with bidId === bidId are removed; 'ALL' documents are shared and kept
    const bidDocs = docs.filter(d => d.bidId === bidId)
    results.documents = bidDocs.length
    saveDocs(docs.filter(d => d.bidId !== bidId))

    // 6. Remove portal submissions
    const SUBS_DEL_PATH = join(__dirname, '../data/submissions.json')
    try {
      const subs = JSON.parse(readFileSync(SUBS_DEL_PATH, 'utf8'))
      if (subs[bidId]) {
        results.submissions = subs[bidId].length
        delete subs[bidId]
        writeFileSync(SUBS_DEL_PATH, JSON.stringify(subs, null, 2))
      }
    } catch {}

    // 7. Delete uploaded files from disk (files named {bidId}_... or {bidId}-...)
    if (existsSync(UPLOADS_DIR)) {
      try {
        const files = readdirSync(UPLOADS_DIR)
        files.forEach(file => {
          if (file.startsWith(bidId + '_') || file.startsWith(bidId + '-')) {
            try {
              unlinkSync(join(UPLOADS_DIR, file))
              results.files++
            } catch (e) {
              results.errors.push(`Could not delete file: ${file}`)
            }
          }
        })
      } catch (e) {
        results.errors.push(`Could not read uploads dir: ${e.message}`)
      }
    }

    // Log deletion summary
    console.log(`[Delete] Bid ${bidId} deleted:`)
    console.log(`  - Bid record:     removed`)
    console.log(`  - Line items:     ${results.lineItems} removed`)
    console.log(`  - Emails:         ${results.emails} removed`)
    console.log(`  - Pricing:        ${results.pricing} removed`)
    console.log(`  - Documents:      ${results.documents} removed`)
    console.log(`  - Uploaded files: ${results.files} deleted`)
    if (results.errors.length > 0) console.log(`  - Errors:`, results.errors)

    res.json({
      success: true,
      deleted: bidId,
      removed: {
        lineItems: results.lineItems,
        emails:    results.emails,
        pricing:   results.pricing,
        documents: results.documents,
        files:     results.files,
      },
    })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// ── POST /api/bids/:bidId/emails/:emailId/extract-pricing ─
// Reads attached PDF/XLSX (or email body as fallback), extracts
// ONLY explicitly stated prices — no AI inference.
// Schwan's-style structured XLSX (col J = bid item #, col R =
// delivered price) is detected and parsed without AI guessing.
router.post('/:bidId/emails/:emailId/extract-pricing', async (req, res) => {
  try {
    const { bidId, emailId } = req.params

    // ── Load source data ──────────────────────────────────
    const email     = loadEmails().find(e => e.id === emailId && e.bidId === bidId)
    if (!email) return res.status(404).json({ error: 'Email not found' })
    const lineItems = loadLineItems().filter(li => li.bidId === bidId)
    const bid       = loadBids().find(b => b.id === bidId) || {}

    // ── PORTAL SUBMISSION: read directly from submissions.json ─────────
    // Portal emails have structured pricing already — no AI extraction needed.
    if (email.portalSubmission && email.threadId) {
      const SUBS_PATH = join(__dirname, '../data/submissions.json')
      let subs = {}
      try { subs = JSON.parse(readFileSync(SUBS_PATH, 'utf8')) } catch {}
      const sub = (subs[bidId] || []).find(s => s.threadId === email.threadId)
      if (sub && Array.isArray(sub.lineItems) && sub.lineItems.length > 0) {
        const enriched = sub.lineItems.map(li => {
          const delivered = parseFloat(li.deliveredPrice) || parseFloat(li.unitPrice) || 0
          const fob       = parseFloat(li.fobPrice)  || 0
          const allw      = parseFloat(li.allowance) || 0
          const ptv       = parseFloat(li.ptvValue)  || 0
          const noBid     = !!li.noBid

          // Try to match to bid line item by itemNo
          const padded = String(li.itemNo || '').padStart(4, '0')
          const bidLi  = lineItems.find(l => l.bidItem === padded)

          return {
            description:        li.description || bidLi?.description || '',
            supplierItemNo:     li.itemNo || '',
            fobPrice:           fob,
            freightAmount:      null,
            allowance:          allw,
            ptvValue:           ptv,
            unitPrice:          delivered,   // primary
            commercialPrice:    delivered,
            devType:            li.devType || null,
            notes:              li.notes   || '',
            noBid,
            lineItemId:         bidLi?.id          || null,
            matchedDescription: bidLi?.description || null,
            matchedBidItemNo:   li.itemNo          || null,
            matchScore:         bidLi ? 100 : 0,
            confidence:         noBid ? 'none' : (bidLi ? 'high' : 'low'),
            confidenceScore:    noBid ? 0     : (bidLi ? 100    : 30),
            confidenceReasons:  bidLi ? ['Exact item number match from portal submission'] : ['No matching bid line item found'],
            matchSource:        'portal',
            // PORTAL-TEMPLATE-START
            customFieldValues:  li.customFieldValues || {},
            // PORTAL-TEMPLATE-END
          }
        })

        const matchedCount = enriched.filter(i => i.lineItemId && !i.noBid).length
        console.log(`[Extract Pricing] ${bidId}/${emailId}: portal submission — ${enriched.length} items, ${matchedCount} matched`)

        return res.json({
          items:          enriched,
          summary:        `${matchedCount} items extracted from portal submission by ${sub.supplierName}`,
          contractType:   '',
          validFrom:      '',
          validTo:        '',
          analystName:    sub.contactName  || '',
          analystPhone:   '',
          sourceUsed:     'portal',
          sourceFileName: `Portal Submission — ${sub.supplierName}`,
          isSchawnsFormat: false,
          supplierName:   sub.supplierName  || email.supplierName || '',
          supplierEmail:  sub.supplierEmail || email.supplierEmail || '',
          emailId,
          bidId,
        })
      }
    }

    // ── DIAGNOSTIC LOGS ───────────────────────────────────
    console.log('[Extract] Full email object:', JSON.stringify(email, null, 2))

    const uploadDir = join(__dirname, '..', 'uploads')
    console.log('[Extract] Files in uploads dir:', readdirSync(uploadDir))

    // ── Resolve attachment file path ──────────────────────
    // Priority 1: email.pricingFilePath — set when file is uploaded
    //   via the Log Supplier Response modal (POST /api/bids/:id/files).
    //   Stored as "uploads/B2600042_Pricing_<ts>.xlsx".
    // Priority 2: search uploads/ by original attachment filename
    //   (for demo emails and IMAP-received emails where only the
    //   original name is known).
    let resolvedFilePath = null
    let resolvedFileName = ''

    console.log(`[Extract Pricing] emailId="${emailId}" bidId="${bidId}" pricingFilePath="${email.pricingFilePath}" attachments=${JSON.stringify(email.attachments)}`)

    if (email.pricingFilePath) {
      // Strip any leading "uploads/" prefix then reconstruct full path
      const stored   = email.pricingFilePath.replace(/^uploads[\\/]/, '')
      const basename = stored.split(/[\\/]/).pop()   // filename only, no dirs
      // Try: exact path first, then just the basename
      const candidates = [
        join(UPLOADS_DIR, stored),     // handles "subdir/file.xlsx" if ever nested
        join(UPLOADS_DIR, basename),   // handles bare filename
      ]
      const found = candidates.find(p => existsSync(p)) || null
      console.log(`[Extract Pricing] pricingFilePath candidates: ${JSON.stringify(candidates.map(p => ({ path: p, exists: existsSync(p) })))}`)
      if (found) { resolvedFilePath = found; resolvedFileName = basename }
    }

    if (!resolvedFilePath) {
      // Fallback: walk email.attachments — handles both new (object) and legacy (string) formats
      const rawAtts = email.attachments || []

      for (const att of rawAtts) {
        // ── New format: { originalName, savedName, path } ─────────────
        if (typeof att === 'object' && att !== null) {
          const origName = att.originalName || att.name || ''
          const savedName = att.savedName || ''
          if (!/\.(pdf|xlsx|xls|csv)$/i.test(origName)) continue

          // Try savedName first (most reliable), then originalName variants
          const candidates = [
            savedName  ? join(UPLOADS_DIR, savedName)  : null,
            origName   ? join(UPLOADS_DIR, origName)   : null,
            origName   ? join(UPLOADS_DIR, `${bidId}_${origName}`) : null,
          ].filter(Boolean)
          const found = candidates.find(p => existsSync(p)) || null
          console.log(`[Extract Pricing] object att "${origName}" (savedName="${savedName}") → ${found || 'NOT FOUND'}`)
          if (found) { resolvedFilePath = found; resolvedFileName = origName || savedName; break }
        }

        // ── Legacy format: plain string filename ──────────────────────
        if (typeof att === 'string') {
          if (!/\.(pdf|xlsx|xls|csv)$/i.test(att)) continue
          const candidates = [
            join(UPLOADS_DIR, att),
            join(UPLOADS_DIR, `${bidId}_${att}`),
            join(UPLOADS_DIR, `${bidId}-${att}`),
          ]
          const found = candidates.find(p => existsSync(p)) || null
          console.log(`[Extract Pricing] string att "${att}" → ${found || 'NOT FOUND'}`)
          if (found) { resolvedFilePath = found; resolvedFileName = att; break }
        }
      }
    }

    console.log('[Extract] Constructed file path:', resolvedFilePath)
    console.log('[Extract] File exists:', resolvedFilePath ? existsSync(resolvedFilePath) : false)

    if (!resolvedFilePath) {
      console.warn(`[Extract Pricing] ⚠ No file found on disk for email ${emailId}. Stored pricingFilePath="${email.pricingFilePath}". UPLOADS_DIR="${UPLOADS_DIR}". Files present: ${existsSync(UPLOADS_DIR) ? readdirSync(UPLOADS_DIR).slice(0, 10).join(', ') : 'dir missing'}`)
    }

    // ── Parse the file ────────────────────────────────────
    let attachmentText  = ''
    let pricingText     = ''   // Schwan's: just the clean item lines (no metadata header)
    let sourceUsed      = 'none'
    let sourceFileName  = resolvedFileName
    // Schwan's-style metadata extracted programmatically
    let schwansDataRows = null
    let contractType    = ''
    let validFrom       = ''
    let validTo         = ''
    let analystName     = ''
    let analystPhone    = ''

    if (resolvedFilePath) {
      const ext = resolvedFileName.split('.').pop().toLowerCase()
      try {
        if (ext === 'pdf') {
          const buf     = readFileSync(resolvedFilePath)
          const pdfData = await pdfParse(buf)
          attachmentText = pdfData.text
          sourceUsed     = 'pdf'
          console.log(`[Extract Pricing] PDF extracted length=${attachmentText.length}`)
          console.log(`[Extract Pricing] PDF preview: ${attachmentText.slice(0, 500)}`)

        } else if (['xlsx', 'xls'].includes(ext)) {
          // Use readFile (reads directly from disk — more reliable for binary XLSX)
          const wb = (XLSX.default ?? XLSX).readFile(resolvedFilePath)

          // Try 'Summary' sheet first (Schwan's format), fall back to first sheet
          const sheetName = wb.SheetNames.includes('Summary') ? 'Summary' : wb.SheetNames[0]
          const sheet     = wb.Sheets[sheetName]
          const rows      = XLSX.utils.sheet_to_json(sheet, { header: 1, defval: null, raw: true })

          // Detect Schwan's structure:
          //   Col J (index 9)  = numeric bid item # (20, 21, 22 …)
          //   Col R (index 17) = delivered case price
          // Use truthy checks so 0-value cells and empty strings are excluded.
          const dataRows = rows.filter(row =>
            row[9] && !isNaN(Number(row[9])) && row[17]
          )

          console.log(`[Extract Pricing] XLSX "${sheetName}" — ${rows.length} total rows, ${dataRows.length} Schwan's data rows`)
          if (dataRows.length > 0) {
            console.log(`[Extract Pricing] Sample row[0]: J=${dataRows[0][9]}, M=${dataRows[0][12]}, P=${dataRows[0][15]}, Q=${dataRows[0][16]}, R=${dataRows[0][17]}`)
          }

          if (dataRows.length > 0) {
            // ── Schwan's structured XLSX ──────────────────────
            schwansDataRows = dataRows
            const firstRow  = dataRows[0]
            contractType    = String(firstRow?.[3]  || 'Billback-Case Price')
            validFrom       = String(firstRow?.[5]  || '')
            validTo         = String(firstRow?.[6]  || '')
            analystName     = String(firstRow?.[7]  || '')
            analystPhone    = String(firstRow?.[8]  || '')

            // Build clean item-only text — one labelled line per item.
            // Stored in `pricingText` so the prompt can inject it WITHOUT
            // the metadata header (which was the previous source of AI confusion).
            pricingText = dataRows.map(row =>
              `Item ${row[9]}: ${row[12]} | ` +
              `Sysco Code: ${row[10]} | ` +
              `FOB: $${row[15]}/cs | ` +
              `Freight: $${row[16]}/cs | ` +
              `Delivered: $${row[17]}/cs | ` +
              `Qty: ${row[14]} cases`
            ).join('\n')

            // `attachmentText` keeps the full content for the generic fallback path
            attachmentText = pricingText

            // ── Diagnostic ──
            console.log('[Extract Pricing] pricingText preview:', pricingText.substring(0, 500))
            console.log('[Extract Pricing] pricingText rows:', pricingText.split('\n').length)

            sourceUsed = 'xlsx'

          } else {
            // ── Generic XLSX fallback ─────────────────────────
            attachmentText = wb.SheetNames.map(name => {
              const sh   = wb.Sheets[name]
              const rws  = XLSX.utils.sheet_to_json(sh, { header: 1, defval: '', raw: false })
              const text = rws.filter(r => r.some(c => String(c).trim())).map(r => r.join('\t')).join('\n')
              return `--- Sheet: ${name} ---\n${text}`
            }).join('\n\n')
            sourceUsed = 'xlsx'
          }

        } else if (ext === 'csv') {
          attachmentText = readFileSync(resolvedFilePath, 'utf8')
          sourceUsed = 'csv'
        }
      } catch (parseErr) {
        console.error('[Extract Pricing] File parsing failed:', {
          filename: resolvedFileName, path: resolvedFilePath, error: parseErr.message,
        })
      }
    }

    // Fall back to email body if nothing was parsed from the file
    if (!attachmentText.trim() && email.body) {
      sourceUsed = 'email'
      console.log(`[Extract Pricing] No file parsed — using email body (${email.body.length} chars)`)
    } else if (!attachmentText.trim() && !email.body) {
      return res.status(422).json({ error: 'No document content found — no attachment on disk and email body is empty.' })
    }

    // ── Build AI prompt ───────────────────────────────────
    const isSchawns = schwansDataRows && schwansDataRows.length > 0

    const userPrompt = isSchawns
      ? `You are a pricing extraction assistant. Extract all product pricing from this supplier XLSX data.

The data is from Schwan's Food Service for bid ${bidId} — ${bid.customer || 'Unknown Customer'}.
Each line follows this format:
Item [number]: [description] | Sysco Code: [code] | FOB: $[price]/cs | Freight: $[amount]/cs | Delivered: $[price]/cs | Qty: [number] cases

CONTRACT TYPE: ${contractType}
VALID: ${validFrom} — ${validTo}
ANALYST: ${analystName} | ${analystPhone}

PRICING DATA:
${pricingText}

Extract ALL ${schwansDataRows.length} items listed above. For each item return:
- description: product description
- bidItemNo: the item number (string)
- syscoProductCode: Sysco code (string)
- fobPrice: FOB price as number
- freightAmount: freight as number
- unitPrice: Delivered price as number (PRIMARY PRICE)
- quantity: quantity as number
- notes: empty string

Return ONLY a JSON object, no markdown, no explanation:
{
  "items": [
    {
      "description": "string",
      "bidItemNo": "string",
      "syscoProductCode": "string",
      "fobPrice": number,
      "freightAmount": number,
      "unitPrice": number,
      "quantity": number,
      "notes": ""
    }
  ],
  "contractType": "${contractType}",
  "validFrom": "${validFrom}",
  "validTo": "${validTo}",
  "analystName": "${analystName}",
  "analystPhone": "${analystPhone}",
  "summary": "${schwansDataRows.length} items extracted from Schwan's XLSX",
  "sourceUsed": "xlsx"
}`
      : `You are a pricing extraction assistant. Extract all product pricing from the following supplier document.

SUPPLIER: ${email.supplierName || 'Unknown Supplier'}
BID: ${bidId} — ${bid.customer || 'Unknown Customer'}

BID LINE ITEMS (for matching — use these to identify which bid item each extracted price belongs to):
${lineItems.map(li => `  Item ${li.bidItem}: ${li.description}${li.category ? ` [${li.category}]` : ''}${li.childNutrition ? ' [CN]' : ''}${li.buyAmerican ? ' [BA]' : ''}${li.pfsRequired ? ' [PFS]' : ''}`).join('\n')}

DOCUMENT CONTENT (${sourceUsed.toUpperCase()}${sourceFileName ? ` — "${sourceFileName}"` : ''}):
${attachmentText.slice(0, 55000)}

${email.body ? `EMAIL BODY (supplementary):\n${email.body}` : ''}

EXTRACTION RULES:
- ONLY extract items where a dollar price is EXPLICITLY stated
- Do NOT infer or guess prices not in the source text
- If no prices found, return empty items []
- For each extracted item, match it to one of the BID LINE ITEMS above if possible

CONFIDENCE SCORING (for each item, score 0–100 how well it matches a bid line item):
- Exact product type match (e.g. "drumstick" = "drumstick"): +40
- Category match (protein / dairy / grain / produce): +20
- Cooking method match (fully cooked, breaded, raw): +15
- Size or weight match (4.0oz, 1.5oz, 3lb): +15
- Certification match (CN, WG, Halal, Buy American): +10
Map score to label: 80–100 → "high", 50–79 → "medium", 20–49 → "low", 0–19 → "none"
confidenceReasons: short array of strings explaining what matched or did not.
IMPORTANT: confidenceScore must be between 0 and 100 — never exceed 100.

MATCHING RULE — REQUIRED: For any item with confidenceScore >= 50, you MUST provide a matchedBidItemNo from the BID LINE ITEMS list above. Do NOT leave matchedBidItemNo null if you have a medium or high confidence match.
- Chicken Breast → match to any bid item with "chicken breast" in description
- Chicken Drumstick → match to protein/poultry bid items
- Chicken Tender → match to protein/poultry bid items
- Chicken Wing → match to protein/poultry bid items
- Breadstick / Churro / Donut / Muffin → match to bakery/grain bid items
Return the 4-digit bidItem number (e.g. "0001") of the best matching bid line item, or null only if no category match exists at all.

Return ONLY a JSON object, no markdown, no explanation:
{
  "items": [
    {
      "description": "string",
      "supplierItemNo": "string or null",
      "commercialPrice": number or null,
      "ptvValue": number or null,
      "netPrice": number or null,
      "quantity": number or null,
      "matchedBidItemNo": "string or null",
      "matchedBidDescription": "string or null",
      "confidence": "high" | "medium" | "low" | "none",
      "confidenceScore": number,
      "confidenceReasons": ["reason 1", "reason 2"],
      "notes": "string"
    }
  ],
  "summary": "1-2 sentence summary",
  "sourceUsed": "${sourceUsed}"
}`

    // ── Call Anthropic ────────────────────────────────────
    const client   = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })
    const response = await client.messages.create({
      model:      process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-5',
      system:     'You are a pricing extraction assistant. Extract ONLY items and prices EXPLICITLY present in the document. Do NOT infer or fabricate. Return ONLY a valid JSON object. No markdown fences, no explanation, no preamble. Start your response with { and end with }.',
      messages:   [{ role: 'user', content: userPrompt }],
      max_tokens: 4096,
    })

    // ── Diagnostic: log raw AI response ──────────────────
    const rawAI = response.content[0]?.text || ''
    console.log('[Extract Pricing] AI raw response:', JSON.stringify(rawAI).slice(0, 400))

    // ── Parse — strip markdown fences, then use extractJSON ──
    const cleaned = rawAI
      .replace(/^```json\s*/i, '')
      .replace(/^```\s*/i, '')
      .replace(/\s*```$/i, '')
      .trim()

    const result = extractJSON(cleaned)

    if (!Array.isArray(result?.items)) {
      return res.status(422).json({ error: 'AI returned unexpected format — could not parse pricing data' })
    }

    // ── Match extracted items to bid line items ───────────
    // For Schwan's: exact match on bid item number (100% reliable).
    // For other sources: keyword overlap on description (fuzzy).
    // ── Confidence helpers ────────────────────────────────
    const scoreToLabel = (s) =>
      s >= 80 ? 'high' : s >= 50 ? 'medium' : s >= 20 ? 'low' : 'none'

    // Backend computes its own keyword-based confidence so we always have a value
    // even when the AI omits confidence fields (Schwan's path, edge cases).
    const backendConfidence = (item, matchedLi, fuzzyScore) => {
      const reasons = []
      let score = 0

      if (!matchedLi) {
        reasons.push('No bid line item matched')
        return { score, label: 'none', reasons }
      }

      const descA = (item.description || '').toLowerCase()
      const descB = (matchedLi.description || '').toLowerCase()

      // +40 product-type: dominant noun overlap (≥1 significant word matches)
      const typeWords = descA.split(/\s+/).filter(w => w.length > 4)
      const typeHits  = typeWords.filter(w => descB.includes(w))
      if (typeHits.length > 0) {
        score += 40
        reasons.push(`Product type matched: "${typeHits.slice(0,2).join(', ')}"`)
      } else {
        reasons.push('Product type: no keyword overlap')
      }

      // +20 category
      const cat = (matchedLi.category || '').toLowerCase()
      const catWords = { protein: ['chicken','beef','pork','meat','protein','turkey'],
                         dairy:   ['milk','cheese','dairy','butter'],
                         grain:   ['bread','muffin','grain','cereal','pretzel','donut'],
                         produce: ['fruit','vegetable','apple','peach','pear','corn'] }
      for (const [c, kws] of Object.entries(catWords)) {
        if (cat.includes(c) && kws.some(kw => descA.includes(kw))) {
          score += 20; reasons.push(`Category match: ${c}`); break
        }
      }

      // +15 cooking method
      const methods = ['fully cooked','breaded','raw','frozen','grilled','oven roasted','baked']
      const mA = methods.find(m => descA.includes(m))
      const mB = methods.find(m => descB.includes(m))
      if (mA && mB && mA === mB) { score += 15; reasons.push(`Cooking method: ${mA}`) }

      // +15 size/weight (e.g. "4.0oz", "3lb")
      const sizeRe = /\b(\d+\.?\d*\s*(oz|lb|g|kg|cs|ct))\b/gi
      const sizesA = [...descA.matchAll(sizeRe)].map(m => m[1])
      const sizesB = [...descB.matchAll(sizeRe)].map(m => m[1])
      const sizeMatch = sizesA.some(s => sizesB.includes(s))
      if (sizeMatch) { score += 15; reasons.push(`Size match: ${sizesA[0]}`) }

      // +10 certification
      const certs = []
      if (matchedLi.childNutrition && (descA.includes('cn') || descA.includes('child nutrition'))) {
        score += 5; certs.push('CN')
      }
      if (matchedLi.buyAmerican && descA.includes('buy american')) {
        score += 5; certs.push('Buy American')
      }
      if (certs.length > 0) reasons.push(`Certifications matched: ${certs.join(', ')}`)

      // Blend with fuzzy word-overlap score (weight 30%)
      const blended = Math.round(score * 0.7 + (fuzzyScore * 100) * 0.3)
      const capped  = Math.min(100, blended)

      return { score: capped, label: scoreToLabel(capped), reasons }
    }

    const enriched = result.items.map(item => {
      // ── 1. Exact bid item number match (Schwan's / structured XLSX) ──
      if (item.bidItemNo) {
        const padded = String(item.bidItemNo).padStart(4, '0')
        const li = lineItems.find(l =>
          l.bidItem === padded ||
          l.bidItem.replace(/^0+/, '') === String(item.bidItemNo)
        )
        if (li) {
          // AI may have returned confidence; if not, exact match = high
          const aiScore   = Math.min(100, item.confidenceScore  ?? 95)
          const aiLabel   = item.confidence       ?? 'high'
          const aiReasons = item.confidenceReasons ?? ['Exact bid item number match']
          return {
            ...item,
            lineItemId:         li.id,
            matchedDescription: li.description,
            matchScore:         100,
            confidenceScore:    aiScore,
            confidence:         aiLabel,
            confidenceReasons:  aiReasons,
          }
        }
      }

      // ── 2. Try AI-suggested matchedBidItemNo ─────────────────────────
      let bestLi = null
      if (item.matchedBidItemNo) {
        const padded = String(item.matchedBidItemNo).padStart(4, '0')
        bestLi = lineItems.find(l =>
          l.bidItem === padded ||
          l.bidItem.replace(/^0+/, '') === String(item.matchedBidItemNo)
        ) || null
      }

      // ── 3. Fuzzy description fallback if AI didn't give a useful match ──
      let fuzzyScore = 0
      if (!bestLi) {
        const descWords = (item.description || '').toLowerCase().split(/\s+/).filter(w => w.length > 3)
        for (const li of lineItems) {
          const hits  = descWords.filter(w => (li.description || '').toLowerCase().includes(w)).length
          const score = descWords.length > 0 ? hits / descWords.length : 0
          if (score > fuzzyScore && score >= 0.3) { fuzzyScore = score; bestLi = li }
        }
      }

      // ── 4. Compute final confidence ───────────────────────────────────
      const bc = backendConfidence(item, bestLi, fuzzyScore)
      // Prefer AI confidence score when it looks reasonable (AI saw the doc content); cap at 100
      const finalScore   = Math.min(100, item.confidenceScore != null ? item.confidenceScore : bc.score)
      const finalLabel   = item.confidence       != null ? item.confidence       : bc.label
      const finalReasons = (item.confidenceReasons && item.confidenceReasons.length > 0)
        ? item.confidenceReasons
        : bc.reasons

      return {
        ...item,
        lineItemId:         bestLi?.id          || null,
        matchedDescription: bestLi?.description || null,
        matchScore:         Math.round(fuzzyScore * 100),
        confidenceScore:    finalScore,
        confidence:         finalLabel,
        confidenceReasons:  finalReasons,
      }
    })

    const matchedCount = enriched.filter(i => i.lineItemId).length
    console.log(`[Extract Pricing] ${bidId}/${emailId}: source="${sourceUsed}" items=${enriched.length} matched=${matchedCount} schawns=${isSchawns}`)

    res.json({
      items:         enriched,
      summary:       result.summary      || '',
      contractType:  result.contractType || contractType || '',
      validFrom:     result.validFrom    || validFrom    || '',
      validTo:       result.validTo      || validTo      || '',
      analystName:   result.analystName  || analystName  || '',
      analystPhone:  result.analystPhone || analystPhone || '',
      sourceUsed,
      sourceFileName,
      isSchawnsFormat: isSchawns,
      supplierName:  email.supplierName  || '',
      supplierEmail: email.supplierEmail || '',
      emailId,
      bidId,
    })
  } catch (err) {
    console.error('[Extract Pricing] Unhandled error:', err.message)
    res.status(500).json({ error: err.message })
  }
})

// ── POST /api/bids/:bidId/portal-reply ───────────────────
// COE sends a reply into a portal thread (internal route)
router.post('/:bidId/portal-reply', async (req, res) => {
  try {
    const { bidId }                            = req.params
    const { threadId, message, supplierEmail } = req.body

    if (!threadId || !message?.trim() || !supplierEmail) {
      return res.status(400).json({ error: 'threadId, message and supplierEmail are required' })
    }

    const bid = loadBids().find(b => b.id === bidId)
    if (!bid) return res.status(404).json({ error: 'Bid not found' })

    // ── Load + update submissions.json ────────────────────
    const SUBMISSIONS_PATH = join(__dirname, '../data/submissions.json')
    let submissions = {}
    try { submissions = JSON.parse(readFileSync(SUBMISSIONS_PATH, 'utf8')) } catch {}

    // Search ALL bids for the threadId (not just the URL bidId) — threadId is globally unique
    let foundBidKey = null
    let subIdx = -1
    for (const [bKey, subs] of Object.entries(submissions)) {
      const idx = subs.findIndex(s => s.threadId === threadId)
      if (idx !== -1) { foundBidKey = bKey; subIdx = idx; break }
    }
    if (foundBidKey === null) {
      console.warn(`[PortalReply] Thread not found: ${threadId} (searched all bids)`)
      return res.status(404).json({ error: `Thread not found: ${threadId}` })
    }
    const list = submissions[foundBidKey]

    const sub      = list[subIdx]
    const now      = new Date().toISOString()
    const msgId    = `MSG-${Date.now()}`

    sub.messages = sub.messages || []
    sub.messages.push({
      id:              msgId,
      direction:       'outbound',
      from:            'COE.BIDS@sysco.com',
      fromName:        'Sysco Bid COE',
      body:            message.trim(),
      attachments:     [],
      timestamp:       now,
      readBySupplier:  false,
    })
    submissions[foundBidKey][subIdx] = sub
    writeFileSync(SUBMISSIONS_PATH, JSON.stringify(submissions, null, 2))
    console.log(`[PortalReply] Saved to thread ${threadId} (bid ${foundBidKey}) — now ${sub.messages.length} messages`)

    // ── Mirror to emailThreads.json ───────────────────────
    const emails = loadEmails()
    emails.push({
      id:            `E-${Date.now()}`,
      bidId,
      direction:     'outbound',
      supplierId:    null,
      supplierName:  sub.supplierName,
      supplierEmail: sub.supplierEmail,
      from:          'COE.BIDS@sysco.com',
      to:            sub.supplierEmail,
      bcc:           [],
      subject:       `Re: ${sub.supplierName} — ${bid.customer} (Portal)`,
      body:          message.trim(),
      date:          now,
      attachments:   [],
      tags:          ['Reply', 'portal-message'],
      read:          true,
      analysisResult: null,
      portalSubmission: true,
      threadId,
      confirmationId: sub.confirmationId,
    })
    saveEmails(emails)

    // ── Send Nodemailer email to supplier ─────────────────
    const PORTAL_BASE = process.env.PORTAL_BASE_URL || 'http://rfp-aiq.supplier.exlservice.com:5173'
    const threadUrl   = `${PORTAL_BASE}/submit/${bidId}/thread/${threadId}`
    const emailBody   = [
      `Hi ${sub.contactName || sub.supplierName},`,
      '',
      'Sysco Bid COE has replied to your pricing submission.',
      '',
      message.trim(),
      '',
      '─────────────────────────────',
      `View full conversation: ${threadUrl}`,
      '',
      'Sysco Bid COE · COE.BIDS@sysco.com',
    ].join('\n')

    try {
      const { sendEmail } = await import('../services/emailService.js')
      await sendEmail({
        to:      sub.supplierEmail,
        bcc:     [],
        subject: `Re: Your pricing submission for ${bid.customer}`,
        body:    emailBody,
        attachmentNames: [],
        attachmentPaths: [],
      })
      console.log(`[PortalReply] Sent email to ${sub.supplierEmail} for ${bidId}/${threadId}`)
    } catch (mailErr) {
      // Non-fatal — message is saved even if email fails
      console.warn(`[PortalReply] Email send failed (message still saved):`, mailErr.message)
    }

    res.json({ success: true, messageId: msgId })
  } catch (err) {
    console.error('[PortalReply] error:', err)
    res.status(500).json({ error: err.message })
  }
})

// ── PATCH /api/bids/:bidId/auto-reminder ─────────────────
// Save auto-reminder config { enabled, daysAfterSolicitation }
router.patch('/:bidId/auto-reminder', (req, res) => {
  try {
    const { bidId } = req.params
    const { enabled, daysAfterSolicitation, lastReminderSent } = req.body
    const bids  = loadBids()
    const idx   = bids.findIndex(b => b.id === bidId)
    if (idx === -1) return res.status(404).json({ error: 'Bid not found' })
    bids[idx].autoReminder = {
      enabled:               Boolean(enabled),
      daysAfterSolicitation: Number(daysAfterSolicitation) || 3,
      lastReminderSent:      lastReminderSent ?? bids[idx].autoReminder?.lastReminderSent ?? null,
    }
    saveBids(bids)
    console.log(`[AutoReminder] ${bidId}: ${enabled ? 'enabled' : 'disabled'} (${daysAfterSolicitation}d)`)
    res.json({ success: true, autoReminder: bids[idx].autoReminder })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})

// PORTAL-TEMPLATE-START
// GET /api/portal-templates
router.get('/portal-templates', (req, res) => {
  try {
    const templates = JSON.parse(readFileSync(PORTAL_TEMPLATES_PATH, 'utf8'))
    res.json(Array.isArray(templates) ? templates : [])
  } catch (err) {
    res.json([])
  }
})

// PATCH /api/bids/:bidId/portal-config
router.patch('/:bidId/portal-config', (req, res) => {
  try {
    const { bidId } = req.params
    const { templateId, customFields } = req.body
    const bids = loadBids()
    const idx = bids.findIndex(b => b.id === bidId)
    if (idx === -1) return res.status(404).json({ error: 'Bid not found' })
    bids[idx].portalConfig = {
      templateId,
      appliedAt: new Date().toISOString(),
      customFields: customFields || [],
    }
    saveBids(bids)
    res.json({ success: true, portalConfig: bids[idx].portalConfig })
  } catch (err) {
    res.status(500).json({ error: err.message })
  }
})
// PORTAL-TEMPLATE-END

export default router
