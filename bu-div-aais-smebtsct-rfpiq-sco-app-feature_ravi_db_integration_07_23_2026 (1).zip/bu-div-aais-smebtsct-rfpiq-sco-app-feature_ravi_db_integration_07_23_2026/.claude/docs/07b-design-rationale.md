# Design Decision Rationale — Why We Changed These

Full backstory for the rules captured in `07-known-fixes.md` "Do Not Revert" section. Read when you need to understand *why* a rule exists.

---

## `analysisResult` must NOT affect supplier status

**What was wrong:** `save_email_analysis` (PATCH `.../analysis`) used to auto-set supplier status to `"Issues Found"` when the AI found problems in the pricing file (missing items, format issues, expired pricing). This made the "Issues Found" pill appear on the left panel whenever a COE analyst ran AI analysis.

**Why it was reverted:** "Issues Found" has a specific meaning in this system — it means **email delivery failure (bounce)**. Conflating it with "AI found content problems in the attached file" caused confusion: a supplier who successfully responded but had a formatting issue in their pricing file would appear in the same visual state as a supplier whose emails all bounced. The "Responded" count dropped to 0 because every analysed email triggered Issues Found.

**Current rule:** `analysisResult` on an email record is display-only metadata. It NEVER writes to `solicitedSuppliers[].status`. Only the inbox poller bounce fan-out sets `"Issues Found"`. Do not add any code that sets supplier status from analysis results.

---

## MS Graph threading — do NOT use SMTP headers

**What was wrong:** An earlier version generated custom SMTP `Message-ID` headers (`<bid-sup-random@sysco.bid>`) and attempted to send `In-Reply-To` / `References` headers for thread linking.

**Why it failed:** MS Graph API rejects any non-`x-` prefixed custom headers with HTTP 400. Standard RFC 2822 threading headers (`In-Reply-To`, `References`) are silently dropped or outright rejected.

**Current approach:** Threading uses the Graph `createReply` method on a prior `graphInternetMessageId`. The `_get_last_internet_message_id()` helper finds the most recent outbound email to a supplier and returns its Graph message ID. `_generate_smtp_message_id()` was deleted entirely — do not bring it back.

---

## BCC solicitation threading fallback

**Why it exists:** A mass BCC solicitation to 20 suppliers is stored as ONE email record in `emailThreads.json` with `supplierId: null` (because there is no single supplier). When a supplier replies, `_get_last_internet_message_id()` must find that original outbound record to thread the reply. Searching by `supplierId` alone fails. The fallback checks if `supplier_email` appears in the `bcc[]` list of any outbound record. Do not remove this fallback — without it, replies to BCC solicitations never thread correctly in Outlook.

---

## Pricing extraction — why schema fields were removed

**What was wrong:** The Python port of `_extract_generic_pricing` added `deliveredPrice`, `fobPrice`, `allowance`, `devType` to the LLM output schema. The Node.js version that worked never had these fields.

**Why they caused hallucination:** When an LLM sees a field name in the schema with `num|null` type, it will populate it with a plausible number even when the column doesn't exist in the document. A supplier pricing file with only a "Net Price" column would get fabricated `fobPrice` and `allowance` values.

**Current rule:** Only include fields in the schema that exist in real supplier documents. If a field is removed from the schema, the LLM stops generating it. Do not re-add `deliveredPrice`, `fobPrice`, `allowance`, or `devType` to the `_extract_generic_pricing` schema.

---

## Pricing extraction — why null-price items must be included

**What was wrong:** `_extract_generic_pricing` prompt said "ONLY extract items where a dollar price is EXPLICITLY stated."

**Why it was wrong:** Suppliers sometimes submit partial pricing (e.g. Schwan's file for bid B2600042 had items #23 and #26 with no price — pending commodity pricing). These rows were silently dropped. The COE user saw 8 rows when there were 10 items in the file, with no indication that 2 were missing.

**Current rule:** ALL line items from a supplier document must appear in output. Null-price rows are included with `netPrice: null` and a `notes` explanation.

---

## Pricing extraction — why column rules must be semantic, not name-based

**What was wrong:** An early version of the extraction rules listed specific column names ("Sysco SI", "Delivered Case pr", etc.) to tell the LLM which column maps to which field.

**Why it was wrong:** Every supplier uses different column names. Schwan's uses "Delivered Case pr"; another supplier might use "Net/Case" or "Price per CS". Hardcoding names makes the extractor fragile for any supplier not explicitly anticipated. It also embeds supplier-specific knowledge in a general-purpose function.

**Current rule:** Extraction rules describe the *semantic meaning* of each field (e.g. "the final all-in price per case after freight"). The LLM infers which column maps to which field from context. Never list specific supplier column names in the extraction prompt.

---

## RFP ID — why filename hash was replaced with UUID

**What was wrong:** Bid IDs were derived from `SHA-256(filename)[:8]`. Uploading the same file twice produced the same ID, blocked by a 409. This seemed like dedup protection but was fragile: renaming the file bypassed it entirely, and the hash was meaningless as an identifier.

**Why UUID is better:** `uuid4().hex[:8]` is random and non-deterministic. Two uploads of the same file always get different IDs. The pre-parse `GET /check-hash` endpoint was removed — it served no purpose once IDs are not hash-derived. The frontend removed the "RFP ID will be RFP-{hash}" chip and duplicate-warning banner.
