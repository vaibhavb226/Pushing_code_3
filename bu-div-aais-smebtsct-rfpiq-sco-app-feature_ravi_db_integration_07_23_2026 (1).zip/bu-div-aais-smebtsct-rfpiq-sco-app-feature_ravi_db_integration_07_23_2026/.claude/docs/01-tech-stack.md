# Tech Stack

## Frontend
- **Framework:** React 18 + Tailwind CSS + Vite — runs on http://localhost:5173
- **Entry:** `frontend/src/App.jsx`
- **Brand:** EXL Orange `#E05A2B` (accents, active tab underline) | EXL Navy `#1F3864` (headers, icons)
- **Dark mode:** Class-based Tailwind. Toggle in top navbar. Persisted in `localStorage` as `'theme'`. `ThemeContext` at `frontend/src/context/ThemeContext.jsx`.

## Python Backend (ACTIVE — use this)
- **Framework:** FastAPI + Uvicorn + pydantic-settings — runs on http://localhost:3001
- **Entry:** `backend_py/main.py`
- **Config:** `backend_py/config.py` (pydantic-settings, all env vars typed + validated at startup)
- **Swagger:** http://localhost:3001/api/docs
- **Local start:** `cd backend_py && .venv/Scripts/python.exe -m uvicorn main:app --reload --port 3001`

## Node.js Backend (DO NOT MODIFY)
- `backend/server.js` — Node.js + Express, Gmail SMTP + IMAP, runs on same port 3001
- ⚠️ **NEVER touch `backend/`** unless explicitly instructed — Python backend is the active one

## AI / LLM
| Env var | Default | Alternatives |
|---------|---------|--------------|
| `LLM_PROVIDER` | `vertexai` (Gemini 2.5 Flash, IAM auth) | `anthropic` (claude-sonnet-4-20250514) |

- VertexAI needs: `GCP_PROJECT`, `GCP_LOCATION`, `VERTEX_MODEL`; service account needs `aiplatform.endpoints.predict`
- Anthropic: `ANTHROPIC_API_KEY` loaded from GCP Secret Manager in Cloud Run

## Database / Email / GCS / Secrets

> Env vars, path patterns, permissions, and setup details: `.claude/docs/01b-config.md`
