# Email System & Supplier Portal

## Email System — Python Backend (MS Graph)

All sending/receiving goes through `MsGraphEmailService` (`backend_py/services/email/msgraph_provider.py`).

**Outbound — `svc.send_email(EmailMessage(...))`:**
- All email types (solicitation, award, reminder, portal-reply, re-solicit) use the same path
- CC: reads `additionalEmails` from `solicitedSuppliers` entry
- Attachments: `_build_attachments()` (async) handles both local paths and `gs://` URIs
  - Local: `Path(path).read_bytes()`
  - GCS: `blob.download_as_bytes()` via `run_in_executor` (blocking SDK call)
- MS Graph threading: uses `createReply` method when a prior `internetMessageId` exists; falls back to `_draft_and_send`. SentItems is searched as a fallback for the prior message.
- MS Graph **only accepts `x-` prefixed custom headers** — standard RFC 2822 threading headers rejected with HTTP 400

**Inbound poller** (`backend_py/services/email_poller.py`):
- 15-second poll loop; single-flighted (lock prevents overlap with `poll-now`)
- **High-water mark** in `data/pollState.json` — fetches `receivedDateTime ≥ lastPolledAt − 10min`
- Cold start (no pollState.json): `POLL_LOOKBACK_HOURS` (default 72), clamped by `MAX_LOOKBACK_DAYS` (30)
- **3-tier matching:**
  1. Bid ID pattern in subject (`B2600042`, `BID-123`, `RFP-abc12345`) — if matched but bid deleted → `unmatchedEmails` (no fallthrough to tier 3)
  2. Cleaned subject matches stored solicitation subject
  3. All significant words (4+ chars) from customer name in subject
- Bounce detection: parses MAILER-DAEMON headers; fan-out writes one record per affected supplier (not one NDR for all)
- Per-supplier bounce body: excerpted to relevant paragraph via `_extract_recipient_block()` (not full NDR)

**Status taxonomy:**
| Status | Meaning | Set by |
|--------|---------|--------|
| Awaiting | Solicited, no reply | Default after solicitation |
| Responded | Reply received | Poller `_update_supplier_responded` |
| Issues Found | **Email delivery failure / bounce** | Poller bounce fan-out |
| Follow-up Sent | Re-solicitation sent | COE action |
| Awarded | Supplier awarded | Email Repo mark-awarded |

⚠️ "Issues Found" = bounce ONLY. NOT "pricing file had problems" — `analysisResult` on the email record handles content problems separately and must NEVER write to supplier status.

**Why this matters:** An earlier version of `save_email_analysis` auto-set status to "Issues Found" when AI detected pricing content problems (missing items, format issues). This collapsed all analysed suppliers into the Issues state and made the "Responded" count drop to 0. The status taxonomy must remain delivery-event driven only — content analysis is advisory metadata, not a state transition.

## Inbound Attachment Serving

`GET /api/files/{bid_id}/attachments/{filename}` (`routers/files.py`):
1. Try local `uploads/{safe_filename}` — if exists, serve directly
2. Try GCS at `inbound/{safe_filename}` — download and stream
3. 404 if neither

## Supplier List Tab (`SuppliersTab.jsx`)

- Status badges are **read-only** — status driven by email events only
- **Channel column:** Email (grey) | Portal (emerald) | Both (blue) — `threadId` alone ≠ Portal
- **Export CSV:** "Export CSV" button exports solicited suppliers with status, channel, last activity
- **Configure Portal Form banner:** blue (unconfigured) → green (configured) with template name
- Portal template panel: slide-in from right, 4 predefined templates
- **Add Supplier:** typeahead search against suppliers.json → add new supplier inline form

## Email Repo Tab (`EmailRepoTab.jsx`)

- Two-panel: left (supplier list with filter pills) | right (conversation thread)
- **Filter pills:** All | Responded | Issues | Bounced | Awaiting | Awarded | Under Consideration
  - "Bounced" (red) shows `hasBounce === true` suppliers; "Issues" excludes pure-bounce suppliers — they're separated so a bounce is not confused with a content/analysis issue
- Filter counts = supplier conversation counts (not raw email counts)
- **`by-supplier` response:** groups emailThreads.json by supplierId; includes `isBroker` per supplier (resolved from `suppliers.json` registry)
- **Export CSV:** "Export CSV" button in header — exports current filtered supplier list with email counts
- **Live refresh:** auto-fetches every 15s + on window focus; pauses during modal flows; selection guard prevents tab from resetting viewed supplier
- **Badge sync:** when supplier count increases, calls `onResponseLogged()` → updates tab badge

**Bounce display:** `isBounce: true` → red "Delivery Failed" badge, red banner, "Update Email Address" inline form → "Update & Re-solicit"

**Award workflow:** Mark Awarded → 2-step modal (Confirm → Edit/Send). On cancel: reverts status.

**Portal supplier controls:** "Reply via Portal" button (orange) only — no direct email reply for portal suppliers.

## Key File Locations — Email & Bounce
- Email Repo tab component: `frontend/src/components/BidDetail/EmailRepoTab.jsx`
  - `SummaryBar` (filter pills), `SupplierRow` (left panel row), `SupplierThread` (right panel)
- `get_emails_by_supplier()` aggregation: `backend_py/routers/bids.py` — groups emailThreads by supplierId, computes `hasBounce`
- Bounce fields on email records: `isBounce`, `bounceCode`, `bounceReason`, `originalRecipient`
- Bounce fields on solicitedSuppliers entries: `hasIssues: true`, `issueType: "bounce"` (set by `_bounce_updater`)
- Email poller bounce detection: `backend_py/services/email_poller.py` — `_detect_bounce()`, `_parse_bounce()`

## Communication Model — Portal First

- **Portal** = primary submission + two-way messaging channel
- **Email** = outbound notifications only (all include portal URL)
- Solicitation subject: `Pricing Request: [customer] — [bidId] | Due [date]`

## Supplier Portal (`frontend/src/pages/SupplierPortal.jsx`)

**Three views in one component:**
- **SubmissionForm** (`/submit/:bidId`): bid info + supplier details + line items table (Unit/Case price + No Bid) + file upload
- **ThreadView** (`/submit/:bidId/thread/:threadId`): email-gated conversation — 401 if email absent, 403 if wrong
- **SubmissionSuccess**: inline after submit — shows confirmationId + "View & Continue Conversation" button

**Thread timeline:** SubmissionEventCard (orange border, expandable pricing) + MessageCard (orange avatar = supplier, navy = COE)

**15s polling** for new COE messages; "New message" banner when scrolled up.

**submissions.json record fields:** `confirmationId, threadId, submittedAt, supplierName, supplierEmail, phone, contactName, lineItems, pricingFile, pricedCount, noBidCount, dlCount, allwCount, otherPricedCount, messages[]`

**Auto-reminder scheduler:** APScheduler fires hourly. Targets `Awaiting` suppliers with no portal submission and no email reply. 3-day minimum gap per bid. Config: `bid.autoReminder = { enabled, daysAfterSolicitation, lastReminderSent }`.
