# Python Backend — Testing, Code Quality & Deployment

Reference for `05-python-backend.md`. Read when running tests, linting, or deploying.

## Testing

```bash
cd backend_py
pytest                                       # all tests
pytest tests/routers/                        # route integration
pytest --cov=. --cov-report=term-missing     # with coverage
```

- `asyncio_mode = "auto"` in `pyproject.toml`
- Each test gets fresh `tmp_data_dir` (FastAPI lifespan bypassed — no poller)

## Code Quality

```bash
ruff check . --fix    # lint + auto-fix
ruff format .         # format
mypy .                # strict type check
```

## Production Deployment (VM + PM2)

**Deploy script:** `deploy.sh` at repo root
**App location:** `/opt/sysco/sysco-rfp-aiq-main/`
**ENV source:** `/opt/sysco/env_file/.env` → copied to `backend_py/.env` at deploy time
**PM2 app name:** `backend`

```bash
# PM2 starts backend:
pm2 start "/opt/sysco/sysco-rfp-aiq-main/backend_py/.venv/bin/python" \
  --name "backend" \
  --cwd "/opt/sysco/sysco-rfp-aiq-main/backend_py" \
  -- -m uvicorn main:app --host 0.0.0.0 --port 3001
```

Frontend: `npm run build` → static files served by nginx

**deploy.sh steps:** check deps → stop PM2 → pull repo → copy .env → install Python deps → build frontend → set ownership → test nginx → restart nginx → start PM2 → verify

**PM2 startup:** configured for systemd so backend survives VM reboots.

**Local Windows dev:**
```bash
cd backend_py
.venv/Scripts/python.exe -m uvicorn main:app --reload --port 3001
```
