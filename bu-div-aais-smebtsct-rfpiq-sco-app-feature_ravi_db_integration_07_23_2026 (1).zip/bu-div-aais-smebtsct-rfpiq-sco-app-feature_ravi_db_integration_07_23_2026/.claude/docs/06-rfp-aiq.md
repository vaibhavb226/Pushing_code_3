# RFP AIQ — Conversational Intelligence

**Product name:** RFP AIQ (use this name everywhere — button labels, drawer header, avatar, toasts)
**Identity:** "You are RFP AIQ, the FoodCorp Bid Intelligence Assistant built by EXL Service for the FoodCorp Bid COE team."

## Entry Points
- **Primary:** Sidebar → "Chat with AIQ" orange button (bottom of nav, `MessageSquare` icon) — toggles drawer open/closed. Button turns EXL orange when active.
- **Secondary:** Document Vault → "Ask RFP AIQ" button (top-right, `BrainCircuit` icon)

## Frontend Components

| Component | Path | Purpose |
|-----------|------|---------|
| `RfpAiqDrawer` | `frontend/src/components/RfpAiq/RfpAiqDrawer.jsx` | 420px slide-in drawer, full chat UI |
| `RfpAiqMessageBubble` | `frontend/src/components/RfpAiq/RfpAiqMessageBubble.jsx` | User/assistant message rendering |

**Drawer features:**
- Navy header with BrainCircuit icon (orange) + X close
- 4 starter prompt chips (2×2 grid) — disappear after first send
- Typing indicator: animated navy 3-dot bounce
- Enter to send, Shift+Enter for newline
- Chat history resets each time drawer is opened

**Message bubbles:**
- User: right-aligned, EXL orange background, white text, `rounded-2xl rounded-tr-sm`
- RFP AIQ: left-aligned, white card `border border-gray-200 rounded-2xl rounded-tl-sm`, navy "AIQ" avatar

**Markdown rendering (`RfpAiqMessageBubble.jsx`):**
Full `renderMarkdown()` function — parses and renders:
- `# headings` (h1–h3)
- `- / 1.` bullet and numbered lists
- ` ``` ` fenced code blocks (with language label)
- `---` horizontal rules
- `**bold**`, `*italic*`
- `` `inline code` ``

**Action pills:** Lines starting with `"Suggested action:"` stripped from response body and rendered as orange-outlined pill buttons → click copies to clipboard + 2s tooltip.

## Backend — Python

**File:** `backend_py/routers/ai_chat.py`
**Endpoint:** `POST /api/ai/chat`
**Request:** `{ messages: [{ role: 'user'|'assistant', content: string }] }`
**Response:** `{ role: 'assistant', content: string }`
**Model:** Configured via `LLM_PROVIDER` (vertexai/anthropic)

**Context assembled per request (`_build_system_prompt()`):**
1. `[BIDS SUMMARY]` — all bids: status, dates, items, compliance, categories
2. `[SUPPLIER ACTIVITY]` — `solicitedSuppliers` with per-supplier status + last activity
3. `[DOCUMENT VAULT]` — vault docs + `bid.uploadedFiles`; shared/global docs; uploads dir listing
4. `[RECENT EMAIL ACTIVITY]` — last 3 emails per bid (direction, subject, 300-char snippet, tags)
5. `[DOCUMENT VAULT CONTENTS]` — text extracted (fitz/openpyxl) from first 10 uploaded files
6. `[LAKEVIEW HISTORICAL DATA]` — multi-year XLSX from `backend_py/data/Lakeview_USD_MultiYear_B2600042_2022-2026.xlsx`

**Lakeview historical file** location: `backend_py/data/` (not `uploads/` — must be in data dir so it's always available)
