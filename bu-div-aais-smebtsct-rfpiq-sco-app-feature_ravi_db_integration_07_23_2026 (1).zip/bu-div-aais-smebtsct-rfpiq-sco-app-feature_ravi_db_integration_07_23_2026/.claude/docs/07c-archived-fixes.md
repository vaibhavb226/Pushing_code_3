# Archived One-Liner Fixes

> Stable, low-risk fixes moved here to reduce main context size.
> Complex fixes with "do not revert" implications are in `07-known-fixes.md`.

| Issue | Fix |
|-------|-----|
| AI JSON parse failures | All AI routes use `extract_json()` — tries direct parse, strips markdown fences on failure |
| AI truncation on large RFPs | `max_tokens=8000` on rfpParser/analyseResponse; `max_tokens=16384` on pricing |
| AI returns trailing text | System prompt: `"CRITICAL: Start your response with { and end with }."` |
| IMAP poller race | Stop backend before bulk data edits (15s poller can overwrite manual changes) |
| MS Graph rejects SMTP headers | Only `x-` prefixed headers accepted. Standard `In-Reply-To`/`References` rejected with HTTP 400 |
| Portal thread empty after submission | `submissions.py` creates initial inbound message in `messages[]` at submit time |
| Portal channel not set to "Portal" | `_update_supplier_responded()` updates `channel` on `solicitedSuppliers` entry |
| Portal thread auth | Email gate always required: 401 if `?email=` absent, 403 if wrong |
| Portal file upload silently dropped | `File(None, alias="pricingFile")` in `submissions.py` — FastAPI uses field name for multipart |
| Portal follow-up body empty | `post_message` uses `Form(...)` fields + `File(None, alias="file")` — was wrongly `body: dict` (JSON) |
| Bounce fan-out missed suppliers | Angle-bracket regex now matches `<mailto:email>` format (Exchange NDR format) |
| Duplicate bounce records | `(uid, recipient)` pair dedup in fallback path of fan-out loop |
| UTF-8 BOM crash | `repositories/base.py` reads with `encoding="utf-8-sig"` (handles PowerShell-generated files) |
| Solicitation emails had no attachments | `EmailComposer.jsx` now reads `bid.uploadedFiles[].path` (gs:// URIs), not deprecated fields |
| `gs://` URIs stripped in send path | `create_bid_email` passes `gs://` URIs through directly; only local paths get UPLOADS_DIR resolution |
| `_build_attachments` couldn't read GCS | Changed from `def` to `async def`; added `gs://` branch with `run_in_executor` |
| Inbound attachments disk-only | `_download_attachments` now dual-writes to `inbound/{saved_name}` in GCS |
| Portal message files disk-only | `post_message` now dual-writes to `{bidId}/PortalMsg/{fname}` in GCS |
| `_parse_bounce` returned None | Return dict was accidentally indented inside `_extract_recipient_block` (dead code). Fix: moved back to end of `_parse_bounce`. |
| Pricing extraction `settings` NameError | `_extract_generic_pricing` uses `get_settings().llm_max_tokens` (not bare `settings.`) |
| Email count badge mismatch | Badge/heading uses `by-supplier` supplier count (conversations), not raw email count |
| `msg.message_id` AttributeError | `message_id` field removed from `EmailMessage` dataclass; `_draft_and_send` uses `""` |
| pgvector bind-param parse error | `:embedding::vector` → `CAST(:embedding AS vector)` — SQLAlchemy mis-parses `:name::cast` |
| RFP AI hallucinating items | Rules 8 + 9 in `BEX_SYSTEM_PROMPT`; Excel-only guard appended to user prompt when Excel provided |
| Excel structure locator discarded | Removed `and "description" in cm` guard — was silently discarding valid LLM result |
| Duplicate RFP upload | Removed hash-based dedup; bid IDs are now `RFP-{uuid4().hex[:8]}` — always unique |
| Chat AIQ cuts off mid-response | `ai_chat.py` had hardcoded `max_tokens=1024`; fixed to `get_settings().llm_max_tokens` |
| Bounced suppliers indistinguishable in Email Repo | `get_emails_by_supplier()` returns `hasBounce: bool`; "Bounced" filter pill added |
| Bounce body identical across all suppliers | CRLF regex bug fixed: `re.split(r"(?:\r?\n){2,}", body)`. Permanent fix: parse RFC 3464 DSN MIME |
| `.xls` pricing files silently return empty | `openpyxl` can't read binary XLS. Added `xlrd` fallback in `document_text._extract_excel()`. |
| `pdf_char_limit` config declared but never applied | Fixed: `_extract_pdf()` in `document_text.py` now reads `get_settings().pdf_char_limit` |
| Large Excel pricing files silently truncated | Row-chunked extraction (100 rows/chunk) via `asyncio.gather` when `len(doc_text) > 45_000` |
| Multi-file emails only process first attachment | Added `?files=` query param for parallel per-file extraction, each item tagged `sourceFile` |
| Working File sub-row prices read-only | Fixed: editable via `editingSubIdx` state + inline input in `WorkingFileRow` |
| No way to delete Working File line items | Added `DELETE /{bid_id}/line-items/{line_id}` endpoint; trash icon in frontend |
| `save()` NotImplementedError in DB mode | Replaced load-modify-save patterns with targeted `append()`, `update_one()`, `delete_where()` calls |
| Email poller effective interval was 15s + poll duration | Fixed: fixed-interval timer using `loop.time()` before/after |
| MSAL token refresh blocked the event loop | Wrapped `acquire_token_for_client()` in `loop.run_in_executor(None, lambda: ...)` |
| Working File Confidence column shows "No Response" despite extracted pricing | Fixed: reads `item.supplierPricing?.[0]?.confidence ?? item.confidence ?? null` |
| Working File fixed columns can be hidden | Fixed: lock icon for `col.fixed` columns; `enforceFixed()` applied on config load |
| Working File export drops supplier sub-rows | Fixed: `exportXlsx` changed from `.map()` to `.flatMap()` iterating `supplierPricing` |
| Poller Tier 1 regex misses `RFP-xxx` style bid IDs | Added `[Rr][Ff][Pp]-[A-Za-z0-9]{6,}` branch to `_BID_PATTERN` in `email_poller.py` |
| Poller Tier 3 sender-email lookup used wrong field name | Fixed: `sup.get("supplierEmail")` → `sup.get("email")` in `email_poller.py` |
| Portal `bids.supplier_id` always NULL | Fixed: `_find_supplier_id` call moved before submission dict construction; `supplierId` added to dict |
| `rfps.customer_id` never set | Added `GET/POST /api/customers` endpoints + `pg_customers_repo.py`; `CustomerCombobox.jsx` replaces free-text input |
| Pricing Excel files: first sheet used as header when it is a cover page | Fixed: `=== Sheet: {name} ===` separator added in `_extract_excel` so header heuristic sees boundaries |
| Award email goes to BidCOE instead of supplier | Fixed: use `supplier.supplierEmail` (from `solicitedSuppliers[].email`) not `supplier.emails?.[0]?.from` |
| readBySupplier changes never persisted to DB | `pg_submissions_repo` now diffs and bulk-UPDATEs only changed `readByBidCOE`/`readBySupplier` values |
| N+1 query explosion in `pg_submissions_repo` | Fixed: batch-fetch all line items and messages in 2 `ANY($1::text[])` queries; 3 queries total regardless of submission count |
| `get_customers_repo` crashes when DB unavailable | Fixed: added `db_host` guard that raises `HTTPException(503)` instead of `RuntimeError` |
| bounce_code stuck at "5.x.x" | `_parse_dsn_mime` guard changed from `not bounce_code.startswith("5.")` to `bounce_code == "5.x.x"` |
| Full table scan on every line-item write | Added `update_by_id`, `delete_by_id`, `delete_for_bid` to both `LineItemsRepository` and `PgLineItemsRepository` |
| Email Repo tab loaded entire suppliers table on 15s poll | Added `get_broker_flags(supplier_ids)` to `PgSuppliersRepository` — fetches only `id, broker` |
| Poller reloaded all bids on every 15s cycle | Added 30s TTL in-memory bid cache (`_get_bids_cached`) in `email_poller.py` |
| Sequential DB writes in portal submission | Wrapped in `asyncio.gather` — both inserts run concurrently |
| Sequential DB reads in portal thread poll | Wrapped in `asyncio.gather` |
| asyncpg pool held 2 idle connections per instance | Changed `min_size=2` → `min_size=1`; `max_size` configurable via `DB_POOL_MAX` (default 5) |
| SQLAlchemy pgvector pool sent health-check ping | Set `pool_pre_ping=False` (pgvector pool unused in production) |
| Customer update/delete caused full table scan | Added `update_by_id(id, updater)` and `delete_by_id(id)` to `PgCustomersRepository` |
| `GET /api/bids/{bid_id}` caused full table scan | Fixed: changed to `await repo.find_by_id(bid_id)` in `bids.py` |
| `pg_bids_repo.load()` and `find_by_id()` ran two queries sequentially | Fixed: `asyncio.gather` with two separate pool connections — queries execute concurrently |
| `GET .../emails/by-supplier` did `find_by_id` then `get_for_bid` sequentially | Fixed: `asyncio.gather` in `get_emails_by_supplier` |
| `DELETE /api/bids/{bid_id}` took ~10s | Added `delete_by_id(bid_id)` to `PgBidsRepository` — single DELETE, CASCADE handles children |
| `POST /api/bids` took ~13s | Three causes: (1) GCS moves sequential → parallel `asyncio.gather`. (2) Wasted `delete_for_bid` on empty table removed. (3) `append_many` + `documents.append` parallelized |
| `PATCH .../line-items/{line_id}` (save pricing) took ~8s | Added `update_with_pricing(line_id, updater, new_pricing)` — combines field update + pricing merge in one transaction |
| `POST /api/bids/{bid_id}/emails` (solicitation) took ~9s + 14s background | Five causes fixed: parallel entry reads, `add_solicited_suppliers()` (2 RT vs 5), eliminated redundant find_one, `graphInternetMessageId` column added to DB, `update_graph_message_ids()` bulk UPDATE |
