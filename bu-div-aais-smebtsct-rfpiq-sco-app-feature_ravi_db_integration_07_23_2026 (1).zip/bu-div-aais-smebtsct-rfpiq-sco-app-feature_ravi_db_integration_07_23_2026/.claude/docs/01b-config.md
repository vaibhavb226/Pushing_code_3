# Tech Stack — Config Reference (DB, Email, GCS, Secrets)

Reference for `01-tech-stack.md`. Read when configuring environment variables, GCS paths, or deployment secrets.

## Database

- **Primary:** PostgreSQL via PSC (Private Service Connect). Set `DB_HOST` to PSC endpoint IP.
- **Fallback:** JSON flat-file (`aiofiles` + `asyncio.Lock` per file) when `DB_HOST` is not set
- Migrations: `DATABASE_URL=postgresql+asyncpg://... alembic upgrade head`

## Email (Python backend — MS Graph only)

- **Provider:** `MsGraphEmailService` — MSAL + httpx → Microsoft Graph API
- **Permissions required:** `Mail.Send` + `Mail.ReadWrite` application permissions on Azure AD app
- **Env:** `MS_TENANT_ID`, `MS_CLIENT_ID`, `MS_CLIENT_SECRET`, `MS_MAILBOX_USER_ID`
- **Poller:** Incremental high-water mark in `data/pollState.json` — delete file to force 72h cold-start
- Gmail provider was removed July 9, 2026 (Python backend). Node.js backend still uses Gmail.

## GCS File Storage

- **Env:** `GCS_BUCKET` — all GCS code is guarded by `if gcs and settings.gcs_bucket:`, safe to leave unset locally
- **Client:** `get_gcs_client(settings)` in `dependencies.py` (returns None if unconfigured)
- **Uploads path:** `gs://{bucket}/{bidId}/{DocType}/{bidId}/{date}/{filename}`
- **Inbound attachments:** `gs://{bucket}/inbound/{savedName}`
- **Portal message files:** `gs://{bucket}/{bidId}/PortalMsg/{fname}`
- **Staging (BEX parse):** `gs://{bucket}/_staging/{uuid}/{file}` — moved to final path on save, staging auto-deleted

## GCP Secret Manager

Secrets loaded at startup: `ANTHROPIC_API_KEY`, `MS_TENANT_ID`, `MS_CLIENT_ID`, `MS_CLIENT_SECRET`, `DB_USER`, `DB_PASS`
- Local dev: `gcloud auth application-default login` when `GCP_PROJECT` is set
- Cloud Run: service account needs `roles/secretmanager.secretAccessor`

## LLM Provider Env Vars

| Env var | Default | Alternatives |
|---------|---------|--------------|
| `LLM_PROVIDER` | `vertexai` | `anthropic` |

- VertexAI needs: `GCP_PROJECT`, `GCP_LOCATION`, `VERTEX_MODEL`; service account needs `aiplatform.endpoints.predict`
- Anthropic: `ANTHROPIC_API_KEY` loaded from GCP Secret Manager in Cloud Run
