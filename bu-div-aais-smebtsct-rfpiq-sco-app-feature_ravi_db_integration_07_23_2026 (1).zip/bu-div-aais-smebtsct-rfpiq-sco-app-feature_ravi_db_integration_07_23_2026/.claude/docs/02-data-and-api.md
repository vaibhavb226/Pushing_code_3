# Data Files & API

## Data Files

Both `backend_py/data/` and `frontend/src/data/` hold these JSON files:

| File | Contents |
|------|----------|
| `bids.json` | Active bids (11 after POC testing) |
| `suppliers.json` | 20 suppliers — categories, segments, compliance tags, bounce flags |
| `lineItems.json` | Line items per bid, linked by `bidId` |
| `emailThreads.json` | Email threads per bid — direction, tags, attachments |
| `pricingData.json` | Supplier pricing responses |
| `documents.json` | Document vault files |
| `submissions.json` | Portal submissions — `dict[bidId, list[submission]]` |
| `portalTemplates.json` | Portal form templates (k12-standard, healthcare, government, quick-quote) |
| `unmatchedEmails.json` | Inbound emails the poller couldn't match to a bid |
| `pollState.json` | Inbox poller high-water mark — delete to force 72h cold-start lookback |

**Source of truth:** `backend_py/data/`. After any manual data change:
```bash
cp backend_py/data/bids.json frontend/src/data/bids.json
```

**lineItems.json fields:** `id, bidId, bidItem, mpcCode, brand, description, pack, size, unit, category, qty, storage, cw, stkType, buyAmerican, childNutrition, pfsRequired, exactSpec, wholeGrain, halal, kosher, rfpPopulated, _source, trueVendor, suppliedPrice, allw, dl, priceCase, devType, openReview, status, confidence`
Note: `supc` intentionally omitted (blank column in Working File — filled from item master later).

## API Endpoints

> Full endpoint listing (shared + Python-only): `.claude/docs/02b-api-reference.md`

All routes available under `/api/v1/` prefix too.

## BEX AI — RFP Parser

**Route:** `/bex` → `frontend/src/components/BexAI/index.jsx`
**Endpoint:** `POST /api/parse-rfp`

**Python pipeline (chunked LLM mapping):**
- Structure locator: 15-row sample → LLM finds header row + column map (junk sheets skipped)
- Chunked mapping: 100-row chunks mapped in parallel with stable PDF compliance context prefix
- PDF path: `find_tables()` TSV + full text; page-chunked for large PDFs

**Critical BEX rules:**
- Rule 8: Excel present → extract EXCLUSIVELY from Excel, not PDF
- Rule 9: NEVER hallucinate items. Missing fields → null. No items found → `line_items: []`
- No SUPC in extracted fields ever

**File combination behaviour:**
| Files | Items source | Metadata |
|-------|-------------|----------|
| PDF + Excel | Excel only | PDF |
| PDF only (items in PDF) | PDF | PDF |
| PDF only (no items) | `[]` | PDF |
| Excel only | Excel | sparse |

**RFP ID generation:**
- Bid ID = `RFP-{uuid4().hex[:8]}` — generated server-side in `parse_rfp()`, returned as `suggestedBidId` in parse response
- Frontend (`BexAI/index.jsx`) pre-populates the editable Bid ID field from `result.suggestedBidId`
- AI-extracted `metadata.bid_id` is ignored — server UUID is the only source of bid ID
- No pre-parse duplicate check — IDs are always unique by design
- `GET /api/parse-rfp/check-hash` endpoint removed (was hash-based, no longer applicable)

**GCS staging flow:**
1. `POST /api/parse-rfp`: files uploaded to `_staging/{uuid}/{file}` in GCS (no local temp write)
2. Parse runs from in-memory bytes; response includes `stagingPdfUri` / `stagingExcelUri`
3. `POST /api/bids` (Save): `_move_staging_to_final` → `copy_blob` to structured path + sets metadata + deletes staging source
