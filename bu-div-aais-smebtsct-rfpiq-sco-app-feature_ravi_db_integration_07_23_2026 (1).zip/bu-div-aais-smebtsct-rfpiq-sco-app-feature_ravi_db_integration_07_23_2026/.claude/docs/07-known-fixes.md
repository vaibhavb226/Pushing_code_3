# Known Fixes & Important Implementation Notes

## Critical Non-Obvious Fixes

> Simple one-liner fixes archived in `.claude/docs/07c-archived-fixes.md`

| Issue | Fix |
|-------|-----|
| Pricing extraction: duplicate rows in modal (8 bid items → 11 modal rows) + some supplier items completely absent | Two root causes: (1) **Single-pass path**: LLM emits the same supplier row multiple times — no dedup existed. (2) **Chunked path**: merge dedup keyed on `matchedBidItemNo` alone — when multiple DIFFERENT supplier products matched the same bid item, only the highest-confidence one survived. Fix: dedup keyed on `(description.lower().strip(), matchedBidItemNo)` — keeps highest-confidence per (supplier product, bid item) pair; different supplier products matching same bid item are BOTH kept. Do NOT restore the old `matchedBidItemNo`-only dedup key. |
| Confidence tooltip shows same reason in both ✓ and ✗ columns | `confidenceReasons` from LLM JSON contained negative strings (e.g. "No cooking method match") — same label appeared in both columns simultaneously. Fix: removed `confidenceReasons` from LLM schema in `_build_pricing_prompt`. Both lists now computed server-side in `_normalize_pricing_items` as strict complements via `_RULE_LABEL_MAP`. Do NOT restore `confidenceReasons` to the LLM schema. |
| Pricing extraction: same description, different pack/size (e.g. 113CT vs 138CT) — only one gets pricing | Two bid items with identical descriptions looked identical to LLM. Fix: `li_lines` in `_build_pricing_prompt` appends `[pack x size]` after each description. Do not remove — without it, same-description items with different pack/size silently lose pricing. |
| `ConfidenceCell` tooltip in `PricingExtractModal` hides behind table | Tooltip inside `overflow-hidden` div; high z-index has no effect. Fix: React portal via `createPortal` at `document.body`. Do NOT revert to absolute positioning inside the table. File: `frontend/src/components/BidDetail/PricingExtractModal.jsx`. |
| `extract-pricing` and `parse-rfp` used fake `setTimeout` timers | Fixed: both endpoints converted to `StreamingResponse` (`text/event-stream`). Shared `parseSSE` async generator (`frontend/src/utils/parseSSE.js`). **UploadFile bytes MUST be read before returning `StreamingResponse`** — FastAPI closes uploads after the response object is returned. |
| Tab presence avatars stay stale (local dev: `_notify_bid` was no-op when pool=None) | Fix: `_notify_bid` now calls `sse_push()` directly when no pool. Also: `tabPresence` entries include `lastSeen: Date.now()`; 60s interval purges entries older than 90s. Do NOT remove `lastSeen` timestamp. Do NOT revert `_notify_bid` to early-return on null pool — breaks all real-time events in local dev. |
| `useBidStream` SSE hook causes retry storm (dozens of requests/second) | EventSource fires `onerror` multiple times; each bumped `retryCount` → new EventSource. Fix: `let done = false` flag; `onerror` checks `if (done) return`. Do NOT remove the `done` guard. File: `frontend/src/hooks/useBidStream.js`. |
| Pricing confidence: identical descriptions score "medium" instead of "high" | Max 5 binary rules gave max 60 points = "medium". Fix: (1) extended cert rule with explicit list (CN/WG/WGR/Whole Grain/BA/Halal/Kosher); (2) extended size unit list to include ct, count, pk, ml; (3) added "Full description match (+15)" rule. Do not remove the full-description-match rule. |
| Bid-level compliance missing `Whole Grain` and `Exact Spec` | LLM prompts omitted these flags. Fix: added both to `BEX_SYSTEM_PROMPT` and `PDF_CONTEXT_EXTRACTION_SYSTEM`. Also added `_derive_bid_compliance(llm_flags, line_items_raw)` in `rfp_parser.py` — takes union of LLM metadata flags and per-item flags. Do NOT remove `_derive_bid_compliance` — prompt fixes alone won't help when WG appears only in per-item rows. |
| `whole_grain`, `halal`, `kosher` compliance flags not stored as per-item fields | Added as `Optional[bool]` to `BEXLineItem`; added to all 4 BEX prompts; added to `_to_app`/`_to_db`/SQL in `pg_line_items_repo.py`. Migration: `add_whole_grain_halal_kosher.sql`. Do not revert — required for DoD/Healthcare/K-12. |
| Large pricing Excel files (>~100 rows) return empty items | `all_lines[0]` was `=== Sheet: X ===` (not column names). Fix: skip `===` lines; use first non-separator line as header. Do not revert — every chunked Excel file silently returns nothing without this. |
| Large pricing PDFs with preamble return empty items | `extract_full_text()` mixed preamble with pricing rows. Fix: `_pdf_to_pricing_text()` pipeline using `find_tables()` + page filter (`[TABLE` marker AND price pattern). New helpers: `_filter_pricing_pages`, `_pdf_to_pricing_text`. Do not revert to `extract_full_text` for PDFs. |
| Pricing: all scores zero / matchedBidItemNo null for all items | Two bugs: (1) col_header dedup check fired on first occurrence because `rows` was already populated with preamble lines. Fix: replaced `rows` emptiness check with `col_header_added` flag. (2) "Full description match" example ("Nugget vs Patty → does NOT fire") caused LLM to return null for all mismatched types. Fix: added NOTE that "does NOT fire" only means those points aren't added, not that there is no match. Do not remove the NOTE. |
| Thinking tokens non-zero on pricing extraction / JSON truncation | `GenerationConfig` doesn't accept `thinking_config` — Gemini ran thinking by default, truncating JSON output. Fix: `_vertex_direct()` now uses google-genai SDK as primary (same as `_vertex_structured()`). Do not revert — leaving thinking enabled causes output truncation. |
| `matchedBidDescription` hallucinated by LLM | Fix: both paths in `_normalize_pricing_items()` now write `item["matchedBidDescription"] = best_li.get("description")`. Do not remove these overwrites. |
| `line_item_pricing` table removed | Was redundant. `pg_pricing_repo.py` deleted; `get_pricing_repo()` in `dependencies.py` returns JSON singleton only. Do not restore. |
| Email pricing extraction created no bid_line_items | Fix: `PricingExtractModal.jsx` fire-and-forgets `POST /api/bids/{bid_id}/submissions/from-extraction`. Backend upserts into `bids` + `bid_line_items` keyed on `(rfp_id, supplier_email)`. Migration: `add_email_id_to_bids.sql`. |
| `bids.thread_id` unique constraint crash on second extraction | Fix: `thread_id = f"EXTR-{uuid.uuid4().hex[:12].upper()}"` when not provided. |
| `LineItemsRepository` (JSON) missing `update_with_pricing` | Fix: added to `repositories/line_items_repo.py` — applies updater + merges pricing in one `update_one` call. |
| Pricing extraction: `commercialPrice`-only documents not saved to Working File | Fix: `netEdited` initialization falls back to `commercialPrice`; `casePrice`/`unitPrice` in new entry use `suppliedPrice`. Do not revert — Working File reads entry prices first, bypassing flat `supplied_price`. |
| Hidden Excel sheets extracted alongside visible ones | Fix: load-time filter in `excel_structurer.py`, `document_text.py`, `line_item_parser.py`, `analyse_response.py`. Also updated `EXCEL_STRUCTURE_LOCATOR_SYSTEM` prompt with name-based `is_item_sheet: false` signals. |
| Frontend stale bid data | Frontend uses `staticBids.find()` first — always `cp backend_py/data/bids.json frontend/src/data/bids.json` after any backend data change. |
| Email Repo "Responded" = 0 | `PATCH .../analysis` endpoint must NEVER set `Issues Found` on supplier — `analysisResult` is display-only metadata. Only the poller bounce fan-out sets `"Issues Found"`. |
| Pricing extraction hallucinating fields | Removed `deliveredPrice`, `fobPrice`, `allowance`, `devType` from LLM schema. Do NOT re-add — LLM hallucinates values for named schema fields even when columns don't exist. |
| Pricing: ALL items extracted including null-price rows | Prompt changed to extract ALL items; null-price rows included with `notes` explanation. Do not revert to "only extract items with explicit price". |
| Pricing: column rules must be semantic, not name-based | Rules describe field *meaning* (e.g. "final all-in delivered price") not specific column names. Do not hardcode column names. |
| Poller Tier 1 mis-match on deleted bids | Tier 1 returns None immediately if bid ID matched but bid doesn't exist — no tier 3 fallthrough. |
| FK violation on POST /api/bids (line items inserted before bid exists) | `rfp_line_items.rfp_id` → `rfps.id` FK requires bid row first. Fixed: `await bids_repo.append(new_bid)` now runs BEFORE the line items insert. |
| `smart_merge_pricing` double-encodes `supplier_pricing` JSONB | asyncpg JSONB codec calls `json.dumps` automatically — do not also call it manually. Fixed: pass `existing` (Python list) directly. `_safe_list()` in `pg_line_items_repo.py` auto-recovers corrupted rows. Do NOT call `json.dumps()` before passing lists to asyncpg JSONB parameters. |
| BCC solicitation emails show all suppliers as "Awaiting" in Email Repo | Fix: `create_bid_email` now writes N per-supplier email records (one per BCC address, `supplierId` set on each). `get_emails_by_supplier` fans out old-format BCC records for backwards compat. |
| Email status bleeds across RFPs (frontend) | Race condition: stale fetch from RFP-A could overwrite RFP-B state. Fix: `cancelledRef` flag in `EmailRepoTab` useEffect cleanup; all setters gated on `!cancelledRef.current`. Also resets `selectedId` and `activeFilter` on bid switch. |
| Email status bleeds across RFPs (poller) | Tier 3 always matched the FIRST bid for a customer name. Fix: prefer the bid that solicited the sender's email; fallback to most recently created bid. |
| Award / reminder emails start a new Outlook thread | Two causes: (1) Bounce NDRs used as threading anchor → `createReply` HTTP 400. Fix: skip `isBounce: true` records in `_get_last_internet_message_id`. (2) No fallback when no per-supplier record exists. Fix: added bid-level solicitation fallback. Do not revert — both fixes required. |
| Pricing extraction false-match on serial numbers | PRIORITY MATCHING block caused LLM to match any numeric column to bid item numbers. Fix: removed block; replaced with ANTI-RULE: "NEVER match by item code, serial number, SKU, or row position." Do not add code-based matching back. |
| "Check Issues" attachment 404 / GCS path mismatch | `files.py` applied `safe_filename()` to GCS path, stripping apostrophes/commas/ampersands — path mismatch for any such filename. Fix: `gcs_name = Path(filename).name` (strips traversal only) for GCS; `local_safe = safe_filename(filename)` for local disk only. Do NOT revert to `safe_filename` for GCS lookup. |
| Pricing extraction returns `items: []` with documentNote on Cloud Run | Two causes: (1) Cross-instance GCS read not tried directly. Fix: explicit `gcs_path = f"gs://{s.gcs_bucket}/inbound/{fname}"` in `_extract_one_file`. (2) `documentNote` trigger too broad — LLM justified returning `[]` when supplier products differed. Fix: trigger only "when the file itself is wrong (unreadable, no price columns, wrong file type)". Do NOT add extra extraction rules — additional "CRITICAL" rules confused the LLM. |
| Multi-file pricing: per-file errors silently dropped, items always `[]` on Cloud Run | Fix: collect `error`, `documentNote`, `warning` into `fileDiagnostics` list; `PricingExtractModal.jsx` renders as red/amber messages. Also added explicit GCS fallback in `_extract_one_file`. |
| Lost-update race in `pg_bids_repo update_by_id` | `find_by_id` then separate connection to write — no row lock between. Fix: single connection, transaction, `SELECT … FOR UPDATE`, then write. `update_one` now delegates to `update_by_id`. |
| Excel BEX parser processes non-item sheets | Guard `if structures and st and not st.is_item_sheet` short-circuited when `st is None`. Fix: `if structures and (st is None or not st.is_item_sheet)`. Also updated prompt to include ALL sheets with `is_item_sheet: false` for non-item ones. |
| RFP AIQ 422 error on 2nd message | `thinking` (list) in stored messages failed Pydantic `list[dict[str, str]]` validation. Fix: `RfpAiqDrawer.jsx` strips to `{role, content}` only before API call. |
| RFP AIQ LangGraph NameError — AgentState not defined | `AgentState` was defined inside `build_graph()`. `get_type_hints` can't find it in local scope. Fix: moved to module level in `services/sql_agent/graph.py`. |
| RFP AIQ LangGraph KeyError `'"sql"'` | `str.format()` choked on curly braces in `SCHEMA_SUMMARY`. Fix: `.replace("{schema}", SCHEMA_SUMMARY)` — brace-syntax agnostic. |

---

## DB Integration — Critical Design Decisions (July 2026)

**`solicitedSuppliers` uses DELETE + re-INSERT, not UPSERT** — `pg_bids_repo.update_one()` deletes all `rfp_solicited_suppliers` rows for the bid then re-inserts the updated list. Why: row IDs (e.g. `RSS-{bid_id}-001`) are internal and not referenced externally. UPSERT would require tracking IDs through updater lambdas. Do not switch to row-level UPSERT.

**asyncpg pool wired at startup (blocking await), NOT as a background task** — `create_asyncpg_pool()` is `await`ed in lifespan before first request. If it ran as `asyncio.create_task()`, any early request would crash.

**JSONB codec registered on pool, not per-query** — asyncpg registers JSON/JSONB codecs once per connection. PG repos pass Python dicts/lists directly with `$N::jsonb`; asyncpg calls `json.dumps()` automatically. Do not add manual `json.dumps()` calls inside PG repos — that double-encodes.

**`pg_unmatched_emails_repo.save()` is UPSERT** — mirrors JSON overwrite pattern. Do not raise `NotImplementedError` here like other PG repos.

**Stale ORM files deleted** — `repositories/backends/`, `repositories/models/`, `repositories/migrations/env.py` removed. Do not restore.

**Two pools serve different purposes** — asyncpg pool = CRUD repos. SQLAlchemy AsyncEngine = pgvector only. Do not mix.

---

## Critical Design Decisions — Do Not Revert

**`analysisResult` NEVER sets supplier status** — display-only. Only the poller bounce fan-out sets `"Issues Found"`. Do not add any code that sets `solicitedSuppliers[].status` from analysis results.

**MS Graph threading: do NOT use SMTP headers** — Use `createReply` on `graphInternetMessageId`. MS Graph rejects non-`x-` prefixed headers with HTTP 400.

**BCC solicitation threading fallback: do NOT remove** — `_get_last_internet_message_id()` must check `supplier_email` in `bcc[]` for BCC solicitations (stored with `supplierId: null`).

**Pricing schema: do NOT re-add `deliveredPrice`, `fobPrice`, `allowance`, `devType`** — LLM hallucinates values for named schema fields even when columns don't exist.

**Pricing: ALL items extracted including null-price rows** — `netPrice: null` + `notes`. Do not revert.

**Pricing: column rules must be semantic, not name-based** — Never list specific supplier column names in the extraction prompt.

**RFP ID: UUID not filename hash** — `uuid4().hex[:8]`. `GET /check-hash` endpoint removed — do not add back.

> Full "what was wrong / why we changed it" backstory: `.claude/docs/07b-design-rationale.md`
> One-liner/stable fixes archive: `.claude/docs/07c-archived-fixes.md`

---

## File Warning System (LLM-Driven)

**BEX RFP upload:** `BEXMetadata` has `file_warning: str | null`. `BEX_SYSTEM_PROMPT` and `PDF_CONTEXT_EXTRACTION_SYSTEM` instruct the LLM to set it when the file seems wrong. `rfp_parser.py` appends it to `parsing_warnings` — rendered as yellow banners in `BexAI/index.jsx`.

**Pricing extraction:** `PRICING_EXTRACTION_SYSTEM` instructs the LLM to set `documentNote: str | null` when no items found or file is wrong. `PricingExtractModal.jsx` shows it as amber text in the empty-state block.

**Truncation warning (`result.warning`)** surfaced as an amber banner above the items table in `PricingExtractModal.jsx`.

---

## FoodCorp Branding
All "Sysco" references → "FoodCorp". EXL Service branding fully preserved.
- Email: `bids@foodcorp.com` (COE), `demo@foodcorp.com` (demo)
- DB name: `foodcorp_rfp`
- Working File column: "FC Code" (was "Sysco Code")
- All supplier emails use `@demo-*.test` addresses (RFC 2606 — non-deliverable)

## Portal Template Feature
Search `PORTAL-TEMPLATE` in codebase to find all related code blocks.
Templates: `k12-standard`, `healthcare`, `government`, `quick-quote` in `backend_py/data/portalTemplates.json`
Bid config: `bid.portalConfig = { templateId, appliedAt, customFields[] }`
Custom fields render in: supplier portal form + Working File extra blue columns (`showInWorkingFile: true`)

## Node.js Backend — Do Not Change
`backend/` is frozen. All active development is Python backend only.

---

## AI Eval Harness (`backend_py/eval/`)

**Why:** No validation coverage existed for BEX Extraction, Pricing Extraction, or Chat AIQ.

**Structure:**
```
backend_py/eval/
  run_eval.py     CLI entry point (--scaffold / --capture / --eval)
  scorer.py       Pure scoring functions (score_bex, score_pricing, score_chat)
  README.md       Workflow guide for COE labellers
  dataset/
    bex/case_001/ … case_010/    10 RFP cases (input.xlsx/pdf + expected.json)
    pricing/case_001/ … case_010/ 10 pricing cases (3-4 supplier files each)
    chat/case_001.json … case_030.json  30 Chat AIQ questions
```

**Key design decisions:**
- Calls Python functions directly — no HTTP server needed.
- `--capture` writes actual.json only; scoring skipped until expected.json is created.
- Chat `expected_facts` are substring checks (case-insensitive); `expected_tool` checks scratchpad actions.
- Scored fields in BEX: description (fuzzy ≥80%), brand, category, pack, size, bool flags. `line_number` never scored.
- `scorer.py` is pure — no LLM calls, no DB access, importable for unit tests.

```bash
cd backend_py
python eval/run_eval.py --component bex --capture --case case_001
python eval/run_eval.py --all
```
