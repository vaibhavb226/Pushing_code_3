# Node.js Backend — Reference (DO NOT MODIFY)

> ⚠️ **FROZEN** — This backend is NOT the active one. Python FastAPI (`backend_py/`) is active.
> Do not modify `backend/` unless explicitly instructed.

## Overview

- **Framework:** Node.js + Express (ES modules — `import`/`export`)
- **Entry:** `backend/server.js`
- **Port:** 3001 (same as Python backend — run only one at a time)
- **AI:** Anthropic `claude-sonnet-4-6` via `ANTHROPIC_API_KEY`
- **Email:** Gmail SMTP (Nodemailer) outbound + Gmail IMAP (ImapFlow) inbound

## Config — `backend/.env`

```
ANTHROPIC_API_KEY=sk-ant-...
EMAIL_FROM=demo@foodcorp.com
EMAIL_APP_PASSWORD=xxxx xxxx xxxx xxxx   # Google App Password (spaces OK — stripped on use)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_IMAP_HOST=imap.gmail.com
EMAIL_IMAP_PORT=993
```

**dotenv:** uses `dotenvConfig({ override: true })` — required because shell env may have empty `ANTHROPIC_API_KEY=""` that blocks loading.

## Routes (`backend/routes/`)

| File | Responsibility |
|------|---------------|
| `bids.js` | Bids CRUD, cascading delete, file upload/serve, email send, portal-reply, award email |
| `rfpParser.js` | `POST /api/parse-rfp` — BEX AI parser + `buildLineItem()` export |
| `suppliers.js` | Supplier list, auto-populate, add new |
| `emails.js` | Email CRUD + `POST /api/analyse-response` |
| `pricing.js` | `POST /api/extract-pricing` — AI pricing extraction |
| `documents.js` | Document vault list + upload |
| `analyseResponse.js` | AI supplier response analysis |
| `submissions.js` | Public portal API (`/api/submit/*`) |
| `ai.js` | `POST /api/ai/chat` — RFP AIQ conversational AI |

## Services (`backend/services/`)

### `emailService.js` — Nodemailer Gmail SMTP
- `sendEmail({ to, bcc, subject, body, attachmentNames })` — STARTTLS port 587
- Gmail requires a `To:` even for BCC-only sends — uses sender address as To
- `verifyEmailConfig()` called at startup → logs ✅ or ⚠️

### `emailPoller.js` — IMAP inbox poller
- Polls Gmail inbox via ImapFlow every **15 seconds**
- Started automatically at boot via `startEmailPoller()` in `server.js`
- Manual trigger: `GET /api/email/poll-now`
- **3-tier matching** (same logic as Python backend):
  1. Bid ID pattern in subject
  2. Cleaned subject matches stored solicitation subject
  3. All significant words (4+ chars) from customer name in subject
- On match: saves to `emailThreads.json`, updates `solicitedSuppliers` status to `"Responded"`
- On no match: saves to `unmatchedEmails.json`
- Marks matched IMAP messages as Seen

### `lineItemParser.js` — Auto line item parsing
- `parseLineItemsFromExcel(bidId, filePath)` — keyword column mapping
- `parseLineItemsFromPDF(bidId, filePath)` — AI extraction via Anthropic
- `autoParseLineItems(bidId, file, filePath)` — detects MIME type and routes
- Excel takes priority over PDF if both are uploaded for the same bid
- Called via `setImmediate` background on file upload (non-blocking)
- Also runs at startup: `backfillLineItemsFromFiles()` for bids with files but 0 items

### `demoData.js`
- `ensureBounceDemo()` — idempotent: injects General Mills bounce demo data into bids.json + emailThreads.json if absent

## Server Startup Sequence (`server.js`)

1. Load `.env` with `override: true`
2. Mount all routers under `/api`
3. `backfillUploadedFiles()` — populates `bid.uploadedFiles[]` from legacy `uploadedRfpPath`/`uploadedItemListPath`
4. `backfillSolicitedSuppliers()` — repair any missing `solicitedSuppliers` entries
5. `backfillLineItemsFromFiles()` — parse line items for bids that have files but no items
6. `ensureBounceDemo()` — inject demo bounce data
7. `verifyEmailConfig()` — test SMTP connection
8. `startEmailPoller()` — begin 15s IMAP poll loop
9. `runAutoReminders()` via `setInterval` every 60 minutes

## Key Implementation Notes

**`buildLineItem()` helper** — exported from `rfpParser.js`, used by both rfpParser and bids.js:
```js
// Maps BEX AI response fields to lineItems.json schema
// Fields: id, bidId, bidItem (4-digit padded), mpcCode, brand, description,
//         pack, size, unit, category, qty, storage, cw, stkType,
//         buyAmerican, childNutrition, pfsRequired, exactSpec, rfpPopulated,
//         trueVendor, suppliedPrice, allw, dl, priceCase, devType, openReview,
//         status ('No Response'), confidence (null)
```

**`extractJSON(rawText)`** — all three AI routes use this: tries `JSON.parse()` first, strips markdown fences on failure.

**Attachment handling in `bids.js:create_bid_email`:**
```js
// Outbound emails store display filenames (not full paths):
attachments: direction === 'outbound' && Array.isArray(attachments)
  ? attachments.filter(Boolean).map(a => String(a).split('/').pop())
  : (Array.isArray(attachments) ? attachments : [])
```

**File serving:**
- `GET /api/bids/:id/files/:filename` — `Content-Disposition: inline` (browser view)
- Download variant uses `Content-Disposition: attachment`

**Award email template:** shared with Python backend — `backend/utils/awardEmailTemplate.js`

## Data Location

`backend/data/` — JSON flat files. **Not the source of truth** — `backend_py/data/` is.
Kept in sync with: `cp backend_py/data/bids.json backend/data/bids.json`

`backend/uploads/` — uploaded files (RFP PDFs, Item Lists, supplier pricing files).
