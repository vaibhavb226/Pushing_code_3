# API Endpoint Reference

Full listing for `02-data-and-api.md`. Read this file when adding or modifying endpoints.

## Shared Endpoints (Python + Node backends)

```
GET    /api/health
GET    /api/bids
POST   /api/bids
GET    /api/bids/:id
PATCH  /api/bids/:id              # accepts any bid fields including status
DELETE /api/bids/:id              # cascading delete of all related data
GET    /api/bids/:id/line-items
PATCH  /api/bids/:id/line-items/:lineId
DELETE /api/bids/:id/line-items/:lineId   # remove single line item from Working File
DELETE /api/bids/:id/line-items/:lineId/supplier-pricing?index=N  # remove one supplier pricing entry (promotes next or clears flat fields)
GET    /api/bids/:id/emails/by-supplier   # grouped view; includes isBroker per supplier
GET    /api/bids/:id/emails
POST   /api/bids/:id/emails
GET    /api/bids/:id/files/:filename      # serve uploaded file (Content-Disposition: inline)
POST   /api/bids/:bidId/files             # upload file to bid
GET    /api/suppliers
POST   /api/suppliers/auto-populate
GET    /api/documents
POST   /api/documents/upload
POST   /api/parse-rfp
POST   /api/analyse-response
POST   /api/extract-pricing
GET    /api/email/poll-now                # manual poll trigger
POST   /api/ai/chat                       # RFP AIQ conversational AI
GET    /api/submit/:bidId                 # public portal — bid info + line items
POST   /api/submit/:bidId                 # portal pricing submission
GET    /api/submit/:bidId/submissions     # portal submission summaries
GET    /api/submit/:bidId/thread/:threadId?email=X  # thread view (email-gated)
POST   /api/submit/:bidId/message         # supplier follow-up message
GET    /api/submit/:bidId/status/:confirmationId
POST   /api/bids/:bidId/portal-reply      # COE reply to portal thread
POST   /api/reports/send-email            # sends live-injected HTML report as email attachment
```

## Python-only Endpoints (not in Node backend)

```
GET    /api/bids/portal-templates
PATCH  /api/bids/{bid_id}/suppliers/{supplier_id}
POST   /api/bids/{bid_id}/emails/{email_id}/extract-pricing
PATCH  /api/bids/{bid_id}/emails/{email_id}/analysis
PATCH  /api/bids/{bid_id}/working-file-config
GET    /api/suppliers/search?q=
GET    /api/bids/{bid_id}/files/{filename}/view
GET    /api/bids/{bid_id}/files/{filename}/download
GET    /api/files/{bid_id}/attachments/{filename}   # serves inbound attachments (local then GCS)
PATCH  /api/documents/{doc_id}/vault
GET    /api/parse-rfp/check-hash?hash=              # pre-parse duplicate check (no LLM)
```

All routes available under `/api/v1/` prefix too.
