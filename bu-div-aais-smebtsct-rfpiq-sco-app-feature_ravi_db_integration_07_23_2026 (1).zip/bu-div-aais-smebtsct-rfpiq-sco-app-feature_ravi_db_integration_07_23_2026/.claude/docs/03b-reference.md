# Frontend — Reference (Login, Status Classes, Component Paths)

Reference for `03-frontend.md`. Read when you need credentials, status CSS, or specific component file locations.

## Login Credentials

**Component:** `frontend/src/pages/Login.jsx`

- `morgan.davis@foodcorp.com` / `FoodCorpBid2026` — Morgan Davis, Bid COE Manager
- `jamie.lee@foodcorp.com` / `FoodCorpBid2026` — Jamie Lee, Bid COE Analyst
- `taylor.smith@foodcorp.com` / `FoodCorpBid2026` — Taylor Smith, Bid COE Coordinator

## Status Config (bidUtils.js)

```
Active:       bg-green-100 / text-green-800
Solicitation: bg-blue-100  / text-blue-800
Working File: bg-amber-100 / text-amber-800
Review:       bg-purple-100 / text-purple-800
At Risk:      bg-red-100   / text-red-800
Awarded:      bg-gray-100  / text-gray-600
Cancelled:    bg-gray-100  / text-gray-500
```

## Key Frontend Component Paths

- BEX AI upload page: `frontend/src/components/BexAI/index.jsx`
- Email Repo tab: `frontend/src/components/BidDetail/EmailRepoTab.jsx`
- Email Composer (solicitation): `frontend/src/components/BidDetail/EmailComposer.jsx`
- Suppliers tab: `frontend/src/components/BidDetail/SuppliersTab.jsx`
- Working File tab: `frontend/src/components/BidDetail/WorkingFileTab.jsx`
- RFP AIQ drawer: `frontend/src/components/RfpAiq/RfpAiqDrawer.jsx`
- RFP AIQ message bubble: `frontend/src/components/RfpAiq/RfpAiqMessageBubble.jsx`
- Supplier Portal: `frontend/src/pages/SupplierPortal.jsx`
- HTML Pipeline Report: `frontend/public/reports/FoodCorp_Bid_Pipeline_Report.html`

## Delete Bid — Cascading

`DELETE /api/bids/:id` removes: bid record, line items, email threads, pricing data, documents, uploaded files. Toast shows item count detail.
