# Key Backend File Locations

## Repository layer
| File | Table(s) | Notes |
|---|---|---|
| `repositories/base.py` | — | `AbstractRepository` ABC + `JsonRepository` implementation |
| `repositories/pg_base.py` | — | `PgRepository` base + `_str_date/_str_dt/_dt/_dt_flex/_js/_jo` helpers |
| `repositories/pg_bids_repo.py` | `rfps` + `rfp_solicited_suppliers` | Two-query load, delete+re-insert for SS updates |
| `repositories/pg_email_threads_repo.py` | `email_threads` | `get_for_bid()`, `find_by_uid()` |
| `repositories/pg_suppliers_repo.py` | `suppliers` | `contact_email` → `contact` rename |
| `repositories/pg_documents_repo.py` | `documents` | |
| `repositories/pg_portal_templates_repo.py` | `portal_templates` | `label`/`segment` dual-write |
| `repositories/pg_line_items_repo.py` | `rfp_line_items` | `get_for_bid()`, `smart_merge_pricing()` |
| `repositories/pg_submissions_repo.py` | `bids` + `bid_line_items` + `submission_messages` | Custom interface (not AbstractRepository); `upsert_from_extraction(bid_id, submission)` for email extractions |
| `repositories/pg_unmatched_emails_repo.py` | `unmatched_emails` | `save()` as UPSERT ON CONFLICT |
| `db/connection.py` | — | `create_asyncpg_pool()`, `get_asyncpg_pool()`, SQLAlchemy engine |
| `dependencies.py` | — | `get_*_repo()` factories — PG if `db_host` set, JSON singleton otherwise |

## Services / routing
- Chat AIQ endpoint: `backend_py/routers/ai_chat.py` — `chat()`, `max_tokens` param
- Pricing extraction: `backend_py/routers/bids.py` — `_extract_generic_pricing()`, `_normalize_pricing_items()`, `_backend_confidence()`, `_compute_missed_reasons()`
- All LLM prompts: `backend_py/routers/prompts.py` — `PRICING_EXTRACTION_SYSTEM`, `BEX_SYSTEM_PROMPT`, `EXTRACT_PROMPT`, `RFPAIQ_IDENTITY`
- LLM provider implementations: `backend_py/services/llm/provider.py` — `_vertex_direct()`, `_anthropic_direct()`
- Email service: `backend_py/services/email/msgraph_provider.py` — `_build_attachments()`, `_download_attachments()`
- Email service factory: `backend_py/services/email/factory.py`
- Email poller: `backend_py/services/email_poller.py` — `_detect_bounce()`, `_parse_bounce()`, `_bounce_updater()`
- `get_emails_by_supplier()` (by-supplier endpoint): `backend_py/routers/bids.py`
