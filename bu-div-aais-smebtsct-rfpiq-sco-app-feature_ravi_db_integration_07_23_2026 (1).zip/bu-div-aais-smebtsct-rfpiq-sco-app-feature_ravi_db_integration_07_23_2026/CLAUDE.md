# FoodCorp RFP AIQ — Claude Code Context

> **Project:** AI-powered procurement tool for FoodCorp Bid COE team | Built by EXL Service | July 2026
> **Status:** Active Development — Python FastAPI backend + React 18 frontend + GCS file storage

---

## ⚠️ CRITICAL RULES

1. **NEVER modify `backend/` (Node.js)** — All backend work is in `backend_py/` (Python FastAPI) only. Port 3001 shared — run only one at a time. Full frozen-backend reference: `.claude/docs/08-nodejs-backend.md`
2. **Data sync:** `backend_py/data/` is source of truth → `cp backend_py/data/bids.json frontend/src/data/bids.json`
3. **Dark mode:** NEVER use `style={{ backgroundColor }}` for section backgrounds — use Tailwind `className` with `dark:` variants
4. **Active portal:** routes `/submit/:bidId` and `/submit/:bidId/thread/:threadId` are live
5. **Self-update:** after any major code change, automatically update the relevant `.claude/docs/` topic file(s) — do this without being asked. Every update must include **why** the change was made, not just what changed. For bug fixes and reversals, document: what was wrong, what symptom it caused, and what the correct approach is. This prevents the same mistake from being made again in a future session. Add "Do not revert" notes for decisions that look like they could be simplified but must not be changed.

---

## Local Dev — Quick Start

```bash
# Backend (Python)
cd backend_py && .venv/Scripts/python.exe -m uvicorn main:app --reload --port 3001

# Frontend
cd frontend && npm run dev      # http://localhost:5173
```

Login: `morgan.davis@foodcorp.com` / `FoodCorpBid2026`

---

## Topic Documentation
@.claude/docs/01-tech-stack.md
@.claude/docs/02-data-and-api.md
@.claude/docs/03-frontend.md
@.claude/docs/04-email-portal.md
@.claude/docs/05-python-backend.md
@.claude/docs/06-rfp-aiq.md
@.claude/docs/07-known-fixes.md

---

## Folder Structure (top-level)

```
project/
├── frontend/src/         # React app
├── backend/              # Node.js (DO NOT MODIFY)
├── backend_py/           # Python FastAPI (active)
│   ├── routers/          # API routes
│   ├── services/         # LLM, email, poller, GCS
│   ├── repositories/     # JSON flat-file storage (+ DB stub)
│   ├── data/             # JSON data files (source of truth)
│   └── uploads/          # Local file cache (GCS is primary)
├── deploy.sh             # VM deployment (PM2 + nginx)
└── CLAUDE.md             # ← This file
```
