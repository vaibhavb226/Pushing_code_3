"""Tests for /api/submit/* (supplier portal) endpoints."""
from __future__ import annotations

import json

import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_get_portal_bid(client: AsyncClient) -> None:
    resp = await client.get("/api/submit/BID-TEST-001")
    assert resp.status_code == 200
    data = resp.json()
    assert data["id"] == "BID-TEST-001"
    assert "lineItems" in data
    assert len(data["lineItems"]) == 1


@pytest.mark.asyncio
async def test_get_portal_bid_not_found(client: AsyncClient) -> None:
    resp = await client.get("/api/submit/BID-NOPE")
    assert resp.status_code == 404


@pytest.mark.asyncio
async def test_submit_pricing(client: AsyncClient) -> None:
    line_items = json.dumps([
        {"itemNo": "0001", "unitPrice": 5.25, "casePrice": 0.0, "noBid": False}
    ])
    resp = await client.post(
        "/api/submit/BID-TEST-001",
        data={
            "supplierName": "Test Supplier Inc",
            "supplierEmail": "supplier@test-demo.test",
            "contactName": "Jane Smith",
            "lineItems": line_items,
            "notes": "Competitive pricing",
        },
    )
    assert resp.status_code == 201
    data = resp.json()
    assert "confirmationId" in data
    assert "threadId" in data
    assert data["pricedCount"] == 1
    assert data["noBidCount"] == 0


@pytest.mark.asyncio
async def test_get_submissions_empty(client: AsyncClient) -> None:
    resp = await client.get("/api/submit/BID-TEST-001/submissions")
    assert resp.status_code == 200
    assert resp.json() == []


@pytest.mark.asyncio
async def test_submission_flow_and_thread_access(client: AsyncClient) -> None:
    """Full portal flow: submit → get thread."""
    # Submit
    resp = await client.post(
        "/api/submit/BID-TEST-001",
        data={
            "supplierName": "Portal Supplier",
            "supplierEmail": "portal@test-demo.test",
            "contactName": "Bob Jones",
            "lineItems": json.dumps([]),
            "notes": "",
        },
    )
    assert resp.status_code == 201
    sub = resp.json()
    thread_id = sub["threadId"]

    # Access thread with correct email (no email gate for empty string)
    resp2 = await client.get(
        f"/api/submit/BID-TEST-001/thread/{thread_id}",
        params={"email": "portal@test-demo.test"},
    )
    assert resp2.status_code == 200
    thread = resp2.json()
    assert thread["supplierName"] == "Portal Supplier"
    assert thread["threadId"] == thread_id


@pytest.mark.asyncio
async def test_thread_email_gate_rejects_wrong_email(client: AsyncClient) -> None:
    # Submit first
    resp = await client.post(
        "/api/submit/BID-TEST-001",
        data={
            "supplierName": "Gated Supplier",
            "supplierEmail": "gated@test-demo.test",
            "contactName": "Alice",
            "lineItems": json.dumps([]),
            "notes": "",
        },
    )
    thread_id = resp.json()["threadId"]

    # Wrong email
    resp2 = await client.get(
        f"/api/submit/BID-TEST-001/thread/{thread_id}",
        params={"email": "wrong@email.test"},
    )
    assert resp2.status_code == 401


@pytest.mark.asyncio
async def test_submission_status_check(client: AsyncClient) -> None:
    resp = await client.post(
        "/api/submit/BID-TEST-001",
        data={
            "supplierName": "Status Test",
            "supplierEmail": "status@test-demo.test",
            "contactName": "X",
            "lineItems": json.dumps([]),
            "notes": "",
        },
    )
    conf_id = resp.json()["confirmationId"]

    resp2 = await client.get(f"/api/submit/BID-TEST-001/status/{conf_id}")
    assert resp2.status_code == 200
    assert resp2.json()["status"] == "received"
