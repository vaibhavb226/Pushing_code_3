"""Tests for /api/suppliers/* endpoints."""
from __future__ import annotations

import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_list_suppliers(client: AsyncClient) -> None:
    resp = await client.get("/api/suppliers/")
    assert resp.status_code == 200
    data = resp.json()
    assert isinstance(data, list)
    assert any(s["id"] == "SM-001" for s in data)


@pytest.mark.asyncio
async def test_search_suppliers(client: AsyncClient) -> None:
    resp = await client.get("/api/suppliers/search?q=Test")
    assert resp.status_code == 200
    results = resp.json()
    assert any("Test" in s["name"] for s in results)


@pytest.mark.asyncio
async def test_search_suppliers_no_results(client: AsyncClient) -> None:
    resp = await client.get("/api/suppliers/search?q=ZzZzNobodyHasThisName")
    assert resp.status_code == 200
    assert resp.json() == []


@pytest.mark.asyncio
async def test_create_supplier(client: AsyncClient) -> None:
    resp = await client.post("/api/suppliers/", json={
        "name": "Brand New Supplier",
        "category": "Dairy",
        "contact": "new@demo-supplier.test",
        "region": "Northeast",
        "segments": ["K-12"],
    })
    assert resp.status_code == 201
    data = resp.json()
    assert data["name"] == "Brand New Supplier"
    assert data["id"].startswith("SM-")
