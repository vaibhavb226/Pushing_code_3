"""Tests for LLMService — uses a mocked LangChain model."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock

import pytest

from services.llm.provider import LLMResponse, LLMService


@pytest.fixture
def mock_model() -> MagicMock:
    model = MagicMock()
    mock_response = MagicMock()
    mock_response.content = '{"items": [{"description": "Test item", "price": 9.99}]}'
    model.bind.return_value.ainvoke = AsyncMock(return_value=mock_response)
    return model


@pytest.mark.asyncio
async def test_chat_returns_content(mock_model: MagicMock) -> None:
    svc = LLMService(mock_model)
    result = await svc.chat(system="You are a helpful assistant", user="Hello")
    assert isinstance(result, LLMResponse)
    assert "items" in result.content


@pytest.mark.asyncio
async def test_chat_with_history(mock_model: MagicMock) -> None:
    svc = LLMService(mock_model)
    messages = [
        {"role": "user", "content": "What bids are open?"},
        {"role": "assistant", "content": "There are 3 open bids."},
        {"role": "user", "content": "Which one is due soonest?"},
    ]
    result = await svc.chat_with_history(
        system="You are RFP AIQ",
        messages=messages,
        max_tokens=512,
    )
    assert isinstance(result, LLMResponse)
    assert result.content


@pytest.mark.asyncio
async def test_chat_passes_max_tokens(mock_model: MagicMock) -> None:
    svc = LLMService(mock_model)
    await svc.chat(system="sys", user="user", max_tokens=8000)
    mock_model.bind.assert_called_once_with(max_tokens=8000)
