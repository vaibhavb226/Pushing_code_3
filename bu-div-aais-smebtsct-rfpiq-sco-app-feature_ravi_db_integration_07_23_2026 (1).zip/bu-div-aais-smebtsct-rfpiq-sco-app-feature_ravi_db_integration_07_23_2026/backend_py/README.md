# Sysco RFP AIQ — Python FastAPI Backend

![Python 3.12](https://img.shields.io/badge/Python-3.12-blue)
![FastAPI](https://img.shields.io/badge/FastAPI-0.115-009688)
![LangChain](https://img.shields.io/badge/LangChain-Anthropic%20%7C%20OpenAI%20%7C%20Vertex-orange)
![pytest](https://img.shields.io/badge/tested%20with-pytest-green)

Production-grade Python FastAPI replacement for the original Node.js/Express server powering Sysco RFP AIQ. Exposes the same REST API surface on **port 3001** — the React frontend (`frontend/`) connects without any configuration changes. Built by EXL Service for the Sysco Bid COE team.

---

## Architecture at a Glance

Three dimensions of the backend are pluggable via environment variables — no code changes required:

| Dimension | Env var | Default | Alternatives |
|-----------|---------|---------|--------------|
| **LLM provider** | `LLM_PROVIDER` | `anthropic` | `openai`, `vertexai` |
| **Database backend** | `DB_BACKEND` | `json` | `sqlite`, `postgres` |

Email is **Microsoft Graph only** (`MsGraphEmailService`); the Gmail provider was removed
July 9, 2026. See the [Email — Microsoft Graph](#email-provider--microsoft-graph) section.

Change the env var, restart the server, and the provider is swapped. Routers and services depend only on abstract interfaces (`LLMService`, `AbstractEmailService`, `AbstractRepository`) and never reference a concrete implementation directly.

---

## Project Structure

```
backend_py/
├── main.py                   # FastAPI app, CORS, lifespan, health check, email poll-now
├── config.py                 # pydantic-settings: all env vars typed + validated at startup
├── dependencies.py           # Repository + service singletons injected via Depends()
├── constants.py              # CATEGORY_MAP, MIME_MAP, STATUS_ORDER
├── requirements.txt          # All Python dependencies (pinned)
├── pyproject.toml            # ruff, mypy, pytest configuration
├── alembic.ini               # Alembic migrations (active only when DB_BACKEND != json)
├── setup_data.py             # One-time bootstrap: copy data + uploads from backend/
├── .env.example              # Environment variable template
├── Dockerfile                # Multi-stage build (python:3.12-slim)
├── docker-compose.yml        # Backend + optional PostgreSQL
│
├── routers/                  # One file per API resource; all mounted in main.py
│   ├── bids.py               # 25 endpoints — full bid lifecycle
│   ├── suppliers.py          # Supplier list, search, auto-populate, create
│   ├── email_threads.py      # Email thread list, get, log
│   ├── documents.py          # Document vault list, upload, toggle
│   ├── rfp_parser.py         # BEX AI — parse RFP PDF + create bid
│   ├── pricing.py            # AI pricing extraction from supplier files
│   ├── analyse_response.py   # AI supplier response analysis
│   ├── ai_chat.py            # RFP AIQ multi-turn conversational intelligence
│   ├── submissions.py        # Public supplier portal (6 endpoints, no auth)
│   ├── files.py              # Serve inbound email attachments from uploads/
│   └── prompts.py            # All LLM system prompt strings (constants)
│
├── services/
│   ├── llm/
│   │   ├── provider.py       # LLMService — async .chat() + .chat_with_history()
│   │   ├── factory.py        # build_llm_service() — selects ChatAnthropic/OpenAI/Vertex
│   │   └── json_parser.py    # extract_json() — strips fences, parses LLM JSON output
│   ├── email/
│   │   ├── base.py           # AbstractEmailService ABC
│   │   ├── msgraph_provider.py # MsGraphEmailService — MSAL + httpx → Graph API (only provider)
│   │   └── factory.py        # build_email_service() — builds MsGraphEmailService
│   ├── email_poller.py       # Graph polling loop (15 s); high-water mark; bounce detection; bid matching
│   ├── line_item_parser.py   # Excel column-map parser + PDF→AI parser
│   ├── auto_reminder.py      # run_auto_reminders() — APScheduler hourly job
│   └── demo_data.py          # ensure_bounce_demo() — idempotent demo data injection
│
├── repositories/
│   ├── base.py               # AbstractRepository ABC + asyncio.Lock-per-file safety
│   ├── backends/
│   │   ├── json_backend.py   # JsonRepository — aiofiles flat-file storage (active default)
│   │   └── db_backend.py     # DbRepository — SQLAlchemy async stub (future)
│   ├── models/               # SQLAlchemy ORM models (used only when DB_BACKEND != json)
│   ├── migrations/           # Alembic env.py
│   ├── bids_repo.py
│   ├── line_items_repo.py    # Includes smart_merge_pricing() deduplication
│   ├── email_threads_repo.py
│   ├── suppliers_repo.py
│   ├── documents_repo.py
│   ├── pricing_repo.py
│   ├── submissions_repo.py   # dict[bidId, list[submission]] — special structure
│   ├── portal_templates_repo.py
│   └── unmatched_emails_repo.py
│
├── schemas/                  # Pydantic v2 request + response models
│   ├── bid.py
│   ├── supplier.py
│   ├── line_item.py
│   ├── email_thread.py
│   ├── submission.py
│   └── document.py
│
├── middleware/
│   ├── request_id.py         # Injects X-Request-ID UUID into every request
│   └── auth.py               # X-API-Key header validation for internal routes
│
├── utils/
│   ├── award_email_template.py  # build_award_email_subject/body
│   ├── file_utils.py            # format_file_size(), safe_filename()
│   └── backfill.py              # 4 startup coroutines for data migration/sync
│
├── tests/
│   ├── conftest.py           # Fixtures: tmp_data_dir, client, mock_llm
│   ├── routers/              # Route integration tests (httpx.AsyncClient)
│   ├── services/             # LLM provider + line item parser tests
│   └── repositories/         # Concurrent write safety tests
│
├── data/                     # JSON flat files (source of truth; see Data Files section)
└── uploads/                  # User-uploaded RFP PDFs, Excel files, attachments
```

---

## Prerequisites

- **Python 3.12+**
- **pip** (or a virtual environment manager such as `venv`/`uv`)
- **Docker + Docker Compose** — optional, for containerised deployment
- **PyMuPDF** — installed automatically via `requirements.txt`; requires no system-level dependencies on Windows/macOS. On Linux, the `pymupdf` wheel bundles MuPDF natively so no `apt install` is needed.

---

## Quick Start — Local

```bash
# Navigate to this directory
cd backend_py

# 1. Bootstrap data and uploads from the Node.js backend (run once)
python setup_data.py

# 2. Configure environment
cp .env.example .env
# Open .env and fill in at minimum:
#   ANTHROPIC_API_KEY=sk-ant-...            (or LLM_PROVIDER=vertexai + GCP_PROJECT)
#   MS_TENANT_ID / MS_CLIENT_ID / MS_CLIENT_SECRET / MS_MAILBOX_USER_ID   (Microsoft Graph)

# 3. Install dependencies
pip install -r requirements.txt

# 4. Start the server
uvicorn main:app --reload --port 3001
```

Once running:
- **API Docs (Swagger):** http://localhost:3001/api/docs
- **ReDoc:** http://localhost:3001/api/redoc
- **Health check:** http://localhost:3001/api/health
- **Frontend (separate):** http://localhost:5173

> `setup_data.py` is idempotent — safe to re-run. It copies `backend/data/*.json` and `backend/uploads/*` into `backend_py/` and creates a `.env` from `.env.example` if one does not already exist.

---

## Quick Start — Docker

```bash
# Default — JSON flat-file backend
docker-compose up

# With optional PostgreSQL (sets DB_BACKEND=postgres)
docker-compose --profile postgres up
```

The `./data` and `./uploads` directories are bind-mounted into the container, so data persists across restarts. The health check (`GET /api/health`) is polled every 30 seconds.

---

## Environment Variables Reference

All variables are optional unless marked **(required)**. Copy `.env.example` to `.env` and edit.

### Server

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3001` | HTTP server port |
| `NODE_ENV` | `development` | `production` enables stricter settings |

### Security

| Variable | Default | Description |
|----------|---------|-------------|
| `INTERNAL_API_KEY` | *(empty — disabled)* | When set, all non-public routes require `X-API-Key: <value>` header |

### LLM Provider

| Variable | Default | Description |
|----------|---------|-------------|
| `LLM_PROVIDER` | `anthropic` | `anthropic` \| `openai` \| `vertexai` |
| `ANTHROPIC_API_KEY` | *(empty)* | **(required for anthropic)** Starts with `sk-ant-` |
| `ANTHROPIC_MODEL` | `claude-sonnet-4-20250514` | Anthropic model ID |
| `OPENAI_API_KEY` | *(empty)* | **(required for openai)** |
| `OPENAI_MODEL` | `gpt-4o` | OpenAI model ID |
| `VERTEX_MODEL` | `gemini-1.5-pro` | Google Vertex AI model name |
| `GCP_PROJECT` | *(empty)* | **(required for vertexai)** GCP project ID |
| `GCP_LOCATION` | `us-central1` | GCP region for Vertex AI |

**Vertex AI Authentication (No API Key Required)**

Vertex AI uses **IAM-based authentication** with service account OAuth 2.0 tokens. No API key is needed. The provider automatically uses Google Cloud credentials from (in order):

1. **`GOOGLE_APPLICATION_CREDENTIALS`** environment variable (path to service account JSON key file)
2. **gcloud ADC** (Application Default Credentials from `gcloud auth application-default login`)
3. **Workload Identity** (automatic on GKE, Cloud Run, or other Google Cloud services)

**Setup instructions:**

```bash
# Option 1: Local development with service account key
export GOOGLE_APPLICATION_CREDENTIALS="/path/to/service-account-key.json"
export LLM_PROVIDER=vertexai
export GCP_PROJECT=your-gcp-project-id
uvicorn main:app --reload --port 3001

# Option 2: Using gcloud CLI (local development)
gcloud auth application-default login
export LLM_PROVIDER=vertexai
export GCP_PROJECT=your-gcp-project-id
uvicorn main:app --reload --port 3001

# Option 3: Kubernetes/GKE with Workload Identity (automatic, no config needed)
# Just set LLM_PROVIDER and GCP_PROJECT env vars
```

**Service account permissions required:**
- `aiplatform.endpoints.predict` (Vertex AI)
- `aiplatform.models.get` (optional)


### Email Provider — Microsoft Graph

Microsoft Graph is the only email provider (the Gmail provider was removed July 9, 2026).

| Variable | Default | Description |
|----------|---------|-------------|
| `MS_TENANT_ID` | *(empty)* | Azure AD tenant ID |
| `MS_CLIENT_ID` | *(empty)* | Azure AD app (client) ID |
| `MS_CLIENT_SECRET` | *(empty)* | Azure AD client secret |
| `MS_MAILBOX_USER_ID` | *(empty)* | UPN of the shared mailbox (e.g. `COE.BIDS@sysco.com`) |

### Inbox Poller

| Variable | Default | Description |
|----------|---------|-------------|
| `POLL_LOOKBACK_HOURS` | `72` | Cold-start window when `data/pollState.json` does not exist yet |
| `MAX_LOOKBACK_DAYS` | `30` | Clamp so a stale high-water mark never triggers a full-mailbox scan |

The poller keeps an incremental high-water mark in `data/pollState.json` and fetches everything
received since the last poll (no `isRead` dependency, no fixed window). Runs single-flighted; deploy
on a single instance. See the Key Architectural Notes.

### Database Backend

| Variable | Default | Description |
|----------|---------|-------------|
| `DB_BACKEND` | `json` | `json` \| `sqlite` \| `postgres` |
| `DATABASE_URL` | `sqlite+aiosqlite:///./sysco_rfp.db` | SQLAlchemy async connection string |

For PostgreSQL: `postgresql+asyncpg://user:pass@host:5432/sysco_rfp`

### Frontend / Portal

| Variable | Default | Description |
|----------|---------|-------------|
| `PORTAL_BASE_URL` | `http://localhost:5173` | Base URL sent to suppliers in emails |
| `FRONTEND_URLS` | `http://localhost:5173,...` | Comma-separated CORS allowed origins |

---

## API Endpoints

> Full request/response schemas are available in Swagger UI at `/api/docs`.
>
> All routes below are also available under the `/api/v1/` prefix.

### Health & Admin

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/health` | Server status — uptime, LLM provider, email config, DB backend |
| `GET` | `/api/email/poll-now` | Manually trigger one IMAP poll cycle (dev/testing) |

### Bids — `/api/bids`

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/bids/portal-templates` | List available portal form templates |
| `GET` | `/api/bids/` | List all bids |
| `POST` | `/api/bids/` | Create a new bid (+ save line items from BEX AI parse result) |
| `GET` | `/api/bids/{bid_id}` | Get a single bid |
| `PATCH` | `/api/bids/{bid_id}` | Update bid fields (any subset) |
| `DELETE` | `/api/bids/{bid_id}` | Cascading delete — removes bid, line items, emails, pricing, documents, uploads |
| `GET` | `/api/bids/{bid_id}/files` | List uploaded files for a bid |
| `POST` | `/api/bids/{bid_id}/files` | Upload a file; auto-parses line items if docType is RFP or Item List |
| `GET` | `/api/bids/{bid_id}/files/{filename}/view` | Stream file inline (browser viewer) |
| `GET` | `/api/bids/{bid_id}/files/{filename}/download` | Download file as attachment |
| `GET` | `/api/bids/{bid_id}/line-items` | List all line items for a bid |
| `PATCH` | `/api/bids/{bid_id}/line-items/{line_id}` | Update a line item (smart-merges supplier pricing) |
| `GET` | `/api/bids/{bid_id}/emails/by-supplier` | Emails grouped by supplier (for Email Repo tab) |
| `GET` | `/api/bids/{bid_id}/emails` | Flat email list for a bid |
| `POST` | `/api/bids/{bid_id}/emails` | Log or send an email (outbound triggers SMTP send) |
| `PATCH` | `/api/bids/{bid_id}/suppliers/{supplier_id}` | Update a solicited supplier's status |
| `POST` | `/api/bids/{bid_id}/send-award-email` | Send award notification email to a supplier |
| `PATCH` | `/api/bids/{bid_id}/emails/{email_id}/analysis` | Save AI analysis result to an email record |
| `POST` | `/api/bids/{bid_id}/emails/{email_id}/extract-pricing` | AI-extract pricing from an email attachment (PDF via PyMuPDF; fuzzy match + confidence enrichment) |
| `POST` | `/api/bids/{bid_id}/portal-reply` | COE reply via portal — appends to thread + sends email |
| `PATCH` | `/api/bids/{bid_id}/auto-reminder` | Enable/configure the hourly auto-reminder scheduler |
| `PATCH` | `/api/bids/{bid_id}/portal-config` | Save portal form template config to a bid |
| `PATCH` | `/api/bids/{bid_id}/working-file-config` | Save Working File column visibility config |

### Suppliers — `/api/suppliers`

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/suppliers/search?q=&limit=20` | Fuzzy prefix typeahead — sorted inverted index, O(log n), `{ results, total }` |
| `POST` | `/api/suppliers/auto-populate` | Business-priority scoring — category gate → compliance (50 pts, TF-IDF text) → segment (30 pts) → TF-IDF text (20 pts); returns ranked suppliers with `matchScore` + `matchReasons` |
| `GET` | `/api/suppliers/recommend` | Vector similarity search (pgvector); falls back to auto-populate if Cloud SQL not configured |
| `GET` | `/api/suppliers/` | List all suppliers |
| `POST` | `/api/suppliers/` | Create a new supplier |

### Email Threads — `/api/emails`

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/emails/` | List all email threads |
| `GET` | `/api/emails/{email_id}` | Get a single email thread |
| `POST` | `/api/emails/log` | Manually log an inbound email |

### Documents — `/api/documents`

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/documents/` | List all vault documents |
| `GET` | `/api/documents/{doc_id}` | Get a single document |
| `POST` | `/api/documents/upload` | Upload a document to the vault |
| `PATCH` | `/api/documents/{doc_id}/vault` | Toggle vault inclusion flag |

### Files — `/api/files`

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/files/{bid_id}/attachments/{filename}` | Serve an inbound email attachment from `uploads/` (Graph/IMAP poller saves them as `INBOUND_{hash}_{name}`). `bid_id` is for URL compatibility only. |

### BEX AI / RFP Parser — `/api/parse-rfp`

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/parse-rfp/` | Parse RFP PDF + Excel → extract metadata + line items via AI |
| `POST` | `/api/parse-rfp/create` | Confirm parsed result → create bid + save line items |

### AI Services

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/api/extract-pricing` | Extract pricing table from a supplier file via AI |
| `POST` | `/api/analyse-response` | AI analysis of a supplier email + attachments |
| `POST` | `/api/ai/chat` | RFP AIQ — multi-turn conversational intelligence (uses full bid context) |

### Supplier Portal — Public — `/api/submit`

> These routes are **public** — no `X-API-Key` header required. Rate-limited at 60 req/min per IP.

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/api/submit/{bid_id}` | Bid info + line items for the supplier submission form |
| `POST` | `/api/submit/{bid_id}` | Submit supplier pricing (multipart; triggers status update) |
| `GET` | `/api/submit/{bid_id}/submissions` | Per-supplier submission summaries (used by Suppliers tab) |
| `GET` | `/api/submit/{bid_id}/thread/{thread_id}?email=` | Email-verified thread view; marks COE messages as read |
| `POST` | `/api/submit/{bid_id}/message` | Supplier follow-up message on an existing thread |
| `GET` | `/api/submit/{bid_id}/status/{confirmation_id}` | Submission receipt lookup |

---

## Swapping Providers

### LLM — OpenAI

```dotenv
LLM_PROVIDER=openai
OPENAI_API_KEY=sk-...
OPENAI_MODEL=gpt-4o        # or gpt-4-turbo, etc.
```

### LLM — Google Vertex AI

```dotenv
LLM_PROVIDER=vertexai
VERTEX_MODEL=gemini-1.5-pro
GCP_PROJECT=my-gcp-project
GCP_LOCATION=us-central1
# Ensure GOOGLE_APPLICATION_CREDENTIALS is set or ADC is configured
```

### Email — Microsoft Graph (Microsoft 365)

```dotenv
MS_TENANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
MS_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
MS_CLIENT_SECRET=your-client-secret
MS_MAILBOX_USER_ID=COE.BIDS@sysco.com
```

The Azure AD app requires `Mail.Send` and `Mail.ReadWrite` application permissions on the target mailbox.

### Database — SQLite

```dotenv
DB_BACKEND=sqlite
DATABASE_URL=sqlite+aiosqlite:///./sysco_rfp.db
```

Then run Alembic to create the schema:

```bash
alembic upgrade head
```

### Database — PostgreSQL

```dotenv
DB_BACKEND=postgres
DATABASE_URL=postgresql+asyncpg://sysco:password@localhost:5432/sysco_rfp
```

```bash
alembic upgrade head
```

> When `DB_BACKEND=json` (the default), Alembic is never invoked and the JSON flat files in `data/` are the source of truth.

---

## Data Files

All JSON files live in `backend_py/data/`. Run `python setup_data.py` once to copy them from the Node.js `backend/data/` directory.

| File | Description |
|------|-------------|
| `bids.json` | Active bids (master list) |
| `suppliers.json` | Supplier master — categories, segments, bounce flags |
| `lineItems.json` | Line items per bid, linked by `bidId` |
| `emailThreads.json` | Email threads per bid — inbound and outbound |
| `pricingData.json` | AI-extracted supplier pricing responses |
| `documents.json` | Document vault metadata |
| `submissions.json` | Supplier portal pricing submissions (`dict[bidId, list]`) |
| `portalTemplates.json` | Predefined portal form templates |
| `unmatchedEmails.json` | Inbound IMAP emails that could not be matched to a bid |

> `backend/data/` is the source of truth when both backends run in parallel. After editing JSON files directly, restart the Python server to clear any in-memory cache.

---

## Running Tests

```bash
# Run all tests
pytest

# Specific test groups
pytest tests/routers/              # Route integration tests
pytest tests/services/             # LLM provider + parser unit tests
pytest tests/repositories/         # Concurrent write safety tests

# Verbose output
pytest -v --tb=short

# With coverage
pytest --cov=. --cov-report=term-missing
```

Test isolation is handled by the `tmp_data_dir` and `client` fixtures in `tests/conftest.py`. Each test gets its own temporary directory with fresh seed JSON files; repositories and the LLM service are patched via `patch()` on `dependencies.*` module attributes. FastAPI's lifespan is bypassed (no poller or scheduler during tests).

`asyncio_mode = "auto"` in `pyproject.toml` — no `@pytest.mark.asyncio` decorator is needed on test functions.

---

## Code Quality

```bash
# Lint + auto-fix
ruff check . --fix

# Format
ruff format .

# Type check (strict)
mypy .

# Install pre-commit hooks (optional — runs ruff + mypy on every git commit)
pre-commit install
```

Configuration lives in `pyproject.toml`. Ruff enforces line length 100, isort, bugbear, and simplification rules. MyPy runs in strict mode with the pydantic plugin enabled.

---

## Key Architectural Notes

- **Concurrent write safety** — `repositories/base.py` maintains a module-level `dict[Path, asyncio.Lock]`. Every JSON file operation acquires the lock for that path, preventing concurrent request handlers from corrupting file contents.

- **FastAPI route ordering** — `GET /api/bids/portal-templates` is declared *before* `GET /api/bids/{bid_id}` in `routers/bids.py`. FastAPI matches routes in declaration order; reversing this would cause the literal string `"portal-templates"` to be interpreted as a `bid_id`.

- **Secrets never logged** — all credentials (`ANTHROPIC_API_KEY`, `EMAIL_APP_PASSWORD`, etc.) are `pydantic.SecretStr`. `.get_secret_value()` is only called at the point of use, never stored in log output or error messages.

- **Supplier search index** — `routers/suppliers.py` maintains a module-level sorted `(token, supplier_id)` pair list built from all supplier text fields (name, category, subcategories, tags, segments, notes). `GET /api/suppliers/search` uses `bisect` binary search for O(log n) prefix lookup — scales to 100k+ suppliers with < 5ms per query. Index is rebuilt lazily on the first request after startup and invalidated automatically when a new supplier is created.

- **AI supplier auto-populate** — `POST /api/suppliers/auto-populate` scores suppliers in business-priority order using `_score_supplier()` in `routers/suppliers.py`:
  1. **Category gate** (hard fail) — supplier must match at least one needed category (mapped from RFP item categories via `CATEGORY_MAP`); Brokers always pass. Suppliers that fail the gate are excluded entirely (score 0, not shown).
  2. **Compliance** — 50 pts. Fraction of the bid's required compliance flags found in the supplier's tags. A supplier holding *more* certs than the bid requires is never penalized — `comp_hits / len(bid_flags)` counts only the bid's flags.
  3. **Segment** — 30 pts. Binary bonus if supplier serves the bid's segment or has `"All"` in segments.
  4. **Text (TF-IDF)** — 20 pts. IDF-weighted token overlap between the bid query (itemCategories + segment + complianceFlags) and composite supplier text (name, category, subcategories, tags, segments, notes). IDF computed once per request from the full supplier corpus via `_compute_idf()`, so common tokens ("food", "service") are downweighted relative to specific ones ("halal", "k-12").

  `matchReasons` lists the matched compliance tag names explicitly (e.g., `"Compliance: Child Nutrition, Buy American"`). No external API calls — standard library only.

- **Background tasks at startup** — four backfill coroutines and the demo data injector run via `asyncio.create_task()` during lifespan startup. They are non-blocking and do not delay server readiness.

- **Inbox poller (Microsoft Graph)** — long-lived asyncio task (15-second poll). Uses an **incremental high-water mark** persisted in `data/pollState.json`: each cycle fetches `receivedDateTime ≥ lastPolledAt − 10min` (no `isRead` dependency, no fixed window), dedups by `uid`, then advances the mark. Cold start falls back to `POLL_LOOKBACK_HOURS` (72), clamped by `MAX_LOOKBACK_DAYS` (30). **Single-flighted** via `asyncio.Lock` so the 15s loop and manual `poll-now` can't overlap. 3-tier bid matching: (1) bid ID pattern in subject, (2) cleaned subject matches stored solicitation subject, (3) all significant words from customer name appear in subject. Bounce detection parses MAILER-DAEMON headers. **Run on a single instance** (`min/max-instances=1`) — the JSON files and `pollState.json` are per-instance. The frontend Email Repo tab (`EmailRepoTab.jsx`) polls `GET /api/bids/{id}/emails/by-supplier` every 15 s (and on window focus) so replies added by this poller appear in the open thread without a reload.

- **Auto-reminder scheduler** — APScheduler `AsyncIOScheduler` fires `run_auto_reminders()` every hour. Enforces a 3-day minimum gap between reminder runs per bid. Targets solicited suppliers with status `Awaiting` who have not submitted via portal and have not replied via email.

- **`setup_data.py` is idempotent** — re-running it will not overwrite an existing `.env` and will not clear existing data files; it only copies files that are missing.

---

*Built by EXL Service | Sysco BID/RFP POC | July 2026 | Confidential*
