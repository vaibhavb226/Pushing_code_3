"""
Public supplier portal API — all /api/submit/* endpoints.

These routes are PUBLIC (no X-API-Key required).
PUBLIC_PREFIXES in middleware/auth.py must include "/api/v1/submit/" and "/api/submit/".
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from datetime import datetime, timezone
from typing import Any

import aiofiles
import structlog
from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile

from config import get_settings
from dependencies import (
    UPLOADS_DIR,
    get_bids_repo,
    get_email_threads_repo,
    get_gcs_client,
    get_line_items_repo,
    get_submissions_repo,
)
from repositories.bids_repo import BidsRepository
from repositories.email_threads_repo import EmailThreadsRepository
from repositories.line_items_repo import LineItemsRepository
from repositories.submissions_repo import SubmissionsRepository
from utils.file_utils import safe_filename

log = structlog.get_logger()
router = APIRouter(tags=["portal"])


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# GET /api/submit/:bidId — bid details for submission form
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}", response_model=dict[str, Any])
async def get_portal_bid(
    bid_id: str,
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    """Public: Return bid details and line items for the supplier pricing submission form.

    Returns only public-safe fields (no internal dates, COE notes, or supplier list).
    Includes `portalConfig` so the form can render custom fields.
    """
    bid = await bids_repo.find_by_id(bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    line_items = await line_items_repo.get_for_bid(bid_id)

    return {
        "bidId": bid["id"],
        "customerName": bid.get("customer", ""),
        "segment": bid.get("segment", ""),
        "dueDate": bid.get("customerDue", ""),
        "complianceRequirements": bid.get("compliance", []),
        "itemCategories": bid.get("itemCategories", []),
        "portalConfig": bid.get("portalConfig"),
        "lineItems": [
            {
                "id": li["id"],
                "bidItem": li.get("bidItem", ""),
                "mpcCode": li.get("mpcCode", ""),
                "description": li.get("description", ""),
                "brand": li.get("brand", ""),
                "pack": li.get("pack", ""),
                "size": li.get("size", ""),
                "unit": li.get("unit", ""),
                "category": li.get("category", ""),
                "buyAmerican": li.get("buyAmerican", False),
                "childNutrition": li.get("childNutrition", False),
                "pfsRequired": li.get("pfsRequired", False),
            }
            for li in line_items
        ],
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# POST /api/submit/:bidId — supplier pricing submission
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.post("/{bid_id}", response_model=dict[str, Any], status_code=201)
async def submit_pricing(
    bid_id: str,
    supplier_name: str = Form("", alias="supplierName"),
    supplier_email: str = Form("", alias="supplierEmail"),
    contact_name: str = Form("", alias="contactName"),
    phone: str = Form("", alias="phone"),
    line_items_json: str = Form("[]", alias="lineItemPrices"),
    notes: str = Form(""),
    pricing_file: UploadFile | None = File(None, alias="pricingFile"),
    bids_repo: BidsRepository = Depends(get_bids_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> dict[str, Any]:
    """Public: Submit supplier pricing for a bid via the portal."""
    bid = await bids_repo.find_by_id(bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    try:
        raw_items: list[dict[str, Any]] = json.loads(line_items_json)
    except json.JSONDecodeError:
        raw_items = []

    # Count priced vs no-bid — matches Node.js: any price field > 0 counts (G3)
    def _is_priced(li: dict[str, Any]) -> bool:
        if li.get("noBid"):
            return False
        return any(
            float(li.get(f) or 0) > 0
            for f in ("unitPrice", "casePrice", "deliveredPrice", "fobPrice")
        )

    priced_count = sum(1 for li in raw_items if _is_priced(li))
    no_bid_count = sum(1 for li in raw_items if li.get("noBid"))
    dl_count     = sum(1 for li in raw_items if _is_priced(li) and li.get("devType") == "DL")
    allw_count   = sum(1 for li in raw_items if _is_priced(li) and li.get("devType") == "ALLW")
    other_count  = max(0, priced_count - dl_count - allw_count)

    # Save pricing file — local disk always; also GCS when configured (Cloud Run safe)
    pricing_file_name = ""
    pricing_file_path = ""   # gs:// URI when GCS available, else "uploads/{fname}" relative path
    if pricing_file:
        content = await pricing_file.read()
        ts = int(time.time() * 1000)
        ext = safe_filename(pricing_file.filename or "upload")
        fname = f"{bid_id}_Portal_{ts}_{ext}"
        dest = UPLOADS_DIR / fname
        async with aiofiles.open(dest, "wb") as f:
            await f.write(content)
        pricing_file_name = fname

        # Upload to GCS so extraction works on any Cloud Run instance
        cfg = get_settings()
        gcs = get_gcs_client(cfg)
        if gcs and cfg.gcs_bucket:
            try:
                object_name = f"{bid_id}/Portal/{bid_id}/{fname}"
                blob = gcs.bucket(cfg.gcs_bucket).blob(object_name)
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(
                    None,
                    lambda: blob.upload_from_string(content, content_type="application/octet-stream"),
                )
                pricing_file_path = f"gs://{cfg.gcs_bucket}/{object_name}"
            except Exception as exc:
                log.warning("portal.gcs_upload_failed", fname=fname, error=str(exc))
                pricing_file_path = f"uploads/{fname}"
        else:
            pricing_file_path = f"uploads/{fname}"

    confirmation_id = f"BID-{bid_id}-{uuid.uuid4().hex[:8].upper()}"
    thread_id       = f"THREAD-{bid_id}-{int(time.time() * 1000)}"
    now             = datetime.now(timezone.utc).isoformat()
    settings        = get_settings()
    portal_url      = f"{settings.portal_base_url}/submit/{bid_id}/thread/{thread_id}"

    # Build auto-generated submission summary (matches Node.js body format) (G9)
    body_lines = [
        f"{supplier_name} submitted pricing via the FoodCorp Supplier Portal.",
        f"Submitted pricing for {priced_count} item(s):",
    ]
    if dl_count:
        body_lines.append(f"  {dl_count} items with Delivered pricing (DL)")
    if allw_count:
        body_lines.append(f"  {allw_count} items with Allowance pricing (ALLW)")
    if other_count:
        body_lines.append(f"  {other_count} items priced (other)")
    if no_bid_count:
        body_lines.append(f"  {no_bid_count} items No Bid")
    if notes:
        body_lines.append(f"\nNotes: {notes}")
    submission_summary = "\n".join(body_lines)

    # Detailed emailThreads body (includes contact info + links, matches Node.js)
    email_body_lines = [
        supplier_name,
        "",
        f"Contact: {contact_name} <{supplier_email}>" + (f" | Phone: {phone}" if phone else ""),
        f"Confirmation ID: {confirmation_id}",
        f"Thread ID: {thread_id}",
        "",
    ] + body_lines[1:] + [
        "",
        f"View conversation: {portal_url}",
    ]
    email_body = "\n".join(email_body_lines)

    # Initial message — matches Node.js which creates one inbound message at submission time (G4)
    initial_message: dict[str, Any] = {
        "id": str(uuid.uuid4()),
        "direction": "inbound",
        "from": supplier_email,
        "fromName": contact_name or supplier_name,
        "body": submission_summary,
        "attachments": [pricing_file_name] if pricing_file_name else [],
        "timestamp": now,
        "readByBidCOE": False,
    }

    # Resolve supplierId now (before append) so it's stored on the bids row
    supplier_id = _find_supplier_id(bid, supplier_email)

    # Persist submission — G1 (phone), G2 (count fields), G4 (initial message)
    submission: dict[str, Any] = {
        "confirmationId": confirmation_id,
        "threadId":       thread_id,
        "submittedAt":    now,
        "supplierName":   supplier_name,
        "supplierEmail":  supplier_email,
        "supplierId":     supplier_id,
        "contactName":    contact_name,
        "phone":          phone,
        "lineItems":      raw_items,
        "pricingFile":    pricing_file_name,
        "pricedCount":    priced_count,
        "noBidCount":     no_bid_count,
        "dlCount":        dl_count,
        "allwCount":      allw_count,
        "otherPricedCount": other_count,
        "notes":          notes,
        "messages":       [initial_message],
    }
    # Build email mirror record before parallel writes
    email_record: dict[str, Any] = {
        "id":               f"E-PORTAL-{uuid.uuid4().hex[:8].upper()}",
        "bidId":            bid_id,
        "direction":        "inbound",
        "supplierId":       supplier_id,
        "supplierName":     supplier_name,
        "supplierEmail":    supplier_email,
        "from":             f"{contact_name or supplier_name} <{supplier_email}>",
        "to":               "bids@foodcorp.com",
        "bcc":              [],
        "subject":          f"Pricing Submission (Portal): {bid_id} — {bid.get('customer', '')} — {supplier_name}",
        "body":             email_body,
        "date":             now,
        "attachments":      [pricing_file_name] if pricing_file_name else [],
        "pricingFilePath":  pricing_file_path if pricing_file_path else None,
        "tags":             ["Response", "Pricing", "portal-submission"],
        "read":             False,
        "analysisResult":   None,
        "isBounce":         False,
        "portalSubmission": True,
        "threadId":         thread_id,
        "confirmationId":   confirmation_id,
    }
    # Persist submission + mirror email record — independent writes, run in parallel
    await asyncio.gather(
        submissions_repo.append_for_bid(bid_id, submission),
        email_threads_repo.append(email_record),
    )

    # Update supplier status + channel (G11, G12) — must follow append so threadId is stored
    await _update_supplier_responded(bid_id, supplier_email, thread_id, bids_repo)

    log.info("portal.submission_received", bid_id=bid_id, supplier=supplier_name, priced=priced_count)

    return {
        "confirmationId":   confirmation_id,
        "threadId":         thread_id,
        "submittedAt":      now,
        "supplierName":     supplier_name,
        "customerName":     bid.get("customer", ""),
        "pricedCount":      priced_count,
        "noBidCount":       no_bid_count,
        "dlCount":          dl_count,
        "allwCount":        allw_count,
        "otherPricedCount": other_count,
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# GET /api/submit/:bidId/submissions — portal submission summaries for SuppliersTab
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}/submissions", response_model=list[dict[str, Any]])
async def get_submissions(
    bid_id: str,
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
) -> list[dict[str, Any]]:
    """List portal submission summaries for a bid — used by the Supplier List tab channel column."""
    all_subs = await submissions_repo.get_for_bid(bid_id)
    return [
        {
            "confirmationId": s.get("confirmationId"),
            "threadId":       s.get("threadId"),
            "supplierName":   s.get("supplierName"),
            "supplierEmail":  s.get("supplierEmail"),
            "submittedAt":    s.get("submittedAt"),
            "pricedCount":    s.get("pricedCount", 0),
            "noBidCount":     s.get("noBidCount", 0),
            "messageCount":   len(s.get("messages", [])),
            "lastActive":     _last_message_time(s),
            # G22: removed hardcoded `accessed: True` — frontend uses messageCount for activity
        }
        for s in all_subs
    ]


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# GET /api/submit/:bidId/thread/:threadId — conversation thread (email-gated)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}/thread/{thread_id}", response_model=dict[str, Any])
async def get_thread(
    bid_id: str,
    thread_id: str,
    email: str = Query(""),
    bids_repo: BidsRepository = Depends(get_bids_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    """Public: Return a portal thread (email-gated). Marks COE messages as read by supplier.

    Query param `?email=` is REQUIRED — must match the submission's supplierEmail (G21).
    Returns full thread with messages, line item pricing, and RFP line items for reference.
    Also polls `messageCount` + `lastUpdated` for the 15-second frontend poller.
    """
    all_subs = await submissions_repo.get_for_bid(bid_id)
    sub = next((s for s in all_subs if s.get("threadId") == thread_id), None)
    if not sub:
        raise HTTPException(status_code=404, detail="Thread not found")

    # G21 — email gate always required (matches Node.js: 401 if missing, 403 if wrong)
    if not email:
        raise HTTPException(
            status_code=401,
            detail={"error": "Email address required to view this thread", "needsEmail": True},
        )
    if email.lower() != sub.get("supplierEmail", "").lower():
        raise HTTPException(
            status_code=403,
            detail={"error": "Email address does not match submission", "needsEmail": True},
        )

    # Mark COE outbound messages as read by supplier
    messages = sub.get("messages", [])
    changed = False
    for msg in messages:
        if msg.get("direction") == "outbound" and not msg.get("readBySupplier"):
            msg["readBySupplier"] = True
            changed = True

    if changed:
        def mark_read(s: dict[str, Any]) -> dict[str, Any]:
            return {**s, "messages": messages}
        await submissions_repo.update_submission(bid_id, thread_id, mark_read)

    line_items, bid = await asyncio.gather(
        line_items_repo.get_for_bid(bid_id),
        bids_repo.find_by_id(bid_id),
    )

    return {
        "confirmationId": sub.get("confirmationId"),
        "threadId":       thread_id,
        "supplierName":   sub.get("supplierName"),
        "supplierEmail":  sub.get("supplierEmail"),
        "contactName":    sub.get("contactName"),
        "submittedAt":    sub.get("submittedAt"),
        "pricedCount":    sub.get("pricedCount", 0),
        "noBidCount":     sub.get("noBidCount", 0),
        "notes":          sub.get("notes", ""),
        "pricingFile":    sub.get("pricingFile"),
        "lineItems":      sub.get("lineItems", []),
        "messages":       messages,
        "messageCount":   len(messages),
        "lastUpdated":    _last_message_time(sub),
        "customerName":   bid.get("customer", "") if bid else "",
        "bidId":          bid_id,
        "rfpLineItems": [
            {
                "id":          li["id"],
                "bidItem":     li.get("bidItem"),
                "description": li.get("description"),
                "category":    li.get("category"),
            }
            for li in line_items
        ],
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# POST /api/submit/:bidId/message — supplier follow-up message
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.post("/{bid_id}/message", response_model=dict[str, Any])
async def post_message(
    bid_id: str,
    thread_id: str = Form(..., alias="threadId"),
    message_text: str = Form(..., alias="message"),
    supplier_email: str = Form("", alias="supplierEmail"),
    supplier_name: str = Form("", alias="supplierName"),
    attachment: UploadFile | None = File(None, alias="file"),
    bids_repo: BidsRepository = Depends(get_bids_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> dict[str, Any]:
    """Public: Supplier posts a follow-up message on an existing portal thread."""
    all_subs = await submissions_repo.get_for_bid(bid_id)
    sub = next((s for s in all_subs if s.get("threadId") == thread_id), None)
    if not sub:
        raise HTTPException(status_code=404, detail="Thread not found")

    # Save attached file if present — dual-write to disk and GCS (same pattern as submit_pricing)
    attachment_name = ""
    if attachment:
        content = await attachment.read()
        ts = int(time.time() * 1000)
        ext = safe_filename(attachment.filename or "upload")
        attachment_name = f"{bid_id}_PortalMsg_{ts}_{ext}"
        dest = UPLOADS_DIR / attachment_name
        async with aiofiles.open(dest, "wb") as f:
            await f.write(content)

        cfg = get_settings()
        gcs = get_gcs_client(cfg)
        if gcs and cfg.gcs_bucket:
            try:
                obj_name = f"{bid_id}/PortalMsg/{attachment_name}"
                blob = gcs.bucket(cfg.gcs_bucket).blob(obj_name)
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(
                    None,
                    lambda: blob.upload_from_string(content, content_type="application/octet-stream"),
                )
            except Exception as exc:
                log.warning("portal_message.gcs_upload_failed", fname=attachment_name, error=str(exc))

    msg_id    = f"MSG-{uuid.uuid4().hex[:12].upper()}"
    timestamp = datetime.now(timezone.utc).isoformat()
    new_msg: dict[str, Any] = {
        "id":           msg_id,
        "direction":    "inbound",
        "from":         sub.get("supplierEmail", supplier_email),
        "fromName":     sub.get("contactName") or sub.get("supplierName") or supplier_name,
        "body":         message_text,
        "attachments":  [attachment_name] if attachment_name else [],
        "timestamp":    timestamp,
        "readByBidCOE": False,
    }

    def append_msg(s: dict[str, Any]) -> dict[str, Any]:
        msgs = list(s.get("messages", []))
        msgs.append(new_msg)
        return {**s, "messages": msgs}

    await submissions_repo.update_submission(bid_id, thread_id, append_msg)

    # Look up bid customer name for subject (G18) and supplierId (G14)
    bid = await bids_repo.find_by_id(bid_id)
    customer = bid.get("customer", bid_id) if bid else bid_id
    actual_email = sub.get("supplierEmail", supplier_email)
    supplier_id = _find_supplier_id(bid, actual_email) if bid else None
    display_from = sub.get("contactName") or sub.get("supplierName") or supplier_name

    # Mirror to emailThreads.json — G14–G20 (supplierId, to, bcc, confirmationId, analysisResult, subject, tags, from)
    mirror: dict[str, Any] = {
        "id":               f"E-PORTAL-MSG-{uuid.uuid4().hex[:8].upper()}",
        "bidId":            bid_id,
        "direction":        "inbound",
        "supplierId":       supplier_id,
        "supplierName":     sub.get("supplierName"),
        "supplierEmail":    actual_email,
        "from":             f"{display_from} <{actual_email}>",
        "to":               "bids@foodcorp.com",
        "bcc":              [],
        "subject":          f"Re: {sub.get('supplierName')} — {customer} (Portal)",
        "body":             message_text,
        "date":             timestamp,
        "attachments":      [attachment_name] if attachment_name else [],
        "tags":             ["Response", "Q&A", "portal-message"],
        "read":             False,
        "analysisResult":   None,
        "isBounce":         False,
        "portalSubmission": True,
        "threadId":         thread_id,
        "confirmationId":   sub.get("confirmationId"),
    }
    await email_threads_repo.append(mirror)

    # G13: return `success` not `ok`
    return {"success": True, "messageId": msg_id}




# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# POST /api/submit/:bidId/submissions/from-extraction — COE internal
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.post("/{bid_id}/submissions/from-extraction", response_model=dict[str, Any])
async def create_submission_from_extraction(
    bid_id: str,
    body: dict[str, Any],
    bids_repo: BidsRepository = Depends(get_bids_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
) -> dict[str, Any]:
    """COE internal: create or update a submission record from email pricing extraction.

    Called fire-and-forget from PricingExtractModal after the per-row PATCH loop.
    Requires PG backend (no-ops gracefully on JSON fallback).
    """
    if not hasattr(submissions_repo, "upsert_from_extraction"):
        return {"confirmationId": None, "lineItemCount": 0, "skipped": True}

    email_id = body.get("emailId") or ""
    if not email_id:
        raise HTTPException(status_code=400, detail="emailId is required")

    bid = await bids_repo.find_by_id(bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    line_items: list[dict[str, Any]] = body.get("lineItems") or []
    priced_count = sum(1 for li in line_items if li.get("casePrice") is not None and not li.get("noBid"))
    no_bid_count = sum(1 for li in line_items if li.get("noBid"))
    now = datetime.now(timezone.utc).isoformat()

    supplier_id = _find_supplier_id(bid, body.get("supplierEmail") or "")

    submission: dict[str, Any] = {
        "supplierName":  body.get("supplierName") or "",
        "supplierEmail": body.get("supplierEmail") or "",
        "supplierId":    supplier_id,
        "emailId":       email_id,
        "pricingFile":   body.get("pricingFile") or "",
        "pricedCount":   priced_count,
        "noBidCount":    no_bid_count,
        "notes":         "Extracted from email attachment",
        "submittedAt":   now,
        "lineItems":     line_items,
    }

    result = await submissions_repo.upsert_from_extraction(bid_id, submission)
    log.info(
        "extraction.submission_created",
        bid_id=bid_id, email_id=email_id, line_items=len(line_items),
    )
    return result


# ── Helpers ────────────────────────────────────────────────────────────────────

def _find_supplier_id(bid: dict[str, Any], email: str) -> str | None:
    for s in bid.get("solicitedSuppliers", []):
        if s.get("email", "").lower() == email.lower():
            return s.get("supplierId")
    return None


async def _update_supplier_responded(
    bid_id: str,
    supplier_email: str,
    thread_id: str,
    bids_repo: BidsRepository,
) -> None:
    today = datetime.now(timezone.utc).date().isoformat()

    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        for s in bid.get("solicitedSuppliers", []):
            if s.get("email", "").lower() == supplier_email.lower():
                # G12: only promote Awaiting → Responded (matches Node.js)
                if s.get("status") == "Awaiting":
                    s["status"] = "Responded"
                # G11: update channel to Portal / Both
                prev_channel = s.get("channel", "Email")
                if prev_channel in ("Email", "Both"):
                    s["channel"] = "Both"
                else:
                    s["channel"] = "Portal"
                s["threadId"]     = thread_id
                s["lastActivity"] = today
        return bid

    await bids_repo.update_by_id(bid_id,updater)


def _last_message_time(sub: dict[str, Any]) -> str:
    messages = sub.get("messages", [])
    if messages:
        return messages[-1].get("timestamp", sub.get("submittedAt", ""))
    return sub.get("submittedAt", "")
