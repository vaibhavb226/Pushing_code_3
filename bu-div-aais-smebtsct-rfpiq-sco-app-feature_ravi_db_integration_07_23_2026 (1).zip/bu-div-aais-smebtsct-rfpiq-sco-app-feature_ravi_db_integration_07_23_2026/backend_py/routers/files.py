"""
Serve email attachment files stored in GCS, with local-disk fallback for dev.

The frontend constructs download URLs as:
    /api/files/{bid_id}/attachments/{savedName}

where savedName is the filename (e.g. INBOUND_A1B2C3D4_pricing.xlsx).
bid_id is accepted for URL compatibility but not used for lookup — all inbound
attachments land flat in UPLOADS_DIR and at gs://{bucket}/inbound/{savedName}.

Resolution order:
  1. GCS at inbound/{savedName} — primary when GCS_BUCKET is configured
  2. Local disk (UPLOADS_DIR / savedName) — fallback for local dev
  3. 404 if neither location has the file

GCS lookup uses Path(filename).name (strips directory traversal, preserves all
other characters) to match exactly how _download_attachments stores blobs —
without safe_filename sanitization which would strip apostrophes, commas, etc.
Local disk uses safe_filename for security (prevents non-word chars in FS paths).
"""
from __future__ import annotations

import asyncio
from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse, Response

from config import get_settings
from dependencies import UPLOADS_DIR, get_gcs_client
from utils.file_utils import safe_filename

router = APIRouter()

_MIME_MAP = {
    ".pdf":  "application/pdf",
    ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ".xls":  "application/vnd.ms-excel",
    ".csv":  "text/csv",
    ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ".doc":  "application/msword",
}


def _mime_for(filename: str) -> str:
    return _MIME_MAP.get(Path(filename).suffix.lower(), "application/octet-stream")


@router.get("/files/{bid_id}/attachments/{filename}")
async def get_email_attachment(bid_id: str, filename: str) -> Response:
    """Download an inbound email attachment by its saved filename."""
    # GCS blobs are stored with the raw saved_name — no sanitization applied by
    # _download_attachments. Use Path().name only (strips directory traversal,
    # preserves special chars like apostrophes/commas) so the lookup matches.
    gcs_name = Path(filename).name
    # Local disk uses full safe_filename to prevent dangerous chars in FS paths.
    local_safe = safe_filename(filename)
    settings = get_settings()

    # 1. GCS primary — try inbound/{savedName}
    gcs = get_gcs_client(settings)
    if gcs and settings.gcs_bucket:
        try:
            loop = asyncio.get_event_loop()
            blob = gcs.bucket(settings.gcs_bucket).blob(f"inbound/{gcs_name}")
            # Direct download — no separate exists() call (saves one GCS round-trip).
            # google.cloud.storage raises google.cloud.exceptions.NotFound on missing blob.
            content = await loop.run_in_executor(None, blob.download_as_bytes)
            return Response(
                content,
                media_type=_mime_for(gcs_name),
                headers={"Content-Disposition": f'attachment; filename="{gcs_name}"'},
            )
        except Exception:
            pass  # blob missing or GCS unavailable — fall through to local

    # 2. Local disk fallback (dev environment or same-instance hit)
    local_path = UPLOADS_DIR / local_safe
    if local_path.exists():
        return FileResponse(
            local_path,
            filename=local_safe,
            media_type=_mime_for(local_safe),
        )

    raise HTTPException(status_code=404, detail=f"Attachment {gcs_name!r} not found")
