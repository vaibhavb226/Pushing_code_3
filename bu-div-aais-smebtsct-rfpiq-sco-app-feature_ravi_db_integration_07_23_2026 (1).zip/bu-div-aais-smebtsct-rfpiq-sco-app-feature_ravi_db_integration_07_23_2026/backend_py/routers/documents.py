"""
GET   /api/documents         — list with filters
GET   /api/documents/:id     — single document
POST  /api/documents/upload  — upload file + add metadata
PATCH /api/documents/:id/vault — toggle Filed ↔ Extracted
"""
from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import Any

import asyncio

import aiofiles
import structlog
from fastapi import APIRouter, Depends, Form, HTTPException, Query, UploadFile

from config import get_settings
from dependencies import UPLOADS_DIR, get_documents_repo, get_gcs_client
from repositories.documents_repo import DocumentsRepository
from utils.file_utils import format_file_size, safe_filename

log = structlog.get_logger()
router = APIRouter(tags=["documents"])


@router.get("", response_model=list[dict[str, Any]])
async def list_documents(
    bid_id: str | None = Query(None, alias="bidId"),
    supplier: str | None = None,
    category: str | None = None,
    doc_type: str | None = Query(None, alias="type"),
    tag: str | None = None,
    search: str | None = None,
    repo: DocumentsRepository = Depends(get_documents_repo),
) -> list[dict[str, Any]]:
    """List documents in the vault with optional filters.

    Query params: `?bidId=B2600042&type=RFP&supplier=Schwan&search=chicken`
    """
    docs = await repo.load()

    if bid_id:
        docs = [d for d in docs if d.get("bidId") in (bid_id, "ALL")]
    if supplier:
        docs = [d for d in docs if supplier.lower() in d.get("supplier", "").lower()]
    if category:
        docs = [d for d in docs if d.get("supplierCategory") == category]
    if doc_type:
        docs = [d for d in docs if d.get("documentType") == doc_type]
    if tag:
        docs = [d for d in docs if tag in d.get("tags", [])]
    if search:
        term = search.lower()
        docs = [
            d for d in docs
            if term in d.get("fileName", "").lower()
            or term in d.get("supplier", "").lower()
            or term in d.get("description", "").lower()
        ]
    return docs


@router.get("/{doc_id}", response_model=dict[str, Any])
async def get_document(
    doc_id: str,
    repo: DocumentsRepository = Depends(get_documents_repo),
) -> dict[str, Any]:
    """Retrieve a single document vault record by ID."""
    doc = await repo.find_one(lambda d: d.get("id") == doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail=f"Document {doc_id!r} not found")
    return doc


@router.post("/upload", response_model=dict[str, Any], status_code=201)
async def upload_document(
    file: UploadFile,
    bid_id: str | None = Form(None, alias="bidId"),
    supplier: str | None = Form(None),
    document_type: str = Form("Other", alias="documentType"),
    notes: str = Form(""),
    repo: DocumentsRepository = Depends(get_documents_repo),
) -> dict[str, Any]:
    """Upload a file to the Document Vault.

    Multipart form fields: `file` (binary), `bidId` (optional), `supplier` (optional),
    `documentType` (RFP | Item List | Pricing | Spec Sheet | Compliance | Other), `notes`.
    File is saved to `uploads/` and a metadata record is created in `documents.json`.
    """
    content = await file.read()
    cfg = get_settings()
    timestamp = int(time.time() * 1000)
    fname = safe_filename(file.filename or "upload")
    saved_name = f"{timestamp}_{fname}"
    dest = UPLOADS_DIR / saved_name

    async with aiofiles.open(dest, "wb") as fh:
        await fh.write(content)

    # Upload to GCS when configured
    stored_path = f"uploads/{saved_name}"
    gcs_client = get_gcs_client(cfg)
    if gcs_client:
        from datetime import datetime as _dt
        date_str = _dt.utcnow().strftime("%Y-%m-%d")
        ctx_id = bid_id or "vault"
        path_type = document_type.replace(" ", "")
        object_name = f"{ctx_id}/{path_type}/{ctx_id}/{date_str}/{saved_name}"
        blob = gcs_client.bucket(cfg.gcs_bucket).blob(object_name)
        blob.metadata = {
            "bid-id": bid_id or "",
            "document-type": document_type,
            "supplier": supplier or "",
        }
        mime = file.content_type or "application/octet-stream"
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(
                None, lambda: blob.upload_from_string(content, content_type=mime)
            )
            stored_path = f"gs://{cfg.gcs_bucket}/{object_name}"
        except Exception as exc:
            log.warning("document.gcs_upload_failed", error=str(exc))

    from datetime import date
    doc_id = f"DOC-{uuid.uuid4().hex[:8].upper()}"
    ext = Path(fname).suffix.lstrip(".")
    doc_record: dict[str, Any] = {
        "id": doc_id,
        "fileName": fname,
        "fileType": ext,
        "sizeKb": len(content) // 1024,
        "supplier": supplier or "",
        "supplierId": None,
        "bidId": bid_id or "ALL",
        "documentType": document_type,
        "tags": [],
        "uploadDate": date.today().isoformat(),
        "uploadedBy": "System",
        "status": "Filed",
        "filePath": stored_path,
        "description": notes,
    }
    await repo.append(doc_record)
    log.info("document.uploaded", id=doc_id, file=fname, gcs=stored_path.startswith("gs://"))

    # Fire-and-forget: index document into document_vectors (pgvector).
    # Works for both GCS and local paths — document_indexer handles both.
    # Guarded by db_host so it's a no-op in local JSON-only dev mode.
    if cfg.db_host:
        from services.document_indexer import index_document_background
        asyncio.ensure_future(
            index_document_background(doc_record, gcs_client, cfg)
        )

    return doc_record


@router.post("/reindex-excel", response_model=dict[str, Any], status_code=202)
async def reindex_excel_documents(
    repo: DocumentsRepository = Depends(get_documents_repo),
) -> dict[str, Any]:
    """Re-index all Excel documents using the row-aware Excel chunker.

    Fire-and-forget: queues background indexing tasks and returns immediately.
    Each task deletes old chunks and inserts new row-keyed ones (idempotent).
    Requires DB mode (DB_HOST configured) — returns 503 otherwise.
    """
    cfg = get_settings()
    if not cfg.db_host:
        raise HTTPException(503, "DB not configured — reindex only available in DB mode")

    docs = await repo.load()
    excel_docs = [
        d for d in docs
        if Path(d.get("fileName", "")).suffix.lower() in (".xlsx", ".xls")
    ]

    if not excel_docs:
        return {"queued": 0, "message": "No Excel documents found"}

    from services.document_indexer import index_document_background
    gcs_client = get_gcs_client(cfg)
    for doc in excel_docs:
        asyncio.ensure_future(index_document_background(doc, gcs_client, cfg))

    log.info("documents.reindex_excel.queued", count=len(excel_docs))
    return {
        "queued": len(excel_docs),
        "message": f"Queued {len(excel_docs)} Excel documents for re-indexing",
    }


@router.patch("/{doc_id}/vault", response_model=dict[str, Any])
async def toggle_vault(
    doc_id: str,
    repo: DocumentsRepository = Depends(get_documents_repo),
) -> dict[str, Any]:
    """Toggle a document's vault status between `Filed` and `Extracted`."""
    def toggle(doc: dict[str, Any]) -> dict[str, Any]:
        doc["status"] = "Filed" if doc.get("status") == "Extracted" else "Extracted"
        return doc

    updated = await repo.update_one(lambda d: d.get("id") == doc_id, toggle)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Document {doc_id!r} not found")
    return updated
