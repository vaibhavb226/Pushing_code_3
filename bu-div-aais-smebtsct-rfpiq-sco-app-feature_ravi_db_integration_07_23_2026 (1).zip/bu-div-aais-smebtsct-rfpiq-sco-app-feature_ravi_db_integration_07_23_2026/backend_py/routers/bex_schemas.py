"""Pydantic v2 schemas for BEX AI parse response."""
from __future__ import annotations

import re
from typing import Optional

from pydantic import BaseModel, Field, field_validator

# Canonical bid segments (lower-case key → display value). Anything else → None.
_SEGMENTS: dict[str, str] = {
    "k-12": "K-12",
    "k12": "K-12",
    "dod": "DoD",
    "university": "University",
    "healthcare": "Healthcare",
    "restaurant": "Restaurant",
    "lodging": "Lodging",
    "government": "Government",
}

_ISO_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class BEXLineItem(BaseModel):
    line_number: Optional[str] = None
    mpc_code: Optional[str] = None
    uom: Optional[str] = None
    volume: Optional[int] = None
    pack: Optional[str] = None
    size: Optional[str] = None
    brand: Optional[str] = None
    description: str = ""
    category: Optional[str] = None
    storage: Optional[str] = None
    buy_american: Optional[bool] = None
    child_nutrition: Optional[bool] = None
    pfs_required: Optional[bool] = None
    whole_grain: Optional[bool] = None
    halal: Optional[bool] = None
    kosher: Optional[bool] = None
    # Extraction confidence (0-100). Populated downstream, not by the LLM extractor.
    confidence: Optional[int] = None

    @field_validator("volume", mode="before")
    @classmethod
    def _coerce_volume(cls, v: object) -> object:
        """Defensively coerce volume to int — strip commas/units, tolerate floats/strings."""
        if v is None or isinstance(v, int):
            return v
        try:
            cleaned = re.sub(r"[^\d.\-]", "", str(v))
            return int(float(cleaned)) if cleaned not in ("", "-", ".") else None
        except (ValueError, TypeError):
            return None


class BEXMetadata(BaseModel):
    bid_id: Optional[str] = None
    customer_name: Optional[str] = None
    segment: Optional[str] = None
    opco_code: Optional[str] = None
    opco_name: Optional[str] = None
    region: Optional[str] = None
    customer_due_date: Optional[str] = None
    compliance_flags: list[str] = Field(default_factory=list)
    total_items: Optional[int] = None
    parsing_confidence: Optional[int] = None
    file_warning: Optional[str] = None

    @field_validator("segment", mode="before")
    @classmethod
    def _normalise_segment(cls, v: object) -> object:
        """Map to a canonical segment; unknown/blank → None (user fixes on the confirm form)."""
        if not v or not isinstance(v, str):
            return None
        return _SEGMENTS.get(v.strip().lower())

    @field_validator("customer_due_date", mode="before")
    @classmethod
    def _validate_due_date(cls, v: object) -> object:
        """Keep only valid YYYY-MM-DD strings; anything else → None (best-effort, non-fatal)."""
        if not v or not isinstance(v, str):
            return None
        s = v.strip()
        return s if _ISO_DATE_RE.match(s) else None


class BEXResponse(BaseModel):
    metadata: BEXMetadata = Field(default_factory=BEXMetadata)
    line_items: list[BEXLineItem] = Field(default_factory=list)
    supplier_targeting: Optional[dict] = None
    parsing_warnings: list[str] = Field(default_factory=list)
