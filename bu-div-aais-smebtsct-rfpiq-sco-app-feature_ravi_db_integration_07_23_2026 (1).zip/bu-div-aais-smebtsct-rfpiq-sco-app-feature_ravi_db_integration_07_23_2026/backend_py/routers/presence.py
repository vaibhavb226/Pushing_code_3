"""
Global presence API — user locations and heartbeat.

POST /api/presence/update   — upsert current user location (called every 30s + on change)
GET  /api/presence          — return all online users (seen within TTL window)

When the user is viewing a specific bid, the update also fires a pg_notify so
SSE-connected clients for that bid receive a presence_tab event immediately
(without waiting for their own next heartbeat poll).
"""
from __future__ import annotations

import asyncio
import json

from fastapi import APIRouter
from pydantic import BaseModel

from db.connection import get_asyncpg_pool
from services.sse_broadcast import get_online_users, update_user_location

router = APIRouter()


class LocationUpdate(BaseModel):
    sessionId: str = ""  # unique per browser tab; empty string for backward compat with old clients
    name: str
    bidId: str | None = None
    tab: str | None = None
    cellId: str | None = None


@router.post("/update")
async def update_presence(body: LocationUpdate):
    update_user_location(body.sessionId, body.name, body.bidId, body.tab, body.cellId)

    # Notify SSE clients currently watching this bid so they see the tab change immediately
    if body.bidId:
        pool = get_asyncpg_pool()
        if pool:
            event = {
                "type": "presence_tab",
                "bidId": body.bidId,
                "user": body.name,
                "sessionId": body.sessionId,  # lets frontend track per-tab presence independently
                "tab": body.tab,
                "cellId": body.cellId,
            }
            asyncio.ensure_future(_pg_notify(pool, body.bidId, event))

    return {"ok": True}


@router.get("")
async def get_presence():
    return {"users": get_online_users(max_age=60.0)}


async def _pg_notify(pool, bid_id: str, event: dict) -> None:
    try:
        async with pool.acquire() as conn:
            await conn.execute(
                "SELECT pg_notify('bid_events', $1::text)", json.dumps(event)
            )
    except Exception:
        pass
