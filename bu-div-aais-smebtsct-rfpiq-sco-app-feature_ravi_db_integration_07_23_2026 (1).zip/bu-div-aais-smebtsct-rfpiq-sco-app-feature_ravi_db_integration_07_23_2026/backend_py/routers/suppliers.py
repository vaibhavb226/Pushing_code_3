"""
GET  /api/suppliers              — list with filters
GET  /api/suppliers/search       — typeahead (must be before /{id})
POST /api/suppliers/auto-populate — AI multi-signal scoring (text + category + compliance + segment)
POST /api/suppliers              — create new supplier
"""
from __future__ import annotations

import bisect
import math
import re
import uuid
from typing import Annotated, Any

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query

from config import get_settings
from constants import CATEGORY_MAP
from dependencies import get_suppliers_repo
from repositories.suppliers_repo import SuppliersRepository
from schemas.supplier import AutoPopulateRequest, SupplierCreate, SupplierResponse

log = structlog.get_logger()
router = APIRouter(tags=["suppliers"])


def _all_known_emails(s: dict) -> list[str]:
    """Return all email addresses (primary + aliases) for a supplier, lowercased."""
    return [e.lower() for e in [s.get("contact", ""), *s.get("additionalEmails", [])] if e]


# ── Lightweight AI scoring helpers (standard library only) ───────────────────

def _tokenize(text: str) -> set[str]:
    """Split text into lowercase tokens, ignore single-char noise."""
    return {t.lower() for t in re.split(r"[\s,/\-]+", text) if len(t) >= 2}


def _compute_idf(all_suppliers: list[dict]) -> dict[str, float]:
    """Smoothed IDF over the supplier corpus.

    Tokens that appear in many supplier profiles (common words) get low weight;
    rare/specific tokens (e.g. 'halal', 'k-12') get high weight.
    Smoothing (+1) avoids log(0) and handles unseen query tokens gracefully.
    """
    N = len(all_suppliers)
    doc_freq: dict[str, int] = {}
    for sup in all_suppliers:
        text = " ".join([
            sup.get("name", ""),
            sup.get("category", ""),
            " ".join(sup.get("subcategories", [])),
            " ".join(sup.get("tags", [])),
            " ".join(sup.get("segments", [])),
            sup.get("notes", ""),
        ])
        for t in _tokenize(text):
            doc_freq[t] = doc_freq.get(t, 0) + 1
    return {t: math.log((N + 1) / (df + 1)) for t, df in doc_freq.items()}


def _score_supplier(
    supplier: dict,
    query_tokens: set[str],
    needed_categories: set[str],
    compliance_flags: list[str],
    segment: str,
    idf: dict[str, float],
) -> tuple[int, list[str]]:
    """Return (score 0-100, reasons[]) for a supplier against bid context.

    Scoring order mirrors business priority:
      1. Category gate  — hard disqualifier (0 pts if fails, no partial credit)
      2. Compliance     — 50 pts  (bid flags the supplier holds)
      3. Segment        — 30 pts  (supplier serves the requested market)
      4. Text (TF-IDF)  — 20 pts  (IDF-weighted query overlap, tiebreaker)

    A supplier with MORE compliance certs than the bid requires is never penalized:
    comp_hits counts only the bid's required flags found in the supplier's tags.
    """
    # Gate — category match (hard fail; no partial credit)
    in_category = (
        supplier.get("category") in needed_categories
        or any(c in needed_categories for c in supplier.get("categories", []))
        or any(sub in needed_categories for sub in supplier.get("subcategories", []))
    )
    if not in_category:
        return 0, []

    # Signal 1 — compliance tag overlap (50 pts)
    sup_tags_lower = {t.lower() for t in supplier.get("tags", [])}
    flags_lower    = [f.lower() for f in compliance_flags]
    matched_flags  = [f for f in flags_lower if f in sup_tags_lower]
    comp_hits      = len(matched_flags)
    # No compliance requirement on bid → all suppliers pass at full score
    comp_norm = comp_hits / len(compliance_flags) if compliance_flags else 1.0

    # Signal 2 — segment match (30 pts)
    segs = supplier.get("segments", [])
    segment_bonus = 1.0 if (not segment or segment in segs or "All" in segs) else 0.0

    # Signal 3 — TF-IDF weighted text similarity (20 pts)
    # Rare, specific tokens (high IDF) outweigh common words (low IDF).
    sup_text = " ".join([
        supplier.get("name", ""),
        supplier.get("category", ""),
        " ".join(supplier.get("subcategories", [])),
        " ".join(supplier.get("tags", [])),
        " ".join(supplier.get("segments", [])),
        supplier.get("notes", ""),
    ])
    sup_tokens  = _tokenize(sup_text)
    total_idf   = sum(idf.get(t, 1.0) for t in query_tokens) or 1.0
    hit_idf     = sum(idf.get(t, 1.0) for t in query_tokens if t in sup_tokens)
    text_norm   = hit_idf / total_idf  # 0.0–1.0

    final_score = min(100, round(
        comp_norm * 50 + segment_bonus * 30 + text_norm * 20
    ))

    reasons: list[str] = []
    reasons.append(f"Category: {supplier.get('category')}")
    if comp_hits > 0:
        # Show the actual matched tag names for transparency
        original_flags = [f for f in compliance_flags if f.lower() in {m.lower() for m in matched_flags}]
        reasons.append(f"Compliance: {', '.join(original_flags)}")
    if segment_bonus and segment:
        reasons.append(f"Serves {segment}")

    return final_score, reasons


# ── Sorted inverted index for scalable prefix search (100k+ suppliers) ───────
# Built once at startup, O(log n) lookup per query token via bisect.

_sorted_pairs:   list[tuple[str, str]] = []   # (token, supplier_id) sorted by token
_supplier_cache: dict[str, dict]       = {}   # id → supplier dict
_index_dirty:    bool                  = True  # set True on any write; rebuilt on next search


def _build_search_index(suppliers: list[dict]) -> None:
    global _sorted_pairs, _supplier_cache, _index_dirty
    cache: dict[str, dict] = {s["id"]: s for s in suppliers}
    pairs: list[tuple[str, str]] = []
    for sup in suppliers:
        text = " ".join([
            sup.get("name", ""),
            sup.get("category", ""),
            " ".join(sup.get("subcategories", [])),
            " ".join(sup.get("tags", [])),
            " ".join(sup.get("segments", [])),
            sup.get("contact", ""),
            " ".join(sup.get("additionalEmails", [])),
            sup.get("notes", ""),
        ])
        for token in _tokenize(text):
            pairs.append((token, sup["id"]))
    _sorted_pairs   = sorted(pairs)
    _supplier_cache = cache
    _index_dirty    = False


def _prefix_lookup(query_token: str) -> set[str]:
    """Binary-search for all supplier IDs whose index tokens start with query_token."""
    sentinel = query_token + "\U0010ffff"   # highest Unicode codepoint → exclusive upper bound
    lo = bisect.bisect_left(_sorted_pairs,  (query_token,))
    hi = bisect.bisect_left(_sorted_pairs,  (sentinel,))
    return {_sorted_pairs[i][1] for i in range(lo, hi)}


def _invalidate_search_index() -> None:
    global _index_dirty
    _index_dirty = True


# ── IMPORTANT: /search and /auto-populate BEFORE /{id} ───────────────────────


@router.get("/search")
async def search_suppliers(
    q: str = Query(""),
    limit: int = Query(20, ge=1, le=50),
    repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> dict[str, Any]:
    """Fuzzy prefix typeahead — prefix + multi-token AND search via sorted inverted index.

    Scales to 100k+ suppliers: O(log n) per token, index built once at startup.
    Returns `{ results: [...], total: N }`.

    Examples: `?q=schw` → Schwan's, `?q=grain bro` → grain brokers
    """
    global _index_dirty
    if not q.strip() or len(q.strip()) < 2:
        return {"results": [], "total": 0}

    if _index_dirty:
        _build_search_index(await repo.load())

    tokens = _tokenize(q)
    candidate_ids: set[str] | None = None
    for token in tokens:
        ids = _prefix_lookup(token)
        candidate_ids = ids if candidate_ids is None else candidate_ids & ids

    if not candidate_ids:
        return {"results": [], "total": 0}

    ql = q.strip().lower()
    results = sorted(
        [_supplier_cache[sid] for sid in candidate_ids if sid in _supplier_cache],
        key=lambda s: (0 if s.get("name", "").lower().startswith(ql) else 1, s.get("name", "")),
    )
    return {"results": results[:limit], "total": len(results)}


@router.post("/auto-populate", response_model=dict[str, Any])
async def auto_populate(
    body: AutoPopulateRequest,
    repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> dict[str, Any]:
    """AI-powered supplier matching using multi-signal scoring.

    Scores every supplier against four signals: text similarity, category mapping,
    compliance tag overlap, and segment match. Returns suppliers with score > 0
    sorted best-first. No external API calls — runs in-memory in < 1 ms.

    Sample input:
    ```json
    { "itemCategories": ["Grain", "Protein"], "segment": "K-12",
      "complianceFlags": ["Child Nutrition", "Buy American"] }
    ```
    """
    all_suppliers = await repo.load()

    # Build needed category set (case-insensitive lookup)
    cat_map_lower = {k.lower(): v for k, v in CATEGORY_MAP.items()}
    needed_categories: set[str] = {"Broker"}
    for cat in body.itemCategories:
        mapped = cat_map_lower.get(cat.lower())
        needed_categories.update(mapped if mapped else [cat])

    # Build query token set for text similarity
    query_parts = body.itemCategories + ([body.segment] if body.segment else []) + body.complianceFlags
    query_tokens = _tokenize(" ".join(query_parts))

    # Compute IDF once from the full corpus so common tokens are downweighted
    idf = _compute_idf(all_suppliers)

    scored: list[dict] = []
    for sup in all_suppliers:
        if body.excludeBounced and sup.get("bounce", False):
            continue
        score, reasons = _score_supplier(
            sup, query_tokens, needed_categories, body.complianceFlags, body.segment, idf
        )
        if score > 0:
            scored.append({**sup, "matchScore": score, "matchReasons": reasons})

    scored.sort(key=lambda s: s["matchScore"], reverse=True)
    bounced_count = sum(1 for s in all_suppliers if s.get("bounce", False))

    log.info("suppliers.auto_populate",
             matched=len(scored), bounced=bounced_count,
             categories=list(needed_categories), segment=body.segment)

    return {"matched": scored, "totalMatched": len(scored), "bounced": bounced_count,
            "categoriesNeeded": list(needed_categories)}



@router.get("/{supplier_id}", response_model=dict[str, Any])
async def get_supplier(
    supplier_id: str,
    repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> dict[str, Any]:
    """Fetch a single supplier record by ID."""
    all_suppliers = await repo.load()
    supplier = next((s for s in all_suppliers if s.get("id") == supplier_id), None)
    if supplier is None:
        raise HTTPException(status_code=404, detail=f"Supplier {supplier_id!r} not found")
    return supplier


@router.patch("/{supplier_id}", response_model=dict[str, Any])
async def update_supplier(
    supplier_id: str,
    body: dict[str, Any],
    repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> dict[str, Any]:
    """Update an existing supplier record. All fields optional except `id` (read-only).

    Sample input:
    ```json
    { "name": "Acme Foods Updated", "contact": "new@acme.com", "additionalEmails": ["alt@acme.com"] }
    ```
    """
    all_suppliers = await repo.load()
    idx = next((i for i, s in enumerate(all_suppliers) if s.get("id") == supplier_id), None)
    if idx is None:
        raise HTTPException(status_code=404, detail=f"Supplier {supplier_id!r} not found")

    # Validate contact email format if provided
    new_contact = body.get("contact", "").strip().lower()
    if new_contact and "@" not in new_contact:
        raise HTTPException(status_code=400, detail="contact must be a valid email address")

    # Duplicate check: new emails must not conflict with other suppliers
    new_additional = [e.strip().lower() for e in body.get("additionalEmails", []) if e.strip()]
    check_emails = ([new_contact] if new_contact else []) + new_additional
    for i, s in enumerate(all_suppliers):
        if i == idx:
            continue  # skip self
        existing = _all_known_emails(s)
        if any(e in existing for e in check_emails if e):
            raise HTTPException(status_code=409, detail="Email already used by another supplier")

    # Merge — protect id and bounce from client overrides
    updated = {**all_suppliers[idx]}
    for key, val in body.items():
        if key in ("id", "bounce"):
            continue
        updated[key] = val
    if new_contact:
        updated["contact"] = new_contact
    if "additionalEmails" in body:
        updated["additionalEmails"] = new_additional

    await repo.update_one(
        lambda s: s.get("id") == supplier_id,
        lambda _: updated,
    )
    log.info("supplier.updated", id=supplier_id)
    _invalidate_search_index()
    _index_supplier_background(updated)
    await _cascade_email_to_bids(supplier_id, updated)
    return {"success": True, "supplier": updated}


async def _cascade_email_to_bids(supplier_id: str, updated: dict[str, Any]) -> None:
    """Propagate updated primary/alias emails to any bids that have already solicited this supplier.

    PATCH /api/suppliers/{id} only writes suppliers.json. Without this cascade,
    bids.json solicitedSuppliers[].email stays frozen at the original solicitation address,
    causing re-solicit and reminder flows to use the old address.
    """
    new_contact = updated.get("contact", "")
    new_aliases = updated.get("additionalEmails", [])
    if not new_contact:
        return
    from dependencies import get_bids_repo  # local import mirrors bids.py pattern (avoids circulars)
    bids_repo = get_bids_repo()
    all_bids = await bids_repo.load()
    changed_bids: list[dict[str, Any]] = []
    for bid in all_bids:
        bid_changed = False
        for entry in bid.get("solicitedSuppliers", []):
            if entry.get("supplierId") == supplier_id:
                entry["email"] = new_contact
                entry["additionalEmails"] = new_aliases
                bid_changed = True
        if bid_changed:
            changed_bids.append(bid)

    for bid in changed_bids:
        bid_id_val = bid["id"]
        bid_snap = dict(bid)
        await bids_repo.update_one(
            lambda b, _id=bid_id_val: b.get("id") == _id,
            lambda _b, _snap=bid_snap: _snap,
        )
    log.info("supplier.email_cascaded_to_bids", id=supplier_id, changed=len(changed_bids))


@router.delete("/{supplier_id}", response_model=dict[str, Any])
async def delete_supplier(
    supplier_id: str,
    repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> dict[str, Any]:
    """Delete a supplier from the master list.

    Note: this does not affect existing bid solicitation records that already reference this supplier.
    """
    n_deleted = await repo.delete_where(lambda s: s.get("id") == supplier_id)
    if n_deleted == 0:
        raise HTTPException(status_code=404, detail=f"Supplier {supplier_id!r} not found")
    log.info("supplier.deleted", id=supplier_id)
    _invalidate_search_index()
    return {"success": True, "deleted": supplier_id}


@router.get("", response_model=list[dict[str, Any]])
async def list_suppliers(
    category: str | None = None,
    segment: str | None = None,
    region: str | None = None,
    exclude_bounced: bool = Query(False, alias="excludeBounced"),
    repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> list[dict[str, Any]]:
    """List all suppliers with optional filters.

    Query params: `?category=Proteins&segment=K-12&region=South&excludeBounced=true`
    """
    suppliers = await repo.load()

    if category:
        suppliers = [s for s in suppliers if s.get("category") == category]
    if segment:
        suppliers = [s for s in suppliers if segment in s.get("segments", [])]
    if region:
        suppliers = [s for s in suppliers if s.get("region") == region]
    if exclude_bounced:
        suppliers = [s for s in suppliers if not s.get("bounce", False)]

    return suppliers


@router.post("", response_model=dict[str, Any], status_code=201)
async def create_supplier(
    body: SupplierCreate,
    repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> dict[str, Any]:
    """Create a new supplier record. Email must be unique across all suppliers.

    Sample input:
    ```json
    {
      "name": "Pacific Coast Produce",
      "contact": "bids@demo-pcproduce.test",
      "category": "Produce",
      "region": "West",
      "segments": ["K-12", "Healthcare"]
    }
    ```
    Auto-assigns ID in the format `SM-XXX`.
    """
    all_suppliers = await repo.load()

    # Check email uniqueness across all known emails (primary + aliases)
    contact = body.contact.strip().lower()
    new_emails = [contact] + [e.strip().lower() for e in body.additionalEmails if e.strip()]
    for s in all_suppliers:
        existing = _all_known_emails(s)
        if any(e in existing for e in new_emails if e):
            raise HTTPException(status_code=409, detail="A supplier with this email already exists")

    # Auto-generate ID: SM-XXX
    existing_ids = [s.get("id", "") for s in all_suppliers if s.get("id", "").startswith("SM-")]
    max_num = 0
    for sid in existing_ids:
        m = re.match(r"SM-(\d+)", sid)
        if m:
            max_num = max(max_num, int(m.group(1)))
    new_id = f"SM-{max_num + 1:03d}"

    # Normalize categories ↔ category: multi-select wins; single falls back to legacy field
    cats = list(body.categories) if body.categories else [body.category or "Grocery"]
    primary = cats[0]
    supplier = {"id": new_id, "bounce": False, **body.model_dump(), "category": primary, "categories": cats}
    await repo.append(supplier)
    log.info("supplier.created", id=new_id, name=body.name)
    _invalidate_search_index()

    # Auto-index into pgvector so the new supplier appears in /recommend immediately
    _index_supplier_background(supplier)

    return {"success": True, "supplier": supplier}


def _index_supplier_background(supplier: dict) -> None:
    """Fire-and-forget: embed + upsert a single supplier into pgvector."""
    import asyncio

    async def _task() -> None:
        try:
            settings = get_settings()
            if not settings.db_host:
                return
            from db.connection import get_db_conn
            from repositories.vector_repo import upsert_supplier
            from services.embedding_service import embed_text, supplier_to_text

            supplier_text = supplier_to_text(supplier)
            embedding = await embed_text(supplier_text, task_type="RETRIEVAL_DOCUMENT", settings=settings)
            async with get_db_conn(settings) as conn:
                if conn is not None:
                    await upsert_supplier(conn, supplier, embedding)
                    log.info("supplier.indexed", id=supplier.get("id"))
        except Exception as exc:
            log.warning("supplier.index_failed", id=supplier.get("id"), error=str(exc))

    asyncio.ensure_future(_task())
