"""
Customers router — full CRUD.

GET    /api/customers          list / search
POST   /api/customers          create
GET    /api/customers/{id}     fetch one
PUT    /api/customers/{id}     update
DELETE /api/customers/{id}     delete
"""
from __future__ import annotations

import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from dependencies import get_customers_repo

router = APIRouter(tags=["customers"])


class CustomerPayload(BaseModel):
    name: str                          # organization_name (required)
    contactPerson: str = ''
    email: str = ''
    phone: str = ''
    address: str = ''
    city: str = ''
    state: str = ''
    zipCode: str = ''
    country: str = 'US'
    customerType: str = ''
    segment: str = ''
    opco: str = ''
    opcoName: str = ''
    region: str = ''
    status: str = 'Active'


def _build_dict(customer_id: str, body: CustomerPayload) -> dict:
    return {
        "id":            customer_id,
        "name":          body.name.strip(),
        "contactPerson": body.contactPerson,
        "email":         body.email,
        "phone":         body.phone,
        "address":       body.address,
        "city":          body.city,
        "state":         body.state,
        "zipCode":       body.zipCode,
        "country":       body.country or "US",
        "customerType":  body.customerType,
        "segment":       body.segment,
        "opco":          body.opco,
        "opcoName":      body.opcoName,
        "region":        body.region,
        "status":        body.status or "Active",
    }


@router.get("")
async def list_customers(
    q: str | None = None,
    customers_repo=Depends(get_customers_repo),
):
    """Return all customers, optionally filtered by substring query."""
    if q:
        return await customers_repo.search(q)
    return await customers_repo.load()


@router.post("", status_code=201)
async def create_customer(
    body: CustomerPayload,
    customers_repo=Depends(get_customers_repo),
):
    """Create a new customer. Returns the new customer with its generated id."""
    name = body.name.strip()
    if not name:
        raise HTTPException(status_code=422, detail="Customer name cannot be empty")

    new_id = f"CUST-{uuid.uuid4().hex[:8].upper()}"
    return await customers_repo.append(_build_dict(new_id, body))


@router.get("/{customer_id}")
async def get_customer(
    customer_id: str,
    customers_repo=Depends(get_customers_repo),
):
    """Fetch a single customer by ID."""
    customer = await customers_repo.find_by_id(customer_id)
    if customer is None:
        raise HTTPException(status_code=404, detail="Customer not found")
    return customer


@router.put("/{customer_id}")
async def update_customer(
    customer_id: str,
    body: CustomerPayload,
    customers_repo=Depends(get_customers_repo),
):
    """Update a customer. All fields replaced."""
    existing = await customers_repo.find_by_id(customer_id)
    if existing is None:
        raise HTTPException(status_code=404, detail="Customer not found")

    updated = await customers_repo.update_by_id(
        customer_id,
        lambda c: {**c, **_build_dict(customer_id, body)},
    )
    return updated


@router.delete("/{customer_id}", status_code=204)
async def delete_customer(
    customer_id: str,
    customers_repo=Depends(get_customers_repo),
):
    """Delete a customer by ID."""
    deleted = await customers_repo.delete_by_id(customer_id)
    if deleted == 0:
        raise HTTPException(status_code=404, detail="Customer not found")
