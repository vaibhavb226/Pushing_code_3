"""
POST /api/ai/chat
RFP AIQ — SQL + Vector RAG chatbot endpoint.

Returns text/event-stream (SSE). Events emitted in order:
  {"type":"thinking_start","node":"plan","label":"Building approach"}
  {"type":"thinking_content","text":"1. Query bids table\\n2. ..."}
  {"type":"thinking_end","node":"plan"}
  {"type":"thinking_start","node":"think","label":"Step 1: ..."}
  ... (repeat for query/search blocks per tool call)
  {"type":"token","text":"chunk of answer text"}
  {"type":"done"}

On error:
  {"type":"error","message":"..."}
  {"type":"done"}

The frontend must consume this as an EventSource/ReadableStream and assemble
the message from token events. Thinking blocks are displayed as collapsible
UI elements above the response bubble.
"""
from __future__ import annotations

import asyncio
import json

import structlog
from fastapi import APIRouter, Depends
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from dependencies import get_llm_service
from services.llm.provider import LLMService
from services.sql_agent.nodes import set_sse_queue, reset_sse_queue

log = structlog.get_logger()
router = APIRouter(tags=["ai"])


class ChatRequest(BaseModel):
    messages: list[dict[str, str]]  # [{"role": "user"|"assistant", "content": str}]


def _sse(event: dict) -> str:
    return f"data: {json.dumps(event)}\n\n"


@router.post("/chat")
async def chat(
    body: ChatRequest,
    llm: LLMService = Depends(get_llm_service),
) -> StreamingResponse:
    """RFP AIQ SQL + Vector RAG chatbot — streaming SSE response.

    Accepts the same request format as the previous endpoint.
    Returns text/event-stream instead of JSON.
    """
    if not body.messages:
        async def _empty():
            yield _sse({"type": "token", "text": "No message provided."})
            yield _sse({"type": "done"})
        return StreamingResponse(_empty(), media_type="text/event-stream")

    query = body.messages[-1].get("content", "").strip()

    async def event_generator():
        from services.sql_agent.graph import get_graph, build_graph
        from db.connection import get_asyncpg_pool

        # Lazily compile graph on first request if startup init was skipped
        graph = get_graph()
        if graph is None:
            try:
                pool = get_asyncpg_pool()
                graph = build_graph(llm=llm, pool=pool)
                log.info("sql_agent.graph_compiled_lazy")
            except Exception as exc:
                log.error("sql_agent.graph_build_failed", error=str(exc))
                yield _sse({"type": "error", "message": f"Agent not available: {exc}"})
                yield _sse({"type": "done"})
                return

        # SSE queue — nodes push events here; we read and yield them
        queue: asyncio.Queue = asyncio.Queue()
        token = set_sse_queue(queue)

        initial_state = {
            "messages": body.messages,
            "query": query,
        }

        # Run graph as a background task; it pushes events onto queue
        async def _run():
            try:
                await graph.ainvoke(initial_state)
            except Exception as exc:
                log.error("sql_agent.graph_error", error=str(exc))
                await queue.put({"type": "error", "message": str(exc)})
            finally:
                await queue.put(None)  # sentinel — signals stream end

        graph_task = asyncio.create_task(_run())

        try:
            while True:
                event = await asyncio.wait_for(queue.get(), timeout=120.0)
                if event is None:  # sentinel
                    break
                yield _sse(event)
        except asyncio.TimeoutError:
            log.error("sql_agent.stream_timeout")
            yield _sse({"type": "error", "message": "Response timed out. Please try again."})
        except Exception as exc:
            log.error("sql_agent.stream_error", error=str(exc))
            yield _sse({"type": "error", "message": str(exc)})
        finally:
            reset_sse_queue(token)
            if not graph_task.done():
                graph_task.cancel()
                try:
                    await graph_task
                except (asyncio.CancelledError, Exception):
                    pass

        yield _sse({"type": "done"})

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",  # disable nginx buffering for SSE
        },
    )
