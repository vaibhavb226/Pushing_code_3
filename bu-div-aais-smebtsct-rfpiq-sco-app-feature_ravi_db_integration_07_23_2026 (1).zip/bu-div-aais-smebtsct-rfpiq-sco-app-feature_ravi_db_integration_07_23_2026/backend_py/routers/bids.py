"""
All /api/bids/* endpoints — 23 routes.

IMPORTANT: /portal-templates is declared BEFORE /{bid_id} to prevent
FastAPI matching the literal string "portal-templates" as bid_id.
"""
from __future__ import annotations

import json
import re
import time
import uuid
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import asyncio

import aiofiles
import structlog
from fastapi import (
    APIRouter,
    BackgroundTasks,
    Depends,
    File,
    Form,
    HTTPException,
    Query,
    UploadFile,
)
from fastapi.responses import FileResponse, Response, StreamingResponse

from config import get_settings
from dependencies import (
    UPLOADS_DIR,
    get_bids_repo,
    get_documents_repo,
    get_email_threads_repo,
    get_gcs_client,
    get_line_items_repo,
    get_llm_service,
    get_portal_templates_repo,
    get_submissions_repo,
    get_suppliers_repo,
)
from repositories.bids_repo import BidsRepository
from repositories.documents_repo import DocumentsRepository
from repositories.email_threads_repo import EmailThreadsRepository
from repositories.line_items_repo import LineItemsRepository
from repositories.portal_templates_repo import PortalTemplatesRepository
from repositories.submissions_repo import SubmissionsRepository
from repositories.suppliers_repo import SuppliersRepository
from routers.prompts import PRICING_EXTRACTION_SYSTEM
from routers.rfp_parser import build_line_item
from schemas.bid import BidCreate, BidResponse, BidUpdate, DeleteResult
from schemas.line_item import LineItemUpdate
from services.llm.json_parser import extract_json
from services.llm.provider import LLMService
from utils.award_email_template import build_award_email_body, build_award_email_subject
from utils.file_utils import format_file_size, safe_filename

log = structlog.get_logger()
router = APIRouter(tags=["bids"])

# ── Real-time SSE helpers ────────────────────────────────────────────────────

async def _notify_bid(bid_id: str, event: dict) -> None:
    """Fire-and-forget pg_notify — never blocks the mutation response.
    Falls back to direct in-process push when no PG pool is available (local dev mode)."""
    try:
        from db.connection import get_asyncpg_pool
        from services.sse_broadcast import push as sse_push
        pool = get_asyncpg_pool()
        if pool is None:
            # Local dev mode: no PG broker — push directly to in-process queues.
            # unsubscribe() already ran before this is called, so the closing tab's
            # queue is already removed and won't receive its own departure event.
            sse_push(bid_id, event)
            return
        async with pool.acquire() as conn:
            await conn.execute(
                "SELECT pg_notify('bid_events', $1::text)",
                json.dumps(event),
            )
    except Exception:
        pass

# ── Bounce detection for manually-logged inbound emails ─────────────────────
_BID_BOUNCE_FROM_RE = re.compile(r"mailer-daemon|postmaster|mail\s*delivery", re.IGNORECASE)
_BID_BOUNCE_SUBJ_RE = re.compile(
    r"delivery\s*(status\s*notification|failure)|undeliverable"
    r"|mail\s*delivery\s*failed|returned\s*mail|bounce|failure\s*notice",
    re.IGNORECASE,
)
_BID_DSN_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"Final-Recipient:.*?rfc822;\s*([^\s\r\n]+)", re.IGNORECASE),
    re.compile(r"Original-Recipient:.*?rfc822;\s*([^\s\r\n]+)", re.IGNORECASE),
    re.compile(r"failed\s+recipient[:\s]+([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})", re.IGNORECASE),
    re.compile(r"(?:to|rcpt\s+to)[:\s<]+([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})", re.IGNORECASE),
]
_BID_ANY_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")


def _extract_bounce_fields(from_addr: str, subject: str, body_text: str) -> dict[str, Any] | None:
    """Auto-detect bounce and extract flat display fields.

    Returns None if not a bounce. Returns {bounceCode, bounceReason, originalRecipient} if detected.
    """
    if not (_BID_BOUNCE_FROM_RE.search(from_addr) or _BID_BOUNCE_SUBJ_RE.search(subject)):
        return None

    code_m = re.search(r"\b(5\d{2}(?:\s+[\d.]+)?)\b", body_text)
    bounce_code = code_m.group(1).strip() if code_m else "550"

    reason_m = re.search(
        r"(user\s*does\s*not\s*exist|mailbox\s*not\s*found|no\s*such\s*user"
        r"|account\s*disabled|relay\s*access\s*denied)",
        body_text, re.IGNORECASE,
    )
    reason_fallback = re.search(r"(?:reason|diagnostic[- ]code)[:\s]+(.+)", body_text, re.IGNORECASE)
    if reason_m:
        bounce_reason = reason_m.group(1)
    elif reason_fallback:
        bounce_reason = reason_fallback.group(1)[:200].strip()
    else:
        bounce_reason = "Unknown delivery failure"

    original_recipient: str | None = None
    for pattern in _BID_DSN_PATTERNS:
        m = pattern.search(body_text)
        if m and m.group(1):
            original_recipient = m.group(1).strip().lower()
            break
    if not original_recipient:
        angle_m = re.search(r"<([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})>", body_text)
        if angle_m and not _BID_BOUNCE_FROM_RE.search(angle_m.group(1)):
            original_recipient = angle_m.group(1).lower()
    if not original_recipient:
        for em in _BID_ANY_EMAIL_RE.findall(body_text):
            if not _BID_BOUNCE_FROM_RE.search(em):
                original_recipient = em.lower()
                break

    return {
        "bounceCode": bounce_code,
        "bounceReason": bounce_reason,
        "originalRecipient": original_recipient,
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PORTAL TEMPLATES — declared BEFORE /{bid_id}
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/portal-templates", response_model=list[dict[str, Any]])
async def get_portal_templates(
    repo: PortalTemplatesRepository = Depends(get_portal_templates_repo),
) -> list[dict[str, Any]]:
    """List all portal submission form templates.

    Returns all predefined templates (e.g. `k12-standard`, `healthcare`, `government`).
    Apply a template to a bid via `PATCH /api/bids/{bid_id}/portal-config`.
    """
    return await repo.load()


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# BIDS CRUD
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━



@router.get("", response_model=list[dict[str, Any]])
async def list_bids(
    segment: str | None = None,
    status: str | None = None,
    repo: BidsRepository = Depends(get_bids_repo),
) -> list[dict[str, Any]]:
    """List all bids, optionally filtered by segment or status.

    Query params: `?segment=K-12`, `?status=Active`
    """
    bids = await repo.load()
    if segment:
        bids = [b for b in bids if b.get("segment") == segment]
    if status:
        bids = [b for b in bids if b.get("status") == status]
    return bids


@router.post("", response_model=dict[str, Any], status_code=201)
async def create_bid(
    body: dict[str, Any],
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
    documents_repo: DocumentsRepository = Depends(get_documents_repo),
) -> dict[str, Any]:
    """Create a new bid record and optionally save its line items.

    Sample input:
    ```json
    {
      "customer": "Lakeview Unified School District",
      "segment": "K-12",
      "opco": "053",
      "opcoName": "FoodCorp Houston",
      "region": "South",
      "customerDue": "2026-07-15",
      "internalDue": "2026-07-10",
      "compliance": ["Child Nutrition", "Buy American"],
      "lineItems": []
    }
    ```
    Temp upload paths (`tempPdfPath`, `tempExcelPath`) from `/api/parse-rfp` are renamed
    to `{bidId}_RFP.pdf` / `{bidId}_ItemList.xlsx` and registered in the document vault.
    """
    bid_id = body.get("id") or f"RFP-{uuid.uuid4().hex[:8]}"
    today_str = date.today().isoformat()

    # ── Rename temp upload files to bid-specific names ────────────────────────
    cfg = get_settings()
    uploaded_files: list[dict[str, Any]] = []
    today_date = datetime.utcnow().strftime("%Y-%m-%d")

    def _try_rename(temp_rel: str | None, dest_name: str) -> str | None:
        if not temp_rel:
            return None
        src = UPLOADS_DIR / temp_rel.replace("uploads/", "", 1).replace("uploads\\", "", 1)
        if not src.exists():
            return None
        dest = UPLOADS_DIR / dest_name
        try:
            src.rename(dest)
            return f"uploads/{dest_name}"
        except OSError:
            return None

    async def _finalize_gcs(local_dest_name: str, doc_type: str, mime: str, original_name: str) -> str:
        """Upload the locally-renamed file to GCS at the structured path (local-dev fallback path)."""
        gcs_client = get_gcs_client(cfg)
        if not gcs_client:
            return ""
        local_path = UPLOADS_DIR / local_dest_name
        if not local_path.exists():
            return ""
        object_name = f"{bid_id}/{doc_type.replace(' ', '')}/{bid_id}/{today_date}/{local_dest_name}"
        blob = gcs_client.bucket(cfg.gcs_bucket).blob(object_name)
        blob.metadata = _blob_metadata(doc_type)
        content = local_path.read_bytes()
        loop = asyncio.get_event_loop()
        await loop.run_in_executor(
            None, lambda: blob.upload_from_string(content, content_type=mime)
        )
        return f"gs://{cfg.gcs_bucket}/{object_name}"

    def _blob_metadata(doc_type: str) -> dict[str, str]:
        """Full structured-path metadata set (matches _upload_to_gcs)."""
        return {
            "bid-id": bid_id,
            "rfp-id": bid_id,
            "document-type": doc_type,
            "region": body.get("region", ""),
            "segment": body.get("segment", ""),
            "customer-name": body.get("customer", ""),
            "opco": body.get("opco", ""),
        }

    async def _move_staging_to_final(staging_uri: str, dest_name: str, doc_type: str) -> str:
        """Move a staged GCS object to the final structured path (server-side copy + delete)."""
        gcs_client = get_gcs_client(cfg)
        if not gcs_client or not staging_uri.startswith("gs://"):
            return ""
        rest = staging_uri[len("gs://"):]
        src_bucket_name, _, src_object = rest.partition("/")
        dest_object = f"{bid_id}/{doc_type.replace(' ', '')}/{bid_id}/{today_date}/{dest_name}"
        meta = _blob_metadata(doc_type)

        def _do_move() -> str:
            src_bucket = gcs_client.bucket(src_bucket_name)
            src_blob = src_bucket.get_blob(src_object)
            if src_blob is None:
                raise FileNotFoundError(staging_uri)
            dest_bucket = gcs_client.bucket(cfg.gcs_bucket)
            new_blob = src_bucket.copy_blob(src_blob, dest_bucket, dest_object)
            new_blob.metadata = meta
            new_blob.patch()
            src_blob.delete()
            return f"gs://{cfg.gcs_bucket}/{dest_object}"

        try:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, _do_move)
        except Exception as exc:
            log.warning("bid.staging_move_failed", uri=staging_uri, error=str(exc))
            return ""

    # Resolve the final GCS URI for each file. Prefer the GCS staging URI (new flow — move,
    # no re-upload, no local disk); fall back to the local temp rename + upload (local-dev).
    pdf_dest_name = f"{bid_id}_RFP.pdf"
    staging_pdf_uri = body.get("stagingPdfUri") or ""
    staging_excel_uri = body.get("stagingExcelUri") or ""
    excel_rel = body.get("tempExcelPath") or ""
    staging_excel_ext = staging_excel_uri.rsplit(".", 1)[-1].lower() if "." in staging_excel_uri else ""
    excel_ext = staging_excel_ext or (excel_rel.rsplit(".", 1)[-1].lower() if "." in excel_rel else "xlsx")
    excel_dest_name = f"{bid_id}_ItemList.{excel_ext}"
    excel_mime = ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                  if excel_ext == "xlsx" else "application/vnd.ms-excel")

    async def _resolve_file(
        staging_uri: str, local_temp: str, dest_name: str,
        doc_type: str, mime: str, orig_name: str,
    ) -> tuple[str, str]:
        """Resolve the final (gcs_uri, local_path) for one uploaded file.

        Tries GCS staging move first; falls back to local rename + upload.
        """
        if staging_uri:
            gcs_uri = await _move_staging_to_final(staging_uri, dest_name, doc_type)
            if gcs_uri:
                return gcs_uri, ""
        local_path = _try_rename(local_temp, dest_name) or ""
        if local_path:
            gcs_uri = await _finalize_gcs(dest_name, doc_type, mime, orig_name)
            return gcs_uri, local_path
        return "", ""

    # PDF and Excel staging moves are independent GCS operations — run in parallel.
    (pdf_gcs_uri, pdf_local_path), (excel_gcs_uri, excel_local_path) = await asyncio.gather(
        _resolve_file(
            staging_pdf_uri, body.get("tempPdfPath") or "", pdf_dest_name,
            "RFP Document", "application/pdf", body.get("pdfOriginalName") or pdf_dest_name,
        ),
        _resolve_file(
            staging_excel_uri, excel_rel, excel_dest_name,
            "Item List", excel_mime, body.get("excelOriginalName") or excel_dest_name,
        ),
    )

    if pdf_gcs_uri or pdf_local_path:
        uploaded_files.append({
            "id": f"FILE-{bid_id}-RFP",
            "name": body.get("pdfOriginalName") or pdf_dest_name,
            "type": "RFP Document",
            "mimetype": "application/pdf",
            "size": body.get("pdfSize") or 0,
            "uploadedAt": today_str,
            "path": pdf_gcs_uri or pdf_local_path,
        })
    if excel_gcs_uri or excel_local_path:
        uploaded_files.append({
            "id": f"FILE-{bid_id}-ITEMS",
            "name": body.get("excelOriginalName") or excel_dest_name,
            "type": "Item List",
            "mimetype": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "size": body.get("excelSize") or 0,
            "uploadedAt": today_str,
            "path": excel_gcs_uri or excel_local_path,
        })

    # live indexing is wired after doc_records are written (see asyncio.gather block below)

    new_bid: dict[str, Any] = {
        "id": bid_id,
        "rfpNumber": body.get("rfpNumber") or body.get("rfp_number") or bid_id,
        "customer": body.get("customer", ""),
        "opco": body.get("opco", ""),
        "opcoName": body.get("opcoName", ""),
        "region": body.get("region", ""),
        "segment": body.get("segment", ""),
        "status": body.get("status", "Active"),
        "intakeDate": today_str,
        "customerDue": body.get("customerDue", ""),
        "internalDue": body.get("internalDue", ""),
        "bidRelease": body.get("bidRelease", ""),
        "items": 0,
        "suppliersContacted": 0,
        "responsesReceived": 0,
        "notes": body.get("notes", ""),
        "compliance": body.get("compliance", []),
        "itemCategories": body.get("itemCategories", []),
        "solicitedSuppliers": [],
        "uploadedFiles": uploaded_files,
        "customerId": body.get("customerId") or None,
    }

    # ── Insert bid first — rfp_line_items FK references rfps.id ─────────────
    raw_items: list[dict[str, Any]] = body.get("lineItems", [])
    built_items: list[dict[str, Any]] = []
    if raw_items:
        built_items = [build_line_item(li, bid_id, i) for i, li in enumerate(raw_items)]
        new_bid["items"] = len(built_items)

    await bids_repo.append(new_bid)

    # ── Write line items + document vault entries in parallel ─────────────────
    # All writes are independent once the bid row exists in rfps (FK satisfied).
    # No delete_for_bid needed: bid_id is a fresh UUID — there are no existing items.
    doc_records = [
        {
            "id": f"DOC-{bid_id}-{'RFP' if f['type'] == 'RFP Document' else 'ITEMS'}",
            "fileName": f["name"],
            "fileType": f["name"].rsplit(".", 1)[-1].lower() if "." in f["name"] else "",
            "sizeKb": None,
            "supplier": "Customer RFP",
            "bidId": bid_id,
            "documentType": f["type"],
            "tags": [],
            "uploadDate": today_str,
            "uploadedBy": "BEX AI Upload",
            "status": "Filed",
            "filePath": f["path"],
        }
        for f in uploaded_files
    ]
    writes = []
    if built_items:
        writes.append(line_items_repo.append_many(built_items))
    for doc in doc_records:
        writes.append(documents_repo.append(doc))
    if writes:
        await asyncio.gather(*writes)

    # Fire-and-forget: index each document into document_vectors (pgvector) after DB writes complete.
    # Guarded by db_host — pgvector is only available in DB mode.
    if cfg.db_host and doc_records:
        from services.document_indexer import index_document_background
        gcs = get_gcs_client(cfg)
        for doc in doc_records:
            asyncio.ensure_future(index_document_background(doc, gcs, cfg))

    log.info("bid.created", bid_id=bid_id, customer=new_bid["customer"], items=len(built_items))
    return {**new_bid, "bidId": bid_id, "lineItemsCreated": len(built_items)}


@router.get("/{bid_id}/stream")
async def bid_event_stream(bid_id: str, user: str = "", session_id: str = "") -> StreamingResponse:
    """Real-time SSE stream for a bid — pushes line item changes, email events, and presence.

    Connect with: EventSource(`/api/bids/${bidId}/stream?user=Morgan+Davis&session_id=<uuid>`)

    Event types emitted:
    - `viewers`           — initial list of current viewers on connect
    - `presence`          — user joined / left (includes sessionId so tab bar can clean up)
    - `line_item_updated` — a line item's fields changed
    - `line_item_deleted` — a line item was removed
    - `bid_updated`       — top-level bid fields changed (status, dates, etc.)
    - `email_sent`        — a solicitation or reply was sent
    - `supplier_updated`  — a supplier's status was overridden
    """
    from services.sse_broadcast import subscribe, unsubscribe, get_viewers

    q = subscribe(bid_id, user or "Anonymous", session_id)

    # Broadcast arrival to existing viewers
    asyncio.ensure_future(_notify_bid(bid_id, {
        "type": "presence", "action": "joined",
        "user": q.user_name, "sessionId": q.session_id, "bidId": bid_id,  # type: ignore[attr-defined]
    }))

    async def generator():
        # Send the current viewer list immediately on connect
        yield f"data: {json.dumps({'type': 'viewers', 'viewers': get_viewers(bid_id), 'bidId': bid_id})}\n\n"
        try:
            while True:
                try:
                    event = await asyncio.wait_for(q.get(), timeout=25.0)
                    yield f"data: {json.dumps(event)}\n\n"
                except asyncio.TimeoutError:
                    yield ": keepalive\n\n"  # SSE comment — prevents nginx proxy timeout
        finally:
            unsubscribe(bid_id, q)
            asyncio.ensure_future(_notify_bid(bid_id, {
                "type": "presence", "action": "left",
                "user": q.user_name, "sessionId": q.session_id, "bidId": bid_id,  # type: ignore[attr-defined]
            }))

    return StreamingResponse(
        generator(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.get("/{bid_id}", response_model=dict[str, Any])
async def get_bid(
    bid_id: str,
    repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    """Retrieve a single bid by ID."""
    bid = await repo.find_by_id(bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    return bid


@router.patch("/{bid_id}", response_model=dict[str, Any])
async def update_bid(
    bid_id: str,
    body: dict[str, Any],
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    """Partially update a bid (any subset of fields).

    Sample input:
    ```json
    { "status": "Solicitation", "internalDue": "2026-07-10", "notes": "Urgent review needed" }
    ```
    If `solicitedSuppliers` is included, award status is automatically synced to line items.
    """
    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        return {**bid, **{k: v for k, v in body.items() if k != "id"}}

    updated = await bids_repo.update_by_id(bid_id, updater)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    # Sync award status to line items if awardedSupplier changes
    if "solicitedSuppliers" in body:
        await _sync_award_to_line_items(bid_id, body["solicitedSuppliers"], line_items_repo)

    log.info("bid.updated", bid_id=bid_id)
    asyncio.ensure_future(_notify_bid(bid_id, {
        "type": "bid_updated", "bidId": bid_id,
        "fields": {k: v for k, v in body.items() if k != "id"},
    }))
    return {"success": True, "bid": updated}


@router.delete("/{bid_id}", response_model=DeleteResult)
async def delete_bid(
    bid_id: str,
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
    documents_repo: DocumentsRepository = Depends(get_documents_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
) -> DeleteResult:
    """Delete a bid and all associated data (cascading).

    Removes: line items, email threads, pricing data, documents, portal submissions,
    and uploaded files from disk.

    Sample response:
    ```json
    { "success": true, "deleted": "B2600042", "removed": { "lineItems": 33, "emails": 4, "pricing": 0, "documents": 4, "files": 2 } }
    ```
    """
    bid = await bids_repo.find_by_id(bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    # Delete uploaded files (before DB delete so we still have the bid record)
    file_count = 0
    if UPLOADS_DIR.exists():
        for fp in UPLOADS_DIR.iterdir():
            if fp.name.startswith(f"{bid_id}_") or fp.name.startswith(f"{bid_id}-"):
                try:
                    fp.unlink()
                    file_count += 1
                except OSError:
                    pass

    # One DELETE FROM rfps; CASCADE handles all child tables atomically
    await bids_repo.delete_by_id(bid_id)
    li_count = em_count = pr_count = doc_count = sub_count = -1  # cascaded, counts unavailable

    # Delete all document_vectors chunks for this bid (pgvector, best-effort)
    if get_settings().db_host:
        from services.document_indexer import delete_bid_index
        asyncio.ensure_future(delete_bid_index(bid_id, get_settings()))

    removed = {
        "lineItems": li_count,
        "emails": em_count,
        "pricing": pr_count,
        "documents": doc_count,
        "submissions": sub_count,
        "files": file_count,
    }
    log.info("bid.deleted", bid_id=bid_id, removed=removed)
    return DeleteResult(success=True, deleted=bid_id, removed=removed)


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# FILE UPLOAD / SERVE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}/files", response_model=list[dict[str, Any]])
async def get_bid_files(
    bid_id: str,
    repo: BidsRepository = Depends(get_bids_repo),
) -> list[dict[str, Any]]:
    """List all uploaded files attached to a bid."""
    bid = await repo.find_one(lambda b: b.get("id") == bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    return bid.get("uploadedFiles", [])


async def _upload_to_gcs(
    content: bytes,
    bid: dict[str, Any],
    doc_type: str,
    saved_name: str,
    mimetype: str,
    cfg,
) -> str | None:
    """Upload file bytes to GCS and return the GCS URI, or None if GCS is not configured."""
    gcs_client = get_gcs_client(cfg)
    if not gcs_client:
        return None
    bid_id = bid.get("id", "unknown")
    rfp_id = bid_id
    date_str = datetime.utcnow().strftime("%Y-%m-%d")
    path_type = doc_type.replace(" ", "")
    object_name = f"{rfp_id}/{path_type}/{bid_id}/{date_str}/{saved_name}"
    blob = gcs_client.bucket(cfg.gcs_bucket).blob(object_name)
    blob.metadata = {
        "bid-id": bid_id,
        "rfp-id": rfp_id,
        "document-type": doc_type,
        "region": bid.get("region", ""),
        "segment": bid.get("segment", ""),
        "customer-name": bid.get("customer", ""),
        "opco": bid.get("opco", ""),
    }
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(
        None,
        lambda: blob.upload_from_string(content, content_type=mimetype),
    )
    return f"gs://{cfg.gcs_bucket}/{object_name}"


async def _serve_gcs_file(gcs_uri: str, disposition: str, filename: str, cfg) -> Response:
    """Download bytes from GCS and return as an HTTP response."""
    gcs_client = get_gcs_client(cfg)
    if not gcs_client:
        raise HTTPException(status_code=404, detail="File not found")
    parts = gcs_uri[len("gs://"):].split("/", 1)
    bucket_name, object_name = parts[0], parts[1]
    blob = gcs_client.bucket(bucket_name).blob(object_name)
    loop = asyncio.get_event_loop()
    try:
        content = await loop.run_in_executor(None, blob.download_as_bytes)
    except Exception:
        raise HTTPException(status_code=404, detail="File not found in GCS")
    mime = blob.content_type or "application/octet-stream"
    return Response(
        content=content,
        media_type=mime,
        headers={"Content-Disposition": f'{disposition}; filename="{filename}"'},
    )


@router.post("/{bid_id}/files", response_model=dict[str, Any], status_code=201)
async def upload_bid_file(
    bid_id: str,
    background_tasks: BackgroundTasks,
    file: UploadFile,
    doc_type: str = Form("Other", alias="docType"),
    notes: str = Form(""),
    bids_repo: BidsRepository = Depends(get_bids_repo),
    documents_repo: DocumentsRepository = Depends(get_documents_repo),
) -> dict[str, Any]:
    """Upload a file and attach it to a bid.

    Multipart form fields: `file` (binary), `docType` (RFP | Item List | Pricing | Spec Sheet | Compliance | Other), `notes` (optional text).
    For `docType=Item List` or `RFP`, line items are auto-parsed in the background.
    The file is also added to the Document Vault.
    """
    bid = await bids_repo.find_by_id(bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    content = await file.read()
    cfg = get_settings()
    if len(content) > cfg.max_upload_bytes:
        raise HTTPException(
            status_code=413,
            detail=f"File exceeds {cfg.max_upload_bytes // (1024 * 1024)} MB limit "
                   f"({len(content) // (1024 * 1024)} MB received)",
        )
    fname = safe_filename(file.filename or "upload")
    timestamp = int(time.time() * 1000)
    saved_name = f"{bid_id}_{doc_type.replace(' ', '_')}_{timestamp}_{fname}"
    dest = UPLOADS_DIR / saved_name

    # Always write locally — needed for line-item auto-parse (PyMuPDF requires local path)
    async with aiofiles.open(dest, "wb") as fh:
        await fh.write(content)

    # Upload to GCS when configured; GCS URI becomes the primary stored path
    gcs_uri = await _upload_to_gcs(
        content, bid, doc_type, saved_name,
        file.content_type or "application/octet-stream", cfg,
    )
    stored_path = gcs_uri if gcs_uri else f"uploads/{saved_name}"

    file_record: dict[str, Any] = {
        "id": f"FILE-{bid_id}-{timestamp}",
        "name": fname,
        "type": doc_type,
        "mimetype": file.content_type or "application/octet-stream",
        "size": format_file_size(len(content)),
        "uploadedAt": date.today().isoformat(),
        "path": stored_path,
        "notes": notes,
    }

    def add_file(b: dict[str, Any]) -> dict[str, Any]:
        files = b.get("uploadedFiles", [])
        files.append(file_record)
        return {**b, "uploadedFiles": files}

    await bids_repo.update_by_id(bid_id,add_file)

    # Also add to document vault
    doc_record: dict[str, Any] = {
        "id": f"DOC-{uuid.uuid4().hex[:8].upper()}",
        "fileName": fname,
        "fileType": Path(fname).suffix.lstrip("."),
        "sizeKb": len(content) // 1024,
        "supplier": "",
        "bidId": bid_id,
        "documentType": doc_type,
        "tags": [],
        "uploadDate": date.today().isoformat(),
        "uploadedBy": "System",
        "status": "Filed",
        "filePath": stored_path,
        "description": notes,
    }
    await documents_repo.append(doc_record)

    # Fire-and-forget: index document into document_vectors (pgvector)
    if cfg.db_host:
        from services.document_indexer import index_document_background
        asyncio.ensure_future(
            index_document_background(doc_record, get_gcs_client(cfg), cfg)
        )

    # Auto-parse line items in background for relevant doc types
    if doc_type in {"Item List", "RFP", "RFP Document"}:
        from services.line_item_parser import auto_parse_line_items
        background_tasks.add_task(auto_parse_line_items, bid_id, fname, str(dest))

    log.info("bid.file_uploaded", bid_id=bid_id, file=fname, doc_type=doc_type, gcs=bool(gcs_uri))
    return {"success": True, "file": file_record}


@router.get("/{bid_id}/files/{filename}/view")
async def view_bid_file(
    bid_id: str,
    filename: str,
    bids_repo: BidsRepository = Depends(get_bids_repo),
) -> Response:
    """Stream a bid file inline in the browser (Content-Disposition: inline)."""
    cfg = get_settings()
    safe_name = safe_filename(filename)

    # GCS primary — look up URI from the bid's file records
    bid = await bids_repo.find_by_id(bid_id)
    if bid:
        for f in bid.get("uploadedFiles", []):
            stored = f.get("path", "")
            if stored.startswith("gs://") and stored.split("/")[-1] == safe_name:
                return await _serve_gcs_file(stored, "inline", safe_name, cfg)

    # Local disk fallback (dev environment)
    local_path = UPLOADS_DIR / safe_name
    if local_path.exists():
        return FileResponse(str(local_path), headers={"Content-Disposition": "inline"})

    raise HTTPException(status_code=404, detail="File not found")


@router.get("/{bid_id}/files/{filename}/download")
async def download_bid_file(
    bid_id: str,
    filename: str,
    bids_repo: BidsRepository = Depends(get_bids_repo),
) -> Response:
    """Download a bid file as an attachment (Content-Disposition: attachment)."""
    cfg = get_settings()
    safe_name = safe_filename(filename)

    # GCS primary — look up URI from the bid's file records
    bid = await bids_repo.find_by_id(bid_id)
    if bid:
        for f in bid.get("uploadedFiles", []):
            stored = f.get("path", "")
            if stored.startswith("gs://") and stored.split("/")[-1] == safe_name:
                return await _serve_gcs_file(stored, "attachment", safe_name, cfg)

    # Local disk fallback (dev environment)
    local_path = UPLOADS_DIR / safe_name
    if local_path.exists():
        return FileResponse(
            str(local_path),
            headers={"Content-Disposition": f'attachment; filename="{safe_name}"'},
        )

    raise HTTPException(status_code=404, detail="File not found")


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# LINE ITEMS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}/line-items", response_model=list[dict[str, Any]])
async def get_line_items(
    bid_id: str,
    repo: LineItemsRepository = Depends(get_line_items_repo),
) -> list[dict[str, Any]]:
    """List all line items for a bid (from the Working File)."""
    return await repo.get_for_bid(bid_id)


@router.patch("/{bid_id}/line-items/{line_id}", response_model=dict[str, Any])
async def update_line_item(
    bid_id: str,
    line_id: str,
    body: dict[str, Any],
    repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    """Update supplier-side fields on a line item (Working File right panel).

    Sample input:
    ```json
    { "trueVendor": "Schwan's Food Service", "suppliedPrice": 14.25, "devType": "DL", "confidence": 92 }
    ```
    If `supplierPricing` array is provided, it is smart-merged (keyed by `supplierName`).
    """
    new_pricing: list[dict[str, Any]] = body.pop("supplierPricing", None) or []

    def updater(item: dict[str, Any]) -> dict[str, Any]:
        return {**item, **{k: v for k, v in body.items() if k not in ("id", "bidId")}}

    if new_pricing:
        # Combined path: field update + pricing merge in one DB round-trip (1 pool acquire, 2 RT)
        # vs. the old separate update_by_id + smart_merge_pricing (3 acquires, 4 RT per item)
        updated = await repo.update_with_pricing(line_id, updater, new_pricing)
    else:
        updated = await repo.update_by_id(line_id, updater)

    if not updated:
        raise HTTPException(status_code=404, detail=f"Line item {line_id!r} not found")

    # Broadcast the change to all SSE clients viewing this bid
    asyncio.ensure_future(_notify_bid(bid_id, {
        "type": "line_item_updated",
        "bidId": bid_id,
        "lineId": line_id,
        "fields": {**body, **({"supplierPricing": updated.get("supplierPricing")} if new_pricing else {})},
    }))
    return updated


@router.delete("/{bid_id}/line-items/{line_id}", status_code=204)
async def delete_line_item(
    bid_id: str,
    line_id: str,
    repo: LineItemsRepository = Depends(get_line_items_repo),
) -> None:
    """Delete a single line item from the Working File."""
    deleted = await repo.delete_by_id(line_id, bid_id)
    if deleted == 0:
        raise HTTPException(status_code=404, detail=f"Line item {line_id!r} not found")
    asyncio.ensure_future(_notify_bid(bid_id, {
        "type": "line_item_deleted", "bidId": bid_id, "lineId": line_id,
    }))


@router.delete("/{bid_id}/line-items/{line_id}/supplier-pricing", response_model=dict[str, Any])
async def remove_supplier_pricing_entry(
    bid_id: str,
    line_id: str,
    index: int = Query(..., description="0-based index into supplierPricing array"),
    repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    """Remove one supplier pricing entry by index.

    Removing index 0 promotes the next entry to primary and updates the flat
    vendor/price fields accordingly. Removing the last entry clears them.
    """
    original: list[dict[str, Any]] = []

    def updater(item: dict[str, Any]) -> dict[str, Any]:
        nonlocal original
        pricing = list(item.get("supplierPricing") or [])
        original = pricing
        if index < 0 or index >= len(pricing):
            return item  # no-op; validated below
        pricing.pop(index)
        updates: dict[str, Any] = {"supplierPricing": pricing}
        if pricing:
            first = pricing[0]
            updates["trueVendor"]    = first.get("supplierName")
            updates["suppliedPrice"] = first.get("unitPrice") or first.get("casePrice")
            updates["devType"]       = first.get("devType")
            updates["confidence"]    = first.get("confidenceScore")
        else:
            updates.update({
                "trueVendor": None, "suppliedPrice": None,
                "devType": None, "confidence": None, "status": "No Response",
            })
        return {**item, **updates}

    updated = await repo.update_by_id(line_id, updater)
    if updated is None:
        raise HTTPException(status_code=404, detail=f"Line item {line_id!r} not found")
    if index < 0 or index >= len(original):
        raise HTTPException(status_code=400, detail=f"Index {index} out of range (0–{len(original) - 1})")
    return updated


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# EMAILS (bid-scoped)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.get("/{bid_id}/emails/by-supplier", response_model=dict[str, Any])
async def get_emails_by_supplier(
    bid_id: str,
    bids_repo: BidsRepository = Depends(get_bids_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
    suppliers_repo: SuppliersRepository = Depends(get_suppliers_repo),
) -> dict[str, Any]:
    """Return emails grouped by supplier — used by the Email Repo tab left panel.

    Returns { solicitation, suppliers: [...] } matching the Node.js backend shape.
    Solicitation email (outbound + Solicitation tag) is extracted separately;
    only per-supplier reply emails are grouped by supplierId.
    """
    bid, all_emails = await asyncio.gather(
        bids_repo.find_by_id(bid_id),
        email_threads_repo.get_for_bid(bid_id),
    )
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    solicited = bid.get("solicitedSuppliers", [])

    # Build broker-flag lookup — only the `broker` boolean is needed from the registry.
    # Use a targeted 2-column query when available (PG mode) rather than loading all supplier rows.
    supplier_ids_in_bid = [s["supplierId"] for s in solicited if s.get("supplierId")]
    broker_by_id: dict[str, bool] = await suppliers_repo.get_broker_flags(supplier_ids_in_bid)
    completed_suppliers: list[str] = bid.get("completedSuppliers", [])

    # Manual status overrides from solicitedSuppliers
    manual_status_map: dict[str, str] = {
        s["supplierId"]: s["status"]
        for s in solicited
        if s.get("supplierId") and s.get("status")
    }

    # Pull out the solicitation email (first outbound with Solicitation tag)
    solicitation = next(
        (e for e in all_emails
         if e.get("direction") == "outbound" and "Solicitation" in e.get("tags", [])),
        None,
    )

    # Build O(1) reverse lookup: email address → supplierId (built once, O(suppliers))
    email_to_sid: dict[str, str] = {}
    for s in solicited:
        sid = s.get("supplierId")
        if not sid:
            continue
        for field in ("email", "supplierEmail"):
            addr = (s.get(field) or "").lower().strip()
            if addr:
                email_to_sid[addr] = sid

    # Group non-solicitation emails by supplierId — O(emails), O(1) lookup per email
    emails_by_sid: dict[str, list] = {}
    for e in all_emails:
        sid = e.get("supplierId")
        if not sid:
            # Fallback: match by sender email address
            raw = e.get("supplierEmail") or e.get("from", "")
            addr = raw.lower().split("<")[-1].strip(" >")
            sid = email_to_sid.get(addr)
        if not sid:
            # BCC fan-out: old-format solicitation stored supplierId=null with bcc[] holding
            # all supplier addresses. Fan each address to its supplier's bucket so existing
            # BCC records show correctly in Email Repo (backwards-compat read layer).
            for bcc_addr in e.get("bcc", []):
                norm = bcc_addr.lower().split("<")[-1].strip(" >")
                bcc_sid = email_to_sid.get(norm)
                if bcc_sid:
                    emails_by_sid.setdefault(bcc_sid, []).append(e)
            continue  # either fanned out or genuinely unattributable
        emails_by_sid.setdefault(sid, []).append(e)

    # Relevant supplier IDs = solicitedSuppliers ONLY (no orphaned email records)
    relevant_ids: set[str] = set()
    for s in solicited:
        if s.get("supplierId"):
            relevant_ids.add(s["supplierId"])

    MANUAL_OVERRIDE_STATUSES = {
        "Awarded", "Complete", "No Bid", "Bounced",
        "Issues Found", "Under Consideration", "In Consideration",
    }

    # Pre-build O(1) lookup — previously this was O(N) inside the loop → O(N²) total
    sol_by_sid: dict[str, dict] = {
        s["supplierId"]: s for s in solicited if s.get("supplierId")
    }

    supplier_rows = []
    for supplier_id in relevant_ids:
        sol_entry = sol_by_sid.get(supplier_id)

        sup_emails = sorted(
            emails_by_sid.get(supplier_id, []),
            key=lambda e: e.get("date", ""),
        )
        inbound  = [e for e in sup_emails if e.get("direction") == "inbound"]
        outbound = [e for e in sup_emails if e.get("direction") == "outbound"]

        # Compute status
        status = "Awaiting"
        if supplier_id in completed_suppliers:
            status = "Awarded"
        elif inbound:
            first_in_date = inbound[0].get("date", "")
            has_follow_up = any((o.get("date", "") or "") > first_in_date for o in outbound)
            if has_follow_up:
                status = "Follow-up Sent"
            elif any(e.get("isBounce") for e in inbound):
                status = "Issues Found"
            else:
                status = "Responded"

        # Manual override takes precedence for specific statuses
        if manual_status_map.get(supplier_id) in MANUAL_OVERRIDE_STATUSES:
            status = manual_status_map[supplier_id]

        # Issue count from latest inbound
        issue_count = 0
        if inbound:
            issues = (inbound[-1].get("analysisResult") or {}).get("issues", {})
            issue_count = sum(len(v) for v in issues.values() if isinstance(v, list))

        last_activity = max((e.get("date", "") for e in sup_emails), default=None) or None

        has_bounce = any(e.get("isBounce") for e in sup_emails)
        supplier_rows.append({
            "supplierId":    supplier_id,
            "supplierName":  sol_entry.get("supplierName", "") if sol_entry else "",
            "supplierEmail": sol_entry.get("email", "") if sol_entry else "",
            "isBroker":      broker_by_id.get(supplier_id, False),
            "status":        status,
            "hasBounce":     has_bounce,
            "emailCount":    len(sup_emails),
            "lastActivity":  last_activity,
            "issueCount":    issue_count,
            "emails":        sup_emails,
            "awardNotificationSent":   sol_entry.get("awardNotificationSent", False) if sol_entry else False,
            "awardNotificationSentAt": sol_entry.get("awardNotificationSentAt") if sol_entry else None,
        })

    # Sort: Issues → Follow-up → Responded → Awarded → Awaiting
    ORDER = {"Issues Found": 0, "Follow-up Sent": 1, "Responded": 2, "Awarded": 3, "Complete": 3, "Awaiting": 4}
    supplier_rows.sort(key=lambda r: ORDER.get(r["status"], 5))

    return {"solicitation": solicitation, "suppliers": supplier_rows}


@router.get("/{bid_id}/emails", response_model=list[dict[str, Any]])
async def get_bid_emails(
    bid_id: str,
    repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> list[dict[str, Any]]:
    """List all email thread entries for a bid (flat list, not grouped)."""
    return await repo.get_for_bid(bid_id)


@router.post("/{bid_id}/emails", response_model=dict[str, Any], status_code=201)
async def create_bid_email(
    bid_id: str,
    body: dict[str, Any],
    background_tasks: BackgroundTasks,
    bids_repo: BidsRepository = Depends(get_bids_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> dict[str, Any]:
    """Log or send an email on a bid thread.

    For `direction=outbound`, the email is sent via SMTP before being saved (returns 502 on SMTP failure).
    For `direction=inbound`, the record is saved directly (manual log, no send).

    Sample input:
    ```json
    {
      "direction": "outbound",
      "supplierId": "SM-001",
      "supplierName": "Schwan's Food Service",
      "supplierEmail": "bids@demo-schwans.test",
      "subject": "Pricing Request: Lakeview USD — B2600042",
      "body": "Please submit pricing via the portal...",
      "bcc": ["bids@demo-schwans.test"],
      "tags": ["Solicitation"]
    }
    ```
    """
    # Fetch bid + all email threads for this bid in parallel — both are independent reads.
    bid, _prefetched_emails = await asyncio.gather(
        bids_repo.find_by_id(bid_id),
        email_threads_repo.get_for_bid(bid_id),
    )
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    direction = body.get("direction", "outbound")
    supplier_id = body.get("supplierId", "")

    # Resolve attachment paths (used for both the send and the record).
    # gs:// URIs (from GCS-enabled bid uploads) are passed through directly;
    # _build_attachments in the email provider handles the GCS download.
    # Local relative paths are resolved against UPLOADS_DIR.
    attachment_paths: list[str] = []
    for a in body.get("attachments", []):
        if not a:
            continue
        if a.startswith("gs://"):
            attachment_paths.append(a)
        else:
            full_path = UPLOADS_DIR / Path(a).name
            if full_path.exists():
                attachment_paths.append(str(full_path))
            else:
                log.warning("create_bid_email.attachment_not_found", path=a)

    # Look up the most recent graphInternetMessageId for this supplier so subsequent
    # emails thread correctly in Outlook via Graph createReply.
    # _prefetched_emails already fetched above — avoid a second round-trip.
    prior_internet_message_id: str | None = None
    supplier_to_email = body.get("to", "")
    if direction == "outbound":
        prior_internet_message_id = await _get_last_internet_message_id(
            bid_id, email_threads_repo,
            supplier_id=supplier_id or None,
            supplier_email=supplier_to_email,
            _prefetched_emails=_prefetched_emails,
        )

    # Build CC list from additional emails registered for this supplier on the bid
    cc_emails: list[str] = list(body.get("additionalEmails", []))
    if not cc_emails and supplier_id:
        for s in bid.get("solicitedSuppliers", []):
            if s.get("supplierId") == supplier_id:
                cc_emails = s.get("additionalEmails", [])
                break

    # Outbound emails — send via SMTP in background (non-fatal; failures write a bounce record)
    if direction == "outbound":
        from dependencies import get_email_service
        from services.email.base import EmailMessage
        svc = get_email_service()
        msg = EmailMessage(
            to=body.get("to", ""),
            bcc=body.get("bcc", []),
            cc=cc_emails,
            subject=body.get("subject", ""),
            body=body.get("body", ""),
            attachment_paths=attachment_paths,
            in_reply_to_internet_message_id=prior_internet_message_id,
        )

        email_record_ids_for_bg: list[str] = []  # filled below after records are written

        async def _send_and_flag() -> None:
            try:
                result = await svc.send_email(msg)
                # Store the Exchange-assigned RFC 2822 ID so future emails can thread under this one.
                # One bulk UPDATE instead of N×(full-scan+UPDATE) — avoids ~14s of background DB work.
                graph_internet_id = result.get("graphInternetMessageId", "")
                if graph_internet_id and email_record_ids_for_bg:
                    try:
                        await email_threads_repo.update_graph_message_ids(
                            email_record_ids_for_bg, graph_internet_id
                        )
                    except Exception as upd_exc:
                        log.warning("bid.email_graph_id_update_failed", error=str(upd_exc))
            except Exception as exc:
                log.warning("bid.email_send_failed", bid_id=bid_id, supplier_id=supplier_id, error=str(exc))
                # Write a delivery-failure record so Email Repo shows "Delivery Failed" banner
                await email_threads_repo.append({
                    "id": f"E-FAIL-{int(time.time() * 1000)}-{uuid.uuid4().hex[:6]}",
                    "bidId": bid_id,
                    "direction": "inbound",
                    "supplierId": supplier_id or None,
                    "supplierName": body.get("supplierName"),
                    "supplierEmail": body.get("to") or body.get("supplierEmail"),
                    "subject": body.get("subject", ""),
                    "body": f"Delivery failed: {exc}",
                    "date": datetime.now(timezone.utc).isoformat(),
                    "tags": ["bounce", "api-failure"],
                    "read": False,
                    "isBounce": True,
                    "bounceCode": "API",
                    "bounceReason": str(exc)[:200],
                    "originalRecipient": body.get("to") or body.get("supplierEmail"),
                })

        background_tasks.add_task(_send_and_flag)

    # Build attachment list for the email record.
    # Outbound (solicitations, reminders): store filenames from attachment_paths as plain strings
    # so they render as display-only pills in Email Repo (GCS URIs are not locally serveable).
    # Inbound (LogResponseModal pricing file): use {originalName, savedName, path} shape.
    pricing_path = body.get("pricingFilePath", "")
    if direction == "outbound" and attachment_paths:
        email_attachments: list[Any] = [p.split("/")[-1] for p in attachment_paths]
    elif pricing_path:
        saved_name = Path(pricing_path).name
        email_attachments = [{
            "originalName": saved_name,
            "savedName": saved_name,
            "path": str(UPLOADS_DIR / saved_name),
        }]
    else:
        email_attachments = []

    from_addr   = body.get("from", "")
    subject_str = body.get("subject", "")
    body_text   = body.get("body", "")
    tags: list[str] = list(body.get("tags", []))

    # Determine isBounce: explicit caller flag OR auto-detection from headers
    caller_is_bounce = bool(body.get("isBounce", False))
    auto_bounce      = _extract_bounce_fields(from_addr, subject_str, body_text) if direction == "inbound" else None
    is_bounce        = caller_is_bounce or (auto_bounce is not None)

    if is_bounce and "bounce" not in tags:
        tags.append("bounce")

    # Resolve flat bounce fields (caller-supplied wins over auto-parsed)
    bounce_code: str | None = None
    bounce_reason: str | None = None
    original_recipient: str | None = body.get("originalRecipient") or None

    if is_bounce:
        if auto_bounce:
            bounce_code        = auto_bounce["bounceCode"]
            bounce_reason      = auto_bounce["bounceReason"]
            original_recipient = original_recipient or auto_bounce.get("originalRecipient")
        bounce_code   = bounce_code   or body.get("bounceCode")   or "550"
        bounce_reason = bounce_reason or body.get("bounceReason") or "Delivery failure"

    # ── BCC solicitation: resolve per-supplier records ───────────────────────────────
    # For mass BCC solicitations, write one email record per supplier (supplierId set on each)
    # so Email Repo attribution works without any read-time hacks for new data.
    bcc_list: list[str] = body.get("bcc", [])
    is_bcc_solicitation = (
        "Solicitation" in tags
        and direction == "outbound"
        and bool(bcc_list)
        and not body.get("supplierId")
    )
    bcc_solicited_sups: list[dict] = []
    if is_bcc_solicitation:
        # Update solicited suppliers and get resolved {supplierId, supplierName, email} entries
        # back in one call — no separate find_one/find_by_id needed (saves ~660ms full-table scan).
        bcc_solicited_sups = await _update_solicited_suppliers(
            bid_id, bcc_list, bids_repo, solicitation_subject=subject_str
        )

    # Shared fields for all records written below
    _shared: dict[str, Any] = {
        "bidId":                   bid_id,
        "direction":               direction,
        "from":                    from_addr,
        "cc":                      cc_emails,
        "subject":                 subject_str,
        "body":                    body_text,
        "date":                    datetime.now(timezone.utc).isoformat(),
        "attachments":             email_attachments,
        "tags":                    tags,
        "read":                    False,
        "analysisResult":          None,
        "isBounce":                is_bounce,
        "bounceCode":              bounce_code,
        "bounceReason":            bounce_reason,
        "originalRecipient":       original_recipient,
        "portalSubmission":        False,
        "graphInternetMessageId":  "",
    }

    if is_bcc_solicitation and bcc_solicited_sups:
        # Build all per-supplier records first, then insert in one batch
        _written_ids: list[str] = []
        _batch: list[dict[str, Any]] = []
        for _sup in bcc_solicited_sups:
            _sup_email = _sup.get("email") or ""
            _rec: dict[str, Any] = {
                **_shared,
                "id":            f"E-{int(time.time() * 1000)}-{uuid.uuid4().hex[:6]}",
                "supplierId":    _sup["supplierId"],
                "supplierName":  _sup.get("supplierName") or "",
                "supplierEmail": _sup_email,
                "to":            _sup_email,
                "bcc":           [],
            }
            _batch.append(_rec)
            _written_ids.append(_rec["id"])
        await email_threads_repo.append_many(_batch)
        # email_record is a synthetic summary used only for the response body below
        email_record: dict[str, Any] = {
            **_shared,
            "id":            _written_ids[0] if _written_ids else "",
            "supplierId":    None,
            "supplierName":  None,
            "supplierEmail": None,
            "to":            "",
            "bcc":           bcc_list,
        }
        email_record_ids_for_bg = _written_ids
    else:
        # Standard path: single record (reply, re-solicit to one supplier, inbound log, etc.)
        email_record = {
            **_shared,
            "id":            f"E-{int(time.time() * 1000)}-{uuid.uuid4().hex[:6]}",
            "supplierId":    body.get("supplierId"),
            "supplierName":  body.get("supplierName"),
            "supplierEmail": body.get("supplierEmail"),
            "to":            body.get("to", ""),
            "bcc":           bcc_list,
        }
        await email_threads_repo.append(email_record)
        email_record_ids_for_bg = [email_record["id"]]

    # Update supplier status to "Issues Found" when a bounce is detected
    if is_bounce:
        target_email = (original_recipient or body.get("supplierEmail") or "").lower()
        if target_email:
            _BOUNCE_PROTECTED = {"Awarded", "Complete"}

            def _bounce_updater(bid_doc: dict[str, Any]) -> dict[str, Any]:
                for s in bid_doc.get("solicitedSuppliers", []):
                    if _email_matches(s, target_email):
                        if s.get("status") not in _BOUNCE_PROTECTED:
                            s["status"]       = "Issues Found"
                            s["hasIssues"]    = True
                            s["issueType"]    = "bounce"
                            s["lastActivity"] = datetime.now(timezone.utc).date().isoformat()
                return bid_doc

            try:
                await bids_repo.update_by_id(bid_id,_bounce_updater)
            except Exception as exc:
                log.warning("bid.bounce_status_update_failed", bid_id=bid_id, error=str(exc))

    # Update supplier status to "Responded" when a non-bounce inbound email is logged
    elif direction == "inbound" and not is_bounce:
        supplier_email = (body.get("supplierEmail") or "").lower()
        if supplier_email:
            _RESPOND_PROTECTED = {"Awarded", "Complete", "Under Consideration"}

            def _respond_updater(bid_doc: dict[str, Any]) -> dict[str, Any]:
                for s in bid_doc.get("solicitedSuppliers", []):
                    if _email_matches(s, supplier_email):
                        if s.get("status") not in _RESPOND_PROTECTED:
                            s["status"]       = "Responded"
                            s["lastActivity"] = datetime.now(timezone.utc).date().isoformat()
                return bid_doc

            try:
                await bids_repo.update_by_id(bid_id,_respond_updater)
            except Exception as exc:
                log.warning("bid.respond_status_update_failed", bid_id=bid_id, error=str(exc))

    # Track solicited suppliers on Solicitation sends
    # BCC solicitations: _update_solicited_suppliers already called above (before record write)
    if not is_bcc_solicitation and "Solicitation" in email_record.get("tags", []) and direction == "outbound":
        if bcc_list:
            await _update_solicited_suppliers(bid_id, bcc_list, bids_repo, solicitation_subject=subject_str)

    asyncio.ensure_future(_notify_bid(bid_id, {"type": "email_sent", "bidId": bid_id}))
    return {
        "success": True,
        "email": email_record,
        "sent": direction == "outbound",
        "recipientCount": len(body.get("bcc", [])),
        "attachedCount": len(attachment_paths),
        "messageId": email_record.get("id", ""),
    }


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# SUPPLIER STATUS OVERRIDE
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.patch("/{bid_id}/suppliers/{supplier_id}", response_model=dict[str, Any])
async def override_supplier_status(
    bid_id: str,
    supplier_id: str,
    body: dict[str, Any],
    repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    """Override the status of a solicited supplier on a bid.

    Sample input:
    ```json
    { "status": "Awarded" }
    ```
    Valid statuses: `Awaiting`, `Contacted`, `Responded`, `Issues Found`, `Follow-up Sent`, `Under Consideration`, `Awarded`.
    """
    new_status = body.get("status", "")

    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        solicited = bid.get("solicitedSuppliers", [])
        for s in solicited:
            if s.get("supplierId") == supplier_id or s.get("email") == supplier_id:
                s["status"] = new_status
                s["lastActivity"] = date.today().isoformat()
        return {**bid, "solicitedSuppliers": solicited}

    updated = await repo.update_one(lambda b: b.get("id") == bid_id, updater)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    asyncio.ensure_future(_notify_bid(bid_id, {
        "type": "supplier_updated", "bidId": bid_id,
        "supplierId": supplier_id, "status": new_status,
    }))
    return updated


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AWARD EMAIL
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def _send_award_background(
    *,
    bid_id: str,
    supplier_name: str,
    supplier_email: str,
    supplier_id: str,
    email_subject: str,
    email_body: str,
    attachment_paths: list[str],
    award_cc: list[str],
    prior_internet_mid: str | None,
    email_record_id: str,
    bids_repo: BidsRepository,
    email_threads_repo: EmailThreadsRepository,
) -> None:
    """Background coroutine: send the award email via MS Graph then write DB records.

    Fires via asyncio.ensure_future so the HTTP endpoint returns immediately.
    Errors are logged but never raised — a failed send writes a bounce-style record
    so Email Repo shows the delivery-failed banner.
    """
    from dependencies import get_email_service
    from services.email.base import EmailMessage

    svc = get_email_service()
    sent = False
    award_graph_mid = ""
    try:
        result = await svc.send_email(
            EmailMessage(
                to=supplier_email,
                bcc=[],
                cc=award_cc,
                subject=email_subject,
                body=email_body,
                attachment_paths=attachment_paths,
                in_reply_to_internet_message_id=prior_internet_mid,
            )
        )
        award_graph_mid = result.get("graphInternetMessageId", "")
        sent = True
    except Exception as exc:
        log.warning("bid.award_email_send_failed", bid_id=bid_id, error=str(exc))

    now = datetime.now(timezone.utc).isoformat()

    email_record: dict[str, Any] = {
        "id": email_record_id,
        "bidId": bid_id,
        "direction": "outbound",
        "supplierName": supplier_name,
        "supplierEmail": supplier_email,
        "supplierId": supplier_id,
        "subject": email_subject,
        "body": email_body,
        "date": now,
        "tags": ["Award", "award-notification"],
        "read": True,
        "isBounce": False,
        "awardEmail": True,
        "deliveryStatus": "sent" if sent else "failed",
        "graphInternetMessageId": award_graph_mid,
    }

    def mark_award(bid_doc: dict[str, Any]) -> dict[str, Any]:
        for s in bid_doc.get("solicitedSuppliers", []):
            if s.get("email") == supplier_email or s.get("supplierName") == supplier_name:
                s["awardNotificationSent"] = True
                s["awardNotificationSentAt"] = now
        return bid_doc

    writes: list[Any] = [
        email_threads_repo.append(email_record),
        bids_repo.update_by_id(bid_id, mark_award),
    ]

    if not sent:
        writes.append(email_threads_repo.append({
            "id": f"E-FAIL-AWARD-{uuid.uuid4().hex[:8]}",
            "bidId": bid_id,
            "direction": "inbound",
            "supplierId": supplier_id or None,
            "supplierName": supplier_name,
            "supplierEmail": supplier_email,
            "subject": email_subject,
            "body": "Award notification delivery failed",
            "date": now,
            "tags": ["bounce", "api-failure", "award-notification"],
            "read": False,
            "isBounce": True,
            "bounceCode": "API",
            "bounceReason": "Email delivery failed at API level",
            "originalRecipient": supplier_email,
        }))

    await asyncio.gather(*writes)


@router.post("/{bid_id}/send-award-email", response_model=dict[str, Any])
async def send_award_email(
    bid_id: str,
    supplierId: str = Form(""),
    supplierName: str = Form(""),
    supplierEmail: str = Form(""),
    to: str = Form(""),
    subject: str = Form(""),
    body: str = Form(""),
    attachments: list[UploadFile] = File(default=[]),
    bids_repo: BidsRepository = Depends(get_bids_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
) -> dict[str, Any]:
    """Send an award notification email to a supplier and log it.

    Accepts multipart/form-data (same as Node.js backend) so the frontend
    FormData payload — including optional file attachments — parses correctly.
    Marks `awardNotificationSent=true` on the supplier entry. Non-fatal if send fails.

    Returns immediately after validation — the MS Graph send runs in the background
    so the endpoint responds in ~100–200 ms instead of blocking for 2–4 s.
    """
    # Parallel DB reads — same pattern as create_bid_email
    bid, prefetched_emails = await asyncio.gather(
        bids_repo.find_by_id(bid_id),
        email_threads_repo.get_for_bid(bid_id),
    )
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    supplier_name  = supplierName
    supplier_email = supplierEmail
    supplier_id    = supplierId
    email_body     = body or build_award_email_body(
        supplier_name=supplier_name,
        customer_name=bid.get("customer", ""),
        bid_id=bid_id,
    )
    email_subject  = subject or build_award_email_subject(bid)

    # Save uploaded attachment files to UPLOADS_DIR so the email service can read them
    attachment_paths: list[str] = []
    for att in attachments:
        if att.filename:
            dest = UPLOADS_DIR / f"AWARD_{bid_id}_{att.filename}"
            content = await att.read()
            dest.write_bytes(content)
            attachment_paths.append(str(dest))

    # Build CC from the supplier's additional emails stored on the bid
    award_cc: list[str] = []
    for s in bid.get("solicitedSuppliers", []):
        if s.get("supplierId") == supplier_id or s.get("email") == supplier_email:
            award_cc = s.get("additionalEmails", [])
            break

    # Resolve the prior graphInternetMessageId using pre-fetched emails (no extra DB call)
    prior_internet_mid = await _get_last_internet_message_id(
        bid_id, email_threads_repo,
        supplier_id=supplier_id or None,
        supplier_email=supplier_email,
        _prefetched_emails=prefetched_emails,
    )

    # Generate the email record ID now so we can return it to the caller immediately
    email_record_id = f"E-AWARD-{bid_id}-{uuid.uuid4().hex[:8]}"

    # Fire-and-forget: MS Graph send + DB writes happen in background (~2–4 s)
    asyncio.ensure_future(_send_award_background(
        bid_id=bid_id,
        supplier_name=supplier_name,
        supplier_email=supplier_email,
        supplier_id=supplier_id,
        email_subject=email_subject,
        email_body=email_body,
        attachment_paths=attachment_paths,
        award_cc=award_cc,
        prior_internet_mid=prior_internet_mid,
        email_record_id=email_record_id,
        bids_repo=bids_repo,
        email_threads_repo=email_threads_repo,
    ))

    return {"ok": True, "queued": True, "emailId": email_record_id}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# EMAIL ANALYSIS RESULT
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.patch("/{bid_id}/emails/{email_id}/analysis", response_model=dict[str, Any])
async def save_email_analysis(
    bid_id: str,
    email_id: str,
    body: dict[str, Any],
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
    bids_repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    """Save AI analysis result to an email record.

    Analysis issues (missing items, format problems, etc.) indicate content problems in the
    supplier's pricing file — they do NOT affect the supplier's status in solicitedSuppliers.
    Supplier status = 'Issues Found' only for email delivery failures (bounces), set by the
    inbox poller, not by this endpoint.
    """
    analysis = body.get("analysisResult", body)

    def updater(e: dict[str, Any]) -> dict[str, Any]:
        return {**e, "analysisResult": analysis}

    updated = await email_threads_repo.update_one(
        lambda e: e.get("id") == email_id and e.get("bidId") == bid_id,
        updater,
    )
    if not updated:
        raise HTTPException(status_code=404, detail=f"Email {email_id!r} not found")

    return updated


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AI PRICING EXTRACTION FROM EMAIL ATTACHMENT
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.post("/{bid_id}/emails/{email_id}/extract-pricing")
async def extract_pricing_from_email(
    bid_id: str,
    email_id: str,
    files: list[str] | None = Query(None, description="Specific filenames to extract. Omit for single-file auto-detection. Pass multiple to extract all in parallel."),
    llm: LLMService = Depends(get_llm_service),
    bids_repo: BidsRepository = Depends(get_bids_repo),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
) -> StreamingResponse:
    """Extract supplier pricing from an email attachment (PDF / Excel / CSV) using AI. Returns text/event-stream.

    For portal submissions, uses structured pricing directly without AI.
    Falls back to email body text if no attachment is found.

    Pass ?files=file1.xlsx&files=file2.xlsx to extract multiple attachments in parallel.

    SSE events:
      {"type":"progress","stage":"reading","file":"...","fileIndex":N,"fileCount":N}
      {"type":"progress","stage":"extracting"}
      {"type":"done","result":{...}}
      {"type":"error","message":"..."}
    """
    # Early 404 validation runs before StreamingResponse is committed so HTTP errors propagate normally
    email = await email_threads_repo.find_one(
        lambda e: e.get("id") == email_id and e.get("bidId") == bid_id
    )
    if not email:
        raise HTTPException(status_code=404, detail=f"Email {email_id!r} not found")

    line_items = await line_items_repo.get_for_bid(bid_id)
    if not line_items:
        raise HTTPException(status_code=404, detail="No line items found for this bid")

    _extract_queue: asyncio.Queue = asyncio.Queue()

    async def _run_extraction_stream() -> None:
        try:
            await _extract_body(
                _extract_queue, email, email_id, bid_id, line_items,
                files, llm, submissions_repo,
            )
        except Exception as exc:
            log.error("pricing.stream_error", error=str(exc))
            await _extract_queue.put({"type": "error", "message": str(exc)})
        finally:
            await _extract_queue.put(None)

    async def _generator():
        asyncio.ensure_future(_run_extraction_stream())
        while True:
            event = await _extract_queue.get()
            if event is None:
                break
            yield f"data: {json.dumps(event)}\n\n"

    return StreamingResponse(_generator(), media_type="text/event-stream", headers={
        "Cache-Control": "no-cache",
        "X-Accel-Buffering": "no",
    })


async def _extract_body(
    queue: asyncio.Queue,
    email: dict[str, Any],
    email_id: str,
    bid_id: str,
    line_items: list[dict[str, Any]],
    files: list[str] | None,
    llm: LLMService,
    submissions_repo: Any,
) -> None:
    """Core pricing extraction logic, emitting SSE events via queue."""

    # Fast-path: portal submission with structured line-item prices
    all_subs: list[dict[str, Any]] = []
    if email.get("portalSubmission") and email.get("threadId"):
        all_subs = await submissions_repo.get_for_bid(bid_id)
        sub = next((s for s in all_subs if s.get("threadId") == email["threadId"]), None)
        if sub:
            portal_result = _build_portal_extraction_result(sub, line_items)
            if portal_result.get("items"):
                # Supplier filled in the form → emit done immediately (no LLM needed)
                await queue.put({"type": "done", "result": portal_result})
                return
            # Supplier uploaded a file but left form blank → fall through to file extraction

    # ── Multi-file extraction path ──────────────────────────────────────────────
    # When ?files= is provided, each filename is resolved from the email's attachments list
    # (savedName field) and extracted in parallel. Results are merged by sourceFile label.
    if files:
        # Build a lookup: savedName → resolved path (local UPLOADS_DIR or gs:// URI)
        att_path_map: dict[str, str] = {}
        for att in email.get("attachments", []):
            if isinstance(att, dict):
                saved = att.get("savedName") or att.get("path", "")
                path = att.get("path") or (str(UPLOADS_DIR / Path(saved).name) if saved else "")
                if saved:
                    att_path_map[Path(saved).name] = path
        # Also check pricingFilePath for single-attachment emails
        pfp = email.get("pricingFilePath", "")
        if pfp:
            att_path_map[Path(pfp).name] = pfp

        async def _extract_one_file(fname: str) -> dict[str, Any]:
            """Extract pricing from one attachment, tag all items with sourceFile."""
            path = att_path_map.get(fname) or str(UPLOADS_DIR / fname)
            # Build explicit GCS path for cross-instance reads (poller wrote the file on another
            # Cloud Run instance; local path won't exist here but GCS copy is durable).
            s = get_settings()
            gcs_path = f"gs://{s.gcs_bucket}/inbound/{fname}" if s.gcs_bucket else ""
            if fname.lower().endswith(".pdf"):
                raw = b""
                if gcs_path:                             # GCS-first when bucket configured
                    raw = await _read_raw_bytes(gcs_path)
                if not raw:                              # local fallback (dev mode or GCS miss)
                    raw = await _read_raw_bytes(path) if (path.startswith("gs://") or Path(path).exists()) else b""
                if not raw:
                    raw = await _read_attachment_bytes(fname)
                text = await _pdf_to_pricing_text(raw) if raw else ""
            elif path.startswith("gs://") or Path(path).exists():
                text = await _read_file_text(path)
            elif gcs_path:
                # Local path missing (different Cloud Run instance) — read directly from GCS
                text = await _read_file_text(gcs_path)
            else:
                text = await _read_attachment_text(fname)
            if not text:
                log.warning("pricing.file_not_readable", bid_id=bid_id, fname=fname,
                            local_path=path, gcs_path=gcs_path)
                return {"items": [], "sourceFile": fname, "error": f"File not found or unreadable: {fname}"}
            file_result = await _extract_generic_pricing(text, line_items, bid_id, llm)
            for item in file_result.get("items", []):
                item["sourceFile"] = fname
            return {**file_result, "sourceFile": fname}

        await queue.put({"type": "progress", "stage": "reading",
                         "fileCount": len(files),
                         "message": f"Reading {len(files)} file(s)..."})
        per_file_results = await asyncio.gather(*[_extract_one_file(f) for f in files])

        await queue.put({"type": "progress", "stage": "extracting",
                         "message": "Extracting pricing data..."})

        # Flatten all items into one list preserving sourceFile; deduplicate by matchedBidItemNo
        # per file (same item from two files stays as two rows so the user can choose which to save).
        combined_items: list[dict[str, Any]] = []
        file_diagnostics: list[dict[str, Any]] = []
        for fr in per_file_results:
            combined_items.extend(fr.get("items", []))
            # Collect per-file errors/notes so the frontend can show why items is empty
            diag: dict[str, Any] = {"file": fr.get("sourceFile", "")}
            if fr.get("error"):
                diag["error"] = fr["error"]
            if fr.get("documentNote"):
                diag["documentNote"] = fr["documentNote"]
            if fr.get("warning"):
                diag["warning"] = fr["warning"]
            if len(diag) > 1:
                file_diagnostics.append(diag)

        merged_result: dict[str, Any] = {
            "items": combined_items,
            "multiFile": True,
            "fileCount": len(files),
            "supplierName": email.get("supplierName") or "",
            "supplierEmail": email.get("supplierEmail") or "",
            "emailId": email_id,
            "sourceUsed": "multi",
        }
        if file_diagnostics:
            merged_result["fileDiagnostics"] = file_diagnostics
        _normalize_pricing_items(merged_result, line_items)
        log.info("pricing.multi_file_extracted", bid_id=bid_id, email_id=email_id,
                 files=files, items=len(merged_result.get("items", [])),
                 diagnostics=file_diagnostics)
        await queue.put({"type": "done", "result": merged_result})
        return

    await queue.put({"type": "progress", "stage": "reading",
                     "message": "Reading attachment..."})

    # ── Single-file path (original behaviour) ───────────────────────────────────
    # Get document text from attachment or pricingFilePath.
    # pricingFilePath is preferred: it may be a gs:// URI (Cloud Run) or "uploads/..." (local dev).
    # attachments[] is the fallback for non-portal emails; portal records store plain strings there.
    # source_used is the file extension (pdf/xlsx/csv) for the frontend SourceBadge, or "email".
    doc_text = ""
    source_file_name = ""
    source_used = "email"

    # Step 1 — prefer pricingFilePath (handles both gs:// and local)
    # GCS-first when bucket is configured: inbound attachments written by the poller on instance A
    # may not exist locally on instance B — GCS copy is always durable and cross-instance safe.
    _sf_settings = get_settings()
    pricing_fp = email.get("pricingFilePath", "")
    if pricing_fp:
        _fp_ext = Path(pricing_fp).suffix.lstrip(".").lower()
        _fp_fname = Path(pricing_fp).name
        _fp_inbound_gcs = f"gs://{_sf_settings.gcs_bucket}/inbound/{_fp_fname}" if _sf_settings.gcs_bucket else ""
        if _fp_ext == "pdf":
            raw = b""
            if _fp_inbound_gcs:                          # GCS-first when bucket configured
                raw = await _read_raw_bytes(_fp_inbound_gcs)
            if not raw:                                  # local / existing gs:// URI fallback
                if pricing_fp.startswith("gs://"):
                    raw = await _read_raw_bytes(pricing_fp)
                else:
                    raw = await _read_attachment_bytes(_fp_fname)
            if raw:
                doc_text = await _pdf_to_pricing_text(raw)
                source_file_name = _fp_fname
                source_used = "pdf"
        else:
            if _fp_inbound_gcs:                          # GCS-first when bucket configured
                doc_text = await _read_file_text(_fp_inbound_gcs)
            if not doc_text:
                if pricing_fp.startswith("gs://"):
                    doc_text = await _read_file_text(pricing_fp)
                else:
                    doc_text = await _read_attachment_text(_fp_fname)
            if doc_text:
                source_file_name = _fp_fname
                source_used = _fp_ext

    # Step 2 — fallback: attachments[] (inbound emails use dict format; portal uses plain strings)
    if not doc_text:
        for att in email.get("attachments", []):
            if isinstance(att, str):
                att_path = att
            else:
                att_path = att.get("path") or att.get("savedName", "")
            fname = Path(att_path).name if att_path else ""
            if not fname:
                continue
            _att_ext = Path(fname).suffix.lstrip(".").lower()
            _att_inbound_gcs = f"gs://{_sf_settings.gcs_bucket}/inbound/{fname}" if _sf_settings.gcs_bucket else ""
            if _att_ext == "pdf":
                raw = b""
                if _att_inbound_gcs:                     # GCS-first
                    raw = await _read_raw_bytes(_att_inbound_gcs)
                if not raw:
                    if att_path.startswith("gs://"):
                        raw = await _read_raw_bytes(att_path)
                    else:
                        raw = await _read_attachment_bytes(fname)
                if raw:
                    doc_text = await _pdf_to_pricing_text(raw)
            else:
                if _att_inbound_gcs:                     # GCS-first
                    doc_text = await _read_file_text(_att_inbound_gcs)
                if not doc_text:
                    if att_path.startswith("gs://"):
                        doc_text = await _read_file_text(att_path)
                    else:
                        doc_text = await _read_attachment_text(fname)
            if doc_text:
                source_file_name = fname
                source_used = _att_ext
                break

    if not doc_text:
        body_text = email.get("body", "")
        if body_text and len(body_text) > 100:
            doc_text = body_text
            source_used = "email"

    if not doc_text:
        await queue.put({"type": "error", "message": "No extractable content found in email", "status": 422})
        return

    await queue.put({"type": "progress", "stage": "extracting",
                     "message": "Extracting pricing data..."})

    result = await _extract_generic_pricing(doc_text, line_items, bid_id, llm)

    # Normalize each item to the contract PricingExtractModal expects:
    #   - Net field binds to unitPrice/netPrice → fill from deliveredPrice when absent
    #   - Resolve the AI's matchedBidItemNo → concrete lineItemId + matchedDescription so the
    #     row is savable (handleSave requires lineItemId) and auto-matches in the UI.
    _normalize_pricing_items(result, line_items)

    # Augment result with supplier context so PricingExtractModal can populate
    # supplierPricing entries with correct identity fields.
    result["supplierName"]   = email.get("supplierName") or ""
    result["supplierEmail"]  = email.get("supplierEmail") or ""
    result["emailId"]        = email_id
    result["sourceFileName"] = source_file_name
    result["sourceUsed"]     = source_used

    log.info(
        "pricing.extracted_from_email",
        bid_id=bid_id,
        email_id=email_id,
        items=len(result.get("items", [])),
        source=source_used,
    )
    await queue.put({"type": "done", "result": result})


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PORTAL REPLY (COE → Supplier)
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.post("/{bid_id}/portal-reply", response_model=dict[str, Any])
async def portal_reply(
    bid_id: str,
    body: dict[str, Any],
    bids_repo: BidsRepository = Depends(get_bids_repo),
    email_threads_repo: EmailThreadsRepository = Depends(get_email_threads_repo),
    submissions_repo: SubmissionsRepository = Depends(get_submissions_repo),
) -> dict[str, Any]:
    """Send a COE reply into a supplier's portal thread and email them a notification.

    Appends the message to `submissions.json`, mirrors it to `emailThreads.json`,
    and sends a Nodemailer email (non-fatal if SMTP fails).

    Sample input:
    ```json
    {
      "threadId": "THREAD-B2600042-1780000000",
      "supplierEmail": "bids@demo-schwans.test",
      "message": "Thank you for your submission. Please confirm the case price for item 0003."
    }
    ```
    """
    thread_id = body.get("threadId", "")
    message = body.get("message", "")
    supplier_email = body.get("supplierEmail", "")

    # Find the bid if not the one given (threadId is globally unique)
    bid = await bids_repo.find_by_id(bid_id)
    if not bid:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")

    msg_id = f"MSG-{uuid.uuid4().hex[:12].upper()}"
    new_msg: dict[str, Any] = {
        "id": msg_id,
        "direction": "outbound",
        "from": "bids@foodcorp.com",
        "fromName": "FoodCorp Bid COE",
        "body": message,
        "attachments": body.get("attachmentPaths", []),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "readBySupplier": False,
    }

    # Append to submissions.json thread
    def append_msg(sub: dict[str, Any]) -> dict[str, Any]:
        msgs = sub.get("messages", [])
        msgs.append(new_msg)
        return {**sub, "messages": msgs}

    await submissions_repo.update_submission(bid_id, thread_id, append_msg)

    # Look up the most recent graphInternetMessageId for this supplier so the COE reply
    # threads under the existing solicitation/submission conversation in Outlook.
    # Portal suppliers may not have a supplierId, so match by email.
    prior_internet_mid = await _get_last_internet_message_id(
        bid_id, email_threads_repo, supplier_email=supplier_email
    )

    # CC to additional emails on the supplier's solicitedSuppliers entry (if present)
    portal_cc: list[str] = []
    for s in bid.get("solicitedSuppliers", []):
        if s.get("email", "").lower() == supplier_email.lower():
            portal_cc = s.get("additionalEmails", [])
            break

    portal_subject = f"Re: Your pricing submission for {bid.get('customer', '')}"
    mirror_id = f"E-COE-REPLY-{uuid.uuid4().hex[:8]}"

    # Mirror to emailThreads.json (written before send so the record exists even if email fails)
    mirror: dict[str, Any] = {
        "id": mirror_id,
        "bidId": bid_id,
        "direction": "outbound",
        "supplierEmail": supplier_email,
        "subject": portal_subject,
        "body": message,
        "date": new_msg["timestamp"],
        "tags": ["portal-reply"],
        "read": True,
        "threadId": thread_id,
        "portalSubmission": True,
        "graphInternetMessageId": "",  # updated after successful send
    }
    await email_threads_repo.append(mirror)

    # Send email to supplier (non-fatal)
    try:
        from config import get_settings
        from dependencies import get_email_service
        from services.email.base import EmailMessage
        settings = get_settings()
        svc = get_email_service()
        result = await svc.send_email(
            EmailMessage(
                to=supplier_email,
                bcc=[],
                cc=portal_cc,
                subject=portal_subject,
                body=(
                    f"Hello,\n\n{message}\n\n"
                    f"View your portal thread: "
                    f"{settings.portal_base_url}/submit/{bid_id}/thread/{thread_id}\n\n"
                    "FoodCorp Bid COE"
                ),
                in_reply_to_internet_message_id=prior_internet_mid,
            )
        )
        portal_graph_mid = result.get("graphInternetMessageId", "")
        if portal_graph_mid:
            try:
                await email_threads_repo.update_graph_message_ids([mirror_id], portal_graph_mid)
            except Exception as upd_exc:
                log.warning("portal_reply.graph_id_update_failed", error=str(upd_exc))
    except Exception as exc:
        log.warning("portal_reply.email_failed", error=str(exc))

    return {"ok": True, "messageId": msg_id}


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# AUTO-REMINDER CONFIG
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.patch("/{bid_id}/auto-reminder", response_model=dict[str, Any])
async def update_auto_reminder(
    bid_id: str,
    body: dict[str, Any],
    repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    """Configure the auto-reminder scheduler for a bid.

    Sample input:
    ```json
    { "enabled": true, "daysAfterSolicitation": 3 }
    ```
    When enabled, the hourly scheduler sends portal-URL reminder emails to `Awaiting` suppliers
    who have not submitted pricing. Min 3-day gap between runs.
    """
    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        current = bid.get("autoReminder", {})
        return {**bid, "autoReminder": {**current, **body}}

    updated = await repo.update_one(lambda b: b.get("id") == bid_id, updater)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    return updated


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# PORTAL CONFIG
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

@router.patch("/{bid_id}/portal-config", response_model=dict[str, Any])
async def update_portal_config(
    bid_id: str,
    body: dict[str, Any],
    repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    """Apply a portal submission form template to a bid.

    Sample input:
    ```json
    {
      "templateId": "k12-standard",
      "customFields": [
        { "id": "halal", "label": "Halal Certified", "type": "yes_no", "showInWorkingFile": true }
      ]
    }
    ```
    Custom fields appear in the supplier portal form and (if `showInWorkingFile=true`) in the Working File.
    """
    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        return {**bid, "portalConfig": {**body, "appliedAt": datetime.now(timezone.utc).isoformat()}}

    updated = await repo.update_one(lambda b: b.get("id") == bid_id, updater)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    return updated


@router.patch("/{bid_id}/working-file-config", response_model=dict[str, Any])
async def update_working_file_config(
    bid_id: str,
    body: dict[str, Any],
    repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    """Save Working File column visibility / ordering preferences for a bid.

    Sample input:
    ```json
    { "hiddenColumns": ["cw", "stkType"], "columnOrder": ["bidItem", "description", "brand"] }
    ```
    """
    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        return {**bid, "workingFileConfig": body}

    updated = await repo.update_one(lambda b: b.get("id") == bid_id, updater)
    if not updated:
        raise HTTPException(status_code=404, detail=f"Bid {bid_id!r} not found")
    return updated


# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# INTERNAL HELPERS
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

async def _get_last_internet_message_id(
    bid_id: str,
    threads_repo: EmailThreadsRepository,
    supplier_id: str | None = None,
    supplier_email: str | None = None,
    _prefetched_emails: list[dict] | None = None,
) -> str | None:
    """Return the graphInternetMessageId of the most recent email in the bid+supplier thread.

    Searches both inbound (supplier's last reply) and outbound records so the next send
    can use createReply to properly thread in Outlook. Inbound emails appear more recent
    when the supplier has replied, which is exactly when we want to thread under their message.
    Returns None when no prior email with a stored graphInternetMessageId is found.

    Pass _prefetched_emails when the caller already fetched get_for_bid() to avoid a
    redundant round-trip (e.g. create_bid_email parallelizes find_by_id + get_for_bid).
    """
    emails = _prefetched_emails if _prefetched_emails is not None else await threads_repo.get_for_bid(bid_id)
    candidates: list[dict] = []
    supplier_email_lower = supplier_email.lower() if supplier_email else ""

    for e in emails:
        gid = e.get("graphInternetMessageId", "")
        if not gid:
            continue
        if e.get("isBounce"):
            # Bounce NDRs carry their own UUID-format Message-ID. createReply on an NDR
            # returns HTTP 400 ErrorInvalidOperation — never use them as threading anchors.
            continue
        if supplier_id and e.get("supplierId") == supplier_id:
            candidates.append(e)
        elif supplier_email_lower and (e.get("supplierEmail") or "").lower() == supplier_email_lower:
            candidates.append(e)

    if not candidates and supplier_email_lower:
        # Fallback: mass BCC solicitation writes one record with supplierId=null.
        # Check if the supplier's email appears in the bcc list of any outbound record.
        for e in emails:
            gid = e.get("graphInternetMessageId", "")
            if not gid or e.get("direction") != "outbound" or e.get("isBounce"):
                continue
            bcc_lower = [addr.lower() for addr in (e.get("bcc") or []) if addr]
            if supplier_email_lower in bcc_lower:
                candidates.append(e)

    if not candidates:
        # Last resort: thread against the bid's solicitation email so suppliers added after
        # the solicitation (or with no per-supplier record) still continue the conversation.
        for e in emails:
            gid = e.get("graphInternetMessageId", "")
            if gid and e.get("direction") == "outbound" and "Solicitation" in (e.get("tags") or []):
                return gid
        return None

    # Sort by date descending — most recent first (prefer supplier reply over our last outbound)
    candidates.sort(key=lambda e: e.get("date", ""), reverse=True)
    return candidates[0]["graphInternetMessageId"]


def _email_matches(entry: dict[str, Any], target: str) -> bool:
    """Check whether target matches the solicited-supplier entry's primary or any alias email."""
    known = [e.lower() for e in [entry.get("email", ""), *entry.get("additionalEmails", [])] if e]
    return target.lower() in known


async def _update_solicited_suppliers(
    bid_id: str, bcc_emails: list[str], bids_repo: BidsRepository,
    solicitation_subject: str = "",
) -> list[dict]:
    from dependencies import get_suppliers_repo
    suppliers = await get_suppliers_repo().load()

    # Build lookup keyed by ALL known emails so a BCC to an alias still resolves the supplier
    email_to_supplier: dict[str, dict] = {}
    for s in suppliers:
        for e in [s.get("contact", ""), *s.get("additionalEmails", [])]:
            if e:
                email_to_supplier[e.lower()] = s

    new_entries = []
    today = date.today().isoformat()
    for email in bcc_emails:
        sup = email_to_supplier.get(email.lower())
        if sup:
            entry: dict[str, Any] = {
                "supplierId": sup.get("id"),
                "supplierName": sup.get("name"),
                "email": email,
                "additionalEmails": sup.get("additionalEmails", []),
                "status": "Awaiting",
                "solicitedDate": today,
                "lastActivity": today,
                "awardNotificationSent": False,
                "awardNotificationSentAt": None,
            }
            if solicitation_subject:
                entry["solicitationSubject"] = solicitation_subject
            new_entries.append(entry)

    # Deduplicate new_entries by supplierId — keeps only the first (primary) email per supplier
    # so a supplier with 2 BCC addresses still becomes one solicitedSuppliers entry.
    seen_sids: set[str] = set()
    deduped: list[dict] = []
    for entry in new_entries:
        sid = entry.get("supplierId")
        if not sid or sid not in seen_sids:
            deduped.append(entry)
            if sid:
                seen_sids.add(sid)

    if deduped:
        await bids_repo.add_solicited_suppliers(bid_id, deduped, today)

    # Return resolved supplier entries for all BCC emails so the caller can build
    # per-supplier email records without an additional DB round-trip (find_one / find_by_id).
    resolved: list[dict] = []
    for email in bcc_emails:
        sup = email_to_supplier.get(email.lower())
        if sup:
            resolved.append({
                "supplierId":   sup.get("id"),
                "supplierName": sup.get("name"),
                "email":        email,
            })
    return resolved


async def _sync_award_to_line_items(
    bid_id: str,
    solicited_suppliers: list[dict[str, Any]],
    line_items_repo: LineItemsRepository,
) -> None:
    awarded = [s for s in solicited_suppliers if s.get("status") == "Awarded"]
    if not awarded:
        return
    awarded_names = {s.get("supplierName", "") for s in awarded}

    all_items = await line_items_repo.load()
    for item in all_items:
        if item.get("bidId") != bid_id:
            continue
        pricing_list = item.get("supplierPricing", [])
        item_changed = False
        for pricing in pricing_list:
            if pricing.get("supplierName") in awarded_names:
                if pricing.get("awardStatus") != "awarded":
                    pricing["awardStatus"] = "awarded"
                    item_changed = True
        if item_changed:
            item_id = item["id"]
            new_pricing = list(pricing_list)
            await line_items_repo.update_by_id(
                item_id,
                lambda it, _p=new_pricing: {**it, "supplierPricing": _p},
            )


async def _read_file_text(path: str) -> str:
    # Route through the shared cached extractor so a document is only extracted once
    # (reused across pricing extraction, the line-item parser, and the embedder).
    # Accepts either a local path or a gs:// URI (portal files stored in GCS on Cloud Run).
    try:
        if path.startswith("gs://"):
            from routers.rfp_parser import _read_source_bytes
            content = await _read_source_bytes(path)
        else:
            with open(path, "rb") as f:
                content = f.read()
        suffix = Path(path).suffix or ""
        # Use extract_full_text (no pdf_char_limit) so pricing extraction sees the
        # complete document. The chunked path in _extract_generic_pricing handles large
        # files — applying pdf_char_limit here silently drops pricing tables that start
        # after the 10k char mark in a long PDF.
        from services.document_text import extract_full_text
        return await extract_full_text(content, suffix=suffix)
    except Exception:
        return ""


async def _read_attachment_text(fname: str) -> str:
    """Read an inbound attachment by bare filename: local UPLOADS_DIR first, then GCS inbound/.

    On Cloud Run, the email poller runs on one instance and writes the file to that
    instance's ephemeral disk. Any other instance (or a restarted container) won't
    have the file locally. The poller dual-writes to GCS inbound/ for exactly this
    reason — so we must try GCS when the local file is absent.
    """
    local = UPLOADS_DIR / fname
    if local.exists():
        return await _read_file_text(str(local))
    s = get_settings()
    if s.gcs_bucket:
        result = await _read_file_text(f"gs://{s.gcs_bucket}/inbound/{fname}")
        if not result:
            log.warning("attachment.gcs_text_empty", fname=fname, bucket=s.gcs_bucket)
        return result
    return ""



async def _read_raw_bytes(path: str) -> bytes:
    """Return raw bytes from a local path or gs:// URI. Used by the PDF pricing pipeline."""
    try:
        if path.startswith("gs://"):
            from routers.rfp_parser import _read_source_bytes
            return await _read_source_bytes(path)
        with open(path, "rb") as f:
            return f.read()
    except Exception:
        return b""


async def _read_attachment_bytes(fname: str) -> bytes:
    """Read an inbound attachment as bytes: local UPLOADS_DIR first, then GCS inbound/."""
    local = UPLOADS_DIR / fname
    if local.exists():
        try:
            with open(local, "rb") as f:
                return f.read()
        except Exception:
            pass
    s = get_settings()
    if s.gcs_bucket:
        result = await _read_raw_bytes(f"gs://{s.gcs_bucket}/inbound/{fname}")
        if not result:
            log.warning("attachment.gcs_bytes_empty", fname=fname, bucket=s.gcs_bucket)
        return result
    return b""


_PRICE_RE = re.compile(r"\b\d+\.\d{2}\b")  # two-decimal numbers = likely price values
_TABLE_FIRST_ROW_RE = re.compile(r"\[TABLE \d+\]\n([^\n]+)")


def _filter_pricing_pages(pages: list[str]) -> list[str]:
    """Keep only pages that have a detected table AND price-like decimal numbers.

    Strips cover pages, instructions, T&C, and commodity notes without an LLM call.
    Falls back to all pages when no table-with-prices page is found (e.g. scanned PDFs).
    """
    pricing = [p for p in pages if "[TABLE" in p and _PRICE_RE.search(p)]
    return pricing if pricing else pages


async def _pdf_to_pricing_text(content: bytes) -> str:
    """Convert a supplier pricing PDF to clean flat text optimised for LLM extraction.

    Pipeline:
    1. extract_pdf_structured — per-page text with find_tables() column alignment
    2. Filter to pricing pages only (tables + decimal prices); fallback to all pages
    3. Detect column header from first table row; deduplicate it across pages
    4. Return flat text: column header row + all data rows (feeds _extract_generic_pricing unchanged)
    """
    if not content:
        return ""
    from services.pdf_structurer import extract_pdf_structured
    result = await extract_pdf_structured(content, char_limit=None)
    if not result.pages:
        return ""

    pages = _filter_pricing_pages(result.pages)
    log.info("pdf_pricing.pages_filtered",
             total=len(result.pages), pricing=len(pages))

    # Detect column header from the first table block on the first pricing page
    col_header = ""
    for page in pages:
        m = _TABLE_FIRST_ROW_RE.search(page)
        if m:
            col_header = m.group(1).strip()
            break

    # Assemble clean flat text: one column header + deduplicated data rows.
    # Use a flag (not `rows` emptiness) to track whether col_header has been emitted —
    # rows is populated with document header info BEFORE the first table, so checking
    # `rows` would incorrectly skip the column header on its first (and only) occurrence.
    col_header_added = False
    rows: list[str] = []
    for page in pages:
        for ln in page.splitlines():
            s = ln.strip()
            if not s:
                continue
            if s.startswith("[TABLE") or s.startswith("=== Page"):
                continue
            if col_header and s == col_header:
                if col_header_added:
                    # Column header repeats on each subsequent page's table — skip duplicates
                    continue
                col_header_added = True
            rows.append(s)

    return "\n".join(rows)


_CAT_WORDS = {
    "protein": ["chicken", "beef", "pork", "meat", "protein", "turkey"],
    "dairy": ["milk", "cheese", "dairy", "butter"],
    "grain": ["bread", "muffin", "grain", "cereal", "pretzel", "donut"],
    "produce": ["fruit", "vegetable", "apple", "peach", "pear", "corn"],
}
_METHODS = ["fully cooked", "breaded", "raw", "frozen", "grilled", "oven roasted", "baked"]
_SIZE_RE = re.compile(r"\b(\d+\.?\d*\s*(?:oz|lb|g|kg|cs|ct))\b", re.IGNORECASE)


def _score_to_label(s: int) -> str:
    return "high" if s >= 70 else "medium" if s >= 40 else "low"


def _backend_confidence(
    item: dict[str, Any], matched_li: dict[str, Any] | None, fuzzy_score: float
) -> tuple[int, str]:
    """Keyword-based confidence so a score always exists even when the AI omits one.

    Ported from the Node backend's backendConfidence(): base match (+10), product-type
    overlap (+40), category (+20), cooking method (+15), size/weight (+15), certification
    (+10), blended 60/40 with the fuzzy description-overlap score.
    """
    if not matched_li:
        return 0, "none"

    desc_a = (item.get("description") or "").lower()
    desc_b = (matched_li.get("description") or "").lower()
    # Base score for any matched item so partial overlap never stays at 0
    score = 10

    # Lower word-length floor to 2 so short but meaningful words (egg, oil, cn) count
    type_words = [w for w in desc_a.split() if len(w) > 2]
    if any(w in desc_b for w in type_words):
        score += 40

    cat = (matched_li.get("category") or "").lower()
    for c, kws in _CAT_WORDS.items():
        if c in cat and any(kw in desc_a for kw in kws):
            score += 20
            break

    m_a = next((m for m in _METHODS if m in desc_a), None)
    m_b = next((m for m in _METHODS if m in desc_b), None)
    if m_a and m_b and m_a == m_b:
        score += 15

    sizes_a = {m.group(1).lower().replace(" ", "") for m in _SIZE_RE.finditer(desc_a)}
    sizes_b = {m.group(1).lower().replace(" ", "") for m in _SIZE_RE.finditer(desc_b)}
    if sizes_a & sizes_b:
        score += 15

    if matched_li.get("childNutrition") and ("cn" in desc_a or "child nutrition" in desc_a):
        score += 5
    if matched_li.get("buyAmerican") and "buy american" in desc_a:
        score += 5

    # 60/40 blend: more weight on fuzzy so genuine word-overlap raises the score
    blended = round(score * 0.6 + (fuzzy_score * 100) * 0.4)
    capped = min(100, blended)
    return capped, _score_to_label(capped)


# Maps each "No X match" missed-reason label to its corresponding "X match" hit label.
# Used by _normalize_pricing_items to compute confidenceReasons server-side so the
# tooltip can never show the same string in both the ✓ and ✗ columns.
_RULE_LABEL_MAP: dict[str, str] = {
    "No product type match":   "Product type match",
    "No category match":       "Category match",
    "No cooking method match": "Cooking method match",
    "No size/weight match":    "Size/weight match",
    "No certification match":  "Certification match",
}


def _compute_missed_reasons(item: dict[str, Any], matched_li: dict[str, Any]) -> list[str]:
    """Return human-readable strings for scoring rules that did NOT fire.

    Uses the same keyword checks as _backend_confidence so the missed-reasons list
    is consistent with the numeric score shown in PricingExtractModal.
    """
    desc_a = (item.get("description") or "").lower()
    desc_b = (matched_li.get("description") or "").lower()
    missed: list[str] = []

    type_words = [w for w in desc_a.split() if len(w) > 2]
    if not any(w in desc_b for w in type_words):
        missed.append("No product type match")

    cat = (matched_li.get("category") or "").lower()
    cat_hit = any(c in cat and any(kw in desc_a for kw in kws) for c, kws in _CAT_WORDS.items())
    if not cat_hit:
        missed.append("No category match")

    m_a = next((m for m in _METHODS if m in desc_a), None)
    m_b = next((m for m in _METHODS if m in desc_b), None)
    if not (m_a and m_b and m_a == m_b):
        missed.append("No cooking method match")

    sizes_a = {m.group(1).lower().replace(" ", "") for m in _SIZE_RE.finditer(desc_a)}
    sizes_b = {m.group(1).lower().replace(" ", "") for m in _SIZE_RE.finditer(desc_b)}
    if not (sizes_a & sizes_b):
        missed.append("No size/weight match")

    cn_match = matched_li.get("childNutrition") and ("cn" in desc_a or "child nutrition" in desc_a)
    ba_match = matched_li.get("buyAmerican") and "buy american" in desc_a
    wg_match = matched_li.get("wholeGrain") and ("wg" in desc_a or "whole grain" in desc_a)
    if not (cn_match or ba_match or wg_match):
        missed.append("No certification match")

    return missed


def _normalize_pricing_items(
    result: dict[str, Any], line_items: list[dict[str, Any]]
) -> None:
    """Align extracted items with the fields PricingExtractModal consumes (in place).

    Ported from the Node backend's `enriched` step so matches/confidence are reliable even
    when the AI omits them:
      - netPrice fills the editable Net field (frontend reads unitPrice/netPrice); fall back
        to deliveredPrice.
      - Resolve to a concrete lineItemId + matchedDescription via, in order: exact bidItemNo
        (schwans/structured), the AI's matchedBidItemNo, then fuzzy description overlap.
      - Always compute a confidenceScore/label, preferring the AI's score when it gave one.
    """
    by_bid_item = {str(li.get("bidItem", "")).zfill(4): li for li in line_items}

    for item in result.get("items", []):
        if item.get("netPrice") is None:
            item["netPrice"] = item.get("deliveredPrice")

        # 1. Exact bid item number match (schwans / structured XLSX)
        exact = item.get("bidItemNo")
        if exact and (li := by_bid_item.get(str(exact).zfill(4))):
            item["lineItemId"] = li["id"]
            item["matchedBidItemNo"] = li.get("bidItem")
            item["matchedDescription"] = li.get("description")
            if item.get("confidenceScore") is None:
                item["confidenceScore"] = 95
            # Label is always derived from the final numeric score so the two never disagree.
            item["confidence"] = _score_to_label(item["confidenceScore"])
            continue

        # 2. AI-suggested matchedBidItemNo
        best_li: dict[str, Any] | None = None
        raw = item.get("matchedBidItemNo") or item.get("bid_item")
        if raw:
            best_li = by_bid_item.get(str(raw).zfill(4))

        # 3. Fuzzy description overlap removed — LLM match only.
        # Word-overlap at 0.2 threshold produced false positives worse than leaving unmatched.
        fuzzy_score = 0.0

        # 4. Confidence — prefer the AI's score (keep a legit 0), else the computed one.
        #    The label is always derived from the final score so number and color agree.
        bc_score, _bc_label = _backend_confidence(item, best_li, fuzzy_score)
        ai_score = item.get("confidenceScore")
        item["confidenceScore"] = min(100, ai_score if ai_score is not None else bc_score)
        item["confidence"] = _score_to_label(item["confidenceScore"])
        item["lineItemId"] = best_li["id"] if best_li else None
        item["matchedBidItemNo"] = best_li.get("bidItem") if best_li else None
        item["matchedDescription"] = best_li.get("description") if best_li else None
        missed = _compute_missed_reasons(item, best_li) if best_li else list(_RULE_LABEL_MAP.keys())
        item["missedReasons"]     = missed
        item["confidenceReasons"] = [_RULE_LABEL_MAP[k] for k in _RULE_LABEL_MAP if k not in set(missed)]

    # Dedup: same supplier product matched to same bid item = LLM duplicate. Keep highest confidence.
    # Different supplier products pointing to the same bid item are BOTH kept (valid multi-supplier).
    seen: dict[tuple, int] = {}
    deduped: list[dict] = []
    for it in result.get("items", []):
        desc = (it.get("description") or "").lower().strip()
        bid_no = it.get("matchedBidItemNo")
        key = (desc, bid_no)
        if key not in seen:
            seen[key] = len(deduped)
            deduped.append(it)
        elif it.get("confidenceScore", 0) > deduped[seen[key]].get("confidenceScore", 0):
            deduped[seen[key]] = it
    result["items"] = deduped


def _build_pricing_prompt(li_lines: str, doc_chunk: str) -> str:
    return f"""Extract all product pricing from the following supplier document.

BID LINE ITEMS (for matching — use these to identify which bid item each extracted price belongs to):
{li_lines}

SUPPLIER DOCUMENT:
{doc_chunk}
    
EXTRACTION RULES:
- Extract ALL line items present in the document, including those with missing or null prices.
- Do NOT skip or omit any item — if a price column exists but is blank for a row, still include
  that item with all price fields as null and explain the gap in the `notes` field
  (e.g. "Price not provided in document", "Pending commodity pricing", "No bid").
- If a document has no line items at all, return an empty items list [].
- Do NOT infer or calculate prices — only populate price fields when a value is explicitly stated.
- netPrice: identify the column by its MEANING — the final all-in price per case after any freight
  or allowances are applied (e.g. a "delivered", "net", or "final price" column). Do NOT calculate
  it by adding or subtracting other columns. Leave null if no such column exists.
- commercialPrice: identify by MEANING — a gross or list price before distributor allowances or
  deductions. Freight columns and FOB columns are NOT commercial price. Leave null if absent.
- ptvValue: identify by MEANING — a USDA commodity or government pass-through value per case.
  Leave null if absent.
- supplierItemNo: identify by MEANING — the supplier's own internal product code, SKU, or catalog
  number that they use in their own system. It is NOT the RFP bid line number. Leave null if no
  such product-identifier column exists.
- quantity is the case quantity if shown per line item (populate ONLY if explicitly stated).
- If a field's column cannot be identified in the document, output null — do NOT estimate or calculate it.

MATCHING ANTI-RULES — Critical:
- NEVER match by item code, serial number, SKU, or row position. Supplier item numbers
  (e.g. "1001", "SKU-4892") are NEVER the same as RFP bid item numbers (e.g. "0001").
  Match ONLY by product description similarity, pack, size, and category.

CONFIDENCE SCORING — score 0–100 using EXACTLY these additive rules (each rule is binary: fires or not):
- Product type match (same key noun in both, e.g. "drumstick" in supplier AND "drumstick" in bid item): +40
- Category match (protein/dairy/grain/produce keyword appears in both descriptions): +20
- Cooking method match (exact match: fully cooked / breaded / raw / frozen / grilled / oven roasted / baked): +15
- Size or weight match (same number+unit appears in both, e.g. "4oz" = "4oz" or "4.0 oz"): +15
- Certification match (CN / Child Nutrition / Buy American / WG appears in both): +10
Do NOT give partial credit. Each rule either fires (+points) or does not (0 points).
Total = sum of fired rules. Minimum score when a match exists = 5 (even if no rule fires).
IMPORTANT: confidenceScore must be an integer between 0 and 100.

MATCHING RULE — REQUIRED: For each extracted item, set matchedBidItemNo to the 4-digit bid item
number (e.g. "0001") of the best-matching BID LINE ITEM above. Only leave it null if the item
clearly has no corresponding bid line item (e.g. a freight charge, surcharge, or handling fee).

Return ONLY a JSON object, no markdown, no preamble:
{{"items": [{{"description": str, "supplierItemNo": str|null, "netPrice": num|null,
"commercialPrice": num|null, "ptvValue": num|null, "quantity": num|null,
"matchedBidItemNo": str|null, "matchedBidDescription": str|null,
"confidence": "high|medium|low", "confidenceScore": int,
"notes": str}}]}}"""


async def _extract_generic_pricing(
    doc_text: str,
    line_items: list[dict[str, Any]],
    bid_id: str,
    llm: LLMService,
) -> dict[str, Any]:
    li_lines = "\n".join(
        f"  Item {li.get('bidItem')}: {li.get('description')}"
        + (f" [{li['pack']} x {li['size']}]" if li.get("pack") and li.get("size") else
           f" [{li['pack']}]" if li.get("pack") else
           f" [{li['size']}]" if li.get("size") else "")
        + (f" [{li['category']}]" if li.get("category") else "")
        + (" [CN]" if li.get("childNutrition") else "")
        + (" [BA]" if li.get("buyAmerican") else "")
        + (" [PFS]" if li.get("pfsRequired") else "")
        for li in line_items
    )

    # Large-document path: chunk into 100-row batches and run LLM calls in parallel.
    # Triggers when EITHER the character count exceeds _CHUNK_THRESHOLD (risk of truncation
    # in single-pass) OR the row count exceeds _ROWS_PER_CHUNK (too many items for one call).
    # Using OR means a verbose 80-item sheet (>45k chars, <100 rows) is still chunked correctly
    # instead of being sent single-pass and silently truncated at [:55000].
    _CHUNK_THRESHOLD = 45_000  # chars — below this, fits comfortably in one LLM call
    _ROWS_PER_CHUNK = 100

    all_lines = doc_text.splitlines()
    use_chunked = len(doc_text) > _CHUNK_THRESHOLD and len(all_lines) > _ROWS_PER_CHUNK

    if use_chunked:
        # For Excel-extracted text, all_lines[0] is a "=== Sheet: X ===" separator —
        # not the column header. Find the first non-separator, non-empty line as the
        # true column header so every chunk starts with column names the LLM can use.
        # Without this, chunk 2+ have no column context and the LLM returns empty items.
        header = ""
        header_idx = 0
        for _i, _ln in enumerate(all_lines[:10]):
            if _ln.strip() and not _ln.startswith("==="):
                header = _ln
                header_idx = _i
                break
        if not header:  # plain text / no sheet separator — fall back to first non-empty line
            header = next((ln for ln in all_lines[:5] if ln.strip()), "")
            header_idx = 1 if header else 0
        data_lines = all_lines[header_idx + 1:]

        chunks: list[str] = []
        for i in range(0, len(data_lines), _ROWS_PER_CHUNK):
            batch = data_lines[i: i + _ROWS_PER_CHUNK]
            chunk_text = (header + "\n" + "\n".join(batch)) if header else "\n".join(batch)
            chunks.append(chunk_text)

        log.info("pricing.chunked_extraction", bid_id=bid_id, chunks=len(chunks), total_chars=len(doc_text))

        _s = get_settings()
        _llm_kwargs = dict(
            max_tokens=_s.llm_max_tokens,
            temperature=_s.llm_extraction_temperature,
            top_p=_s.llm_extraction_top_p,
            top_k=_s.llm_extraction_top_k,
            seed=_s.llm_extraction_seed,
        )

        async def _call_llm(chunk: str, chunk_idx: int) -> dict[str, Any]:
            prompt = _build_pricing_prompt(li_lines, chunk)
            try:
                result = await llm.chat(system=PRICING_EXTRACTION_SYSTEM, user=prompt, **_llm_kwargs)
                parsed = extract_json(result.content)
                return parsed if isinstance(parsed, dict) else {"items": parsed}
            except Exception as exc:
                log.warning("pricing.chunk_failed", chunk_idx=chunk_idx, error=str(exc))
                return {"items": []}

        chunk_results = await asyncio.gather(*[_call_llm(c, i) for i, c in enumerate(chunks)])

        # Merge: keep highest-confidence result per (matchedBidItemNo, supplier description) pair.
        # Key includes description so multiple DIFFERENT supplier products matching the same bid item
        # are all preserved — only true cross-chunk duplicates (same supplier row in 2 chunks) are dropped.
        # Unmatched items (no matchedBidItemNo) are deduped by description so a product that appears
        # in N chunks without a match isn't repeated N times in the modal.
        merged: dict[tuple, dict[str, Any]] = {}
        unmatched_seen: dict[str, dict[str, Any]] = {}
        for result in chunk_results:
            for item in result.get("items", []):
                bid_item_no = item.get("matchedBidItemNo")
                desc = (item.get("description") or "").lower().strip()
                if bid_item_no:
                    key = (bid_item_no, desc)
                    existing = merged.get(key)
                    if existing is None or item.get("confidenceScore", 0) > existing.get("confidenceScore", 0):
                        merged[key] = item
                else:
                    existing_u = unmatched_seen.get(desc)
                    if existing_u is None or item.get("confidenceScore", 0) > existing_u.get("confidenceScore", 0):
                        unmatched_seen[desc] = item

        return {"items": list(merged.values()) + list(unmatched_seen.values())}

    # Single-pass path for documents within the threshold.
    # Add a warning if the document had to be truncated to fit the LLM context window.
    truncated = len(doc_text) > 55_000
    user_prompt = _build_pricing_prompt(li_lines, doc_text[:55000])

    try:
        # Large ceiling: a full pricing sheet can be 30+ items × ~11 fields each. Too small a
        # limit truncates the JSON mid-object and extract_json fails. Both configured providers
        # (gemini-2.5-flash, claude-sonnet-4) support well above this.
        _s = get_settings()
        result = await llm.chat(
            system=PRICING_EXTRACTION_SYSTEM,
            user=user_prompt,
            max_tokens=_s.llm_max_tokens,
            temperature=_s.llm_extraction_temperature,
            top_p=_s.llm_extraction_top_p,
            top_k=_s.llm_extraction_top_k,
            seed=_s.llm_extraction_seed,
        )
        parsed = extract_json(result.content)
        data = parsed if isinstance(parsed, dict) else {"items": parsed}
        if truncated:
            data["warning"] = (
                "This document was too large to fully analyse in one pass. "
                "Only the first portion was processed — results may be incomplete. "
                "Consider splitting the file into smaller sheets."
            )
        return data
    except Exception as exc:
        log.error("pricing.generic_extract_failed", bid_id=bid_id, error=str(exc))
        return {"items": [], "error": str(exc)}


def _build_portal_extraction_result(
    sub: dict[str, Any], line_items: list[dict[str, Any]]
) -> dict[str, Any]:
    li_by_item = {li.get("bidItem", ""): li for li in line_items}
    items = []
    for li_price in sub.get("lineItems", []):
        item_no = str(li_price.get("itemNo", "")).zfill(4)
        li = li_by_item.get(item_no)
        if li and not li_price.get("noBid"):
            price = li_price.get("deliveredPrice") or li_price.get("unitPrice")
            if price:
                items.append({
                    "rfp_line_id": li["id"],
                    "bid_item": item_no,
                    "description": li.get("description", ""),
                    "deliveredPrice": price,
                    "fobPrice": li_price.get("fobPrice"),
                    "allowance": li_price.get("allowance"),
                    "devType": li_price.get("devType"),
                    "confidenceScore": 99,
                    "matchedBidItemNo": item_no,
                    "matchSource": "portal",
                })
    return {
        "items": items,
        "source": "portal",
        "supplierName": sub.get("supplierName"),
        "pricedCount": sub.get("pricedCount", 0),
        "noBidCount": sub.get("noBidCount", 0),
    }
