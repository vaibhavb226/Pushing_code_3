"""
POST /api/web-search/suppliers   — find food suppliers on the web
POST /api/web-search/find-email  — find contact email for a company
"""
from __future__ import annotations

import structlog
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from config import get_settings
from dependencies import get_llm_service
from routers.prompts import EMAIL_EXTRACTION_PROMPT, SUPPLIER_EXTRACTION_PROMPT
from services.llm.json_parser import extract_json
from services.llm.provider import LLMService
from services.web_search_service import langsearch_search

log = structlog.get_logger()
router = APIRouter(tags=["web-search"])


# ── Request / response models ─────────────────────────────────────────────────

class SupplierSearchRequest(BaseModel):
    categories: list[str] = ["Grocery"]
    segments: list[str] = []
    region: str = "National"
    compliance: str = ""       # free-text compliance requirements (e.g. "Halal, CN certified")
    keywords: str = ""
    limit: int = 5


class FindEmailRequest(BaseModel):
    companyName: str
    website: str | None = None


# ── Input validation ─────────────────────────────────────────────────────────

_MAX_FIELD_LEN = 200

# Terms that have no place in a food-procurement supplier search.
_BLOCKLIST = {
    # adult/explicit
    "porn", "xxx", "nude", "escort", "sex",
    # stalking / personal-data harvesting
    "home address", "personal phone", "private address", "ssn", "social security",
    "passport number", "credit card",
    # malware / hacking context
    "malware", "phishing", "exploit", "hack", "botnet",
    # drug / weapons
    "drugs", "cocaine", "heroin", "fentanyl", "firearm", "weapon",
}


def _validate_search_input(*fields: str) -> None:
    """Raise HTTP 400 if any field is too long or contains blocklisted terms.

    Keeps web-search inputs within the scope of legitimate food-procurement queries.
    """
    combined = " ".join(f.lower() for f in fields if f)
    if any(term in combined for term in _BLOCKLIST):
        raise HTTPException(
            400,
            detail="Search request contains inappropriate or unsupported content.",
        )
    for field in fields:
        if len(field) > _MAX_FIELD_LEN:
            raise HTTPException(
                400,
                detail=f"Search field exceeds maximum length ({_MAX_FIELD_LEN} characters).",
            )


# ── Helpers ───────────────────────────────────────────────────────────────────

def _results_to_text(results: list[dict]) -> str:
    """Convert LangSearch results to a readable block for the LLM."""
    lines: list[str] = []
    for i, r in enumerate(results, 1):
        lines.append(f"--- Result {i} ---")
        lines.append(f"Title: {r.get('name', '')}")
        lines.append(f"URL: {r.get('url', '')}")
        lines.append(f"Snippet: {r.get('snippet', '')}")
        summary = r.get("summary", "")
        if summary:
            lines.append(f"Full text:\n{summary[:3000]}")
        lines.append("")
    return "\n".join(lines)


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("/suppliers")
async def search_suppliers(
    body: SupplierSearchRequest,
    llm: LLMService = Depends(get_llm_service),
) -> dict:
    """Search the web for food suppliers matching a category/segment/keyword combination.

    Returns a list of structured supplier candidates that can be imported into the app.
    Requires LANGSEARCH_API_KEY to be configured (returns 503 otherwise).
    """
    _validate_search_input(
        *body.categories,
        body.keywords,
        body.compliance,
        body.region,
    )

    parts = list(body.categories) if body.categories else ["Grocery"]
    if body.keywords.strip():
        parts.append(body.keywords.strip())
    parts.append("food supplier")
    if body.segments:
        parts.extend(body.segments[:2])   # cap at 2 segments so query stays focused
    if body.region.strip() and body.region.lower() != "national":
        parts.append(body.region.strip())
    if body.compliance.strip():
        parts.append(body.compliance.strip())
    parts.append("contact email")

    query = " ".join(parts)
    log.info("web_search.suppliers.start", query=query, limit=body.limit,
             categories=body.categories, segments=body.segments)

    results = await langsearch_search(query, count=min(body.limit, 8), summary=True)

    if not results:
        return {"results": [], "query": query, "count": 0}

    results_text = _results_to_text(results)
    user_content = f"Search query: {query}\n\nSearch results:\n{results_text}"

    try:
        llm_result = await llm.chat(
            system=SUPPLIER_EXTRACTION_PROMPT,
            user=user_content,
            max_tokens=get_settings().llm_max_tokens,
        )
        parsed = extract_json(llm_result.content)
        suppliers = parsed.get("suppliers", [])
    except Exception as exc:
        log.warning("web_search.suppliers.llm_failed", error=str(exc))
        suppliers = []

    # Dedupe by name (case-insensitive)
    seen: set[str] = set()
    unique: list[dict] = []
    for s in suppliers:
        key = (s.get("name") or "").lower().strip()
        if key and key not in seen:
            seen.add(key)
            unique.append(s)

    log.info("web_search.suppliers.done", found=len(unique), query=query)
    return {"results": unique, "query": query, "count": len(unique)}


@router.post("/find-email")
async def find_email(
    body: FindEmailRequest,
    llm: LLMService = Depends(get_llm_service),
) -> dict:
    """Search the web for a contact email address for a named company.

    Returns ranked candidates (email, type, context). The caller decides which to use.
    Requires LANGSEARCH_API_KEY to be configured (returns 503 otherwise).
    """
    _validate_search_input(body.companyName, body.website or "")
    if len(body.companyName.strip()) < 2:
        raise HTTPException(400, detail="Company name is too short.")

    if body.website:
        # Prefer results from the company's own domain
        domain = body.website.replace("https://", "").replace("http://", "").split("/")[0]
        query = f'site:{domain} contact email OR "{body.companyName}" food company contact email purchasing'
    else:
        query = f'"{body.companyName}" food company contact email sales purchasing'

    log.info("web_search.find_email.start", company=body.companyName)

    results = await langsearch_search(query, count=5, summary=True)

    if not results:
        return {"candidates": []}

    results_text = _results_to_text(results)
    user_content = f"Search results for company email lookup:\n{results_text}"

    try:
        llm_result = await llm.chat(
            system=EMAIL_EXTRACTION_PROMPT.replace("{company_name}", body.companyName),
            user=user_content,
            max_tokens=get_settings().llm_max_tokens,
        )
        parsed = extract_json(llm_result.content)
        emails = parsed.get("emails", [])
    except Exception as exc:
        log.warning("web_search.find_email.llm_failed", company=body.companyName, error=str(exc))
        emails = []

    # Dedupe by address
    seen_emails: set[str] = set()
    unique_emails: list[dict] = []
    for e in emails:
        addr = (e.get("email") or "").lower().strip()
        if addr and "@" in addr and addr not in seen_emails:
            seen_emails.add(addr)
            unique_emails.append(e)

    log.info("web_search.find_email.done", company=body.companyName, found=len(unique_emails))
    return {"candidates": unique_emails[:5]}
