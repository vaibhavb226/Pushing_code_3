"""
POST /api/reports/send-email
Generate and email the bid pipeline HTML report with live bid data as an attachment.
"""
from __future__ import annotations

import json
import os
import re
import tempfile
from datetime import date
from pathlib import Path
from typing import Any

import structlog
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response

from dependencies import get_bids_repo, get_email_service
from repositories.bids_repo import BidsRepository
from services.email.base import AbstractEmailService, EmailMessage

log = structlog.get_logger()
router = APIRouter(tags=["reports"])

_REPORT_PATH = Path(__file__).parents[2] / "frontend/public/reports/FoodCorp_Bid_Pipeline_Report.html"

_COMPLIANCE_MAP: dict[str, str] = {
    "Child Nutrition": "CN",
    "Buy American": "Buy Am.",
    "PFS Required": "PFS",
    "PFS": "PFS",
    "Halal": "Halal",
    "Kosher": "Kosher",
    "Vegan": "Vegan",
    "SOX": "SOX",
}

_RESPONDED = {"Responded", "Follow-up Sent", "Under Consideration", "Issues Found", "Awarded", "Complete"}


def _response_rate(bid: dict[str, Any]) -> int:
    solicited = bid.get("solicitedSuppliers") or []
    total = len(solicited) or bid.get("suppliersContacted") or 0
    if total == 0:
        return 0
    responded = sum(1 for s in solicited if s.get("status") in _RESPONDED)
    return round(responded / total * 100)


def _due_info(bid: dict[str, Any]) -> tuple[str, str]:
    internal = bid.get("internalDue") or ""
    if not internal:
        return bid.get("customerDue") or "TBD", "ok"
    try:
        d = date.fromisoformat(internal)
    except ValueError:
        return internal, "ok"
    today = date.today()
    delta = (d - today).days
    if delta < 0:
        return f"{abs(delta)}d overdue", "overdue"
    if delta == 0:
        return "Due Today", "critical"
    if delta <= 3:
        return f"{delta}d left", "critical"
    if delta <= 7:
        return f"{delta}d left", "warning"
    return f"{d.strftime('%b')} {d.day}, {d.year}", "ok"


def _build_report_bids(bids: list[dict[str, Any]]) -> list[dict[str, Any]]:
    result = []
    for b in bids:
        due_label, due_status = _due_info(b)
        opco = b.get("opco") or ""
        opco_name = b.get("opcoName") or ""
        opco_str = f"{opco} · {opco_name}".strip(" ·") if opco or opco_name else ""
        compliance_raw = b.get("compliance") or []
        compliance = [_COMPLIANCE_MAP.get(t, t) for t in compliance_raw]
        result.append({
            "id": b.get("id") or "",
            "customer": b.get("customer") or "",
            "segment": b.get("segment") or "",
            "opco": opco_str,
            "status": b.get("status") or "",
            "response": _response_rate(b),
            "dueLabel": due_label,
            "dueStatus": due_status,
            "compliance": compliance,
        })
    return result


def _live_init_script(report_bids: list[dict[str, Any]]) -> str:
    """JS IIFE appended to the report to update KPI cards, subtexts, alert table, and footer date."""
    total = len(report_bids)
    avg_resp = round(sum(b["response"] for b in report_bids) / total) if total else 0
    overdue_count = sum(1 for b in report_bids if b["dueStatus"] == "overdue")
    at_risk_count = sum(
        1 for b in report_bids if b["status"] == "At Risk" or b["dueStatus"] in ("warning", "critical")
    )
    awarded_count = sum(1 for b in report_bids if b["status"] == "Awarded")
    seg_count = len({b["segment"] for b in report_bids if b["segment"]})
    above50 = sum(1 for b in report_bids if b["response"] >= 50)
    today = date.today()
    today_str = f"{today.strftime('%B')} {today.day}, {today.year}"

    return f"""
(function() {{
  var kv = document.querySelectorAll('.kpi-value');
  if (kv.length >= 5) {{
    kv[0].textContent = {total};
    kv[1].textContent = '{avg_resp}%';
    kv[2].textContent = {overdue_count};
    kv[3].textContent = {at_risk_count};
    kv[4].textContent = {awarded_count};
  }}
  var ks = document.querySelectorAll('.kpi-sub');
  if (ks.length >= 2) {{
    ks[0].textContent = 'Across {seg_count} segment' + ({seg_count} !== 1 ? 's' : '');
    ks[1].textContent = '{above50} of {total} bids above 50%';
  }}
  var alertTitle = document.querySelector('.alert-title');
  var flagged = bids.filter(function(b) {{ return b.dueStatus !== 'ok'; }});
  flagged.sort(function(a, b) {{
    var ord = {{overdue: 0, critical: 1, warning: 2}};
    return ((ord[a.dueStatus] !== undefined ? ord[a.dueStatus] : 3) -
            (ord[b.dueStatus] !== undefined ? ord[b.dueStatus] : 3));
  }});
  if (alertTitle) alertTitle.textContent = 'Bids Requiring Immediate Attention — ' + flagged.length + ' Flagged';
  var tbody = document.querySelector('.alert-table tbody');
  if (tbody) {{
    tbody.innerHTML = flagged.map(function(b) {{
      var issueText = b.dueStatus === 'overdue' ? 'Overdue — review' :
                      b.status === 'At Risk'    ? 'At Risk — low responses' : 'Due soon';
      var issueColor = b.dueStatus === 'overdue' ? 'var(--red)' : 'var(--amber)';
      var badgeCls   = b.dueStatus === 'overdue' ? 'overdue-badge' : 'warning-badge';
      var rc = b.response >= 75 ? 'var(--green)' : b.response >= 50 ? '#F59E0B' : 'var(--red)';
      return '<tr>' +
        '<td><div class="bid-name">' + b.customer + '</div><div class="bid-id-sm">' + b.id + '</div></td>' +
        '<td>' + b.segment + '</td><td>' + b.opco + '</td>' +
        '<td><span class="badge ' + (STATUS_CLASS[b.status] || '') + '"><span class="badge-dot"></span>' + b.status + '</span></td>' +
        '<td><div class="resp-inline"><div class="resp-inline-bar">' +
          '<div class="resp-inline-fill" style="width:' + b.response + '%;background:' + rc + ';"></div></div>' +
          '<span class="resp-inline-pct" style="color:' + rc + '">' + b.response + '%</span></div></td>' +
        '<td><span class="' + badgeCls + '">' + b.dueLabel + '</span></td>' +
        '<td style="color:' + issueColor + ';font-size:11px;">' + issueText + '</td>' +
        '</tr>';
    }}).join('');
  }}
  var footer = document.querySelector('.report-footer div');
  if (footer) footer.textContent = 'FoodCorp RFP AIQ · Bid Pipeline Report · Generated {today_str}';
}})();
"""


def _inject_live_data(html: str, report_bids: list[dict[str, Any]]) -> str:
    bids_json = json.dumps(report_bids, ensure_ascii=False)
    html = re.sub(
        r"const bids\s*=\s*\[[\s\S]*?\];",
        f"const bids = {bids_json};",
        html,
    )
    html = html.replace("</script>", _live_init_script(report_bids) + "\n</script>", 1)
    return html


@router.get("/live")
async def get_live_report(
    bids_repo: BidsRepository = Depends(get_bids_repo),
) -> Response:
    """Return the bid pipeline HTML report with live bid data baked in.

    Served as a file download so the browser saves it locally. The file still
    contains the live-fetch JS, so it will refresh itself when opened while
    connected to the backend.
    """
    if not _REPORT_PATH.exists():
        raise HTTPException(status_code=500, detail="Report template not found on server.")

    all_bids = await bids_repo.load()
    report_bids = _build_report_bids(all_bids)
    html = _inject_live_data(_REPORT_PATH.read_text(encoding="utf-8"), report_bids)

    today = date.today()
    filename = f"FoodCorp_Bid_Pipeline_{today.strftime('%b%Y')}.html"
    return Response(
        content=html.encode("utf-8"),
        media_type="text/html",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("/send-email", response_model=dict[str, Any])
async def send_report_email(
    body: dict[str, Any],
    svc: AbstractEmailService = Depends(get_email_service),
    bids_repo: BidsRepository = Depends(get_bids_repo),
) -> dict[str, Any]:
    """Email the bid pipeline HTML report with live data to the supplied address."""
    to = (body.get("to") or "").strip()
    if not to:
        raise HTTPException(status_code=400, detail="'to' email address is required.")

    if not _REPORT_PATH.exists():
        raise HTTPException(status_code=500, detail="Report template not found on server.")

    all_bids = await bids_repo.load()
    report_bids = _build_report_bids(all_bids)
    html = _inject_live_data(_REPORT_PATH.read_text(encoding="utf-8"), report_bids)

    tmp_dir = tempfile.mkdtemp()
    tmp_path = os.path.join(tmp_dir, "FoodCorp_Bid_Pipeline_Report.html")
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(html)

        await svc.send_email(EmailMessage(
            to=to,
            bcc=[],
            subject="FoodCorp Bid Pipeline Report",
            body="Please find the attached FoodCorp Bid Pipeline Report with live bid queue data.",
            body_is_html=False,
            attachment_paths=[tmp_path],
        ))
    except Exception as exc:
        log.error("reports.send_email_failed", to=to, error=str(exc))
        raise HTTPException(status_code=502, detail=f"Email send failed: {exc}") from exc
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)
        if os.path.exists(tmp_dir):
            os.rmdir(tmp_dir)

    log.info("reports.sent", to=to, bid_count=len(report_bids))
    return {"ok": True}
