"""
Database query logger — instruments every asyncpg query automatically.

Pass LoggingConnection as the connection_class when creating the asyncpg pool
(db/connection.py). Every execute / fetch / fetchrow / fetchval / executemany
call then logs to the "db" logger, which routing_config.py routes to db.log.

What is logged per query:
  event       : "db.query" or "db.query_error"
  op          : SQL verb (SELECT / INSERT / UPDATE / DELETE / …)
  sql         : first 400 chars of the SQL template (no bind-param values — safe to log)
  elapsed_ms  : wall-clock time in milliseconds
  rows        : row count returned / affected (where available)
  status      : asyncpg status string, e.g. "INSERT 0 1" / "UPDATE 3"
  slow        : True when elapsed_ms exceeds DB_SLOW_QUERY_MS threshold

Slow queries (elapsed_ms > DB_SLOW_QUERY_MS, default 200) are logged at
WARNING level so they also land in errors.log for easy alerting.

Pool statistics are logged at startup via log_pool_stats(); call it once after
the pool is created.

DB_SLOW_QUERY_MS env var — change the slow-query threshold (milliseconds).
"""
from __future__ import annotations

import os
import sys
import time
from typing import Any

import asyncpg
import structlog

_db_log = structlog.get_logger("db")
_SLOW_MS: float = float(os.getenv("DB_SLOW_QUERY_MS", "200"))

# asyncpg runs this reset sequence whenever a connection is returned to the pool.
# It is pool-internal plumbing — not application SQL — so we skip logging it.
_ASYNCPG_RESET_SQL = (
    "SELECT pg_advisory_unlock_all();\n"
    "CLOSE ALL;\n"
    "UNLISTEN *;\n"
    "RESET ALL;"
)


# ── Caller frame resolution ────────────────────────────────────────────────────

# Path fragments that identify non-application frames to skip when walking
# the call stack.  We want the first frame that belongs to *our* code, not to
# asyncpg internals, asyncio, structlog, or this file.
_SKIP_PATH_FRAGMENTS = ("asyncpg", "asyncio", "structlog", "logging")
_SKIP_BASENAMES = frozenset({"query_logger.py"})


def _app_caller(depth: int = 3) -> str:
    """Return up to `depth` application frames as a call chain.

    Example: 'pg_bids_repo.py:load:87 → email_poller.py:run_poll:175 → ...'

    Walks sys._getframe() upward — no source-file reads, sub-microsecond cost.
    Skips this file plus asyncpg / asyncio / structlog internals so only
    application frames (repos, routers, services) appear in the chain.
    """
    frames: list[str] = []
    frame = sys._getframe()
    while frame is not None and len(frames) < depth:
        fname = frame.f_code.co_filename.replace("\\", "/")
        base = os.path.basename(fname)
        if base not in _SKIP_BASENAMES and not any(p in fname for p in _SKIP_PATH_FRAGMENTS):
            frames.append(f"{base}:{frame.f_code.co_name}:{frame.f_lineno}")
        frame = frame.f_back
    return " → ".join(frames) if frames else "unknown"


# ── Helpers ────────────────────────────────────────────────────────────────────

def _ms(t0: float) -> float:
    """Elapsed milliseconds since t0 (perf_counter), rounded to 2dp."""
    return round((time.perf_counter() - t0) * 1000, 2)


def _op(sql: str) -> str:
    """Extract the leading SQL verb (SELECT, INSERT, …) from a query string."""
    token = sql.strip().split(None, 1)[0].upper() if sql.strip() else "QUERY"
    return token if token in {
        "SELECT", "INSERT", "UPDATE", "DELETE", "TRUNCATE",
        "CREATE", "DROP", "ALTER", "WITH", "COPY",
    } else token


def _emit(sql: str, elapsed_ms: float, **extra: Any) -> None:
    """Emit a db.query log at INFO or WARNING depending on latency."""
    slow = elapsed_ms > _SLOW_MS
    level = "warning" if slow else "info"
    getattr(_db_log, level)(
        "db.query",
        op=_op(sql),
        sql=sql[:400].strip(),
        elapsed_ms=elapsed_ms,
        slow=slow,
        caller=_app_caller(),
        **extra,
    )


def _emit_error(sql: str, elapsed_ms: float, exc: Exception) -> None:
    """Emit a db.query_error log."""
    _db_log.error(
        "db.query_error",
        op=_op(sql),
        sql=sql[:400].strip(),
        elapsed_ms=elapsed_ms,
        error=str(exc),
    )


# ── Instrumented connection ────────────────────────────────────────────────────

class LoggingConnection(asyncpg.Connection):
    """
    asyncpg.Connection subclass that wraps every query method with timing +
    structured logging.  Pass as `connection_class` to asyncpg.create_pool().

    Bind-parameter *values* are never logged — only the SQL template — so
    passwords, PII, and other sensitive column values are never written to disk.
    """

    async def execute(self, query: str, *args: Any, timeout: float | None = None) -> str:
        if query.strip() == _ASYNCPG_RESET_SQL:
            return await super().execute(query, *args, timeout=timeout)
        t0 = time.perf_counter()
        try:
            result: str = await super().execute(query, *args, timeout=timeout)
            ms = _ms(t0)
            _emit(query, ms, status=result)
            return result
        except Exception as exc:
            _emit_error(query, _ms(t0), exc)
            raise

    async def fetch(self, query: str, *args: Any, timeout: float | None = None) -> list:
        t0 = time.perf_counter()
        try:
            rows = await super().fetch(query, *args, timeout=timeout)
            ms = _ms(t0)
            _emit(query, ms, rows=len(rows))
            return rows
        except Exception as exc:
            _emit_error(query, _ms(t0), exc)
            raise

    async def fetchrow(self, query: str, *args: Any, timeout: float | None = None):
        t0 = time.perf_counter()
        try:
            row = await super().fetchrow(query, *args, timeout=timeout)
            ms = _ms(t0)
            _emit(query, ms, rows=1 if row is not None else 0)
            return row
        except Exception as exc:
            _emit_error(query, _ms(t0), exc)
            raise

    async def fetchval(
        self, query: str, *args: Any, column: int = 0, timeout: float | None = None
    ) -> Any:
        t0 = time.perf_counter()
        try:
            val = await super().fetchval(query, *args, column=column, timeout=timeout)
            ms = _ms(t0)
            _emit(query, ms)
            return val
        except Exception as exc:
            _emit_error(query, _ms(t0), exc)
            raise

    async def executemany(
        self, command: str, args: list, *, timeout: float | None = None
    ) -> None:
        t0 = time.perf_counter()
        try:
            await super().executemany(command, args, timeout=timeout)
            ms = _ms(t0)
            _emit(command, ms, rows=len(args))
        except Exception as exc:
            _emit_error(command, _ms(t0), exc)
            raise


# ── Pool stats helper ──────────────────────────────────────────────────────────

def log_pool_stats(pool: "asyncpg.Pool") -> None:
    """Emit a db.pool_stats log.  Call once after pool creation."""
    try:
        _db_log.info(
            "db.pool_stats",
            size=pool.get_size(),
            idle=pool.get_idle_size(),
            max_size=pool.get_max_size(),
            min_size=pool.get_min_size(),
        )
    except Exception:
        pass  # pool stats are advisory — never crash on them
