"""
PostgreSQL connection helpers.

Two separate pools:
  1. SQLAlchemy AsyncEngine (_engine) — used exclusively for pgvector/embedding queries.
  2. asyncpg.Pool (_pg_pool) — used by all CRUD repositories (PgBidsRepository, etc.).

If DB_HOST is empty both return None and the app falls back to JSON flat-file repos.
"""
from __future__ import annotations

import json as _json
from contextlib import asynccontextmanager
from typing import TYPE_CHECKING, AsyncIterator

import asyncpg
import structlog

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine

log = structlog.get_logger()

# ── SQLAlchemy engine (pgvector only) ─────────────────────────────────────────
_engine: "AsyncEngine | None" = None

# ── asyncpg pool (CRUD repos) ─────────────────────────────────────────────────
_pg_pool: "asyncpg.Pool | None" = None


def get_engine(settings) -> "AsyncEngine | None":
    """Return (or lazily create) the shared SQLAlchemy AsyncEngine singleton (pgvector)."""
    global _engine
    if _engine is None and settings.db_host:
        try:
            from sqlalchemy.ext.asyncio import create_async_engine
            _engine = create_async_engine(
                settings.pg_dsn,
                pool_size=5,
                max_overflow=5,
                pool_pre_ping=False,   # disabled — pgvector pool only used for ANN; pre-ping adds latency
                pool_recycle=1800,
                echo=False,
            )
            log.info("db.engine_created", host=settings.db_host, port=settings.db_port)
        except Exception as exc:
            log.error("db.engine_failed", error=str(exc))
    return _engine


@asynccontextmanager
async def get_db_conn(settings) -> "AsyncIterator[AsyncConnection | None]":
    """
    Async context manager that yields an AsyncConnection from the SQLAlchemy pool,
    or None if DB_HOST is not configured (falls back to rule-based logic).
    """
    engine = get_engine(settings)
    if engine is None:
        yield None
        return
    connected = False
    try:
        async with engine.connect() as conn:
            connected = True
            yield conn
    except Exception as exc:
        if connected:
            raise
        log.error("db.connection_failed", error=str(exc), exc_info=True)
        yield None


async def close_engine() -> None:
    """Call at application shutdown to drain the SQLAlchemy connection pool."""
    global _engine
    if _engine is not None:
        await _engine.dispose()
        _engine = None
        log.info("db.engine_closed")


# ── asyncpg pool ──────────────────────────────────────────────────────────────

async def _init_connection(conn: asyncpg.Connection) -> None:
    """Register JSON/JSONB codecs so asyncpg auto-encodes/decodes Python dicts and lists."""
    await conn.set_type_codec(
        "jsonb",
        encoder=_json.dumps,
        decoder=_json.loads,
        schema="pg_catalog",
    )
    await conn.set_type_codec(
        "json",
        encoder=_json.dumps,
        decoder=_json.loads,
        schema="pg_catalog",
    )


async def create_asyncpg_pool(settings) -> "asyncpg.Pool | None":
    """
    Create the asyncpg connection pool used by all PG CRUD repos.
    Returns None when DB_HOST is not configured — repos fall back to JSON.

    Call once from main.py lifespan startup.

    Pool sizing:
      max_size — configurable via DB_POOL_MAX env var (default 10).
      min_size — configurable via DB_POOL_MIN env var; DEFAULTS TO max_size so the
                 pool is fully warm.

      Why warm (min_size == max_size)? The app connects to Cloud SQL over a
      high-RTT link (~330 ms India→US) with ssl="require". Opening a *new*
      connection costs a TCP + TLS handshake + server startup + type
      introspection ≈ 1.5–2 s. Endpoints like /emails/by-supplier issue
      concurrent queries (asyncio.gather → 2+ connections at once); with a lazy
      min_size=1 pool the extra connections were opened fresh on almost every
      request, so the handshake — not the SQL — dominated latency (observed
      3–4 s responses). Keeping every connection warm removes that cost entirely.

      SCALE TRADEOFF: a warm pool holds `max_size` connections per instance for
      the process lifetime. On a deployment that auto-scales to many instances,
      set DB_POOL_MIN=1 (lazy) to avoid exhausting Cloud SQL's global connection
      cap. The inbox poller runs on a single instance, so warming is the right
      default for the current small-instance-count deployment.

    Query logging:
      LoggingConnection instruments every execute/fetch/fetchrow/fetchval call and
      writes structured timing logs to db.log (see db/query_logger.py).
    """
    import os
    from db.query_logger import LoggingConnection, log_pool_stats
    global _pg_pool
    if not settings.db_host:
        log.info("db.pg_pool_skipped", reason="DB_HOST not set — using JSON repos")
        return None
    max_size = max(2, int(os.getenv("DB_POOL_MAX", "10")))
    # Warm by default: min_size == max_size unless DB_POOL_MIN overrides it.
    min_size = int(os.getenv("DB_POOL_MIN", str(max_size)))
    min_size = max(1, min(min_size, max_size))
    try:
        _pg_pool = await asyncpg.create_pool(
            host=settings.db_host,
            port=settings.db_port,
            database=settings.db_name,
            user=settings.db_user,
            password=settings.db_pass.get_secret_value(),
            min_size=min_size,
            max_size=max_size,
            command_timeout=30,
            ssl="require",
            init=_init_connection,
            connection_class=LoggingConnection,
        )
        log.info(
            "db.pg_pool_created",
            host=settings.db_host,
            port=settings.db_port,
            db=settings.db_name,
            min_size=min_size,
            max_size=max_size,
        )
        log_pool_stats(_pg_pool)
        return _pg_pool
    except Exception as exc:
        log.error("db.pg_pool_failed", error=str(exc), exc_info=True)
        return None


def get_asyncpg_pool() -> "asyncpg.Pool | None":
    """Return the running asyncpg pool, or None if not yet created."""
    return _pg_pool


async def close_asyncpg_pool() -> None:
    """Drain the asyncpg pool at application shutdown."""
    global _pg_pool
    if _pg_pool is not None:
        await _pg_pool.close()
        _pg_pool = None
        log.info("db.pg_pool_closed")
