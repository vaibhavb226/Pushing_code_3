"""
Shared constants de-duplicated from server.js and suppliers.js.
"""
from __future__ import annotations

# Maps RFP item categories → supplier categories for auto-populate
CATEGORY_MAP: dict[str, list[str]] = {
    "Fluid Milk": ["Dairy"],
    "Fruit": ["Produce", "Broker"],
    "Grain": ["Bakery", "Grocery", "Broker"],
    "Snack": ["Grocery", "Bakery", "Broker"],
    "M/MA": ["Protein", "Broker"],
    "M/MA+Grain": ["Protein", "Bakery", "Broker"],
    "Produce": ["Produce", "Broker"],
    "Protein": ["Protein", "Broker"],
    "Dairy": ["Dairy"],
    "Bakery": ["Bakery"],
    "Grocery": ["Grocery", "Broker"],
    "Beverage": ["Beverage"],
    "Paper": ["Paper"],
    "Entree": ["Protein", "Grocery", "Broker"],
    "Vegetable": ["Produce", "Broker"],
    "Frozen": ["Protein", "Grocery", "Broker"],
}

# Supplier/bid statuses in display order
ALL_BID_STATUSES: list[str] = [
    "Active",
    "Solicitation",
    "Working File",
    "Review",
    "At Risk",
    "Awarded",
    "Cancelled",
]

ALL_SUPPLIER_STATUSES: list[str] = [
    "Awaiting",
    "Contacted",
    "Responded",
    "Issues Found",
    "Follow-up Sent",
    "Under Consideration",
    "Awarded",
    "No Bid",
    "Bounced",
    "Complete",
]

# Statuses that count as "responded" for response-rate calculation
RESPONDED_STATUSES: frozenset[str] = frozenset(
    ["Responded", "Issues Found", "Follow-up Sent", "Complete"]
)

# Statuses that block auto-reminder sends
MANUAL_OVERRIDE_STATUSES: frozenset[str] = frozenset(
    ["Issues Found", "Awarded", "Under Consideration", "No Bid"]
)

# MIME type → file extension map for upload handling
MIME_MAP: dict[str, str] = {
    "application/pdf": ".pdf",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "application/vnd.ms-excel": ".xls",
    "text/csv": ".csv",
    "application/msword": ".doc",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
}

# Compliance label display names
COMPLIANCE_LABELS: dict[str, str] = {
    "childNutrition": "CN",
    "buyAmerican": "Buy Am.",
    "pfsRequired": "PFS",
    "halal": "Halal",
    "kosher": "Kosher",
    "wholeGrain": "WG",
}

# Category abbreviation map (used in Working File tab)
CA_MAP: dict[str, str] = {
    "Fluid Milk": "FM",
    "Fruit": "FR",
    "Grain": "GR",
    "Protein": "PR",
    "Produce": "PD",
    "Dairy": "DY",
    "Bakery": "BK",
    "Grocery": "GC",
    "Beverage": "BV",
    "Paper": "PP",
    "Snack": "SN",
    "Entree": "EN",
    "Vegetable": "VG",
    "Frozen": "FZ",
}

# Valid segments
ALL_SEGMENTS: list[str] = [
    "K-12",
    "DoD",
    "University",
    "Healthcare",
    "Restaurant",
    "Lodging",
    "Government",
]

# Valid regions
ALL_REGIONS: list[str] = [
    "Northeast",
    "Southeast",
    "Midwest",
    "Southwest",
    "West",
    "National",
]
