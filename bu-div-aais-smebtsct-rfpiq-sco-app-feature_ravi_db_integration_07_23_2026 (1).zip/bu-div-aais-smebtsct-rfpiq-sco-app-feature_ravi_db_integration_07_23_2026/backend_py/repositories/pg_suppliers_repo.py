"""
PostgreSQL repository for the suppliers table.

Field rename: contact_email → contact (app uses "contact" key for the email address).
"""
from __future__ import annotations

from repositories.pg_base import PgRepository
from collections.abc import Callable


class PgSuppliersRepository(PgRepository):
    TABLE = "suppliers"
    ORDER_BY = "name"

    def _to_app(self, row) -> dict:
        d = dict(row)
        return {
            "id":               d["id"],
            "name":             d.get("name") or "",
            "category":         d.get("category") or "",
            "subcategories":    d.get("subcategories") or [],
            "contactName":      d.get("contact_name") or "",
            "contact":          d.get("contact_email") or "",
            "phone":            d.get("phone") or "",
            "region":           d.get("region") or "National",
            "broker":           bool(d.get("broker", False)),
            "segments":         d.get("segments") or [],
            "tags":             d.get("tags") or [],
            "bounce":           bool(d.get("bounce", False)),
            "notes":            d.get("notes") or "",
            "additionalEmails": d.get("additional_emails") or [],
        }

    def _to_db(self, item: dict) -> dict:
        return {
            "id":               item["id"],
            "name":             item.get("name") or "",
            "category":         item.get("category") or "",
            "subcategories":    item.get("subcategories") or [],
            "contact_name":     item.get("contactName") or "",
            "contact_email":    item.get("contact") or "",
            "phone":            item.get("phone") or "",
            "region":           item.get("region") or "National",
            "broker":           bool(item.get("broker", False)),
            "segments":         item.get("segments") or [],
            "tags":             item.get("tags") or [],
            "bounce":           bool(item.get("bounce", False)),
            "notes":            item.get("notes") or "",
            "additional_emails": item.get("additionalEmails") or [],
        }

    async def _insert_returning(self, conn, item: dict):
        d = item if "contact_email" in item else self._to_db(item)
        return await conn.fetchrow(
            """
            INSERT INTO suppliers
                (id, name, category, subcategories, contact_name, contact_email, phone,
                 region, broker, segments, tags, bounce, notes, additional_emails)
            VALUES ($1, $2, $3, $4::jsonb, $5, $6, $7, $8, $9, $10::jsonb, $11::jsonb, $12, $13, $14::jsonb)
            RETURNING *
            """,
            d["id"], d["name"], d["category"], d["subcategories"],
            d["contact_name"], d["contact_email"], d["phone"],
            d["region"], d["broker"], d["segments"], d["tags"],
            d["bounce"], d["notes"], d["additional_emails"],
        )

    async def _update_in_place(self, conn, updated: dict) -> None:
        d = self._to_db(updated)
        await conn.execute(
            """
            UPDATE suppliers SET
                name              = $2,
                category          = $3,
                subcategories     = $4::jsonb,
                contact_name      = $5,
                contact_email     = $6,
                phone             = $7,
                region            = $8,
                broker            = $9,
                segments          = $10::jsonb,
                tags              = $11::jsonb,
                bounce            = $12,
                notes             = $13,
                additional_emails = $14::jsonb,
                updated_at        = now()
            WHERE id = $1
            """,
            d["id"], d["name"], d["category"], d["subcategories"],
            d["contact_name"], d["contact_email"], d["phone"],
            d["region"], d["broker"], d["segments"], d["tags"],
            d["bounce"], d["notes"], d["additional_emails"],
        )

    async def find_one(self, predicate: Callable) -> dict | None:
        rows = await self.load()
        return next((r for r in rows if predicate(r)), None)

    async def get_broker_flags(self, supplier_ids: list[str]) -> dict[str, bool]:
        """Return {supplier_id: is_broker} for the given IDs — 2-column targeted query.

        Replaces suppliers_repo.load() in get_emails_by_supplier so the 15-second
        Email Repo poll no longer fetches the entire suppliers table for one boolean.
        """
        if not supplier_ids:
            return {}
        async with self._pool().acquire() as conn:
            rows = await conn.fetch(
                "SELECT id, broker FROM suppliers WHERE id = ANY($1::text[])",
                supplier_ids,
            )
        return {r["id"]: bool(r.get("broker", False)) for r in rows}
