"""
PostgreSQL repository for unmatched_emails table.

The email poller uses load() + save() to batch-replace the list.
PG implementation: save() is an UPSERT ON CONFLICT (id) so existing records
are preserved and new ones are added — equivalent to the JSON overwrite pattern.

Field renames (DB → app):
  from_address → from
  received_at  → date
  raw_payload  → full dict is exploded back into the app dict
"""
from __future__ import annotations

import json
from typing import Any

from repositories.pg_base import PgRepository, _str_dt, _dt


class PgUnmatchedEmailsRepository(PgRepository):
    TABLE = "unmatched_emails"
    ORDER_BY = "received_at DESC"

    def _to_app(self, row) -> dict:
        d = dict(row)
        # raw_payload stores the complete original email dict — return it as-is
        # but merge in any explicitly stored columns for correctness.
        payload: dict = d.get("raw_payload") or {}
        result = {**payload}
        result["id"]      = d["id"]
        result["subject"] = d.get("subject") or payload.get("subject") or ""
        result["from"]    = d.get("from_address") or payload.get("from") or ""
        result["body"]    = d.get("body") or payload.get("body") or ""
        result["date"]    = _str_dt(d.get("received_at")) or payload.get("date") or ""
        return result

    def _to_db(self, item: dict) -> dict:
        return {
            "id":           item["id"],
            "subject":      item.get("subject") or "",
            "from_address": item.get("from") or "",
            "body":         item.get("body") or "",
            "received_at":  _dt(item.get("date")),
            "raw_payload":  item,          # store full dict for round-trip fidelity
        }

    async def _insert_returning(self, conn, item: dict):
        d = item if "from_address" in item else self._to_db(item)
        return await conn.fetchrow(
            """
            INSERT INTO unmatched_emails (id, subject, from_address, body, received_at, raw_payload)
            VALUES ($1, $2, $3, $4, $5, $6::jsonb)
            RETURNING *
            """,
            d["id"], d["subject"], d["from_address"], d["body"],
            d["received_at"], d["raw_payload"],
        )

    async def _update_in_place(self, conn, updated: dict) -> None:
        d = self._to_db(updated)
        await conn.execute(
            """
            UPDATE unmatched_emails SET
                subject      = $2,
                from_address = $3,
                body         = $4,
                received_at  = $5,
                raw_payload  = $6::jsonb
            WHERE id = $1
            """,
            d["id"], d["subject"], d["from_address"], d["body"],
            d["received_at"], d["raw_payload"],
        )

    async def load(self) -> list[dict[str, Any]]:
        """Return the 500 most recent unmatched emails.

        The poller's _handle_unmatched only needs a recent window for UID dedup;
        keeping the full history in memory on every cycle is wasteful.
        save() then caps the table to the 500 records returned here + any new ones,
        which is sufficient for the email ops team to investigate routing mismatches.
        """
        async with self._pool().acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM unmatched_emails ORDER BY received_at DESC LIMIT 500"
            )
        return [self._to_app(r) for r in rows]

    async def save(self, data: list[dict[str, Any]]) -> None:
        """
        UPSERT the full list — emulates the JSON overwrite pattern.

        Existing records not in `data` are deleted; new ones are inserted.
        Called by the email poller when appending to unmatchedEmails.
        """
        if not data:
            return
        # Convert all items to DB dicts
        rows = [self._to_db(item) for item in data]
        incoming_ids = [r["id"] for r in rows]

        async with self._pool().acquire() as conn:
            # UPSERT — insert new, update existing
            await conn.executemany(
                """
                INSERT INTO unmatched_emails (id, subject, from_address, body, received_at, raw_payload)
                VALUES ($1, $2, $3, $4, $5, $6::jsonb)
                ON CONFLICT (id) DO UPDATE SET
                    subject      = EXCLUDED.subject,
                    from_address = EXCLUDED.from_address,
                    body         = EXCLUDED.body,
                    received_at  = EXCLUDED.received_at,
                    raw_payload  = EXCLUDED.raw_payload
                """,
                [
                    (r["id"], r["subject"], r["from_address"], r["body"],
                     r["received_at"], r["raw_payload"])
                    for r in rows
                ],
            )
            # Delete rows that are no longer in the list
            await conn.execute(
                "DELETE FROM unmatched_emails WHERE id != ALL($1::text[])",
                incoming_ids,
            )
