"""
PostgreSQL repository for bids (rfps table + rfp_solicited_suppliers).

load() fetches both tables in two queries and stitches solicitedSuppliers
into each bid dict, so callers see the same shape as the JSON repo.

update_one() writes to rfps then DELETE + re-INSERT rfp_solicited_suppliers
for that bid — simple, correct, and avoids complex UPSERT ID tracking.

append() inserts into rfps then inserts any solicitedSuppliers.
"""
from __future__ import annotations

import asyncio
import json
import uuid
from collections import defaultdict
from collections.abc import Callable
from typing import Any

from repositories.pg_base import PgRepository, _str_date, _dt_flex, _jo, _str_dt


class PgBidsRepository(PgRepository):
    TABLE = "rfps"
    ORDER_BY = "created_at"

    # ── Row → app dict ────────────────────────────────────────────────────────

    def _to_app(self, row) -> dict:
        d = dict(row)
        return {
            "id":                  d["id"],
            "bidId":               d["id"],
            "rfpNumber":           d.get("rfp_number") or "",
            "customer":            d.get("customer_name") or "",
            "segment":             d.get("segment") or "",
            "opco":                d.get("opco") or "",
            "opcoName":            d.get("opco_name") or "",
            "region":              d.get("region") or "",
            "status":              d.get("status") or "Active",
            "intakeDate":          _str_date(d.get("intake_date")),
            "bidRelease":          _str_date(d.get("bid_release")),
            "customerDue":         _str_date(d.get("customer_due")),
            "internalDue":         _str_date(d.get("internal_due")),
            "lastSolicitationDate": _str_date(d.get("last_solicitation_date")),
            "compliance":          d.get("compliance") or [],
            "itemCategories":      d.get("item_categories") or [],
            "items":               d.get("items") or 0,
            "suppliersContacted":  d.get("suppliers_contacted") or 0,
            "responsesReceived":   d.get("responses_received") or 0,
            "uploadedRfpPath":     d.get("uploaded_rfp_path") or "",
            "uploadedItemListPath": d.get("uploaded_item_list_path") or "",
            "uploadedFiles":       d.get("uploaded_files") or [],
            "_lineItemSource":     d.get("line_item_source") or "",
            "autoReminder":        d.get("auto_reminder"),
            "portalConfig":        d.get("portal_config"),
            "workingFileConfig":   d.get("working_file_config"),
            "notes":               d.get("notes") or "",
            "customerId":          d.get("customer_id"),
            # solicitedSuppliers populated by load() after stitching
            "solicitedSuppliers":  [],
        }

    def _ss_to_app(self, row) -> dict:
        d = dict(row)
        return {
            "id":               d.get("id"),
            "supplierId":       d.get("supplier_id"),
            "supplierName":     d.get("supplier_name") or "",
            "email":            d.get("email") or "",
            "category":         d.get("category") or "",
            "status":           d.get("status") or "Awaiting",
            "solicitedDate":    _str_date(d.get("solicited_date")),
            "lastActivity":     _str_dt(d.get("last_activity")),
            "hasIssues":        bool(d.get("has_issues", False)),
            "issueType":        d.get("issue_type"),
            "bouncedAt":        _str_dt(d.get("bounced_at")),
            "channel":          d.get("channel") or "Email",
            "threadId":         d.get("thread_id"),
            "additionalEmails": d.get("additional_emails") or [],
        }

    # ── load() — two-query join ───────────────────────────────────────────────

    async def load(self) -> list[dict]:
        async def _q_rfps():
            async with self._pool().acquire() as conn:
                return await conn.fetch("SELECT * FROM rfps ORDER BY created_at")

        async def _q_ss():
            async with self._pool().acquire() as conn:
                return await conn.fetch(
                    "SELECT * FROM rfp_solicited_suppliers ORDER BY rfp_id, id"
                )

        bid_rows, ss_rows = await asyncio.gather(_q_rfps(), _q_ss())
        # Group solicited suppliers by rfp_id
        ss_by_rfp: dict[str, list] = defaultdict(list)
        for r in ss_rows:
            ss_by_rfp[r["rfp_id"]].append(self._ss_to_app(r))

        result = []
        for r in bid_rows:
            bid = self._to_app(r)
            bid["solicitedSuppliers"] = ss_by_rfp.get(r["id"], [])
            result.append(bid)
        return result

    # ── find_by_id — direct single-bid lookup (avoids full table scan) ───────

    async def find_by_id(self, bid_id: str) -> dict | None:
        """Fetch one bid by primary key.  Two targeted WHERE id=$1 queries run in
        parallel instead of sequentially on a single connection."""
        async def _q_bid():
            async with self._pool().acquire() as conn:
                return await conn.fetchrow("SELECT * FROM rfps WHERE id = $1", bid_id)

        async def _q_ss():
            async with self._pool().acquire() as conn:
                return await conn.fetch(
                    "SELECT * FROM rfp_solicited_suppliers WHERE rfp_id = $1 ORDER BY id",
                    bid_id,
                )

        bid_row, ss_rows = await asyncio.gather(_q_bid(), _q_ss())
        if bid_row is None:
            return None
        bid = self._to_app(bid_row)
        bid["solicitedSuppliers"] = [self._ss_to_app(r) for r in ss_rows]
        return bid

    # ── update_by_id — optimised single-bid update ───────────────────────────

    async def update_by_id(self, bid_id: str, updater) -> dict | None:
        """Update one bid without a full table scan.

        Reads and writes inside a single transaction with SELECT … FOR UPDATE
        so concurrent callers block rather than racing on a stale snapshot.
        """
        async with self._pool().acquire() as conn:
            async with conn.transaction():
                bid_row = await conn.fetchrow(
                    "SELECT * FROM rfps WHERE id = $1 FOR UPDATE", bid_id
                )
                if bid_row is None:
                    return None
                ss_rows = await conn.fetch(
                    "SELECT * FROM rfp_solicited_suppliers WHERE rfp_id = $1 ORDER BY id",
                    bid_id,
                )
                item = self._to_app(bid_row)
                item["solicitedSuppliers"] = [self._ss_to_app(r) for r in ss_rows]
                updated = updater(item)
                await self._update_rfp(conn, updated)
                await conn.execute(
                    "DELETE FROM rfp_solicited_suppliers WHERE rfp_id = $1", bid_id
                )
                solicited = updated.get("solicitedSuppliers") or []
                if solicited:
                    await self._insert_solicited(conn, bid_id, solicited)
        return updated

    # ── find_one — fallback for predicate-based lookup ────────────────────────

    async def find_one(self, predicate: Callable) -> dict | None:
        rows = await self.load()
        return next((r for r in rows if predicate(r)), None)

    # ── append() — insert rfp + solicited suppliers ───────────────────────────

    async def append(self, item: dict) -> dict:
        solicited = item.get("solicitedSuppliers") or []
        async with self._pool().acquire() as conn:
            row = await conn.fetchrow(
                """
                INSERT INTO rfps (
                    id, rfp_number, customer_name, customer_id,
                    segment, opco, opco_name, region, status,
                    intake_date, bid_release, customer_due, internal_due,
                    compliance, item_categories,
                    items, suppliers_contacted, responses_received,
                    uploaded_rfp_path, uploaded_item_list_path, uploaded_files,
                    line_item_source, auto_reminder, portal_config,
                    working_file_config, last_solicitation_date, notes
                ) VALUES (
                    $1, $2, $3, $4,
                    $5, $6, $7, $8, $9,
                    $10, $11, $12, $13,
                    $14::jsonb, $15::jsonb,
                    $16, $17, $18,
                    $19, $20, $21::jsonb,
                    $22, $23::jsonb, $24::jsonb,
                    $25::jsonb, $26, $27
                )
                RETURNING *
                """,
                item.get("id") or f"RFP-{uuid.uuid4().hex[:8]}",
                item.get("rfpNumber") or "",
                item.get("customer") or "",
                item.get("customerId") or None,
                item.get("segment") or "",
                item.get("opco") or "",
                item.get("opcoName") or "",
                item.get("region") or "",
                item.get("status") or "Active",
                _dt_flex(item.get("intakeDate")),
                _dt_flex(item.get("bidRelease")),
                _dt_flex(item.get("customerDue")),
                _dt_flex(item.get("internalDue")),
                item.get("compliance") or [],
                item.get("itemCategories") or [],
                item.get("items") or 0,
                item.get("suppliersContacted") or 0,
                item.get("responsesReceived") or 0,
                item.get("uploadedRfpPath") or "",
                item.get("uploadedItemListPath") or "",
                item.get("uploadedFiles") or [],
                item.get("_lineItemSource") or "",
                item.get("autoReminder"),
                item.get("portalConfig"),
                item.get("workingFileConfig"),
                _dt_flex(item.get("lastSolicitationDate")),
                item.get("notes") or "",
            )
            inserted = self._to_app(row)
            inserted["solicitedSuppliers"] = []
            if solicited:
                inserted["solicitedSuppliers"] = await self._insert_solicited(
                    conn, inserted["id"], solicited
                )
        return inserted

    # ── update_one — override to handle both tables ───────────────────────────

    async def update_one(
        self, predicate: Callable, updater: Callable
    ) -> dict | None:
        # Resolve the bid ID via the (potentially stale) full-load, then delegate
        # to update_by_id which re-reads inside a transaction with FOR UPDATE.
        rows = await self.load()
        item = next((r for r in rows if predicate(r)), None)
        if item is None:
            return None
        return await self.update_by_id(item["id"], updater)

    # ── _update_rfp — write rfps row ──────────────────────────────────────────

    async def _update_rfp(self, conn, bid: dict) -> None:
        await conn.execute(
            """
            UPDATE rfps SET
                rfp_number             = $2,
                customer_name          = $3,
                customer_id            = $4,
                segment                = $5,
                opco                   = $6,
                opco_name              = $7,
                region                 = $8,
                status                 = $9,
                intake_date            = $10,
                bid_release            = $11,
                customer_due           = $12,
                internal_due           = $13,
                compliance             = $14::jsonb,
                item_categories        = $15::jsonb,
                items                  = $16,
                suppliers_contacted    = $17,
                responses_received     = $18,
                uploaded_rfp_path      = $19,
                uploaded_item_list_path= $20,
                uploaded_files         = $21::jsonb,
                line_item_source       = $22,
                auto_reminder          = $23::jsonb,
                portal_config          = $24::jsonb,
                working_file_config    = $25::jsonb,
                last_solicitation_date = $26,
                notes                  = $27,
                updated_at             = now()
            WHERE id = $1
            """,
            bid["id"],
            bid.get("rfpNumber") or "",
            bid.get("customer") or "",
            bid.get("customerId") or None,
            bid.get("segment") or "",
            bid.get("opco") or "",
            bid.get("opcoName") or "",
            bid.get("region") or "",
            bid.get("status") or "Active",
            _dt_flex(bid.get("intakeDate")),
            _dt_flex(bid.get("bidRelease")),
            _dt_flex(bid.get("customerDue")),
            _dt_flex(bid.get("internalDue")),
            bid.get("compliance") or [],
            bid.get("itemCategories") or [],
            bid.get("items") or 0,
            bid.get("suppliersContacted") or 0,
            bid.get("responsesReceived") or 0,
            bid.get("uploadedRfpPath") or "",
            bid.get("uploadedItemListPath") or "",
            bid.get("uploadedFiles") or [],
            bid.get("_lineItemSource") or "",
            bid.get("autoReminder"),
            bid.get("portalConfig"),
            bid.get("workingFileConfig"),
            _dt_flex(bid.get("lastSolicitationDate")),
            bid.get("notes") or "",
        )

    # ── _insert_solicited — bulk insert rfp_solicited_suppliers ───────────────

    async def _insert_solicited(
        self, conn, rfp_id: str, suppliers: list[dict]
    ) -> list[dict]:
        rows = []
        for idx, ss in enumerate(suppliers):
            row_id = ss.get("id") or f"RSS-{rfp_id}-{idx:03d}"
            rows.append((
                row_id,
                rfp_id,
                ss.get("supplierId"),
                ss.get("supplierName") or "",
                ss.get("email") or "",
                ss.get("category") or "",
                ss.get("status") or "Awaiting",
                _dt_flex(ss.get("solicitedDate")),
                _dt_flex(ss.get("lastActivity")),
                bool(ss.get("hasIssues", False)),
                ss.get("issueType"),
                _dt_flex(ss.get("bouncedAt")),
                ss.get("channel") or "Email",
                ss.get("threadId"),
                ss.get("additionalEmails") or [],
            ))

        await conn.executemany(
            """
            INSERT INTO rfp_solicited_suppliers (
                id, rfp_id, supplier_id, supplier_name, email, category,
                status, solicited_date, last_activity,
                has_issues, issue_type, bounced_at,
                channel, thread_id, additional_emails
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15::jsonb)
            ON CONFLICT (id) DO UPDATE SET
                status         = EXCLUDED.status,
                last_activity  = EXCLUDED.last_activity,
                has_issues     = EXCLUDED.has_issues,
                issue_type     = EXCLUDED.issue_type,
                bounced_at     = EXCLUDED.bounced_at,
                channel        = EXCLUDED.channel,
                thread_id      = EXCLUDED.thread_id,
                additional_emails = EXCLUDED.additional_emails,
                updated_at     = now()
            """,
            rows,
        )
        return suppliers

    # ── add_solicited_suppliers — add-only solicitation update ───────────────

    async def add_solicited_suppliers(
        self,
        bid_id: str,
        new_entries: list[dict],
        last_solicitation_date: str,
    ) -> None:
        """Add new solicited-supplier rows without a full read-modify-write cycle.

        Uses 2 round-trips (UPDATE rfps + INSERT rfp_solicited_suppliers) instead of
        the 5-round-trip update_by_id transaction used by the general update path.
        INSERT ON CONFLICT DO NOTHING safely skips suppliers already present.
        """
        async with self._pool().acquire() as conn:
            await conn.execute(
                "UPDATE rfps SET last_solicitation_date = $1, updated_at = now() WHERE id = $2",
                _dt_flex(last_solicitation_date),
                bid_id,
            )
            if not new_entries:
                return
            rows = [
                (
                    f"RSS-{bid_id}-{uuid.uuid4().hex[:6]}",
                    bid_id,
                    ss.get("supplierId"),
                    ss.get("supplierName") or "",
                    ss.get("email") or "",
                    ss.get("category") or "",
                    ss.get("status") or "Awaiting",
                    _dt_flex(ss.get("solicitedDate")),
                    _dt_flex(ss.get("lastActivity")),
                    bool(ss.get("hasIssues", False)),
                    ss.get("issueType"),
                    _dt_flex(ss.get("bouncedAt")),
                    ss.get("channel") or "Email",
                    ss.get("threadId"),
                    ss.get("additionalEmails") or [],
                )
                for ss in new_entries
            ]
            await conn.executemany(
                """
                INSERT INTO rfp_solicited_suppliers (
                    id, rfp_id, supplier_id, supplier_name, email, category,
                    status, solicited_date, last_activity,
                    has_issues, issue_type, bounced_at,
                    channel, thread_id, additional_emails
                ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15::jsonb)
                ON CONFLICT DO NOTHING
                """,
                rows,
            )

    # ── delete_by_id — single-row delete, CASCADE handles all child tables ────

    async def delete_by_id(self, bid_id: str) -> None:
        """Delete one bid in one round-trip.

        Every child table (rfp_line_items, rfp_solicited_suppliers, email_threads,
        documents, bids/submissions) has ON DELETE CASCADE to rfps(id) —
        PostgreSQL cascades everything atomically.
        """
        async with self._pool().acquire() as conn:
            await conn.execute("DELETE FROM rfps WHERE id = $1", bid_id)

    # ── delete_where — cascade via FK or explicit delete ─────────────────────

    async def delete_where(self, predicate: Callable) -> int:
        rows = await self.load()
        ids = [r["id"] for r in rows if predicate(r)]
        if not ids:
            return 0
        async with self._pool().acquire() as conn:
            # Delete solicited suppliers first (in case no cascade)
            await conn.execute(
                "DELETE FROM rfp_solicited_suppliers WHERE rfp_id = ANY($1::text[])", ids
            )
            result = await conn.execute(
                "DELETE FROM rfps WHERE id = ANY($1::text[])", ids
            )
        return int(result.split()[-1])

    # ── AbstractRepository stubs (not used for bids) ──────────────────────────

    def _to_db(self, item: dict) -> dict:
        return item

    async def _insert_returning(self, conn, item: dict):
        return None

    async def _update_in_place(self, conn, updated: dict) -> None:
        pass
