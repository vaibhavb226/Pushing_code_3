"""
Base class for asyncpg PostgreSQL repositories.

Implements AbstractRepository against the module-level asyncpg pool from
db.connection. Subclasses declare the table name and implement the four
abstract hooks (_to_app, _to_db, _insert_returning, _update_in_place);
load / find_one / append / update_one / delete_where are provided here.

Date helpers (exported so subclasses don't repeat them):
    _str_date(val) -> str | None   — date/datetime → "YYYY-MM-DD"
    _str_dt(val)   -> str | None   — datetime → ISO-8601 with Z
    _dt(val)       -> datetime | None — ISO string → aware datetime
    _js(val)       -> str          — serialize as JSON array string
    _jo(val)       -> str | None   — serialize dict as JSON string
"""
from __future__ import annotations

import json as _json
from collections.abc import Callable
from datetime import date, datetime, timezone
from typing import Any

from repositories.base import AbstractRepository


# ── Date / JSON helpers ──────────────────────────────────────────────────────

def _str_date(val: Any) -> str | None:
    if val is None:
        return None
    if isinstance(val, (date, datetime)):
        return val.isoformat()[:10]
    return str(val)[:10] if val else None


def _str_dt(val: Any) -> str | None:
    if val is None:
        return None
    if isinstance(val, datetime):
        if val.tzinfo is None:
            val = val.replace(tzinfo=timezone.utc)
        s = val.isoformat()
        return s.replace("+00:00", "Z") if "+00:00" in s else s
    return str(val) if val else None


def _dt(val: Any) -> datetime | None:
    if not val:
        return None
    if isinstance(val, datetime):
        return val if val.tzinfo else val.replace(tzinfo=timezone.utc)
    try:
        s = str(val).replace("Z", "+00:00")
        return datetime.fromisoformat(s)
    except (ValueError, TypeError):
        return None


def _dt_flex(val: Any) -> datetime | None:
    """Parse ISO datetime or date-only string → aware datetime."""
    if not val:
        return None
    dt = _dt(val)
    if dt:
        return dt
    try:
        d = date.fromisoformat(str(val)[:10])
        return datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    except (ValueError, TypeError):
        return None


def _js(val: Any) -> str:
    """Serialize to JSON array/object string (for JSONB columns)."""
    return _json.dumps(val if val is not None else [])


def _jo(val: Any) -> str | None:
    """Serialize dict to JSON string, or None if falsy."""
    return _json.dumps(val) if val else None


# ── Base PG repository ───────────────────────────────────────────────────────

class PgRepository(AbstractRepository):
    """
    asyncpg-backed AbstractRepository.

    Subclasses must set:
        TABLE: str      — PostgreSQL table name
        ORDER_BY: str   — default ORDER BY column (default: 'created_at')

    And implement:
        _to_app(row)               -> dict       — DB row → app camelCase dict
        _to_db(item)               -> dict       — app dict → DB snake_case dict
        _insert_returning(conn, item) -> Record  — INSERT RETURNING * raw row
        _update_in_place(conn, updated) -> None  — UPDATE by id
    """

    TABLE: str = ""
    ORDER_BY: str = "created_at"

    # ── Connection pool accessor ─────────────────────────────────────────────

    def _pool(self):
        from db.connection import get_asyncpg_pool
        pool = get_asyncpg_pool()
        if pool is None:
            raise RuntimeError(
                "asyncpg CRUD pool not initialized — ensure DB_HOST is set "
                "and create_asyncpg_pool() completed at startup."
            )
        return pool

    # ── Subclass hooks ───────────────────────────────────────────────────────

    def _to_app(self, row) -> dict:
        raise NotImplementedError

    def _to_db(self, item: dict) -> dict:
        raise NotImplementedError

    async def _insert_returning(self, conn, item: dict):
        raise NotImplementedError

    async def _update_in_place(self, conn, updated: dict) -> None:
        raise NotImplementedError

    # ── AbstractRepository implementation ────────────────────────────────────

    async def load(self) -> list[dict]:
        async with self._pool().acquire() as conn:
            rows = await conn.fetch(
                f"SELECT * FROM {self.TABLE} ORDER BY {self.ORDER_BY}"
            )
        return [self._to_app(r) for r in rows]

    async def find_one(self, predicate: Callable) -> dict | None:
        rows = await self.load()
        return next((r for r in rows if predicate(r)), None)

    async def append(self, item: dict) -> dict:
        async with self._pool().acquire() as conn:
            row = await self._insert_returning(conn, item)
        return self._to_app(row) if row else item

    async def update_one(
        self, predicate: Callable, updater: Callable
    ) -> dict | None:
        item = await self.find_one(predicate)
        if item is None:
            return None
        updated = updater(item)
        async with self._pool().acquire() as conn:
            await self._update_in_place(conn, updated)
        return updated

    async def delete_where(self, predicate: Callable) -> int:
        rows = await self.load()
        ids = [r["id"] for r in rows if predicate(r)]
        if not ids:
            return 0
        async with self._pool().acquire() as conn:
            result = await conn.execute(
                f"DELETE FROM {self.TABLE} WHERE id = ANY($1::text[])", ids
            )
        return int(result.split()[-1])

    async def save(self, data: list[dict]) -> None:
        raise NotImplementedError(
            "save() is not supported for DB repositories. "
            "Use append() or update_one() instead."
        )
