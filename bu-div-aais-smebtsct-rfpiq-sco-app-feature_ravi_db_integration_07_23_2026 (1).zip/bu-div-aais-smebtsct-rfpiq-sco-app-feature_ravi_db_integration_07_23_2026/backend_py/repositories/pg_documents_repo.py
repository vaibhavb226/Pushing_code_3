"""
PostgreSQL repository for the documents table.

Field renames (DB → app):
  rfp_id              → bidId
  file_name           → fileName
  file_type           → fileType
  size_kb             → sizeKb
  document_type       → documentType
  upload_date         → uploadDate
  uploaded_by         → uploadedBy
  file_path           → filePath
  supplier_category   → supplierCategory
  extraction_confidence → extractionConfidence
  linked_line_items   → linkedLineItems
"""
from __future__ import annotations

import uuid
from repositories.pg_base import PgRepository, _str_dt, _dt_flex


class PgDocumentsRepository(PgRepository):
    TABLE = "documents"
    ORDER_BY = "upload_date DESC"

    def _to_app(self, row) -> dict:
        d = dict(row)
        return {
            "id":                   d["id"],
            "bidId":                d.get("rfp_id"),
            "supplierId":           d.get("supplier_id"),
            "fileName":             d.get("file_name") or "",
            "fileType":             d.get("file_type") or "",
            "sizeKb":               d.get("size_kb") or 0,
            "documentType":         d.get("document_type") or "",
            "tags":                 d.get("tags") or [],
            "uploadDate":           _str_dt(d.get("upload_date")),
            "uploadedBy":           d.get("uploaded_by") or "",
            "status":               d.get("status") or "Filed",
            "filePath":             d.get("file_path") or "",
            "description":          d.get("description") or "",
            "category":             d.get("category") or "",
            "notes":                d.get("notes") or "",
            "supplier":             d.get("supplier") or "",
            "supplierCategory":     d.get("supplier_category") or "",
            "extractionConfidence": d.get("extraction_confidence"),
            "linkedLineItems":      d.get("linked_line_items") or [],
        }

    def _to_db(self, item: dict) -> dict:
        return {
            "id":                   item.get("id") or f"DOC-{uuid.uuid4().hex[:8]}",
            "rfp_id":               item.get("bidId"),
            "supplier_id":          item.get("supplierId"),
            "file_name":            item.get("fileName") or "",
            "file_type":            item.get("fileType") or "",
            "size_kb":              item.get("sizeKb") or 0,
            "document_type":        item.get("documentType") or "",
            "tags":                 item.get("tags") or [],
            "upload_date":          _dt_flex(item.get("uploadDate")),
            "uploaded_by":          item.get("uploadedBy") or "",
            "status":               item.get("status") or "Filed",
            "file_path":            item.get("filePath") or "",
            "description":          item.get("description") or "",
            "category":             item.get("category") or "",
            "notes":                item.get("notes") or "",
            "supplier":             item.get("supplier") or "",
            "supplier_category":    item.get("supplierCategory") or "",
            "extraction_confidence": item.get("extractionConfidence"),
            "linked_line_items":    item.get("linkedLineItems") or [],
        }

    async def _insert_returning(self, conn, item: dict):
        d = item if "rfp_id" in item else self._to_db(item)
        return await conn.fetchrow(
            """
            INSERT INTO documents (
                id, rfp_id, supplier_id, file_name, file_type, size_kb,
                document_type, tags, upload_date, uploaded_by, status,
                file_path, description, category, notes,
                supplier, supplier_category, extraction_confidence, linked_line_items
            ) VALUES (
                $1, $2, $3, $4, $5, $6,
                $7, $8::jsonb, $9, $10, $11,
                $12, $13, $14, $15,
                $16, $17, $18, $19::jsonb
            )
            RETURNING *
            """,
            d["id"], d["rfp_id"], d["supplier_id"], d["file_name"], d["file_type"], d["size_kb"],
            d["document_type"], d["tags"], d["upload_date"], d["uploaded_by"], d["status"],
            d["file_path"], d["description"], d["category"], d["notes"],
            d["supplier"], d["supplier_category"], d["extraction_confidence"], d["linked_line_items"],
        )

    async def append(self, item: dict) -> dict:
        db = self._to_db(item)
        async with self._pool().acquire() as conn:
            row = await self._insert_returning(conn, db)
        return self._to_app(row) if row else item

    async def _update_in_place(self, conn, updated: dict) -> None:
        d = self._to_db(updated)
        await conn.execute(
            """
            UPDATE documents SET
                rfp_id               = $2,
                supplier_id          = $3,
                file_name            = $4,
                file_type            = $5,
                size_kb              = $6,
                document_type        = $7,
                tags                 = $8::jsonb,
                upload_date          = $9,
                uploaded_by          = $10,
                status               = $11,
                file_path            = $12,
                description          = $13,
                category             = $14,
                notes                = $15,
                supplier             = $16,
                supplier_category    = $17,
                extraction_confidence= $18,
                linked_line_items    = $19::jsonb,
                updated_at           = now()
            WHERE id = $1
            """,
            d["id"], d["rfp_id"], d["supplier_id"], d["file_name"], d["file_type"], d["size_kb"],
            d["document_type"], d["tags"], d["upload_date"], d["uploaded_by"], d["status"],
            d["file_path"], d["description"], d["category"], d["notes"],
            d["supplier"], d["supplier_category"], d["extraction_confidence"], d["linked_line_items"],
        )
