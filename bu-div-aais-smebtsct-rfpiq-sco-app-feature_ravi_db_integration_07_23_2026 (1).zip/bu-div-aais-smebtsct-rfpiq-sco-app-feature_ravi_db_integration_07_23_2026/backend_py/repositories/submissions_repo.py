"""
Special repository for submissions.json.

Unlike all other JSON files which are flat arrays, submissions.json is:
  { "<bidId>": [ <submission>, ... ], ... }

This repo does NOT inherit JsonRepository — it handles the dict-keyed structure.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import aiofiles

from repositories.base import _get_lock


class SubmissionsRepository:
    def __init__(self, path: Path) -> None:
        self._path = path
        self._lock = _get_lock(path)

    async def load(self) -> dict[str, list[dict[str, Any]]]:
        async with self._lock:
            try:
                async with aiofiles.open(self._path, encoding="utf-8") as f:
                    content = await f.read()
                if content.strip():
                    result = json.loads(content)
                    return result if isinstance(result, dict) else {}
            except FileNotFoundError:
                pass
            return {}

    async def save(self, data: dict[str, list[dict[str, Any]]]) -> None:
        async with self._lock:
            async with aiofiles.open(self._path, "w", encoding="utf-8") as f:
                await f.write(json.dumps(data, indent=2, ensure_ascii=False))

    async def get_for_bid(self, bid_id: str) -> list[dict[str, Any]]:
        data = await self.load()
        return data.get(bid_id, [])

    async def append_for_bid(
        self, bid_id: str, submission: dict[str, Any]
    ) -> dict[str, Any]:
        async with self._lock:
            async with aiofiles.open(self._path, encoding="utf-8") as f:
                content = await f.read()
            data: dict[str, list[dict[str, Any]]] = {}
            if content.strip():
                loaded = json.loads(content)
                if isinstance(loaded, dict):
                    data = loaded
            data.setdefault(bid_id, []).append(submission)
            async with aiofiles.open(self._path, "w", encoding="utf-8") as f:
                await f.write(json.dumps(data, indent=2, ensure_ascii=False))
        return submission

    async def update_submission(
        self, bid_id: str, thread_id: str, updater: Any
    ) -> dict[str, Any] | None:
        async with self._lock:
            async with aiofiles.open(self._path, encoding="utf-8") as f:
                content = await f.read()
            data: dict[str, list[dict[str, Any]]] = {}
            if content.strip():
                loaded = json.loads(content)
                if isinstance(loaded, dict):
                    data = loaded
            subs = data.get(bid_id, [])
            idx = next((i for i, s in enumerate(subs) if s.get("threadId") == thread_id), None)
            if idx is None:
                return None
            subs[idx] = updater(subs[idx])
            data[bid_id] = subs
            async with aiofiles.open(self._path, "w", encoding="utf-8") as f:
                await f.write(json.dumps(data, indent=2, ensure_ascii=False))
            return subs[idx]

    async def delete_for_bid(self, bid_id: str) -> int:
        async with self._lock:
            async with aiofiles.open(self._path, encoding="utf-8") as f:
                content = await f.read()
            data: dict[str, list[dict[str, Any]]] = {}
            if content.strip():
                loaded = json.loads(content)
                if isinstance(loaded, dict):
                    data = loaded
            count = len(data.pop(bid_id, []))
            async with aiofiles.open(self._path, "w", encoding="utf-8") as f:
                await f.write(json.dumps(data, indent=2, ensure_ascii=False))
        return count
