from __future__ import annotations

from pathlib import Path
from typing import Any

from repositories.base import JsonRepository


class LineItemsRepository(JsonRepository):
    """Repository for lineItems.json — array of line item objects."""

    def __init__(self, path: Path) -> None:
        super().__init__(path)

    async def get_for_bid(self, bid_id: str) -> list[dict[str, Any]]:
        data = await self.load()
        return [item for item in data if item.get("bidId") == bid_id]

    async def update_by_id(
        self, line_id: str, updater
    ) -> dict | None:
        """Update a single line item by primary key. JSON fallback delegates to update_one."""
        return await self.update_one(lambda x: x.get("id") == line_id, updater)

    async def delete_by_id(self, line_id: str, bid_id: str) -> int:
        """Delete a single line item by primary key. JSON fallback delegates to delete_where."""
        return await self.delete_where(
            lambda x: x.get("id") == line_id and x.get("bidId") == bid_id
        )

    async def delete_for_bid(self, bid_id: str) -> int:
        """Delete all line items for a bid. JSON fallback delegates to delete_where."""
        return await self.delete_where(lambda x: x.get("bidId") == bid_id)

    async def update_with_pricing(
        self, line_id: str, updater, new_pricing: list[dict[str, Any]]
    ) -> dict[str, Any] | None:
        """Update a line item and merge pricing in one atomic operation. JSON fallback."""
        def combined_updater(item: dict[str, Any]) -> dict[str, Any]:
            item = updater(item)
            existing: list[dict[str, Any]] = item.get("supplierPricing", [])
            for new_entry in new_pricing:
                new_name    = new_entry.get("supplierName", "")
                new_item_no = new_entry.get("supplierItemNo", "")
                new_email_id = new_entry.get("emailId", "")
                dup_idx = next(
                    (
                        i for i, e in enumerate(existing)
                        if e.get("supplierName") == new_name
                        and (
                            (new_item_no and e.get("supplierItemNo") and e.get("supplierItemNo") == new_item_no)
                            or (not new_item_no and not e.get("supplierItemNo") and new_email_id and e.get("emailId") == new_email_id)
                        )
                    ),
                    None,
                )
                if dup_idx is not None:
                    existing[dup_idx] = {**existing[dup_idx], **new_entry}
                else:
                    existing.append(new_entry)
            item["supplierPricing"] = existing
            return item

        return await self.update_one(lambda x: x.get("id") == line_id, combined_updater)

    async def smart_merge_pricing(
        self, line_id: str, new_pricing: list[dict[str, Any]]
    ) -> dict[str, Any] | None:
        """
        Merge supplierPricing array without duplicating entries.

        Deduplication rules (in priority order):
        1. Both entries have supplierItemNo → match on supplierName + supplierItemNo only.
           Two different products from the same email must NOT collapse into one.
        2. Neither entry has supplierItemNo → fall back to supplierName + emailId.
           Handles re-submissions where item numbers are unavailable.
        """
        def updater(item: dict[str, Any]) -> dict[str, Any]:
            existing: list[dict[str, Any]] = item.get("supplierPricing", [])
            for new_entry in new_pricing:
                new_name = new_entry.get("supplierName", "")
                new_item_no = new_entry.get("supplierItemNo", "")
                new_email_id = new_entry.get("emailId", "")

                dup_idx = next(
                    (
                        i for i, e in enumerate(existing)
                        if e.get("supplierName") == new_name
                        and (
                            # Rule 1: both have item numbers — item number is the identity
                            (new_item_no and e.get("supplierItemNo") and e.get("supplierItemNo") == new_item_no)
                            # Rule 2: neither has item number — fall back to emailId
                            or (not new_item_no and not e.get("supplierItemNo") and new_email_id and e.get("emailId") == new_email_id)
                        )
                    ),
                    None,
                )
                if dup_idx is not None:
                    existing[dup_idx] = {**existing[dup_idx], **new_entry}
                else:
                    existing.append(new_entry)
            item["supplierPricing"] = existing
            return item

        return await self.update_one(lambda x: x.get("id") == line_id, updater)
