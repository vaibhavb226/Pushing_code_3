"""
PostgreSQL repository for portal submissions.

Maps to three tables:
  bids              — one row per submission (confirmation_id used as PK)
  bid_line_items    — one row per priced line item per submission
  submission_messages — one row per portal message (inbound/outbound)

This repo does NOT inherit PgRepository — it mirrors the custom interface of
SubmissionsRepository (load→dict, get_for_bid, append_for_bid, update_submission,
delete_for_bid) and is NOT an AbstractRepository subclass.
"""
from __future__ import annotations

import uuid
from typing import Any

from repositories.pg_base import _str_dt, _dt


def _pool():
    from db.connection import get_asyncpg_pool
    pool = get_asyncpg_pool()
    if pool is None:
        raise RuntimeError(
            "asyncpg CRUD pool not initialized — ensure DB_HOST is set "
            "and create_asyncpg_pool() completed at startup."
        )
    return pool


# ── Row mappers ───────────────────────────────────────────────────────────────

def _bid_to_app(row, line_items: list, messages: list) -> dict:
    d = dict(row)
    return {
        "confirmationId":  d.get("confirmation_id") or d["id"],
        "threadId":        d.get("thread_id") or "",
        "submittedAt":     _str_dt(d.get("submitted_at")),
        "supplierName":    d.get("supplier_name") or "",
        "supplierEmail":   d.get("supplier_email") or "",
        "contactName":     d.get("contact_name") or "",
        "phone":           d.get("phone") or "",
        "pricingFile":     d.get("pricing_file") or "",
        "pricedCount":     d.get("priced_count") or 0,
        "noBidCount":      d.get("no_bid_count") or 0,
        "dlCount":         d.get("dl_count") or 0,
        "allwCount":       d.get("allw_count") or 0,
        "otherPricedCount": d.get("other_priced_count") or 0,
        "notes":           d.get("notes") or "",
        "lineItems":       line_items,
        "messages":        messages,
    }


def _line_item_to_app(row) -> dict:
    d = dict(row)
    return {
        "id":            d.get("rfp_line_id") or d["id"],
        "bidItem":       d.get("item_no") or "",
        "description":   d.get("description") or "",
        "unitPrice":     d.get("unit_price"),
        "casePrice":     d.get("case_price"),
        "deliveredPrice": d.get("delivered_price"),
        "fobPrice":      d.get("fob_price"),
        "allowance":     d.get("allowance"),
        "noBid":         bool(d.get("no_bid", False)),
        "devType":       d.get("dev_type"),
        "customFieldValues": d.get("custom_field_values") or {},
    }


def _msg_to_app(row) -> dict:
    d = dict(row)
    return {
        "id":           d["id"],
        "direction":    d.get("direction") or "inbound",
        "from":         d.get("from_address") or "",
        "fromName":     d.get("from_name") or "",
        "body":         d.get("body") or "",
        "attachments":  d.get("attachments") or [],
        "timestamp":    _str_dt(d.get("message_ts")),
        "readByBidCOE": bool(d.get("read_by_bid_coe", False)),
        "readBySupplier": bool(d.get("read_by_supplier", False)),
    }


# ── Internal loaders ──────────────────────────────────────────────────────────

async def _load_line_items(conn, bid_pk: str) -> list[dict]:
    rows = await conn.fetch(
        "SELECT * FROM bid_line_items WHERE bid_id = $1 ORDER BY item_no",
        bid_pk,
    )
    return [_line_item_to_app(r) for r in rows]


async def _load_messages(conn, bid_pk: str) -> list[dict]:
    rows = await conn.fetch(
        "SELECT * FROM submission_messages WHERE bid_id = $1 ORDER BY message_ts",
        bid_pk,
    )
    return [_msg_to_app(r) for r in rows]


async def _build_submission(conn, bid_row) -> dict:
    pk = bid_row["id"]
    line_items = await _load_line_items(conn, pk)
    messages   = await _load_messages(conn, pk)
    return _bid_to_app(bid_row, line_items, messages)


# ── INSERT helpers ────────────────────────────────────────────────────────────

async def _insert_bid(conn, rfp_id: str, submission: dict):
    conf_id = submission.get("confirmationId") or f"BID-{rfp_id}-{uuid.uuid4().hex[:8].upper()}"
    return await conn.fetchrow(
        """
        INSERT INTO bids (
            id, confirmation_id, thread_id, rfp_id,
            supplier_name, supplier_email, supplier_id, contact_name, phone,
            submitted_at, bid_status, pricing_file,
            priced_count, no_bid_count, dl_count, allw_count, other_priced_count,
            notes, email_id
        ) VALUES (
            $1,  $2,  $3,  $4,
            $5,  $6,  $7,  $8,  $9,
            $10, $11, $12,
            $13, $14, $15, $16, $17,
            $18, $19
        )
        RETURNING *
        """,
        conf_id,
        conf_id,
        submission.get("threadId") or f"EXTR-{uuid.uuid4().hex[:12].upper()}",
        rfp_id,
        submission.get("supplierName") or "",
        submission.get("supplierEmail") or "",
        submission.get("supplierId") or None,
        submission.get("contactName") or "",
        submission.get("phone") or "",
        _dt(submission.get("submittedAt")),
        "Submitted",
        submission.get("pricingFile") or "",
        submission.get("pricedCount") or 0,
        submission.get("noBidCount") or 0,
        submission.get("dlCount") or 0,
        submission.get("allwCount") or 0,
        submission.get("otherPricedCount") or 0,
        submission.get("notes") or "",
        submission.get("emailId") or "",
    )


async def _insert_line_items(conn, bid_pk: str, line_items: list[dict]) -> None:
    if not line_items:
        return
    rows = []
    for li in line_items:
        rows.append((
            str(uuid.uuid4()),
            bid_pk,
            li.get("id") or None,        # rfp_line_id (nullable FK — NULL when absent)
            li.get("bidItem") or "",      # item_no
            li.get("description") or "",
            li.get("unitPrice"),
            li.get("casePrice"),
            li.get("deliveredPrice"),
            li.get("fobPrice"),
            li.get("allowance"),
            bool(li.get("noBid", False)),
            li.get("devType"),
            li.get("customFieldValues") or {},
        ))
    await conn.executemany(
        """
        INSERT INTO bid_line_items (
            id, bid_id, rfp_line_id, item_no, description,
            unit_price, case_price, delivered_price, fob_price, allowance,
            no_bid, dev_type, custom_field_values
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13::jsonb)
        ON CONFLICT (id) DO NOTHING
        """,
        rows,
    )


async def _insert_messages(conn, bid_pk: str, messages: list[dict]) -> None:
    if not messages:
        return
    rows = []
    for msg in messages:
        rows.append((
            msg.get("id") or str(uuid.uuid4()),
            bid_pk,
            msg.get("direction") or "inbound",
            msg.get("from") or "",
            msg.get("fromName") or "",
            msg.get("body") or "",
            msg.get("attachments") or [],
            _dt(msg.get("timestamp")),
            bool(msg.get("readByBidCOE", False)),
            bool(msg.get("readBySupplier", False)),
        ))
    await conn.executemany(
        """
        INSERT INTO submission_messages (
            id, bid_id, direction, from_address, from_name, body,
            attachments, message_ts, read_by_bid_coe, read_by_supplier
        ) VALUES ($1, $2, $3, $4, $5, $6, $7::jsonb, $8, $9, $10)
        ON CONFLICT (id) DO NOTHING
        """,
        rows,
    )


async def _upsert_extraction_line_items(
    conn, bid_pk: str, line_items: list[dict], email_id: str
) -> None:
    """Delete this email's previous items then insert the current selection.

    Items from OTHER emails are never touched — enables accumulation across follow-up emails
    while allowing clean re-saves of the same email without stale rows.
    """
    await conn.execute(
        "DELETE FROM bid_line_items WHERE bid_id = $1 AND email_id = $2",
        bid_pk, email_id,
    )
    if not line_items:
        return
    rows = [
        (
            str(uuid.uuid4()),
            bid_pk,
            li.get("id") or None,          # rfp_line_id — nullable FK
            li.get("bidItem") or "",        # item_no
            li.get("description") or "",
            li.get("unitPrice"),
            li.get("casePrice"),
            bool(li.get("noBid", False)),
            li.get("devType"),
            email_id,
        )
        for li in line_items
    ]
    await conn.executemany(
        """
        INSERT INTO bid_line_items
            (id, bid_id, rfp_line_id, item_no, description,
             unit_price, case_price, no_bid, dev_type, email_id)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
        """,
        rows,
    )


# ── Repository class ──────────────────────────────────────────────────────────

class PgSubmissionsRepository:
    """
    Custom interface matching SubmissionsRepository.

    Methods:
      load()                                → dict[rfp_id, list[submission]]
      get_for_bid(bid_id)                   → list[submission]
      append_for_bid(bid_id, submission)    → submission
      update_submission(bid_id, thread_id, updater) → submission | None
      delete_for_bid(bid_id)                → int
    """

    async def load(self) -> dict[str, list[dict[str, Any]]]:
        """Load all submissions grouped by rfp_id (3 queries total, not N+1)."""
        async with _pool().acquire() as conn:
            bid_rows = await conn.fetch("SELECT * FROM bids ORDER BY submitted_at")
            if not bid_rows:
                return {}
            bid_pks = [r["id"] for r in bid_rows]
            li_rows = await conn.fetch(
                "SELECT * FROM bid_line_items WHERE bid_id = ANY($1::text[]) ORDER BY item_no",
                bid_pks,
            )
            msg_rows = await conn.fetch(
                "SELECT * FROM submission_messages WHERE bid_id = ANY($1::text[]) ORDER BY message_ts",
                bid_pks,
            )
        li_by_bid: dict[str, list] = {}
        for r in li_rows:
            li_by_bid.setdefault(r["bid_id"], []).append(_line_item_to_app(r))
        msg_by_bid: dict[str, list] = {}
        for r in msg_rows:
            msg_by_bid.setdefault(r["bid_id"], []).append(_msg_to_app(r))
        grouped: dict[str, list] = {}
        for row in bid_rows:
            pk = row["id"]
            sub = _bid_to_app(row, li_by_bid.get(pk, []), msg_by_bid.get(pk, []))
            grouped.setdefault(row["rfp_id"], []).append(sub)
        return grouped

    async def get_for_bid(self, bid_id: str) -> list[dict[str, Any]]:
        """Load submissions for one RFP (3 queries total, not N+1)."""
        async with _pool().acquire() as conn:
            bid_rows = await conn.fetch(
                "SELECT * FROM bids WHERE rfp_id = $1 ORDER BY submitted_at",
                bid_id,
            )
            if not bid_rows:
                return []
            bid_pks = [r["id"] for r in bid_rows]
            li_rows = await conn.fetch(
                "SELECT * FROM bid_line_items WHERE bid_id = ANY($1::text[]) ORDER BY item_no",
                bid_pks,
            )
            msg_rows = await conn.fetch(
                "SELECT * FROM submission_messages WHERE bid_id = ANY($1::text[]) ORDER BY message_ts",
                bid_pks,
            )
        li_by_bid: dict[str, list] = {}
        for r in li_rows:
            li_by_bid.setdefault(r["bid_id"], []).append(_line_item_to_app(r))
        msg_by_bid: dict[str, list] = {}
        for r in msg_rows:
            msg_by_bid.setdefault(r["bid_id"], []).append(_msg_to_app(r))
        return [
            _bid_to_app(row, li_by_bid.get(row["id"], []), msg_by_bid.get(row["id"], []))
            for row in bid_rows
        ]

    async def append_for_bid(
        self, bid_id: str, submission: dict[str, Any]
    ) -> dict[str, Any]:
        async with _pool().acquire() as conn:
            bid_row = await _insert_bid(conn, bid_id, submission)
            bid_pk = bid_row["id"]
            await _insert_line_items(conn, bid_pk, submission.get("lineItems") or [])
            await _insert_messages(conn, bid_pk, submission.get("messages") or [])
        return submission

    async def update_submission(
        self, bid_id: str, thread_id: str, updater: Any
    ) -> dict[str, Any] | None:
        async with _pool().acquire() as conn:
            # Find the bid row by thread_id
            bid_row = await conn.fetchrow(
                "SELECT * FROM bids WHERE rfp_id = $1 AND thread_id = $2",
                bid_id, thread_id,
            )
            if bid_row is None:
                return None
            bid_pk = bid_row["id"]

            # Load current state and apply updater
            current = await _build_submission(conn, bid_row)
            updated = updater(current)

            # Update bids row
            await conn.execute(
                """
                UPDATE bids SET
                    supplier_name     = $2,
                    supplier_email    = $3,
                    contact_name      = $4,
                    phone             = $5,
                    pricing_file      = $6,
                    priced_count      = $7,
                    no_bid_count      = $8,
                    dl_count          = $9,
                    allw_count        = $10,
                    other_priced_count= $11,
                    notes             = $12
                WHERE id = $1
                """,
                bid_pk,
                updated.get("supplierName") or "",
                updated.get("supplierEmail") or "",
                updated.get("contactName") or "",
                updated.get("phone") or "",
                updated.get("pricingFile") or "",
                updated.get("pricedCount") or 0,
                updated.get("noBidCount") or 0,
                updated.get("dlCount") or 0,
                updated.get("allwCount") or 0,
                updated.get("otherPricedCount") or 0,
                updated.get("notes") or "",
            )

            # Sync messages: insert new ones, update read-flags on existing ones
            existing_rows = await conn.fetch(
                "SELECT id, read_by_bid_coe, read_by_supplier FROM submission_messages WHERE bid_id = $1",
                bid_pk,
            )
            existing_by_id = {r["id"]: r for r in existing_rows}
            new_msgs: list[dict] = []
            flag_updates: list[tuple] = []
            for m in (updated.get("messages") or []):
                mid = m.get("id")
                if mid not in existing_by_id:
                    new_msgs.append(m)
                else:
                    row = existing_by_id[mid]
                    new_coe = bool(m.get("readByBidCOE", False))
                    new_sup = bool(m.get("readBySupplier", False))
                    if new_coe != bool(row["read_by_bid_coe"]) or new_sup != bool(row["read_by_supplier"]):
                        flag_updates.append((mid, new_coe, new_sup))
            await _insert_messages(conn, bid_pk, new_msgs)
            if flag_updates:
                await conn.executemany(
                    "UPDATE submission_messages SET read_by_bid_coe = $2, read_by_supplier = $3 WHERE id = $1",
                    flag_updates,
                )

        return updated

    async def delete_for_bid(self, bid_id: str) -> int:
        async with _pool().acquire() as conn:
            # Cascade handled via FK; explicitly delete messages first for safety
            bid_ids = [
                r["id"] for r in
                await conn.fetch("SELECT id FROM bids WHERE rfp_id = $1", bid_id)
            ]
            if bid_ids:
                await conn.execute(
                    "DELETE FROM submission_messages WHERE bid_id = ANY($1::text[])", bid_ids
                )
                await conn.execute(
                    "DELETE FROM bid_line_items WHERE bid_id = ANY($1::text[])", bid_ids
                )
            result = await conn.execute("DELETE FROM bids WHERE rfp_id = $1", bid_id)
        return int(result.split()[-1])

    async def upsert_from_extraction(self, bid_id: str, submission: dict) -> dict:
        """
        Create or update the extraction-sourced submission record for a supplier.

        Keyed on (rfp_id, supplier_email) — one bids row per supplier per RFP.
        This means follow-up emails from the same supplier accumulate items in the
        same submission rather than creating fragmented per-email rows.

        bid_line_items are managed per-email_id: on each save we delete only the
        items tagged with the current email_id then re-insert the current selection.
        Items from other emails are never touched.

        Portal submissions (email_id = '') use a separate unique constraint path
        and are never matched or modified here.
        """
        email_id       = submission.get("emailId") or ""
        supplier_email = submission.get("supplierEmail") or ""
        if not email_id:
            raise ValueError("emailId is required for extraction submissions")

        async with _pool().acquire() as conn:
            async with conn.transaction():
                # Partial index bids_rfp_supplier_extraction_idx covers this lookup
                existing = await conn.fetchrow(
                    "SELECT id FROM bids WHERE rfp_id = $1 AND supplier_email = $2 AND email_id != ''",
                    bid_id, supplier_email,
                )
                if existing:
                    bid_pk = existing["id"]
                    await conn.execute(
                        """
                        UPDATE bids SET
                            email_id     = $2,
                            pricing_file = $3,
                            priced_count = $4,
                            no_bid_count = $5,
                            submitted_at = $6
                        WHERE id = $1
                        """,
                        bid_pk,
                        email_id,
                        submission.get("pricingFile") or "",
                        submission.get("pricedCount") or 0,
                        submission.get("noBidCount") or 0,
                        _dt(submission.get("submittedAt")),
                    )
                else:
                    bid_row = await _insert_bid(conn, bid_id, submission)
                    bid_pk = bid_row["id"]

                # Delete this email's old items, insert current selection
                # bid_line_items_bid_email_idx makes the DELETE an index scan
                await _upsert_extraction_line_items(
                    conn, bid_pk, submission.get("lineItems") or [], email_id
                )

        return {
            "confirmationId": bid_pk,
            "lineItemCount": len(submission.get("lineItems") or []),
        }

    async def save(self, data: dict[str, list[dict[str, Any]]]) -> None:
        raise NotImplementedError(
            "save() not supported for DB submissions repo — use append_for_bid."
        )
