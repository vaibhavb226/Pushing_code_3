"""
PostgreSQL repository for email_threads table.

Critical field renames (DB → app):
  rfp_id         → bidId
  from_address   → from
  to_address     → to
  bcc_addresses  → bcc
  email_date     → date
  bounce_info    → bounceDetails
  message_id     → messageId
  auto_matched   → autoMatched
  original_recipient → originalRecipient
  bounce_code    → bounceCode
  bounce_reason  → bounceReason

Extra methods beyond AbstractRepository:
  get_for_bid(bid_id)  — indexed lookup by rfp_id
  find_by_uid(uid)     — indexed lookup for email poller dedup
"""
from __future__ import annotations

import uuid
from typing import Any

from repositories.pg_base import PgRepository, _str_dt, _dt


class PgEmailThreadsRepository(PgRepository):
    TABLE = "email_threads"
    ORDER_BY = "email_date"

    # ── Row → app dict ────────────────────────────────────────────────────────

    def _to_app(self, row) -> dict:
        d = dict(row)
        return {
            "id":               d["id"],
            "bidId":            d.get("rfp_id") or "",
            "supplierId":       d.get("supplier_id"),
            "supplierName":     d.get("supplier_name") or "",
            "supplierEmail":    d.get("supplier_email") or "",
            "direction":        d.get("direction") or "inbound",
            "subject":          d.get("subject") or "",
            "body":             d.get("body") or "",
            "date":             _str_dt(d.get("email_date")),
            "from":             d.get("from_address") or "",
            "to":               d.get("to_address") or "",
            "bcc":              d.get("bcc_addresses") or [],
            "tags":             d.get("tags") or [],
            "isBounce":         bool(d.get("is_bounce", False)),
            "bounceDetails":    d.get("bounce_info"),
            "bounceCode":       d.get("bounce_code"),
            "bounceReason":     d.get("bounce_reason"),
            "originalRecipient": d.get("original_recipient"),
            "attachments":      d.get("attachments") or [],
            "analysisResult":   d.get("analysis_result"),
            "pricingFilePath":  d.get("pricing_file_path") or "",
            "read":                    bool(d.get("read", False)),
            "uid":                     d.get("uid"),
            "type":                    d.get("type"),
            "messageId":               d.get("message_id"),
            "autoMatched":             bool(d.get("auto_matched", False)),
            "graphInternetMessageId":  d.get("graph_internet_message_id") or "",
        }

    # ── App dict → DB params dict ─────────────────────────────────────────────

    def _to_db(self, item: dict) -> dict:
        return {
            "id":               item.get("id") or f"ET-{uuid.uuid4().hex[:8]}",
            "rfp_id":           item.get("bidId") or "",
            "supplier_id":      item.get("supplierId"),
            "supplier_name":    item.get("supplierName") or "",
            "supplier_email":   item.get("supplierEmail") or "",
            "direction":        item.get("direction") or "inbound",
            "subject":          item.get("subject") or "",
            "body":             item.get("body") or "",
            "email_date":       _dt(item.get("date")),
            "from_address":     item.get("from") or "",
            "to_address":       item.get("to") or "",
            "bcc_addresses":    item.get("bcc") or [],
            "tags":             item.get("tags") or [],
            "is_bounce":        bool(item.get("isBounce", False)),
            "bounce_info":      item.get("bounceDetails"),
            "bounce_code":      item.get("bounceCode"),
            "bounce_reason":    item.get("bounceReason"),
            "original_recipient": item.get("originalRecipient"),
            "attachments":      item.get("attachments") or [],
            "analysis_result":  item.get("analysisResult"),
            "pricing_file_path": item.get("pricingFilePath") or "",
            "read":                       bool(item.get("read", False)),
            "uid":                        item.get("uid"),
            "type":                       item.get("type"),
            "message_id":                 item.get("messageId"),
            "auto_matched":               bool(item.get("autoMatched", False)),
            "graph_internet_message_id":  item.get("graphInternetMessageId") or "",
        }

    # ── INSERT RETURNING * ────────────────────────────────────────────────────

    async def _insert_returning(self, conn, item: dict):
        d = item if "rfp_id" in item else self._to_db(item)
        return await conn.fetchrow(
            """
            INSERT INTO email_threads (
                id, rfp_id, supplier_id, supplier_name, supplier_email,
                direction, subject, body, email_date,
                from_address, to_address, bcc_addresses, tags,
                is_bounce, bounce_info, attachments, analysis_result,
                pricing_file_path, read,
                uid, type, message_id, auto_matched,
                original_recipient, bounce_code, bounce_reason,
                graph_internet_message_id
            ) VALUES (
                $1,  $2,  $3,  $4,  $5,
                $6,  $7,  $8,  $9,
                $10, $11, $12::jsonb, $13::jsonb,
                $14, $15::jsonb, $16::jsonb, $17::jsonb,
                $18, $19,
                $20, $21, $22, $23,
                $24, $25, $26,
                $27
            )
            RETURNING *
            """,
            d["id"], d["rfp_id"], d["supplier_id"], d["supplier_name"], d["supplier_email"],
            d["direction"], d["subject"], d["body"], d["email_date"],
            d["from_address"], d["to_address"], d["bcc_addresses"], d["tags"],
            d["is_bounce"], d["bounce_info"], d["attachments"], d["analysis_result"],
            d["pricing_file_path"], d["read"],
            d["uid"], d["type"], d["message_id"], d["auto_matched"],
            d["original_recipient"], d["bounce_code"], d["bounce_reason"],
            d["graph_internet_message_id"],
        )

    async def append(self, item: dict) -> dict:
        db = self._to_db(item)
        async with self._pool().acquire() as conn:
            row = await self._insert_returning(conn, db)
        return self._to_app(row) if row else item

    async def append_many(self, records: list[dict]) -> None:
        """Insert N email thread records in a single connection acquire + executemany.

        Reduces N separate round-trips (each ~330 ms India→US) to one.
        Used by create_bid_email (BCC solicitation) and bounce fan-out in email_poller.
        """
        if not records:
            return
        args = [
            (
                d["id"], d["rfp_id"], d["supplier_id"], d["supplier_name"], d["supplier_email"],
                d["direction"], d["subject"], d["body"], d["email_date"],
                d["from_address"], d["to_address"], d["bcc_addresses"], d["tags"],
                d["is_bounce"], d["bounce_info"], d["attachments"], d["analysis_result"],
                d["pricing_file_path"], d["read"],
                d["uid"], d["type"], d["message_id"], d["auto_matched"],
                d["original_recipient"], d["bounce_code"], d["bounce_reason"],
                d["graph_internet_message_id"],
            )
            for d in [self._to_db(r) for r in records]
        ]
        async with self._pool().acquire() as conn:
            await conn.executemany(
                """
                INSERT INTO email_threads (
                    id, rfp_id, supplier_id, supplier_name, supplier_email,
                    direction, subject, body, email_date,
                    from_address, to_address, bcc_addresses, tags,
                    is_bounce, bounce_info, attachments, analysis_result,
                    pricing_file_path, read,
                    uid, type, message_id, auto_matched,
                    original_recipient, bounce_code, bounce_reason,
                    graph_internet_message_id
                ) VALUES (
                    $1,  $2,  $3,  $4,  $5,
                    $6,  $7,  $8,  $9,
                    $10, $11, $12::jsonb, $13::jsonb,
                    $14, $15::jsonb, $16::jsonb, $17::jsonb,
                    $18, $19,
                    $20, $21, $22, $23,
                    $24, $25, $26,
                    $27
                )
                ON CONFLICT (id) DO NOTHING
                """,
                args,
            )

    # ── UPDATE by id ──────────────────────────────────────────────────────────

    async def _update_in_place(self, conn, updated: dict) -> None:
        d = self._to_db(updated)
        await conn.execute(
            """
            UPDATE email_threads SET
                rfp_id                    = $2,
                supplier_id               = $3,
                supplier_name             = $4,
                supplier_email            = $5,
                direction                 = $6,
                subject                   = $7,
                body                      = $8,
                email_date                = $9,
                from_address              = $10,
                to_address                = $11,
                bcc_addresses             = $12::jsonb,
                tags                      = $13::jsonb,
                is_bounce                 = $14,
                bounce_info               = $15::jsonb,
                attachments               = $16::jsonb,
                analysis_result           = $17::jsonb,
                pricing_file_path         = $18,
                read                      = $19,
                uid                       = $20,
                type                      = $21,
                message_id                = $22,
                auto_matched              = $23,
                original_recipient        = $24,
                bounce_code               = $25,
                bounce_reason             = $26,
                graph_internet_message_id = $27,
                updated_at                = now()
            WHERE id = $1
            """,
            d["id"], d["rfp_id"], d["supplier_id"], d["supplier_name"], d["supplier_email"],
            d["direction"], d["subject"], d["body"], d["email_date"],
            d["from_address"], d["to_address"], d["bcc_addresses"], d["tags"],
            d["is_bounce"], d["bounce_info"], d["attachments"], d["analysis_result"],
            d["pricing_file_path"], d["read"],
            d["uid"], d["type"], d["message_id"], d["auto_matched"],
            d["original_recipient"], d["bounce_code"], d["bounce_reason"],
            d["graph_internet_message_id"],
        )

    # ── Extra methods ─────────────────────────────────────────────────────────

    async def get_for_bid(self, bid_id: str) -> list[dict]:
        async with self._pool().acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM email_threads WHERE rfp_id = $1 ORDER BY email_date",
                bid_id,
            )
        return [self._to_app(r) for r in rows]

    async def find_by_uid(self, uid: str) -> dict | None:
        """Direct index lookup for email poller dedup (avoids full table scan)."""
        async with self._pool().acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM email_threads WHERE uid = $1 LIMIT 1", uid
            )
        return self._to_app(row) if row else None

    async def update_graph_message_ids(self, record_ids: list[str], graph_id: str) -> None:
        """Bulk-set graphInternetMessageId on N records in one round-trip.

        Replaces the N×(full-scan+UPDATE) loop that _send_and_flag previously used.
        graph_id is the Exchange-assigned RFC 2822 Message-ID used for reply threading.
        """
        if not record_ids or not graph_id:
            return
        async with self._pool().acquire() as conn:
            await conn.execute(
                "UPDATE email_threads "
                "SET graph_internet_message_id = $1, updated_at = now() "
                "WHERE id = ANY($2::text[])",
                graph_id,
                record_ids,
            )
