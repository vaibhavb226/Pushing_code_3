from __future__ import annotations

from pathlib import Path

from repositories.base import JsonRepository


class SuppliersRepository(JsonRepository):
    """Repository for suppliers.json — array of supplier objects."""

    def __init__(self, path: Path) -> None:
        super().__init__(path)
