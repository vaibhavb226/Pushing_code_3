"""
PostgreSQL repository for portal_templates table.
"""
from __future__ import annotations

from repositories.pg_base import PgRepository


class PgPortalTemplatesRepository(PgRepository):
    TABLE = "portal_templates"
    ORDER_BY = "name"

    def _to_app(self, row) -> dict:
        d = dict(row)
        return {
            "id":           d["id"],
            "name":         d.get("name") or "",
            "label":        d.get("label") or d.get("segment") or "",
            "segment":      d.get("segment") or d.get("label") or "",
            "description":  d.get("description") or "",
            "customFields": d.get("custom_fields") or [],
        }

    def _to_db(self, item: dict) -> dict:
        seg = item.get("segment") or item.get("label") or ""
        return {
            "id":           item["id"],
            "name":         item.get("name") or "",
            "label":        seg,
            "segment":      seg,
            "description":  item.get("description") or "",
            "custom_fields": item.get("customFields") or [],
        }

    async def _insert_returning(self, conn, item: dict):
        d = item if "custom_fields" in item else self._to_db(item)
        return await conn.fetchrow(
            """
            INSERT INTO portal_templates (id, name, label, segment, description, custom_fields)
            VALUES ($1, $2, $3, $4, $5, $6::jsonb)
            RETURNING *
            """,
            d["id"], d["name"], d["label"], d["segment"], d["description"], d["custom_fields"],
        )

    async def _update_in_place(self, conn, updated: dict) -> None:
        d = self._to_db(updated)
        await conn.execute(
            """
            UPDATE portal_templates SET
                name          = $2,
                label         = $3,
                segment       = $4,
                description   = $5,
                custom_fields = $6::jsonb,
                updated_at    = now()
            WHERE id = $1
            """,
            d["id"], d["name"], d["label"], d["segment"], d["description"], d["custom_fields"],
        )
