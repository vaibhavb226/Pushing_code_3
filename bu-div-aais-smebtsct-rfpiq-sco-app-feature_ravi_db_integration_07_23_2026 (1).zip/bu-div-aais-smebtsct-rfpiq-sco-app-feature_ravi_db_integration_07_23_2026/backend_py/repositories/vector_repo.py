"""
pgvector repository — supplier embedding upsert and ANN similarity search.
Operates on a SQLAlchemy AsyncConnection passed in from the caller.
"""
from __future__ import annotations

import json
from typing import TYPE_CHECKING, Any

import structlog
from sqlalchemy import text

if TYPE_CHECKING:
    from sqlalchemy.ext.asyncio import AsyncConnection

log = structlog.get_logger()


def _vec(v: list[float]) -> str:
    """Serialize a float list as a Postgres vector literal: '[0.1,0.2,...]'"""
    return "[" + ",".join(str(x) for x in v) + "]"


async def upsert_supplier(conn: "AsyncConnection", supplier: dict, embedding: list[float]) -> None:
    """Insert or replace a supplier's embedding vector."""
    await conn.execute(
        text("""
        INSERT INTO supplier_vectors (supplier_id, embedding, supplier_json, indexed_at)
        VALUES (:supplier_id, CAST(:embedding AS vector), CAST(:supplier_json AS jsonb), now())
        ON CONFLICT (supplier_id) DO UPDATE
            SET embedding     = EXCLUDED.embedding,
                supplier_json = EXCLUDED.supplier_json,
                indexed_at    = now()
        """),
        {
            "supplier_id":   supplier["id"],
            "embedding":     _vec(embedding),
            "supplier_json": json.dumps(supplier),
        },
    )
    await conn.commit()


async def search_suppliers(
    conn: "AsyncConnection",
    query_embedding: list[float],
    top_k: int = 20,
) -> list[dict[str, Any]]:
    """
    Return top-K suppliers ordered by cosine similarity to query_embedding.
    Each result includes a 'similarity' float (0–1, higher is better).
    """
    rows = (
        await conn.execute(
            text("""
            SELECT supplier_id,
                   supplier_json,
                   1 - (embedding <=> CAST(:emb AS vector)) AS similarity
            FROM supplier_vectors
            ORDER BY embedding <=> CAST(:emb AS vector)
            LIMIT :top_k
            """),
            {"emb": _vec(query_embedding), "top_k": top_k},
        )
    ).mappings().all()

    results: list[dict[str, Any]] = []
    for row in rows:
        supplier_data: dict = json.loads(row["supplier_json"])
        supplier_data["similarity"] = round(float(row["similarity"]), 4)
        results.append(supplier_data)

    return results


# ── Document vector functions ────────────────────────────────────────────────

async def upsert_document_chunks(
    conn: "AsyncConnection",
    doc_id: str,
    rows: list[dict[str, Any]],
) -> None:
    """Delete existing chunks for doc_id then insert the new set (idempotent re-index)."""
    await conn.execute(
        text("DELETE FROM document_vectors WHERE document_id = :doc_id"),
        {"doc_id": doc_id},
    )
    for row in rows:
        await conn.execute(
            text("""
            INSERT INTO document_vectors
                (id, gcs_uri, bucket, object_name, file_name, file_type,
                 bid_id, document_id, document_type,
                 chunk_index, chunk_text, embedding, metadata, indexed_at)
            VALUES
                (:id, :gcs_uri, :bucket, :object_name, :file_name, :file_type,
                 :bid_id, :document_id, :document_type,
                 :chunk_index, :chunk_text, CAST(:embedding AS vector),
                 CAST(:metadata AS jsonb), now())
            ON CONFLICT (id) DO UPDATE
                SET chunk_text  = EXCLUDED.chunk_text,
                    embedding   = EXCLUDED.embedding,
                    metadata    = EXCLUDED.metadata,
                    indexed_at  = now()
            """),
            {
                "id":            row["id"],
                "gcs_uri":       row.get("gcs_uri", ""),
                "bucket":        row.get("bucket", ""),
                "object_name":   row.get("object_name", ""),
                "file_name":     row.get("file_name", ""),
                "file_type":     row.get("file_type", ""),
                "bid_id":        row.get("bid_id", ""),
                "document_id":   row.get("document_id", ""),
                "document_type": row.get("document_type", ""),
                "chunk_index":   row.get("chunk_index", 0),
                "chunk_text":    row.get("chunk_text", ""),
                "embedding":     _vec(row["embedding"]),
                "metadata":      json.dumps(row.get("metadata", {})),
            },
        )
    await conn.commit()
    log.info("vector_repo.chunks_upserted", doc_id=doc_id, count=len(rows))


async def delete_document_chunks(conn: "AsyncConnection", doc_id: str) -> int:
    """Delete all vector chunks for a single document. Returns the row count deleted."""
    result = await conn.execute(
        text("DELETE FROM document_vectors WHERE document_id = :doc_id"),
        {"doc_id": doc_id},
    )
    await conn.commit()
    deleted = result.rowcount if result.rowcount is not None else 0
    log.info("vector_repo.chunks_deleted", doc_id=doc_id, count=deleted)
    return deleted


async def delete_bid_chunks(conn: "AsyncConnection", bid_id: str) -> int:
    """Delete ALL vector chunks for every document belonging to a bid. Returns row count."""
    result = await conn.execute(
        text("DELETE FROM document_vectors WHERE bid_id = :bid_id"),
        {"bid_id": bid_id},
    )
    await conn.commit()
    deleted = result.rowcount if result.rowcount is not None else 0
    log.info("vector_repo.bid_chunks_deleted", bid_id=bid_id, count=deleted)
    return deleted


async def search_documents(
    conn: "AsyncConnection",
    query_embedding: list[float],
    top_k: int = 8,
    bid_id: str | None = None,
    similarity_threshold: float = 0.50,
) -> list[dict[str, Any]]:
    """ANN cosine search over document_vectors with optional bid-scoped filtering.

    Fetches top_k * 2 candidates then filters by similarity_threshold, returning at most top_k.
    Returns list of dicts with: chunk_text, file_name, bid_id, document_type, similarity (0–1).
    """
    fetch_k = top_k * 2  # over-fetch so threshold filtering doesn't leave us empty
    emb_str = _vec(query_embedding)

    if bid_id:
        sql = text("""
            SELECT chunk_text, file_name, bid_id, document_type, metadata,
                   1 - (embedding <=> CAST(:emb AS vector)) AS similarity
            FROM document_vectors
            WHERE bid_id = :bid_id
            ORDER BY embedding <=> CAST(:emb AS vector)
            LIMIT :fetch_k
        """)
        params: dict[str, Any] = {"emb": emb_str, "bid_id": bid_id, "fetch_k": fetch_k}
    else:
        sql = text("""
            SELECT chunk_text, file_name, bid_id, document_type, metadata,
                   1 - (embedding <=> CAST(:emb AS vector)) AS similarity
            FROM document_vectors
            ORDER BY embedding <=> CAST(:emb AS vector)
            LIMIT :fetch_k
        """)
        params = {"emb": emb_str, "fetch_k": fetch_k}

    rows = (await conn.execute(sql, params)).mappings().all()

    results = []
    for row in rows:
        sim = float(row["similarity"])
        if sim >= similarity_threshold:
            meta = row["metadata"]
            results.append({
                "chunk_text":    row["chunk_text"],
                "file_name":     row["file_name"],
                "bid_id":        row["bid_id"],
                "document_type": row["document_type"],
                "metadata":      dict(meta) if meta else {},
                "similarity":    round(sim, 4),
            })
        if len(results) >= top_k:
            break

    return results
