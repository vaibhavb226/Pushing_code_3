"""
PostgreSQL repository for customers table.

Thin PgRepository subclass — load() returns all customers for the dropdown;
append() inserts a new customer row.

No JSON fallback — all customer data lives in Cloud SQL.
"""
from __future__ import annotations

import uuid
from typing import Any

from repositories.pg_base import PgRepository


class PgCustomersRepository(PgRepository):
    TABLE = "customers"
    ORDER_BY = "organization_name"

    def _to_app(self, row) -> dict:
        d = dict(row)
        return {
            "id":            d["id"],
            "name":          d.get("organization_name") or "",
            "contactPerson": d.get("contact_person") or "",
            "email":         d.get("email") or "",
            "phone":         d.get("phone") or "",
            "address":       d.get("address") or "",
            "city":          d.get("city") or "",
            "state":         d.get("state") or "",
            "zipCode":       d.get("zip_code") or "",
            "country":       d.get("country") or "US",
            "customerType":  d.get("customer_type") or "",
            "segment":       d.get("segment") or "",
            "opco":          d.get("opco") or "",
            "opcoName":      d.get("opco_name") or "",
            "region":        d.get("region") or "",
            "status":        d.get("status") or "Active",
        }

    def _to_db(self, item: dict) -> dict:
        return {
            "id":               item.get("id") or f"CUST-{uuid.uuid4().hex[:8].upper()}",
            "organization_name": item.get("name") or "",
            "contact_person":   item.get("contactPerson") or "",
            "email":            item.get("email") or "",
            "phone":            item.get("phone") or "",
            "address":          item.get("address") or "",
            "city":             item.get("city") or "",
            "state":            item.get("state") or "",
            "zip_code":         item.get("zipCode") or "",
            "country":          item.get("country") or "US",
            "customer_type":    item.get("customerType") or "",
            "segment":          item.get("segment") or "",
            "opco":             item.get("opco") or "",
            "opco_name":        item.get("opcoName") or "",
            "region":           item.get("region") or "",
            "status":           item.get("status") or "Active",
        }

    async def _insert_returning(self, conn, item: dict):
        db = self._to_db(item)
        return await conn.fetchrow(
            """
            INSERT INTO customers (
                id, organization_name, contact_person, email, phone,
                address, city, state, zip_code, country,
                customer_type, segment, opco, opco_name, region, status
            ) VALUES (
                $1, $2, $3, $4, $5,
                $6, $7, $8, $9, $10,
                $11, $12, $13, $14, $15, $16
            )
            ON CONFLICT (id) DO UPDATE SET
                organization_name = EXCLUDED.organization_name,
                contact_person    = EXCLUDED.contact_person,
                email             = EXCLUDED.email,
                phone             = EXCLUDED.phone,
                address           = EXCLUDED.address,
                city              = EXCLUDED.city,
                state             = EXCLUDED.state,
                zip_code          = EXCLUDED.zip_code,
                country           = EXCLUDED.country,
                customer_type     = EXCLUDED.customer_type,
                segment           = EXCLUDED.segment,
                opco              = EXCLUDED.opco,
                opco_name         = EXCLUDED.opco_name,
                region            = EXCLUDED.region,
                status            = EXCLUDED.status,
                updated_at        = now()
            RETURNING *
            """,
            db["id"], db["organization_name"], db["contact_person"], db["email"], db["phone"],
            db["address"], db["city"], db["state"], db["zip_code"], db["country"],
            db["customer_type"], db["segment"], db["opco"], db["opco_name"], db["region"], db["status"],
        )

    async def _update_in_place(self, conn, updated: dict) -> None:
        db = self._to_db(updated)
        await conn.execute(
            """
            UPDATE customers SET
                organization_name = $2, contact_person = $3, email = $4, phone = $5,
                address = $6, city = $7, state = $8, zip_code = $9, country = $10,
                customer_type = $11, segment = $12, opco = $13, opco_name = $14,
                region = $15, status = $16, updated_at = now()
            WHERE id = $1
            """,
            db["id"], db["organization_name"], db["contact_person"], db["email"], db["phone"],
            db["address"], db["city"], db["state"], db["zip_code"], db["country"],
            db["customer_type"], db["segment"], db["opco"], db["opco_name"], db["region"], db["status"],
        )

    async def update_by_id(self, customer_id: str, updater) -> dict | None:
        """Update one customer by PK — avoids full table scan used by update_one."""
        async with self._pool().acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT * FROM customers WHERE id = $1 FOR UPDATE", customer_id
                )
                if row is None:
                    return None
                updated = updater(self._to_app(row))
                await self._update_in_place(conn, updated)
        return updated

    async def delete_by_id(self, customer_id: str) -> int:
        """Delete one customer by PK — avoids full table scan used by delete_where."""
        async with self._pool().acquire() as conn:
            result = await conn.execute(
                "DELETE FROM customers WHERE id = $1", customer_id
            )
        return int(result.split()[-1])

    async def find_by_id(self, customer_id: str) -> dict | None:
        async with self._pool().acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM customers WHERE id = $1", customer_id
            )
        return self._to_app(row) if row else None

    async def find_by_name(self, name: str) -> dict | None:
        """Case-insensitive exact match by organization_name."""
        async with self._pool().acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM customers WHERE lower(organization_name) = lower($1)",
                name,
            )
        return self._to_app(row) if row else None

    async def search(self, query: str) -> list[dict]:
        """Prefix/substring search for the combobox filter."""
        async with self._pool().acquire() as conn:
            rows = await conn.fetch(
                """
                SELECT * FROM customers
                WHERE lower(organization_name) LIKE lower($1)
                ORDER BY organization_name
                LIMIT 50
                """,
                f"%{query}%",
            )
        return [self._to_app(r) for r in rows]
