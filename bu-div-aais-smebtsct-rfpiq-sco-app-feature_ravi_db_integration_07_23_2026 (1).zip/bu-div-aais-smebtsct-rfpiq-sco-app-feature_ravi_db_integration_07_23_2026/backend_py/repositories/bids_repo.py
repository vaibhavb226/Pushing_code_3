from __future__ import annotations

from pathlib import Path

from repositories.base import JsonRepository


class BidsRepository(JsonRepository):
    """Repository for bids.json — array of bid objects."""

    def __init__(self, path: Path) -> None:
        super().__init__(path)

    async def find_by_id(self, bid_id: str) -> dict | None:
        return await self.find_one(lambda b: b.get("id") == bid_id)

    async def update_by_id(self, bid_id: str, updater) -> dict | None:
        return await self.update_one(lambda b: b.get("id") == bid_id, updater)
