-- ================================================================
-- FoodCorp RFP AIQ — Complete Database Schema
-- Last updated: July 2026 | Cloud SQL PostgreSQL 15+
--
-- This is the single source-of-truth DDL for a fresh installation.
-- Run this file once to create all tables, indexes, and extensions.
--
-- Table order respects FK dependencies (parents before children):
--   customers → suppliers → products → portal_templates → poll_state
--   → unmatched_emails → rfps → rfp_line_items
--   → rfp_solicited_suppliers → email_threads → documents
--   → bids → bid_line_items → submission_messages
--   → supplier_vectors → document_text → document_vectors
-- ================================================================

-- ── Extensions ────────────────────────────────────────────────────────────────
-- pg_trgm: trigram search for CustomerCombobox (LIKE '%query%' via GIN index)
-- vector:  pgvector for supplier and document RAG embeddings
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS vector;


-- ── 1. customers ──────────────────────────────────────────────────────────────
-- Organizations that issue RFPs to FoodCorp Bid COE.
CREATE TABLE IF NOT EXISTS customers (
    id                TEXT        PRIMARY KEY,
    organization_name TEXT        NOT NULL,
    contact_person    TEXT        DEFAULT '',
    email             TEXT        DEFAULT '',
    phone             TEXT        DEFAULT '',
    address           TEXT        DEFAULT '',
    city              TEXT        DEFAULT '',
    state             TEXT        DEFAULT '',
    zip_code          TEXT        DEFAULT '',
    country           TEXT        DEFAULT 'US',
    customer_type     TEXT        DEFAULT '',
    segment           TEXT        DEFAULT '',   -- K-12 | DoD | University | Healthcare | Restaurant | Lodging | Government
    opco              TEXT        DEFAULT '',   -- OpCo code e.g. "016"
    opco_name         TEXT        DEFAULT '',   -- e.g. "FoodCorp Boston"
    region            TEXT        DEFAULT '',   -- Northeast | Midwest | Southeast | etc.
    status            TEXT        NOT NULL DEFAULT 'Active',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Trigram GIN index for fast LIKE '%query%' substring search in CustomerCombobox.
-- Trigram GIN index for fast LIKE '%query%' substring search in CustomerCombobox.
CREATE INDEX IF NOT EXISTS customers_org_name_trgm_idx
    ON customers USING GIN (lower(organization_name) gin_trgm_ops);
-- Unique index for exact case-insensitive find_by_name lookups.
CREATE UNIQUE INDEX IF NOT EXISTS customers_org_name_lower_idx
    ON customers (lower(organization_name));


-- ── 2. suppliers ──────────────────────────────────────────────────────────────
-- Food manufacturers, distributors, and brokers.
CREATE TABLE IF NOT EXISTS suppliers (
    id                TEXT        PRIMARY KEY,
    name              TEXT        NOT NULL,
    category          TEXT        DEFAULT '',       -- primary: Broker | Grocery | Protein | Bakery | Produce | Dairy | etc.
    subcategories     JSONB       NOT NULL DEFAULT '[]',  -- ["Rice","Grains"]
    contact_name      TEXT        DEFAULT '',
    contact_email     TEXT        DEFAULT '',       -- primary contact email
    phone             TEXT        DEFAULT '',
    address           TEXT        DEFAULT '',
    city              TEXT        DEFAULT '',
    state             TEXT        DEFAULT '',
    zip_code          TEXT        DEFAULT '',
    country           TEXT        DEFAULT 'US',
    region            TEXT        DEFAULT 'National',
    broker            BOOLEAN     NOT NULL DEFAULT false,
    segments          JSONB       NOT NULL DEFAULT '[]',  -- ["K-12","DoD","University","Healthcare"]
    tags              JSONB       NOT NULL DEFAULT '[]',  -- compliance: ["Buy American","Child Nutrition"]
    additional_emails JSONB       NOT NULL DEFAULT '[]',  -- extra CC addresses
    compliance        JSONB       NOT NULL DEFAULT '[]',  -- compliance certifications held
    notes             TEXT        DEFAULT '',
    bounce            BOOLEAN     NOT NULL DEFAULT false,
    status            TEXT        NOT NULL DEFAULT 'Active',
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- ── 3. products ───────────────────────────────────────────────────────────────
-- FoodCorp SUPC item master. Phase 2 integration — schema ready,
-- FK from rfp_line_items is nullable until SUPC matching is implemented.
CREATE TABLE IF NOT EXISTS products (
    id              TEXT        PRIMARY KEY,
    brand           TEXT        DEFAULT '',
    product_code    TEXT        DEFAULT '',     -- manufacturer product code (MPC)
    supc            TEXT        UNIQUE,         -- FoodCorp Universal Product Code
    product_name    TEXT        NOT NULL,
    description     TEXT        DEFAULT '',
    category        TEXT        DEFAULT '',
    sub_category    TEXT        DEFAULT '',
    unit_of_measure TEXT        DEFAULT '',
    status          TEXT        NOT NULL DEFAULT 'Active',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- ── 4. portal_templates ───────────────────────────────────────────────────────
-- Predefined portal form templates: k12-standard, healthcare, government, quick-quote.
-- Read-only at runtime — seeded from portalTemplates.json; no live create/update API.
CREATE TABLE IF NOT EXISTS portal_templates (
    id              TEXT        PRIMARY KEY,
    name            TEXT        NOT NULL,
    label           TEXT        DEFAULT '',
    description     TEXT        DEFAULT '',
    segment         TEXT        NOT NULL DEFAULT '',   -- target customer segment
    standard_fields JSONB       NOT NULL DEFAULT '[]', -- built-in field definitions
    custom_fields   JSONB       NOT NULL DEFAULT '[]', -- [{id, label, type, required, showInWorkingFile}]
    fields          JSONB       NOT NULL DEFAULT '[]', -- alias for standard_fields (used by app layer)
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- ── 5. poll_state ─────────────────────────────────────────────────────────────
-- Single-row high-water mark for the MS Graph inbox poller.
-- last_polled_at advances on every poll cycle that processes messages.
CREATE TABLE IF NOT EXISTS poll_state (
    id             INTEGER     PRIMARY KEY DEFAULT 1,
    last_polled_at TIMESTAMPTZ,
    updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT poll_state_single_row CHECK (id = 1)
);
-- Ensure the single seed row always exists.
INSERT INTO poll_state (id) VALUES (1) ON CONFLICT DO NOTHING;


-- ── 6. unmatched_emails ───────────────────────────────────────────────────────
-- Inbound emails the MS Graph poller could not match to any active RFP.
-- Capped at 500 most recent rows by the PG repo's load() override.
CREATE TABLE IF NOT EXISTS unmatched_emails (
    id           TEXT        PRIMARY KEY,
    subject      TEXT        DEFAULT '',
    from_address TEXT        DEFAULT '',
    body         TEXT        DEFAULT '',
    received_at  TIMESTAMPTZ,
    attachments  JSONB       NOT NULL DEFAULT '[]',
    uid          TEXT,                              -- MS Graph message UID for dedup
    raw_payload  JSONB,
    processed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS unmatched_emails_received_at_idx
    ON unmatched_emails (received_at DESC);


-- ── 7. rfps ───────────────────────────────────────────────────────────────────
-- The primary entity: an RFP solicitation FoodCorp Bid COE sends to suppliers.
-- In application code the variable names are bid/bidId (historical, not renamed).
CREATE TABLE IF NOT EXISTS rfps (
    id                      TEXT        PRIMARY KEY,            -- system ID: RFP-XXXXX or B2600042
    rfp_number              TEXT,                               -- customer's doc reference; NULL for older records
    customer_id             TEXT        REFERENCES customers(id) ON DELETE SET NULL,
    customer_name           TEXT        NOT NULL,               -- denormalized for display without join
    segment                 TEXT        DEFAULT '',             -- K-12 | DoD | University | Healthcare | Restaurant | Lodging | Government
    opco                    TEXT        DEFAULT '',
    opco_name               TEXT        DEFAULT '',
    region                  TEXT        DEFAULT '',
    status                  TEXT        NOT NULL DEFAULT 'Active',
    -- Valid statuses: Active | Solicitation | Working File | Review | At Risk | Awarded | Cancelled

    -- Dates
    intake_date             DATE,
    bid_release             DATE,
    customer_due            DATE,                               -- customer-facing deadline
    internal_due            DATE,                               -- Bid COE internal deadline (usually customerDue - 5 days)

    -- Compliance & categories
    compliance              JSONB       NOT NULL DEFAULT '[]',  -- ["Child Nutrition","Buy American","PFS","Exact Spec"]
    item_categories         JSONB       NOT NULL DEFAULT '[]',  -- ["Fluid Milk","Grain","Snack","M/MA"]

    -- Denormalized counts (updated on solicitation / response events)
    items                   INTEGER     NOT NULL DEFAULT 0,
    suppliers_contacted     INTEGER     NOT NULL DEFAULT 0,
    responses_received      INTEGER     NOT NULL DEFAULT 0,

    -- File references
    uploaded_rfp_path       TEXT        DEFAULT '',
    uploaded_item_list_path TEXT        DEFAULT '',
    uploaded_files          JSONB       NOT NULL DEFAULT '[]',  -- [{id, name, type, path, uploadedAt}]
    line_item_source        TEXT        DEFAULT '',             -- 'excel' | 'pdf'

    -- Config blobs
    auto_reminder           JSONB,                             -- {enabled, daysAfterSolicitation, lastReminderSent}
    portal_config           JSONB,                             -- {templateId, appliedAt, customFields[]}
    working_file_config     JSONB,                             -- column visibility settings

    -- Misc
    last_solicitation_date  DATE,
    total_budget            NUMERIC,
    notes                   TEXT        DEFAULT '',
    created_by              TEXT        DEFAULT '',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS rfps_customer_id_idx      ON rfps (customer_id);
CREATE INDEX IF NOT EXISTS rfps_status_idx           ON rfps (status);
CREATE INDEX IF NOT EXISTS rfps_segment_idx          ON rfps (segment);
CREATE INDEX IF NOT EXISTS rfps_internal_due_idx     ON rfps (internal_due);
CREATE INDEX IF NOT EXISTS rfps_rfp_number_idx       ON rfps (rfp_number);
CREATE INDEX IF NOT EXISTS rfps_segment_status_idx   ON rfps (segment, status);
CREATE INDEX IF NOT EXISTS rfps_created_at_idx       ON rfps (created_at DESC);
CREATE INDEX IF NOT EXISTS rfps_uploaded_files_gin   ON rfps USING gin(uploaded_files);


-- ── 8. rfp_line_items ─────────────────────────────────────────────────────────
-- Product line items within an RFP.
-- Left side = Customer RFP data. Right side = selected Supplier Response.
-- supplier_pricing JSONB holds all extracted/submitted pricing offers per item.
CREATE TABLE IF NOT EXISTS rfp_line_items (
    id              TEXT        PRIMARY KEY,
    rfp_id          TEXT        NOT NULL REFERENCES rfps(id) ON DELETE CASCADE,
    product_id      TEXT        REFERENCES products(id) ON DELETE SET NULL,  -- nullable until SUPC integrated (Phase 2)

    -- Left side: Customer RFP columns
    bid_item        TEXT        DEFAULT '',         -- 4-digit padded item number: "0001"
    line_number     INTEGER     DEFAULT 0,
    mpc_code        TEXT        DEFAULT '',         -- manufacturer product code
    mfg_code        TEXT,                           -- manufacturer code (alternate ID)
    gtin            TEXT,                           -- global trade item number
    subcategory     TEXT,
    supc            TEXT,                           -- FoodCorp SUPC (filled later from item master)
    brand           TEXT        DEFAULT '',
    description     TEXT        DEFAULT '',
    pack            TEXT        DEFAULT '',         -- e.g. "6"
    size            TEXT        DEFAULT '',         -- e.g. "10 oz"
    unit            TEXT        DEFAULT '',         -- UOM: CS | EA | LB | etc.
    category        TEXT        DEFAULT '',
    qty             INTEGER     NOT NULL DEFAULT 0, -- estimated annual volume
    storage         TEXT        DEFAULT '',
    cw              TEXT        DEFAULT 'N',        -- catchweight: Y/N
    stk_type        TEXT        DEFAULT 'A',        -- stock type: A=Active
    buy_american    BOOLEAN     NOT NULL DEFAULT false,
    child_nutrition BOOLEAN     NOT NULL DEFAULT false,
    pfs_required    BOOLEAN     NOT NULL DEFAULT false,
    exact_spec      BOOLEAN     NOT NULL DEFAULT false,
    whole_grain     BOOLEAN     NOT NULL DEFAULT false,
    halal           BOOLEAN     NOT NULL DEFAULT false,
    kosher          BOOLEAN     NOT NULL DEFAULT false,
    rfp_populated   BOOLEAN     NOT NULL DEFAULT true,
    source          TEXT        DEFAULT '',         -- 'excel' | 'pdf'

    -- Right side: Selected supplier response columns (awarded/working-file values)
    true_vendor      TEXT,                          -- winning supplier name
    supplied_price   NUMERIC,
    allw             NUMERIC,                       -- allowance off-invoice
    dl               NUMERIC,                      -- delivered cost override
    price_case       NUMERIC,                      -- net $/case
    dev_type         TEXT,                          -- 'ALLW' | 'DL' | NULL
    open_review      BOOLEAN     NOT NULL DEFAULT false,
    status           TEXT        NOT NULL DEFAULT 'No Response',
    confidence       NUMERIC,

    -- All supplier pricing offers for this line item (JSONB array, keyed by supplierName+emailId).
    -- true_vendor + price_case hold the COE-selected award price.
    supplier_pricing JSONB       NOT NULL DEFAULT '[]',

    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS rfp_line_items_rfp_id_idx   ON rfp_line_items (rfp_id);
CREATE INDEX IF NOT EXISTS rfp_line_items_bid_item_idx ON rfp_line_items (rfp_id, bid_item);


-- ── 9. rfp_solicited_suppliers ────────────────────────────────────────────────
-- Which suppliers were solicited per RFP and their current response status.
CREATE TABLE IF NOT EXISTS rfp_solicited_suppliers (
    id                         TEXT        PRIMARY KEY,
    rfp_id                     TEXT        NOT NULL REFERENCES rfps(id) ON DELETE CASCADE,
    supplier_id                TEXT        REFERENCES suppliers(id) ON DELETE SET NULL,
    supplier_name              TEXT        NOT NULL,
    email                      TEXT        NOT NULL,
    category                   TEXT        DEFAULT '',
    status                     TEXT        NOT NULL DEFAULT 'Awaiting',
    -- Valid: Awaiting | Contacted | Responded | Issues Found | Follow-up Sent | Under Consideration | Awarded
    channel                    TEXT        NOT NULL DEFAULT 'Email',  -- 'Email' | 'Portal' | 'Both'
    thread_id                  TEXT,                -- portal thread ID (set when supplier uses portal)
    additional_emails          JSONB       NOT NULL DEFAULT '[]',    -- CC addresses for this supplier
    solicitation_subject       TEXT,                -- stored for email reply-thread matching
    solicited_date             DATE,
    last_activity              TIMESTAMPTZ,
    has_issues                 BOOLEAN     NOT NULL DEFAULT false,
    issue_type                 TEXT,                -- 'bounce' | etc.
    bounced_at                 TIMESTAMPTZ,
    award_notification_sent    BOOLEAN     NOT NULL DEFAULT false,
    award_notification_sent_at TIMESTAMPTZ,
    created_at                 TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                 TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS rfp_sol_rfp_id_idx      ON rfp_solicited_suppliers (rfp_id);
CREATE INDEX IF NOT EXISTS rfp_sol_supplier_id_idx ON rfp_solicited_suppliers (supplier_id);
CREATE INDEX IF NOT EXISTS rfp_sol_status_idx      ON rfp_solicited_suppliers (rfp_id, status);


-- ── 10. email_threads ─────────────────────────────────────────────────────────
-- All email traffic per RFP: solicitations, replies, bounces, reminders, portal mirrors.
CREATE TABLE IF NOT EXISTS email_threads (
    id                        TEXT        PRIMARY KEY,
    rfp_id                    TEXT        NOT NULL REFERENCES rfps(id) ON DELETE CASCADE,
    supplier_id               TEXT        REFERENCES suppliers(id) ON DELETE SET NULL,
    supplier_name             TEXT        DEFAULT '',
    supplier_email            TEXT        DEFAULT '',
    direction                 TEXT        NOT NULL,           -- 'inbound' | 'outbound'
    type                      TEXT,                          -- 'solicitation' | 'reminder' | 'reply' | 'bounce' | 'award' | 'portal'
    subject                   TEXT        NOT NULL DEFAULT '',
    body                      TEXT        NOT NULL DEFAULT '',
    email_date                TIMESTAMPTZ NOT NULL DEFAULT now(),
    from_address              TEXT        DEFAULT '',
    to_address                TEXT        DEFAULT '',
    bcc_addresses             JSONB       NOT NULL DEFAULT '[]',
    tags                      JSONB       NOT NULL DEFAULT '[]', -- ['solicitation','reminder','resolicitation','auto','portal-url']
    is_bounce                 BOOLEAN     NOT NULL DEFAULT false,
    bounce_info               JSONB,                            -- {errorCode, reason, failedAddress}
    bounce_code               TEXT,                            -- SMTP bounce code e.g. "5.1.1"
    bounce_reason             TEXT,                            -- human-readable bounce description
    original_recipient        TEXT,                            -- affected address in an NDR
    attachments               JSONB       NOT NULL DEFAULT '[]', -- [{originalName, savedName, path}]
    analysis_result           JSONB,                            -- AI pricing analysis (display only — never sets supplier status)
    pricing_file_path         TEXT        DEFAULT '',
    message_id                TEXT,                            -- MS Graph internetMessageId for reply threading
    graph_internet_message_id TEXT        NOT NULL DEFAULT '', -- Exchange-assigned RFC 2822 Message-ID
    auto_matched              BOOLEAN     NOT NULL DEFAULT false, -- set by inbox poller
    uid                       TEXT,                            -- MS Graph message UID (for dedup)
    read                      BOOLEAN     NOT NULL DEFAULT false,
    created_at                TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at                TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS email_threads_rfp_id_idx      ON email_threads (rfp_id);
CREATE INDEX IF NOT EXISTS email_threads_supplier_id_idx ON email_threads (supplier_id);
CREATE INDEX IF NOT EXISTS email_threads_direction_idx   ON email_threads (direction);
CREATE INDEX IF NOT EXISTS email_threads_date_idx        ON email_threads (email_date DESC);
CREATE INDEX IF NOT EXISTS email_threads_message_id_idx  ON email_threads (message_id);
CREATE INDEX IF NOT EXISTS email_threads_uid_idx         ON email_threads (uid) WHERE uid IS NOT NULL;
-- Partial index — only non-empty graph IDs are used for threading lookups.
CREATE INDEX IF NOT EXISTS email_threads_graph_id_idx
    ON email_threads (graph_internet_message_id)
    WHERE graph_internet_message_id IS NOT NULL AND graph_internet_message_id != '';


-- ── 11. documents ─────────────────────────────────────────────────────────────
-- Document vault: RFP files, supplier quotes, compliance certs, spec sheets.
CREATE TABLE IF NOT EXISTS documents (
    id                     TEXT        PRIMARY KEY,
    rfp_id                 TEXT        REFERENCES rfps(id) ON DELETE CASCADE,
    supplier_id            TEXT        REFERENCES suppliers(id) ON DELETE SET NULL,
    supplier               TEXT,                             -- denormalized supplier name
    supplier_category      TEXT,
    file_name              TEXT        NOT NULL,
    file_type              TEXT        DEFAULT '',           -- pdf | xlsx | docx | csv | etc.
    size_kb                INTEGER     DEFAULT 0,
    document_type          TEXT        DEFAULT '',           -- RFP | Item List | Pricing | Spec Sheet | Compliance | Other
    category               TEXT        NOT NULL DEFAULT '',  -- vault category
    tags                   JSONB       NOT NULL DEFAULT '[]',
    notes                  TEXT        NOT NULL DEFAULT '',
    upload_date            TIMESTAMPTZ NOT NULL DEFAULT now(),
    uploaded_by            TEXT        DEFAULT '',
    status                 TEXT        NOT NULL DEFAULT 'Filed',
    file_path              TEXT        DEFAULT '',           -- local path (dev/fallback)
    gcs_uri                TEXT,                             -- gs://bucket/rfp_id/DocType/...
    description            TEXT        DEFAULT '',
    in_vault               BOOLEAN     NOT NULL DEFAULT true,
    extraction_confidence  INTEGER,
    linked_line_items      JSONB       NOT NULL DEFAULT '[]',
    created_at             TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at             TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS documents_rfp_id_idx      ON documents (rfp_id);
CREATE INDEX IF NOT EXISTS documents_supplier_id_idx ON documents (supplier_id);
CREATE INDEX IF NOT EXISTS documents_gcs_uri_idx     ON documents (gcs_uri);


-- ── 12. bids (supplier submissions) ──────────────────────────────────────────
-- A supplier's pricing submission in response to an RFP.
-- "Bid" = what the supplier submits. Distinct from rfps (what COE issues).
--
-- email_id: empty string for portal submissions; set to email record ID for
--   extractions. Unique partial index (rfp_id, supplier_email) WHERE email_id != ''
--   ensures one extraction row per supplier per RFP while allowing multiple
--   portal rows (email_id = '' exempt from constraint).
CREATE TABLE IF NOT EXISTS bids (
    id                 TEXT        PRIMARY KEY,
    confirmation_id    TEXT        UNIQUE NOT NULL,  -- "SUB-B2600042-XXXXXXXX"
    thread_id          TEXT        UNIQUE NOT NULL,  -- "THREAD-B2600042-XXXXXXXX" | "EXTR-XXXXXXXXXXXX"
    rfp_id             TEXT        NOT NULL REFERENCES rfps(id) ON DELETE CASCADE,
    supplier_id        TEXT        REFERENCES suppliers(id) ON DELETE SET NULL,
    supplier_name      TEXT        NOT NULL,
    supplier_email     TEXT        NOT NULL,
    contact_name       TEXT        DEFAULT '',
    phone              TEXT        DEFAULT '',
    submitted_by       TEXT        DEFAULT '',
    submitted_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    bid_status         TEXT        NOT NULL DEFAULT 'Submitted',
    total_bid_amount   NUMERIC,
    currency           TEXT        DEFAULT 'USD',
    delivery_timeframe TEXT        DEFAULT '',
    payment_terms      TEXT        DEFAULT '',
    pricing_file       TEXT        DEFAULT '',       -- uploaded pricing filename / source file
    priced_count       INTEGER     NOT NULL DEFAULT 0,
    no_bid_count       INTEGER     NOT NULL DEFAULT 0,
    dl_count           INTEGER     NOT NULL DEFAULT 0,
    allw_count         INTEGER     NOT NULL DEFAULT 0,
    other_priced_count INTEGER     NOT NULL DEFAULT 0,
    email_id           TEXT        NOT NULL DEFAULT '', -- '' = portal | '<id>' = extraction source email
    notes              TEXT        DEFAULT '',
    created_at         TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at         TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS bids_rfp_id_idx      ON bids (rfp_id);
CREATE INDEX IF NOT EXISTS bids_supplier_id_idx ON bids (supplier_id);
CREATE INDEX IF NOT EXISTS bids_confirmation_idx ON bids (confirmation_id);
-- Partial index: allow partial supplier lookups only where thread_id is set.
CREATE INDEX IF NOT EXISTS bids_thread_id_idx
    ON bids (thread_id) WHERE thread_id IS NOT NULL AND thread_id <> '';
-- One extraction row per (rfp, supplier). Portal rows (email_id='') are exempt.
CREATE UNIQUE INDEX IF NOT EXISTS bids_rfp_supplier_extraction_idx
    ON bids (rfp_id, supplier_email)
    WHERE email_id != '';


-- ── 13. bid_line_items ────────────────────────────────────────────────────────
-- Individual line item pricing in a supplier's bid submission.
-- email_id: '' for portal submissions | source email ID for extraction submissions.
--   On re-save of the same email, only rows with that email_id are replaced;
--   items from other emails accumulate untouched.
CREATE TABLE IF NOT EXISTS bid_line_items (
    id                  TEXT        PRIMARY KEY,
    bid_id              TEXT        NOT NULL REFERENCES bids(id) ON DELETE CASCADE,
    rfp_line_id         TEXT        REFERENCES rfp_line_items(id) ON DELETE SET NULL,
    product_id          TEXT        REFERENCES products(id) ON DELETE SET NULL,  -- nullable
    item_no             TEXT        DEFAULT '',     -- matches rfp_line_items.bid_item
    line_number         INTEGER     DEFAULT 0,
    description         TEXT        DEFAULT '',
    unit_price          NUMERIC,
    case_price          NUMERIC,
    delivered_price     NUMERIC,
    fob_price           NUMERIC,
    allowance           NUMERIC,
    ptv_value           NUMERIC,
    total_line_amount   NUMERIC,
    dev_type            TEXT,                       -- 'ALLW' | 'DL' | NULL
    no_bid              BOOLEAN     NOT NULL DEFAULT false,
    notes               TEXT        DEFAULT '',
    custom_field_values JSONB       NOT NULL DEFAULT '{}',  -- portal custom fields per item
    email_id            TEXT        NOT NULL DEFAULT '',    -- '' = portal | '<id>' = extraction source
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS bid_line_items_bid_id_idx      ON bid_line_items (bid_id);
CREATE INDEX IF NOT EXISTS bid_line_items_rfp_line_id_idx ON bid_line_items (rfp_line_id);
-- Composite index for efficient DELETE WHERE bid_id=X AND email_id=Y on re-save.
CREATE INDEX IF NOT EXISTS bid_line_items_bid_email_idx   ON bid_line_items (bid_id, email_id);


-- ── 14. submission_messages ───────────────────────────────────────────────────
-- Portal two-way conversation thread messages (supplier ↔ Bid COE).
CREATE TABLE IF NOT EXISTS submission_messages (
    id               TEXT        PRIMARY KEY,
    bid_id           TEXT        NOT NULL REFERENCES bids(id) ON DELETE CASCADE,
    direction        TEXT        NOT NULL,          -- 'inbound' (supplier) | 'outbound' (Bid COE)
    from_address     TEXT        NOT NULL,
    from_name        TEXT        DEFAULT '',
    body             TEXT        NOT NULL DEFAULT '',
    attachments      JSONB       NOT NULL DEFAULT '[]',
    message_ts       TIMESTAMPTZ NOT NULL DEFAULT now(),
    read_by_bid_coe  BOOLEAN     NOT NULL DEFAULT false,
    read_by_supplier BOOLEAN     NOT NULL DEFAULT false
);

CREATE INDEX IF NOT EXISTS submission_messages_bid_id_idx ON submission_messages (bid_id);
CREATE INDEX IF NOT EXISTS submission_messages_ts_idx     ON submission_messages (message_ts DESC);


-- ── 15. supplier_vectors ──────────────────────────────────────────────────────
-- Supplier profile embeddings for RAG-based auto-populate recommendations.
-- Populated by POST/PATCH /api/suppliers (background task) and scripts/index_suppliers.py.
CREATE TABLE IF NOT EXISTS supplier_vectors (
    supplier_id   TEXT        PRIMARY KEY,
    embedding     vector(768),          -- Google text-embedding-004 output dimensions
    supplier_json JSONB       NOT NULL, -- snapshot of supplier record at index time
    indexed_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- IVFFlat approximate nearest-neighbour index (cosine distance).
-- lists=10 is appropriate for up to ~1000 suppliers.
CREATE INDEX IF NOT EXISTS supplier_vectors_embedding_idx
    ON supplier_vectors
    USING ivfflat (embedding vector_cosine_ops)
    WITH (lists = 10);


-- ── 16. document_text ────────────────────────────────────────────────────────
-- Extracted-text cache keyed by md5(content).
-- Currently disabled (2026-07-09) — caching code commented out in document_text.py.
-- Re-enable by uncommenting the cache read/write paths in services/document_text.py.
CREATE TABLE IF NOT EXISTS document_text (
    doc_key      TEXT        PRIMARY KEY,   -- md5 hex of the document bytes
    text         TEXT        NOT NULL,
    char_count   INTEGER     NOT NULL DEFAULT 0,
    format       TEXT,
    extracted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);


-- ── 17. document_vectors ─────────────────────────────────────────────────────
-- Document chunk embeddings for RAG over uploaded RFP documents.
-- Live — triggered on document upload via asyncio.ensure_future(index_document_background(...))
-- in bids.py (POST /api/bids) and documents.py (POST /api/documents/upload).
CREATE TABLE IF NOT EXISTS document_vectors (
    id            TEXT        PRIMARY KEY,  -- {gcs_uri}::chunk:{index}
    gcs_uri       TEXT        NOT NULL,
    bucket        TEXT        NOT NULL,
    object_name   TEXT        NOT NULL,
    file_name     TEXT        NOT NULL,
    file_type     TEXT,
    bid_id        TEXT,
    document_id   TEXT,
    document_type TEXT,
    region        TEXT,
    segment       TEXT,
    customer_name TEXT,
    opco          TEXT,
    content_type  TEXT,
    size_bytes    BIGINT,
    gcs_updated   TIMESTAMPTZ,
    chunk_index   INTEGER     NOT NULL DEFAULT 0,
    chunk_text    TEXT        NOT NULL,
    embedding     VECTOR(768) NOT NULL,     -- Google text-embedding-004 output dimensions
    metadata      JSONB       NOT NULL DEFAULT '{}',
    indexed_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS document_vectors_emb_idx
    ON document_vectors USING ivfflat (embedding vector_cosine_ops) WITH (lists = 20);
CREATE INDEX IF NOT EXISTS document_vectors_gcs_idx     ON document_vectors (gcs_uri);
CREATE INDEX IF NOT EXISTS document_vectors_bid_idx     ON document_vectors (bid_id);
CREATE INDEX IF NOT EXISTS document_vectors_doc_idx     ON document_vectors (document_id);
CREATE INDEX IF NOT EXISTS document_vectors_region_idx  ON document_vectors (region);
CREATE INDEX IF NOT EXISTS document_vectors_segment_idx ON document_vectors (segment);


-- ================================================================
-- Summary: 18 tables | 2 extensions
--
-- Fresh install: run this file once.
-- After running: execute scripts/seed_database.py to load initial data.
--
-- Note: this script does NOT backfill rfps.uploaded_files from the
-- documents table — that only applies when migrating an existing
-- deployment. For migrations, the individual migration scripts in
-- this directory's git history serve as the audit trail.
-- ================================================================
