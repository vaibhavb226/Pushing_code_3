from __future__ import annotations

import os
import re
from pathlib import Path

from constants import MIME_MAP


def format_file_size(size_bytes: int) -> str:
    """Human-readable file size string."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    if size_bytes < 1024 ** 2:
        return f"{size_bytes / 1024:.1f} KB"
    return f"{size_bytes / 1024 ** 2:.1f} MB"


def safe_filename(name: str) -> str:
    """Strip directory components and dangerous characters from a filename."""
    name = Path(name).name  # strips all directory components
    name = re.sub(r"[^\w\s\-()\[\].]", "", name)  # keep word chars, spaces, hyphens, parens, brackets, dots
    name = name.strip()
    return name or "upload"


def guess_extension(mime_type: str, original_name: str = "") -> str:
    """Return file extension for a MIME type, falling back to original name's suffix."""
    ext = MIME_MAP.get(mime_type, "")
    if not ext and original_name:
        ext = Path(original_name).suffix
    return ext or ".bin"


def file_size_kb(path: str | Path) -> int:
    try:
        return os.path.getsize(path) // 1024
    except OSError:
        return 0
