"""
Startup backfill coroutines — mirrors the 4 backfill functions in backend/server.js.

All run as asyncio.create_task() in main.py lifespan — non-blocking.
"""
from __future__ import annotations

import os
from datetime import date
from pathlib import Path
from typing import Any

import structlog

log = structlog.get_logger()


async def backfill_uploaded_files() -> None:
    """
    Populate bid.uploadedFiles[] from bid.uploadedRfpPath / bid.uploadedItemListPath
    for bids that have file paths stored but an empty uploadedFiles array.
    Mirrors backfillUploadedFiles() in server.js.
    """
    from dependencies import UPLOADS_DIR, get_bids_repo

    repo = get_bids_repo()
    bids = await repo.load()
    changed_bids: list[dict[str, Any]] = []

    for bid in bids:
        if bid.get("uploadedFiles"):
            continue

        files: list[dict[str, Any]] = []
        for field, doc_type in [
            ("uploadedRfpPath", "RFP"),
            ("uploadedItemListPath", "Item List"),
        ]:
            path_str = bid.get(field, "")
            if not path_str:
                continue
            # Path might be absolute or just a filename
            p = Path(path_str)
            if not p.is_absolute():
                p = UPLOADS_DIR / p.name
            if p.exists():
                files.append({
                    "id": f"FILE-{bid['id']}-{doc_type.replace(' ', '')}",
                    "name": p.name,
                    "type": doc_type,
                    "mimetype": _guess_mime(p.name),
                    "size": _fmt_size(p.stat().st_size),
                    "uploadedAt": date.today().isoformat(),
                    "path": f"uploads/{p.name}",
                    "notes": "",
                })

        if files:
            bid["uploadedFiles"] = files
            changed_bids.append(bid)

    for bid in changed_bids:
        bid_id_val = bid["id"]
        bid_snap = dict(bid)
        await repo.update_one(
            lambda b, _id=bid_id_val: b.get("id") == _id,
            lambda _b, _snap=bid_snap: _snap,
        )
    if changed_bids:
        log.info("backfill.uploaded_files", updated=len(changed_bids))


async def backfill_solicited_suppliers() -> None:
    """
    For bids that have suppliersContacted > 0 but an empty solicitedSuppliers array,
    add placeholder entries from the outbound solicitation emails in emailThreads.json.
    Mirrors backfillSolicitedSuppliers() in server.js.
    Only adds suppliers whose email address actually appeared in a BCC outbound email.
    """
    from dependencies import get_bids_repo, get_email_threads_repo, get_suppliers_repo

    bids_repo = get_bids_repo()
    threads_repo = get_email_threads_repo()
    suppliers_repo = get_suppliers_repo()

    bids = await bids_repo.load()
    threads = await threads_repo.load()
    suppliers = await suppliers_repo.load()
    email_to_supplier = {s.get("contact", "").lower(): s for s in suppliers}

    changed_bids: list[dict[str, Any]] = []
    for bid in bids:
        if bid.get("solicitedSuppliers"):
            continue

        bid_id = bid.get("id", "")
        # Find outbound emails for this bid
        outbound = [
            t for t in threads
            if t.get("bidId") == bid_id and t.get("direction") == "outbound"
        ]

        bcc_emails: set[str] = set()
        for email in outbound:
            for addr in email.get("bcc", []):
                bcc_emails.add(addr.lower())

        if not bcc_emails:
            continue

        solicited_date = outbound[0].get("date", date.today().isoformat())[:10]
        entries: list[dict[str, Any]] = []

        for addr in bcc_emails:
            sup = email_to_supplier.get(addr)
            if sup:
                entries.append({
                    "supplierId": sup.get("id"),
                    "supplierName": sup.get("name"),
                    "email": addr,
                    "status": "Awaiting",
                    "solicitedDate": solicited_date,
                    "lastActivity": solicited_date,
                    "awardNotificationSent": False,
                    "awardNotificationSentAt": None,
                })

        if entries:
            bid["solicitedSuppliers"] = entries
            bid["lastSolicitationDate"] = solicited_date
            changed_bids.append(bid)

    for bid in changed_bids:
        bid_id_val = bid["id"]
        bid_snap = dict(bid)
        await bids_repo.update_one(
            lambda b, _id=bid_id_val: b.get("id") == _id,
            lambda _b, _snap=bid_snap: _snap,
        )
    if changed_bids:
        log.info("backfill.solicited_suppliers", updated=len(changed_bids))


async def backfill_email_attachments() -> None:
    """
    For email records that have attachmentNames[] (legacy) but no attachments[],
    convert to the new attachments[] format with path references.
    """
    from dependencies import UPLOADS_DIR, get_email_threads_repo

    repo = get_email_threads_repo()
    threads = await repo.load()
    changed_threads: list[dict[str, Any]] = []

    for thread in threads:
        if thread.get("attachments") or not thread.get("attachmentNames"):
            continue
        names: list[str] = thread.get("attachmentNames", [])
        thread["attachments"] = [
            {"name": n, "path": f"uploads/{n}"}
            for n in names
            if (UPLOADS_DIR / n).exists()
        ]
        changed_threads.append(thread)

    for thread in changed_threads:
        thread_id_val = thread["id"]
        thread_snap = dict(thread)
        await repo.update_one(
            lambda t, _id=thread_id_val: t.get("id") == _id,
            lambda _t, _snap=thread_snap: _snap,
        )
    if changed_threads:
        log.info("backfill.email_attachments", updated=len(changed_threads))


async def backfill_line_items_from_files() -> None:
    """
    For bids with uploaded files but 0 line items, auto-parse from the best available file.
    Excel takes priority over PDF (same logic as autoParseLineItems).
    Mirrors backfillLineItemsFromFiles() in server.js.
    """
    from dependencies import UPLOADS_DIR, get_bids_repo, get_line_items_repo
    from services.line_item_parser import auto_parse_line_items

    bids_repo = get_bids_repo()
    items_repo = get_line_items_repo()

    bids = await bids_repo.load()
    all_items = await items_repo.load()
    bid_ids_with_items = {it.get("bidId") for it in all_items}

    for bid in bids:
        bid_id = bid.get("id", "")
        if bid_id in bid_ids_with_items:
            continue

        uploaded_files = bid.get("uploadedFiles", [])
        if not uploaded_files:
            continue

        # Find the best file to parse (Excel first, then PDF)
        best_file: dict[str, Any] | None = None
        for f in uploaded_files:
            if f.get("type") in ("Item List", "RFP", "RFP Document"):
                name = f.get("name", "")
                if name.lower().endswith((".xlsx", ".xls", ".csv")):
                    best_file = f
                    break
        if not best_file:
            for f in uploaded_files:
                if f.get("type") in ("Item List", "RFP", "RFP Document"):
                    if f.get("name", "").lower().endswith(".pdf"):
                        best_file = f
                        break

        if not best_file:
            continue

        path_str = best_file.get("path", "")
        p = Path(path_str) if Path(path_str).is_absolute() else UPLOADS_DIR / Path(path_str).name
        if not p.exists() or not p.is_file():
            continue

        try:
            await auto_parse_line_items(bid_id, best_file.get("name", ""), str(p))
            log.info("backfill.line_items_parsed", bid_id=bid_id, file=p.name)
        except Exception as exc:
            log.warning("backfill.line_items_failed", bid_id=bid_id, error=str(exc))


# ── Helpers ────────────────────────────────────────────────────────────────────

def _guess_mime(filename: str) -> str:
    ext = filename.lower().rsplit(".", 1)[-1]
    return {
        "pdf": "application/pdf",
        "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "xls": "application/vnd.ms-excel",
        "csv": "text/csv",
        "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    }.get(ext, "application/octet-stream")


def _fmt_size(size_bytes: int) -> str:
    if size_bytes < 1024:
        return f"{size_bytes} B"
    if size_bytes < 1024 * 1024:
        return f"{size_bytes // 1024} KB"
    return f"{size_bytes // (1024 * 1024)} MB"
