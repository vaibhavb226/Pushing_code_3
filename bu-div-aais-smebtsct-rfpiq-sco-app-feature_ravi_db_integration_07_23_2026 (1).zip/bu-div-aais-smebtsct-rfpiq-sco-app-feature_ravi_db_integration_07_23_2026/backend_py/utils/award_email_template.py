"""
Award email template builders.
Mirrors backend/utils/awardEmailTemplate.js exactly.
"""
from __future__ import annotations


def build_award_email_subject(bid: dict) -> str:
    customer = bid.get("customer", "Customer")
    bid_id = bid.get("id", "")
    return f"Award Notification — {customer} | {bid_id}"


def build_award_email_body(
    *,
    supplier_name: str,
    customer_name: str,
    bid_id: str,
    contract_start: str | None = None,
    contract_end: str | None = None,
) -> str:
    dates_section = ""
    if contract_start or contract_end:
        start = contract_start or "TBD"
        end = contract_end or "TBD"
        dates_section = f"\nContract Period: {start} – {end}\n"

    return f"""Dear {supplier_name},

We are pleased to inform you that your pricing submission for the following bid has been selected:

Customer: {customer_name}
Bid ID: {bid_id}{dates_section}

This award is subject to final contract execution and compliance verification.

Please do not hesitate to reach out if you have any questions.

Thank you for your participation.

Regards,
FoodCorp Bid COE
"""
