from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path

from pydantic import SecretStr, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_ENV_FILE = Path(__file__).parent / ".env"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Server ────────────────────────────────────────────────
    port: int = 3001
    node_env: str = "development"

    # ── LLM provider ─────────────────────────────────────────
    llm_provider: str = "vertexai"          # anthropic | vertexai

    # Anthropic
    anthropic_api_key: SecretStr = SecretStr("")
    anthropic_model: str = "claude-sonnet-4-20250514"

    # Google Vertex AI (IAM-based authentication — no API key needed)
    # Auth order: GOOGLE_APPLICATION_CREDENTIALS → gcloud ADC → Workload Identity
    # Set LLM_PROVIDER=vertexai to use this provider
    vertex_model: str = "gemini-2.5-flash"
    gcp_project: str = ""                          # GCP project ID (required for Vertex AI)
    gcp_location: str = "us-central1"              # GCP region
    google_application_credentials: str = ""       # path to service account JSON; empty = gcloud ADC

    # ── Email — Microsoft Graph (only provider) ────────────────
    ms_tenant_id: str = ""
    ms_client_id: str = ""
    ms_client_secret: SecretStr = SecretStr("")
    ms_mailbox_user_id: str = ""            # UPN of mailbox e.g. bids@foodcorp.com

    # Inbox poller — incremental high-water mark (see services/email_poller.py)
    poll_lookback_hours: int = 72   # cold-start window when no pollState.json exists yet
    max_lookback_days: int = 30     # clamp so a stale high-water mark never triggers a full scan

    # ── PostgreSQL / pgvector (supplier RAG recommendations) ─────────────────
    # Connect via PSC (Private Service Connect) endpoint — standard TCP, no connector.
    # Leave db_host empty to disable vector search (falls back to rule-based matching).
    db_host: str = ""           # PSC endpoint IP, e.g. "10.0.0.5"
    db_port: int = 5432
    db_name: str = "foodcorp_rfp"
    db_user: str = ""
    db_pass: SecretStr = SecretStr("")

    # Kept for backward-compat reference; no longer used at runtime.
    cloud_sql_connection_name: str = ""

    @property
    def pg_dsn(self) -> str:
        """SQLAlchemy async DSN for the PSC PostgreSQL endpoint."""
        pwd = self.db_pass.get_secret_value() if self.db_pass else ""
        return (
            f"postgresql+asyncpg://{self.db_user}:{pwd}"
            f"@{self.db_host}:{self.db_port}/{self.db_name}"
            f"?ssl=require"
        )

    # ── GCS document storage ─────────────────────────────────
    # When set, uploaded documents are stored in this GCS bucket instead of local disk.
    # Leave empty to use local UPLOADS_DIR (local dev fallback).
    gcs_bucket: str = ""

    # ── Web Search (LangSearch — free, no subscription) ───────
    # Get API key at https://langsearch.com/dashboard
    # Set LANGSEARCH_API_KEY env var. Leave empty to disable (endpoints return 503).
    langsearch_api_key: SecretStr = SecretStr("")
    # ── File upload / parsing limits ──────────────────────────
    # Hard cap on incoming file size (bytes). Requests exceeding this return 413.
    max_upload_bytes: int = 10 * 1024 * 1024   # 10 MB
    # PDF read cap (characters). If set, the PDF text is read up to this many chars;
    # if left EMPTY in .env (→ None here), the ENTIRE PDF is read. Defaults to 10k when
    # the key is absent from .env.
    pdf_char_limit: int | None = 10_000
    # NOTE: excel_char_limit is no longer used for the item read — Excel line items are
    # now read deterministically row-by-row (no char truncation). Kept for backward compat.
    excel_char_limit: int = 50_000

    # Max output tokens — ceiling passed to every extraction LLM call.
    # Gemini 2.5 Flash (Vertex AI default): 65_536.
    # Anthropic claude-sonnet-4 (standard): 16_000. Set LLM_MAX_TOKENS=16000 in .env when using that provider.
    llm_max_tokens: int = 65_536

    # Determinism settings for pricing extraction calls only.
    # temperature=0 + top_k=1 = greedy decoding (most deterministic).
    # seed is Vertex AI only (best-effort ~85–95% reproducibility); ignored by Anthropic.
    # Do not change these for extraction — variability causes inconsistent confidence scores.
    llm_extraction_temperature: float = 0.0
    llm_extraction_top_p: float = 1.0
    llm_extraction_top_k: int = 1
    llm_extraction_seed: int | None = None

    # ── Frontend / portal ─────────────────────────────────────
    portal_base_url: str = "http://rfp-aiq.supplier.exlservice.com:5173"
    frontend_urls: str = "http://localhost:5173,http://localhost:5174,http://localhost:4173"

    @property
    def allowed_origins(self) -> list[str]:
        base = [o.strip() for o in self.frontend_urls.split(",") if o.strip()]
        # Always include portal URL as well
        if self.portal_base_url not in base:
            base.append(self.portal_base_url)
        return base

    @property
    def is_production(self) -> bool:
        return self.node_env == "production"

    @field_validator("pdf_char_limit", mode="before")
    @classmethod
    def _blank_pdf_limit_means_unlimited(cls, v: object) -> object:
        """An empty value in .env (e.g. `PDF_CHAR_LIMIT=`) means 'read the entire PDF'."""
        if v is None or (isinstance(v, str) and v.strip() == ""):
            return None
        return v


@lru_cache
def get_settings() -> Settings:
    # Bootstrap: read GCP_PROJECT + credentials directly from shell env or .env
    # so we can reach Secret Manager before the full Settings() object exists.
    from dotenv import dotenv_values
    bootstrap = dotenv_values(_ENV_FILE) if _ENV_FILE.exists() else {}

    project = os.environ.get("GCP_PROJECT") or bootstrap.get("GCP_PROJECT", "")

    # Ensure GOOGLE_APPLICATION_CREDENTIALS is set before the SM client is created
    gac = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS") or bootstrap.get("GOOGLE_APPLICATION_CREDENTIALS", "")
    if gac:
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = gac

    if project:
        from services.secret_manager import load_gcp_secrets_to_env
        load_gcp_secrets_to_env(project)

    return Settings()
