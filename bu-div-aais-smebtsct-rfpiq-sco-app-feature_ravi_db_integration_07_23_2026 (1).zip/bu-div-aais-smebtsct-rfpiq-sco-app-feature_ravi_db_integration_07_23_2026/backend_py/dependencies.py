"""
Dependency factories for FastAPI's Depends() injection system.

All repositories and services are instantiated here. Routers import
get_*_repo / get_llm_service and declare them as Depends() parameters —
they never reference JsonRepository or DbRepository directly.

Backend selection:
  If settings.db_host is set → return a PG repo (asyncpg pool-backed).
  Otherwise → return the module-level JSON singleton (local dev fallback).

PG repo instances are stateless (the pool is the singleton), so creating a
new instance per request is cheap.
"""
from __future__ import annotations

from pathlib import Path

from config import get_settings
from repositories.bids_repo import BidsRepository
from repositories.documents_repo import DocumentsRepository
from repositories.email_threads_repo import EmailThreadsRepository
from repositories.line_items_repo import LineItemsRepository
from repositories.portal_templates_repo import PortalTemplatesRepository
from repositories.pricing_repo import PricingRepository
from repositories.submissions_repo import SubmissionsRepository
from repositories.suppliers_repo import SuppliersRepository
from repositories.unmatched_emails_repo import UnmatchedEmailsRepository

BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
UPLOADS_DIR = BASE_DIR / "uploads"
LOGS_DIR = BASE_DIR / "logs"


# ── JSON repository singletons (used when DB_HOST is not configured) ──────────

_bids = BidsRepository(DATA_DIR / "bids.json")
_line_items = LineItemsRepository(DATA_DIR / "lineItems.json")
_email_threads = EmailThreadsRepository(DATA_DIR / "emailThreads.json")
_suppliers = SuppliersRepository(DATA_DIR / "suppliers.json")
_documents = DocumentsRepository(DATA_DIR / "documents.json")
_pricing = PricingRepository(DATA_DIR / "pricingData.json")
_submissions = SubmissionsRepository(DATA_DIR / "submissions.json")
_portal_templates = PortalTemplatesRepository(DATA_DIR / "portalTemplates.json")
_unmatched = UnmatchedEmailsRepository(DATA_DIR / "unmatchedEmails.json")


# ── Repository factories ──────────────────────────────────────────────────────
# Each factory returns a PG repo when DB_HOST is configured, falling back to
# the JSON singleton for local dev (DB_HOST not set).

def get_bids_repo():
    if get_settings().db_host:
        from repositories.pg_bids_repo import PgBidsRepository
        return PgBidsRepository()
    return _bids


def get_line_items_repo():
    if get_settings().db_host:
        from repositories.pg_line_items_repo import PgLineItemsRepository
        return PgLineItemsRepository()
    return _line_items


def get_email_threads_repo():
    if get_settings().db_host:
        from repositories.pg_email_threads_repo import PgEmailThreadsRepository
        return PgEmailThreadsRepository()
    return _email_threads


def get_suppliers_repo():
    if get_settings().db_host:
        from repositories.pg_suppliers_repo import PgSuppliersRepository
        return PgSuppliersRepository()
    return _suppliers


def get_documents_repo():
    if get_settings().db_host:
        from repositories.pg_documents_repo import PgDocumentsRepository
        return PgDocumentsRepository()
    return _documents


def get_pricing_repo():
    return _pricing


def get_submissions_repo():
    if get_settings().db_host:
        from repositories.pg_submissions_repo import PgSubmissionsRepository
        return PgSubmissionsRepository()
    return _submissions


def get_portal_templates_repo():
    if get_settings().db_host:
        from repositories.pg_portal_templates_repo import PgPortalTemplatesRepository
        return PgPortalTemplatesRepository()
    return _portal_templates


def get_unmatched_repo():
    if get_settings().db_host:
        from repositories.pg_unmatched_emails_repo import PgUnmatchedEmailsRepository
        return PgUnmatchedEmailsRepository()
    return _unmatched


def get_customers_repo():
    # Always PG — no JSON fallback; all customer data lives in Cloud SQL
    if not get_settings().db_host:
        from fastapi import HTTPException
        raise HTTPException(
            status_code=503,
            detail="Customer endpoints require a database connection (DB_HOST not configured).",
        )
    from repositories.pg_customers_repo import PgCustomersRepository
    return PgCustomersRepository()


# ── GCS client ────────────────────────────────────────────────────────────────
_gcs_client = None


def get_gcs_client(settings=None):
    """Return (or lazily create) the shared GCS storage.Client.

    Returns None when GCS_BUCKET is not configured (local-disk fallback mode).
    Uses ADC (GOOGLE_APPLICATION_CREDENTIALS → gcloud → Workload Identity),
    the same credential chain already used by Vertex AI.
    """
    global _gcs_client
    if settings is None:
        settings = get_settings()
    if not settings.gcs_bucket:
        return None
    if _gcs_client is None:
        try:
            from google.cloud import storage
            _gcs_client = storage.Client(project=settings.gcp_project or None)
        except Exception as exc:
            import logging
            logging.getLogger(__name__).error("gcs.client_failed: %s", exc)
    return _gcs_client


# ── LLM service ───────────────────────────────────────────────────────────────
_llm_service = None  # Lazily initialised on first call


def get_llm_service():
    global _llm_service
    if _llm_service is None:
        from services.llm.factory import build_llm_service
        _llm_service = build_llm_service(get_settings())
    return _llm_service


# ── Email service ─────────────────────────────────────────────────────────────
_email_service = None


def get_email_service():
    global _email_service
    if _email_service is None:
        from services.email.factory import build_email_service
        _email_service = build_email_service(get_settings())
    return _email_service
