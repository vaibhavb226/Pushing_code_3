"""
GCS Document Embedder — Cloud Run ready

Fetches documents from Google Cloud Storage, converts to text embeddings via
Vertex AI text-embedding-004, and upserts into a PostgreSQL pgvector table.

GCS path rules
--------------
  gs://bucket/prefix/          → embed every supported file under that prefix
  gs://bucket/path/to/file.pdf → embed only that single file

Supported file types: .pdf  .xlsx  .xls  .docx  .txt  .csv

Usage — CLI (Cloud Run Job or local):
    python main.py --path gs://my-bucket/rfp-docs/
    python main.py --path gs://my-bucket/rfp-docs/contract.pdf
    python main.py --path gs://my-bucket/rfp-docs/ --dry-run
    python main.py --path gs://my-bucket/rfp-docs/ --metadata '{"bid_id":"B2600042"}'

Usage — FastAPI service (Cloud Run Service / Eventarc):
    uvicorn main:app --host 0.0.0.0 --port 8080

    GET  /health
    POST /embed      { "path": "gs://...", "dry_run": false, "metadata": {} }
    POST /events/gcs  (Eventarc CloudEvent — GCS object.finalized)

Required environment variables:
    GCP_PROJECT    GCP project ID (Vertex AI + GCS)
    DB_URL         postgresql+asyncpg://user:pass@<PSC_IP>:5432/db  ← explicit DSN
                   OR set DB_HOST + DB_USER + DB_PASS + DB_NAME separately
    GCP_LOCATION   (optional, default: us-central1)
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

load_dotenv(override=True)

# ── Settings ──────────────────────────────────────────────────────────────────

GCP_PROJECT    = os.environ.get("GCP_PROJECT", "")
GCP_LOCATION   = os.environ.get("GCP_LOCATION", "us-central1")

EMBEDDING_MODEL = os.environ.get("EMBEDDING_MODEL", "text-embedding-004")
EMBEDDING_DIMS  = int(os.environ.get("EMBEDDING_DIMS", "768"))
CHUNK_SIZE      = int(os.environ.get("CHUNK_SIZE", "800"))
CHUNK_OVERLAP   = int(os.environ.get("CHUNK_OVERLAP", "100"))
BATCH_SIZE      = int(os.environ.get("BATCH_SIZE", "20"))

DB_URL  = os.environ.get("DB_URL", "")   # e.g. postgresql+asyncpg://user:pass@<PSC_IP>:5432/db
DB_NAME = os.environ.get("DB_NAME", "postgres")
DB_USER = os.environ.get("DB_USER", "")
DB_PASS = os.environ.get("DB_PASS", "")
DB_HOST = os.environ.get("DB_HOST", "")
DB_PORT = os.environ.get("DB_PORT", "5432")

SUPPORTED_EXTENSIONS = {".pdf", ".xlsx", ".xls", ".docx", ".txt", ".csv"}


# ── GCS helpers ───────────────────────────────────────────────────────────────

def parse_gcs_uri(uri: str) -> tuple[str, str]:
    """Return (bucket_name, object_or_prefix) from a gs:// URI."""
    if not uri.startswith("gs://"):
        raise ValueError(f"Expected a gs:// URI, got: {uri!r}")
    remainder = uri[5:]
    parts = remainder.split("/", 1)
    bucket = parts[0]
    obj_or_prefix = parts[1] if len(parts) > 1 else ""
    return bucket, obj_or_prefix


def list_gcs_objects(bucket_name: str, prefix: str) -> list[dict]:
    """Return metadata dicts for every supported file under a GCS prefix."""
    from google.cloud import storage  # type: ignore[import-untyped]

    client = storage.Client(project=GCP_PROJECT or None)
    blobs = []
    for blob in client.list_blobs(bucket_name, prefix=prefix):
        if Path(blob.name).suffix.lower() not in SUPPORTED_EXTENSIONS:
            continue
        blobs.append({
            "bucket":       bucket_name,
            "name":         blob.name,
            "size":         blob.size,
            "content_type": blob.content_type,
            "updated":      blob.updated,
            "metadata":     blob.metadata or {},
        })
    return blobs


def get_gcs_blob_info(bucket_name: str, object_name: str) -> dict:
    """Return metadata dict for a single GCS blob. Raises FileNotFoundError if absent."""
    from google.cloud import storage  # type: ignore[import-untyped]

    client = storage.Client(project=GCP_PROJECT or None)
    blob = client.bucket(bucket_name).get_blob(object_name)
    if blob is None:
        raise FileNotFoundError(f"GCS object not found: gs://{bucket_name}/{object_name}")
    return {
        "bucket":       bucket_name,
        "name":         object_name,
        "size":         blob.size,
        "content_type": blob.content_type,
        "updated":      blob.updated,
        "metadata":     blob.metadata or {},
    }


def download_gcs_object(bucket_name: str, object_name: str, dest: Path) -> None:
    """Download a GCS object to a local path."""
    from google.cloud import storage  # type: ignore[import-untyped]

    client = storage.Client(project=GCP_PROJECT or None)
    client.bucket(bucket_name).blob(object_name).download_to_filename(str(dest))


# ── Text extraction ───────────────────────────────────────────────────────────

def _extract_pdf(path: Path) -> str:
    try:
        import fitz  # type: ignore[import-untyped]  # PyMuPDF
        doc = fitz.open(str(path))
        text = "\n".join(page.get_text() for page in doc)
        doc.close()
        return text.strip()
    except Exception as exc:
        print(f"    ⚠  PDF extract failed: {exc}")
        return ""


def _extract_excel(path: Path) -> str:
    try:
        import openpyxl  # type: ignore[import-untyped]
        wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
        rows: list[str] = []
        for sheet in wb.worksheets:
            if sheet.sheet_state != 'visible':
                continue
            rows.append(f"[Sheet: {sheet.title}]")
            for row in sheet.iter_rows(values_only=True):
                cells = " | ".join(str(v) for v in row if v is not None)
                if cells.strip():
                    rows.append(cells)
        wb.close()
        return "\n".join(rows).strip()
    except Exception as exc:
        print(f"    ⚠  Excel extract failed: {exc}")
        return ""


def _extract_docx(path: Path) -> str:
    try:
        from docx import Document  # type: ignore[import-untyped]  # python-docx
        doc = Document(str(path))
        return "\n".join(p.text for p in doc.paragraphs if p.text.strip()).strip()
    except Exception as exc:
        print(f"    ⚠  DOCX extract failed: {exc}")
        return ""


def extract_text(file_path: Path) -> str:
    """Dispatch to the appropriate extractor based on file extension."""
    suffix = file_path.suffix.lower()
    if suffix == ".pdf":
        return _extract_pdf(file_path)
    if suffix in (".xlsx", ".xls"):
        return _extract_excel(file_path)
    if suffix == ".docx":
        return _extract_docx(file_path)
    # .txt, .csv — plain read
    try:
        return file_path.read_text(encoding="utf-8", errors="replace").strip()
    except Exception as exc:
        print(f"    ⚠  Text read failed: {exc}")
        return ""


# ── Chunking ──────────────────────────────────────────────────────────────────

def chunk_text(text: str) -> list[str]:
    """Split text into overlapping fixed-size chunks."""
    text = text.strip()
    if not text:
        return []
    if len(text) <= CHUNK_SIZE:
        return [text]
    chunks: list[str] = []
    start = 0
    while start < len(text):
        chunk = text[start : start + CHUNK_SIZE].strip()
        if chunk:
            chunks.append(chunk)
        start += CHUNK_SIZE - CHUNK_OVERLAP
    return chunks


# ── Embedding ─────────────────────────────────────────────────────────────────

_genai_client: Any = None


async def _get_embed_client() -> Any:
    global _genai_client
    if _genai_client is None:
        from google import genai  # type: ignore[import-untyped]
        _genai_client = genai.Client(
            vertexai=True,
            project=GCP_PROJECT,
            location=GCP_LOCATION,
        )
    return _genai_client


async def embed_batch(texts: list[str]) -> list[list[float]]:
    """Embed a batch of texts; returns one EMBEDDING_DIMS-dim vector per input."""
    from google.genai import types as gt  # type: ignore[import-untyped]

    client = await _get_embed_client()
    result = await client.aio.models.embed_content(
        model=EMBEDDING_MODEL,
        contents=texts,
        config=gt.EmbedContentConfig(task_type="RETRIEVAL_DOCUMENT"),
    )
    return [e.values for e in result.embeddings]


# ── Database ──────────────────────────────────────────────────────────────────

_CREATE_TABLE_SQL = f"""
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS document_vectors (
    id            TEXT PRIMARY KEY,
    gcs_uri       TEXT        NOT NULL,
    bucket        TEXT        NOT NULL,
    object_name   TEXT        NOT NULL,
    file_name     TEXT        NOT NULL,
    file_type     TEXT,
    bid_id        TEXT,
    rfp_id        TEXT,
    document_id   TEXT,
    document_type TEXT,
    region        TEXT,
    segment       TEXT,
    customer_name TEXT,
    opco          TEXT,
    content_type  TEXT,
    size_bytes    BIGINT,
    gcs_updated   TIMESTAMPTZ,
    chunk_index   INTEGER     NOT NULL DEFAULT 0,
    chunk_text    TEXT        NOT NULL,
    embedding     VECTOR({EMBEDDING_DIMS}) NOT NULL,
    metadata      JSONB       NOT NULL DEFAULT '{{}}',
    indexed_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS document_vectors_emb_idx
    ON document_vectors USING ivfflat (embedding vector_cosine_ops) WITH (lists = 20);

CREATE INDEX IF NOT EXISTS document_vectors_gcs_idx
    ON document_vectors (gcs_uri);

CREATE INDEX IF NOT EXISTS document_vectors_bid_idx
    ON document_vectors (bid_id);

CREATE INDEX IF NOT EXISTS document_vectors_region_idx
    ON document_vectors (region);

CREATE INDEX IF NOT EXISTS document_vectors_segment_idx
    ON document_vectors (segment);
"""


def _effective_db_url() -> str:
    """Build the SQLAlchemy asyncpg DSN, preferring explicit DB_URL over component parts."""
    if DB_URL:
        return DB_URL
    if DB_HOST:
        return f"postgresql+asyncpg://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"
    raise RuntimeError(
        "No database configured. Set DB_URL or DB_HOST + DB_USER + DB_PASS + DB_NAME."
    )


_engine: Any = None  # sqlalchemy.ext.asyncio.AsyncEngine singleton


def _get_engine() -> Any:
    global _engine
    if _engine is None:
        from sqlalchemy.ext.asyncio import create_async_engine
        _engine = create_async_engine(
            _effective_db_url(),
            pool_size=3,
            max_overflow=2,
            pool_pre_ping=True,
            pool_recycle=1800,
            echo=False,
        )
    return _engine


def _vec(v: list[float]) -> str:
    return "[" + ",".join(str(x) for x in v) + "]"


async def ensure_table(conn: Any) -> None:
    from sqlalchemy import text
    for stmt in _CREATE_TABLE_SQL.strip().split(";"):
        s = stmt.strip()
        if s:
            await conn.execute(text(s))
    await conn.commit()


async def delete_chunks_for_uri(conn: Any, gcs_uri: str) -> int:
    """Delete all existing chunks for this GCS URI; returns count removed."""
    from sqlalchemy import text
    result = await conn.execute(
        text("DELETE FROM document_vectors WHERE gcs_uri = :uri"),
        {"uri": gcs_uri},
    )
    await conn.commit()
    return result.rowcount


async def upsert_chunk(
    conn: Any,
    *,
    row_id: str,
    gcs_uri: str,
    bucket: str,
    object_name: str,
    file_name: str,
    file_type: str,
    bid_id: str | None,
    rfp_id: str | None,
    document_id: str | None,
    document_type: str | None,
    region: str | None,
    segment: str | None,
    customer_name: str | None,
    opco: str | None,
    content_type: str | None,
    size_bytes: int | None,
    gcs_updated: Any,
    chunk_index: int,
    chunk_text: str,
    embedding: list[float],
    metadata: dict,
) -> None:
    from sqlalchemy import text
    await conn.execute(
        text("""
        INSERT INTO document_vectors
            (id, gcs_uri, bucket, object_name, file_name, file_type,
             bid_id, rfp_id, document_id, document_type,
             region, segment, customer_name, opco,
             content_type, size_bytes, gcs_updated,
             chunk_index, chunk_text, embedding, metadata, indexed_at)
        VALUES
            (:id, :gcs_uri, :bucket, :object_name, :file_name, :file_type,
             :bid_id, :rfp_id, :document_id, :document_type,
             :region, :segment, :customer_name, :opco,
             :content_type, :size_bytes, :gcs_updated,
             :chunk_index, :chunk_text, :embedding::vector, :metadata::jsonb, now())
        ON CONFLICT (id) DO UPDATE
            SET chunk_text    = EXCLUDED.chunk_text,
                embedding     = EXCLUDED.embedding,
                metadata      = EXCLUDED.metadata,
                bid_id        = EXCLUDED.bid_id,
                rfp_id        = EXCLUDED.rfp_id,
                document_type = EXCLUDED.document_type,
                region        = EXCLUDED.region,
                segment       = EXCLUDED.segment,
                customer_name = EXCLUDED.customer_name,
                opco          = EXCLUDED.opco,
                size_bytes    = EXCLUDED.size_bytes,
                gcs_updated   = EXCLUDED.gcs_updated,
                indexed_at    = now()
        """),
        {
            "id":            row_id,
            "gcs_uri":       gcs_uri,
            "bucket":        bucket,
            "object_name":   object_name,
            "file_name":     file_name,
            "file_type":     file_type,
            "bid_id":        bid_id or None,
            "rfp_id":        rfp_id or None,
            "document_id":   document_id or None,
            "document_type": document_type or None,
            "region":        region or None,
            "segment":       segment or None,
            "customer_name": customer_name or None,
            "opco":          opco or None,
            "content_type":  content_type,
            "size_bytes":    size_bytes,
            "gcs_updated":   gcs_updated,
            "chunk_index":   chunk_index,
            "chunk_text":    chunk_text,
            "embedding":     _vec(embedding),
            "metadata":      json.dumps(metadata),
        },
    )
    await conn.commit()


# ── Core per-file processing ──────────────────────────────────────────────────

async def process_blob(
    blob_info: dict,
    *,
    conn: Any,
    dry_run: bool,
    extra_metadata: dict | None,
) -> tuple[int, str]:
    """
    Process a single GCS blob.
    Returns (chunks_indexed, status) where status is "ok", "skipped:<reason>",
    or "error:<message>".
    """
    bucket      = blob_info["bucket"]
    object_name = blob_info["name"]
    gcs_uri     = f"gs://{bucket}/{object_name}"
    file_name   = Path(object_name).name
    file_type   = Path(object_name).suffix.lstrip(".").lower()

    # Extract bid context from GCS object custom metadata (set at upload time)
    gcs_meta      = blob_info.get("metadata") or {}
    extra         = extra_metadata or {}
    bid_id        = gcs_meta.get("bid-id")        or extra.get("bid_id")        or ""
    rfp_id        = gcs_meta.get("rfp-id")        or extra.get("rfp_id")        or bid_id
    document_id   = gcs_meta.get("document-id")   or extra.get("document_id")   or ""
    document_type = gcs_meta.get("document-type") or extra.get("document_type") or ""
    region        = gcs_meta.get("region")         or extra.get("region")        or ""
    segment       = gcs_meta.get("segment")        or extra.get("segment")       or ""
    customer_name = gcs_meta.get("customer-name")  or extra.get("customer_name") or ""
    opco          = gcs_meta.get("opco")           or extra.get("opco")          or ""

    with tempfile.TemporaryDirectory() as tmpdir:
        local_path = Path(tmpdir) / file_name

        try:
            download_gcs_object(bucket, object_name, local_path)
        except Exception as exc:
            return 0, f"error:download failed — {exc}"

        raw_text = extract_text(local_path)

    if not raw_text:
        return 0, "skipped:no text extracted"

    # Prepend a header so the embedding encodes document context, not just content
    header_parts: list[str] = [gcs_uri, file_type.upper()]
    for v in [bid_id, document_type, region, segment]:
        if v:
            header_parts.append(v)
    header = " | ".join(filter(None, header_parts))
    full_text = f"{header}\n\n{raw_text}" if header else raw_text

    chunks = chunk_text(full_text)
    if not chunks:
        return 0, "skipped:no chunks"

    print(f"    {len(chunks)} chunk(s) from {len(raw_text):,} chars")

    if dry_run:
        for i, c in enumerate(chunks[:3]):
            print(f"      chunk {i}: {c[:80]!r}...")
        if len(chunks) > 3:
            print(f"      ... ({len(chunks) - 3} more)")
        return len(chunks), "ok:dry-run"

    # Clean up stale chunks for this URI before inserting new ones
    removed = await delete_chunks_for_uri(conn, gcs_uri)
    if removed:
        print(f"    removed {removed} stale chunk(s)")

    # Build metadata stored alongside every chunk
    row_metadata: dict = {
        "gcs_uri":      gcs_uri,
        "size_bytes":   blob_info.get("size"),
        "content_type": blob_info.get("content_type"),
        "bid_id":       bid_id,
        "rfp_id":       rfp_id,
        "document_type": document_type,
        "region":       region,
        "segment":      segment,
    }

    indexed = 0
    for batch_start in range(0, len(chunks), BATCH_SIZE):
        batch = chunks[batch_start : batch_start + BATCH_SIZE]
        embeddings = await embed_batch(batch)

        for i, (chunk, emb) in enumerate(zip(batch, embeddings)):
            global_idx = batch_start + i
            await upsert_chunk(
                conn,
                row_id=f"{gcs_uri}::chunk:{global_idx}",
                gcs_uri=gcs_uri,
                bucket=bucket,
                object_name=object_name,
                file_name=file_name,
                file_type=file_type,
                bid_id=bid_id or None,
                rfp_id=rfp_id or None,
                document_id=document_id or None,
                document_type=document_type or None,
                region=region or None,
                segment=segment or None,
                customer_name=customer_name or None,
                opco=opco or None,
                content_type=blob_info.get("content_type"),
                size_bytes=blob_info.get("size"),
                gcs_updated=blob_info.get("updated"),
                chunk_index=global_idx,
                chunk_text=chunk,
                embedding=emb,
                metadata=row_metadata,
            )
            indexed += 1

    return indexed, "ok"


# ── Main orchestration ────────────────────────────────────────────────────────

async def run_embedding(
    gcs_path: str,
    *,
    dry_run: bool = False,
    extra_metadata: dict | None = None,
) -> dict:
    """
    Orchestrate embedding for a GCS path (directory prefix or single file).

    gcs_path examples:
        "gs://my-bucket/rfp-docs/"            → all supported files under prefix
        "gs://my-bucket/rfp-docs/plan.pdf"    → single file only

    Returns a summary dict with keys: processed, total_chunks, skipped, errors, dry_run.
    """
    bucket_name, obj_or_prefix = parse_gcs_uri(gcs_path)

    if gcs_path.endswith("/"):
        print(f"Listing objects in gs://{bucket_name}/{obj_or_prefix} ...")
        blobs = list_gcs_objects(bucket_name, obj_or_prefix)
        print(f"Found {len(blobs)} supported file(s)\n")
    else:
        blobs = [get_gcs_blob_info(bucket_name, obj_or_prefix)]
        print(f"Single file: {gcs_path}\n")

    if not blobs:
        print("No files to process.")
        return {"processed": 0, "total_chunks": 0, "skipped": 0, "errors": 0, "dry_run": dry_run}

    total_chunks = ok = skipped = errors = 0

    if dry_run:
        print("⚠   DRY RUN — no DB writes\n")
        for blob_info in blobs:
            gcs_uri   = f"gs://{blob_info['bucket']}/{blob_info['name']}"
            file_name = Path(blob_info["name"]).name
            size_kb   = f"{blob_info['size'] / 1024:.1f} KB" if blob_info.get("size") else "?"
            print(f"  {file_name}  ({size_kb})  {gcs_uri}")
            try:
                n, status = await process_blob(
                    blob_info, conn=None, dry_run=True, extra_metadata=extra_metadata
                )
                if status.startswith("ok"):
                    total_chunks += n
                    ok += 1
                else:
                    reason = status.split(":", 1)[-1] if ":" in status else status
                    print(f"    ⚠   Skipped — {reason}")
                    skipped += 1
            except Exception as exc:
                print(f"    ❌  ERROR: {exc}")
                errors += 1
            print()
    else:
        print("Connecting to database...")
        async with _get_engine().connect() as conn:
            print("✅  Connected\n")
            print("Ensuring document_vectors table...")
            await ensure_table(conn)
            print("✅  Table ready\n")

            for blob_info in blobs:
                gcs_uri   = f"gs://{blob_info['bucket']}/{blob_info['name']}"
                file_name = Path(blob_info["name"]).name
                size_kb   = f"{blob_info['size'] / 1024:.1f} KB" if blob_info.get("size") else "?"
                print(f"  {file_name}  ({size_kb})  {gcs_uri}")
                try:
                    n, status = await process_blob(
                        blob_info,
                        conn=conn,
                        dry_run=False,
                        extra_metadata=extra_metadata,
                    )
                    if status.startswith("ok"):
                        total_chunks += n
                        ok += 1
                        print(f"    ✅  {n} chunk(s) indexed")
                    else:
                        reason = status.split(":", 1)[-1] if ":" in status else status
                        print(f"    ⚠   Skipped — {reason}")
                        skipped += 1
                except Exception as exc:
                    print(f"    ❌  ERROR: {exc}")
                    errors += 1
                print()

    sep = "─" * 50
    print(sep)
    print(f"  Files processed  : {ok}")
    print(f"  Chunks indexed   : {total_chunks}")
    print(f"  Skipped          : {skipped}")
    print(f"  Errors           : {errors}")
    if dry_run:
        print("\n  ⚠   Dry run — nothing written to database.")
    elif errors == 0 and ok > 0:
        print("\n  ✅  All done. document_vectors is ready for RAG queries.")
    elif errors:
        print(f"\n  ⚠   {errors} file(s) failed — re-run to retry.")

    return {
        "processed":    ok,
        "total_chunks": total_chunks,
        "skipped":      skipped,
        "errors":       errors,
        "dry_run":      dry_run,
    }


# ── FastAPI app (Cloud Run Service / Eventarc) ────────────────────────────────

from fastapi import FastAPI, HTTPException, Request  # noqa: E402
from pydantic import BaseModel  # noqa: E402

app = FastAPI(title="GCS Document Embedder", version="1.0.0")


class EmbedRequest(BaseModel):
    path: str
    dry_run: bool = False
    metadata: dict = {}


class EmbedResponse(BaseModel):
    processed: int
    total_chunks: int
    skipped: int
    errors: int
    dry_run: bool


@app.get("/health")
async def health() -> dict:
    return {"status": "ok"}


@app.post("/embed", response_model=EmbedResponse)
async def embed(req: EmbedRequest) -> EmbedResponse:
    """
    Trigger embedding for a GCS path.

    Request body:
        path      — gs://bucket/prefix/ or gs://bucket/file.pdf
        dry_run   — if true, extract + chunk only, no DB writes (default: false)
        metadata  — optional dict stored alongside each chunk in the metadata column
    """
    try:
        summary = await run_embedding(
            req.path,
            dry_run=req.dry_run,
            extra_metadata=req.metadata or None,
        )
        return EmbedResponse(**summary)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))


@app.post("/events/gcs")
async def eventarc_gcs(request: Request) -> dict:
    """
    Eventarc endpoint for GCS object.finalized CloudEvents.

    Wire up with:
        gcloud eventarc triggers create gcs-embed-trigger \\
          --destination-run-service=gcs-embedder \\
          --destination-run-path=/events/gcs \\
          --event-filters="type=google.cloud.storage.object.v1.finalized" \\
          --event-filters="bucket=my-bucket"
    """
    body = await request.json()
    # CloudEvent data payload
    data = body.get("data", body)
    bucket = data.get("bucket", "")
    name   = data.get("name", "")

    if not bucket or not name:
        raise HTTPException(status_code=400, detail="Missing bucket or name in CloudEvent data")

    suffix = Path(name).suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        return {"status": "skipped", "reason": f"unsupported extension: {suffix}"}

    gcs_path = f"gs://{bucket}/{name}"
    summary = await run_embedding(gcs_path)
    return {"status": "ok", **summary}


# ── CLI entry point ───────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Embed GCS documents into pgvector",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py --path gs://my-bucket/rfp-docs/
  python main.py --path gs://my-bucket/rfp-docs/contract.pdf
  python main.py --path gs://my-bucket/rfp-docs/ --dry-run
  python main.py --path gs://my-bucket/rfp-docs/ --metadata '{"bid_id":"B2600042","doc_type":"RFP"}'
        """,
    )
    parser.add_argument(
        "--path", required=True,
        help="GCS path: gs://bucket/prefix/ for directory, gs://bucket/file.pdf for single file",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Extract and chunk text but do not write to the database",
    )
    parser.add_argument(
        "--metadata", default=None,
        help='JSON string of extra metadata, e.g. \'{"bid_id":"B2600042"}\'',
    )
    args = parser.parse_args()

    extra: dict | None = None
    if args.metadata:
        try:
            extra = json.loads(args.metadata)
        except json.JSONDecodeError as exc:
            print(f"❌  Invalid --metadata JSON: {exc}")
            sys.exit(1)

    asyncio.run(run_embedding(args.path, dry_run=args.dry_run, extra_metadata=extra))


if __name__ == "__main__":
    main()
