# Cloud Run Deployment — GCS Document Embedder

Project: `div-aais-rfpiq-usc1-uat` | Region: `us-central1`

---

## 1 — Prerequisites

```bash
gcloud auth login
gcloud config set project div-aais-rfpiq-usc1-uat

gcloud services enable \
  run.googleapis.com \
  cloudbuild.googleapis.com \
  artifactregistry.googleapis.com \
  sqladmin.googleapis.com \
  aiplatform.googleapis.com \
  storage.googleapis.com \
  eventarc.googleapis.com \
  secretmanager.googleapis.com

# Create Artifact Registry repo (once)
gcloud artifacts repositories create rfpiq \
  --repository-format=docker \
  --location=us-central1 \
  --description="RFP AIQ container images"
```

---

## 2 — Service Account & IAM

```bash
gcloud iam service-accounts create embed-sa \
  --display-name="Embed Service — Cloud Run" \
  --project=div-aais-rfpiq-usc1-uat

export SA=embed-sa@div-aais-rfpiq-usc1-uat.iam.gserviceaccount.com
export PROJECT=div-aais-rfpiq-usc1-uat

gcloud projects add-iam-policy-binding $PROJECT \
  --member="serviceAccount:$SA" --role=roles/storage.objectViewer

gcloud projects add-iam-policy-binding $PROJECT \
  --member="serviceAccount:$SA" --role=roles/aiplatform.user

gcloud projects add-iam-policy-binding $PROJECT \
  --member="serviceAccount:$SA" --role=roles/cloudsql.client

gcloud projects add-iam-policy-binding $PROJECT \
  --member="serviceAccount:$SA" --role=roles/secretmanager.secretAccessor
```

| Role | Purpose |
|------|---------|
| `storage.objectViewer` | Read/download files from GCS |
| `aiplatform.user` | Call `text-embedding-004` |
| `cloudsql.client` | Cloud SQL connector socket auth |
| `secretmanager.secretAccessor` | Mount `DB_PASS` at runtime |

---

## 3 — Dockerfile

Create `backend_py/embed_service/Dockerfile`:

```dockerfile
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY main.py .
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8080"]
```

The same image handles both modes — override CMD at job creation time for batch CLI usage.

---

## 4 — Build & Push Image

```bash
# From repo root
gcloud builds submit backend_py/embed_service/ \
  --tag=us-central1-docker.pkg.dev/div-aais-rfpiq-usc1-uat/rfpiq/embed-service:latest \
  --project=div-aais-rfpiq-usc1-uat

# Or tag by git SHA
export TAG=$(git rev-parse --short HEAD)
gcloud builds submit backend_py/embed_service/ \
  --tag=us-central1-docker.pkg.dev/div-aais-rfpiq-usc1-uat/rfpiq/embed-service:$TAG
```

---

## 5 — Store Secrets

```bash
echo -n "your-db-password" | \
  gcloud secrets create embed-db-pass \
    --data-file=- \
    --project=div-aais-rfpiq-usc1-uat

# Rotate later:
echo -n "new-password" | gcloud secrets versions add embed-db-pass --data-file=-
```

---

## 6 — Deploy: Cloud Run Service

```bash
export IMAGE=us-central1-docker.pkg.dev/div-aais-rfpiq-usc1-uat/rfpiq/embed-service:latest

gcloud run deploy embed-service \
  --image=$IMAGE \
  --region=us-central1 \
  --service-account=embed-sa@div-aais-rfpiq-usc1-uat.iam.gserviceaccount.com \
  --add-cloudsql-instances=div-aais-rfpiq-usc1-uat:us-central1:rfpiq-db \
  --set-env-vars=GCP_PROJECT=div-aais-rfpiq-usc1-uat,GCP_LOCATION=us-central1,CLOUD_SQL_CONNECTION_NAME=div-aais-rfpiq-usc1-uat:us-central1:rfpiq-db,DB_NAME=sysco_rfp,DB_USER=embed_svc \
  --set-secrets=DB_PASS=embed-db-pass:latest \
  --memory=1Gi \
  --cpu=1 \
  --concurrency=4 \
  --timeout=3600 \
  --min-instances=0 \
  --no-allow-unauthenticated

# Capture URL
export SERVICE_URL=$(gcloud run services describe embed-service \
  --region=us-central1 --format="value(status.url)")
```

---

## 7 — Deploy: Cloud Run Job (batch mode)

```bash
gcloud run jobs create embed-job \
  --image=$IMAGE \
  --region=us-central1 \
  --service-account=embed-sa@div-aais-rfpiq-usc1-uat.iam.gserviceaccount.com \
  --add-cloudsql-instances=div-aais-rfpiq-usc1-uat:us-central1:rfpiq-db \
  --set-env-vars=GCP_PROJECT=div-aais-rfpiq-usc1-uat,GCP_LOCATION=us-central1,CLOUD_SQL_CONNECTION_NAME=div-aais-rfpiq-usc1-uat:us-central1:rfpiq-db,DB_NAME=sysco_rfp,DB_USER=embed_svc \
  --set-secrets=DB_PASS=embed-db-pass:latest \
  --command=python \
  --args=main.py,--path,gs://rfpiq-docs/uploads/ \
  --memory=1Gi \
  --task-timeout=3600

# Execute
gcloud run jobs execute embed-job --region=us-central1 --wait

# Execute with different path (override at run time)
gcloud run jobs execute embed-job \
  --region=us-central1 \
  --args="main.py,--path,gs://rfpiq-docs/uploads/B2600042_RFP.pdf,--metadata,{\"bid_id\":\"B2600042\"}"
```

---

## 8 — Eventarc GCS Trigger

Grant the SA invocation rights first:

```bash
gcloud run services add-iam-policy-binding embed-service \
  --region=us-central1 \
  --member="serviceAccount:embed-sa@div-aais-rfpiq-usc1-uat.iam.gserviceaccount.com" \
  --role=roles/run.invoker
```

Create the trigger:

```bash
gcloud eventarc triggers create embed-trigger \
  --location=us-central1 \
  --destination-run-service=embed-service \
  --destination-run-region=us-central1 \
  --destination-run-path=/events/gcs \
  --event-filters="type=google.cloud.storage.object.v1.finalized" \
  --event-filters="bucket=rfpiq-docs" \
  --service-account=embed-sa@div-aais-rfpiq-usc1-uat.iam.gserviceaccount.com
```

---

## 9 — Testing

```bash
export TOKEN=$(gcloud auth print-identity-token)

# 1. Health check
curl -H "Authorization: Bearer $TOKEN" $SERVICE_URL/health
# Expected: {"status": "ok"}

# 2. Dry run (no DB writes)
curl -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"path": "gs://rfpiq-docs/uploads/", "dry_run": true}' \
  $SERVICE_URL/embed

# 3. Real embed — single file with metadata
curl -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"path": "gs://rfpiq-docs/uploads/B2600042_RFP.pdf", "metadata": {"bid_id": "B2600042"}}' \
  $SERVICE_URL/embed

# 4. Simulate Eventarc trigger
curl -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -H "Ce-Specversion: 1.0" \
  -H "Ce-Type: google.cloud.storage.object.v1.finalized" \
  -d '{"data": {"bucket": "rfpiq-docs", "name": "uploads/test.pdf"}}' \
  $SERVICE_URL/events/gcs
```

Verify rows in PostgreSQL:

```sql
SELECT gcs_uri, chunk_index, length(chunk_text) AS chars, metadata->>'bid_id', indexed_at
FROM document_vectors
ORDER BY indexed_at DESC LIMIT 10;
```

---

## 10 — Logs & Monitoring

```bash
# Tail live logs
gcloud run services logs tail embed-service --region=us-central1

# Job execution logs
gcloud run jobs executions logs embed-job --region=us-central1

# Filter errors only
gcloud logging read \
  'resource.type="cloud_run_revision" resource.labels.service_name="embed-service" severity>=ERROR' \
  --project=div-aais-rfpiq-usc1-uat --limit=50 --format=json
```

| What to watch | Where |
|---------------|-------|
| Request latency / instance count | Cloud Run → embed-service → Metrics |
| Eventarc delivery failures | Eventarc → Triggers → embed-trigger |
| Vertex AI quota | APIs & Services → Vertex AI API → Quotas |
| Cloud SQL connection errors | Cloud SQL → rfpiq-db → Operations |
