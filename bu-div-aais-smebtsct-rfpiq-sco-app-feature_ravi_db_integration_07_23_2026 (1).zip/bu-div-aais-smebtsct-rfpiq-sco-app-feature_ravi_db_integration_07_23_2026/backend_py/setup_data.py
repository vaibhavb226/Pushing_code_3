"""
One-time setup: copy JSON data files and uploads from backend/ to backend_py/.

Run from the project root:
    python backend_py/setup_data.py
"""
from __future__ import annotations

import shutil
from pathlib import Path

SRC = Path(__file__).parent.parent / "backend"
DST = Path(__file__).parent
print()
DATA_FILES = [
    "bids.json",
    "suppliers.json",
    "lineItems.json",
    "emailThreads.json",
    "pricingData.json",
    "documents.json",
    "unmatchedEmails.json",
    "portalTemplates.json",
    "submissions.json",
]


def main() -> None:
    # Copy data files
    src_data = SRC / "data"
    dst_data = DST / "data"
    dst_data.mkdir(exist_ok=True)

    for fname in DATA_FILES:
        src_file = src_data / fname
        if src_file.exists():
            shutil.copy2(src_file, dst_data / fname)
            print(f"  ✓ data/{fname}")
        else:
            # Create empty default
            import json
            default: dict | list = {} if fname == "submissions.json" else []
            (dst_data / fname).write_text(json.dumps(default, indent=2))
            print(f"  + data/{fname} (created empty)")

    # Copy uploads directory
    src_uploads = SRC / "uploads"
    dst_uploads = DST / "uploads"
    dst_uploads.mkdir(exist_ok=True)
    if src_uploads.exists():
        for f in src_uploads.iterdir():
            if f.is_file():
                shutil.copy2(f, dst_uploads / f.name)
        print(f"  ✓ uploads/ ({len(list(src_uploads.iterdir()))} files)")
    else:
        print("  - uploads/ (source not found, created empty)")

    # Copy .env
    src_env = SRC / ".env"
    dst_env = DST / ".env"
    if src_env.exists() and not dst_env.exists():
        shutil.copy2(src_env, dst_env)
        print("  ✓ .env (copied from backend/.env)")
    elif not dst_env.exists():
        shutil.copy2(DST / ".env.example", dst_env)
        print("  ✓ .env (created from .env.example — fill in your keys)")

    print("\nSetup complete. Start the server:")
    print("  cd backend_py && uvicorn main:app --reload --port 3001")


if __name__ == "__main__":
    main()
