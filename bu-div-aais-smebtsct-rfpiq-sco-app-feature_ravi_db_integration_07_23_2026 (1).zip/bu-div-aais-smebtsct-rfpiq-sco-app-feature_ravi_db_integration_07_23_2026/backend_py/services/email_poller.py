"""
IMAP / Graph inbox poller — mirrors backend/services/emailPoller.js.

Polls every POLL_INTERVAL seconds (default 15).
3-tier bid matching strategy (same as JS):
  1. Bid ID pattern in subject (B2600042, BID-106, etc.)
  2. Cleaned subject matches stored solicitation subject (strips Re:/Fwd:)
  3. All significant words (4+ chars) from customer name appear in subject

On match  → saves to emailThreads.json, updates supplier status to Responded.
On no match → saves to unmatchedEmails.json.
"""
from __future__ import annotations

import asyncio
import json
import re
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

import aiofiles
import structlog

from services.email.base import AbstractEmailService, InboundEmail

log = structlog.get_logger()

POLL_INTERVAL = 15  # seconds
_POLL_TIMEOUT = 60  # seconds — hard ceiling per poll cycle to prevent indefinite hangs
_OVERLAP = timedelta(minutes=10)  # re-scan window before the mark (uid dedup makes it safe)

# Single-flight guard: the 15s loop and manual GET /api/email/poll-now both call run_poll().
# Without it they can overlap and race on emailThreads.json / pollState.json + the uid dedup.
_poll_lock = asyncio.Lock()

# Incremental high-water mark — persisted so the window advances across polls and restarts.
_POLL_STATE_FILE = Path(__file__).parent.parent / "data" / "pollState.json"

_BID_PATTERN = re.compile(
    r"\b([Bb]\d{7}|[Bb][Ii][Dd]-\d+|[Rr][Ff][Pp]-[A-Za-z0-9]{6,})\b"
)

_RE_FWD = re.compile(r"^(re|fwd|fw|ant|aw)\s*:\s*", re.IGNORECASE)


def _att_record(p: str) -> dict[str, Any]:
    """Build an attachment dict in the format the frontend expects.

    Inbound attachments from the Graph/IMAP poller are saved as
    ``INBOUND_{hash}_{original_name}`` in UPLOADS_DIR. Strip the prefix
    to recover the original display name while keeping the full saved name
    for URL construction (/api/files/{bidId}/attachments/{savedName}).
    """
    saved = Path(p).name
    parts = saved.split("_", 2)
    original = parts[2] if len(parts) == 3 and parts[0] == "INBOUND" else saved
    return {"originalName": original, "savedName": saved, "path": p}


async def start_email_poller(email_service: AbstractEmailService) -> None:
    """Long-running loop — runs as an asyncio.Task in main.py lifespan.

    Uses a fixed-interval timer: sleep for max(0, POLL_INTERVAL - poll_duration)
    so slow poll cycles don't push the next start further than 15s into the future.
    """
    loop = asyncio.get_event_loop()
    while True:
        tick = loop.time()
        try:
            await asyncio.wait_for(run_poll(email_service), timeout=_POLL_TIMEOUT)
        except asyncio.TimeoutError:
            log.warning("poller.timeout", timeout_s=_POLL_TIMEOUT)
        except asyncio.CancelledError:
            raise  # propagate — clean shutdown
        except Exception as exc:
            log.warning("poller.iteration_failed", error=str(exc))
        elapsed = loop.time() - tick
        await asyncio.sleep(max(0.0, POLL_INTERVAL - elapsed))



async def _load_poll_state() -> dict[str, Any]:
    try:
        async with aiofiles.open(_POLL_STATE_FILE, encoding="utf-8") as f:
            return json.loads(await f.read())
    except (FileNotFoundError, json.JSONDecodeError):
        return {}


async def _save_poll_state(state: dict[str, Any]) -> None:
    _POLL_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    async with aiofiles.open(_POLL_STATE_FILE, "w", encoding="utf-8") as f:
        await f.write(json.dumps(state, indent=2))


async def _compute_since(now: datetime) -> datetime | None:
    """Lower bound for the next poll: the persisted high-water mark minus an overlap.

    Returns None on cold start (no pollState) so the provider applies its own lookback window.
    Clamped to `max_lookback_days` so a very stale mark never triggers a full-mailbox scan.
    """
    state = await _load_poll_state()
    last = state.get("lastPolledAt")
    if not last:
        return None
    try:
        last_dt = datetime.fromisoformat(last)
    except ValueError:
        return None
    if last_dt.tzinfo is None:
        last_dt = last_dt.replace(tzinfo=timezone.utc)

    from config import get_settings
    max_days = get_settings().max_lookback_days
    floor = now - timedelta(days=max_days)
    return max(last_dt - _OVERLAP, floor)


async def run_poll(email_service: AbstractEmailService) -> dict[str, Any]:
    """Single poll cycle — also exposed to GET /api/email/poll-now.

    Single-flighted: if a cycle is already running (loop + manual trigger overlap), returns
    ``{"skipped": True}`` instead of racing.
    """
    if _poll_lock.locked():
        log.info("poller.skipped_already_running")
        return {"skipped": True, "total": 0, "matched": 0, "unmatched": 0}

    async with _poll_lock:
        now = datetime.now(timezone.utc)
        since = await _compute_since(now)
        messages = await email_service.poll_inbox(since=since)
        matched = 0
        unmatched = 0

        if not messages:
            # Skip poll-state write on empty cycles — the high-water mark only needs to
            # advance when messages are actually processed. UID dedup prevents re-processing
            # if the window covers a slightly wider range on the next non-empty cycle.
            return {"matched": 0, "unmatched": 0, "total": 0}

        from dependencies import (
            get_bids_repo,
            get_email_threads_repo,
            get_unmatched_repo,
        )

        bids_repo = get_bids_repo()
        threads_repo = get_email_threads_repo()
        unmatched_repo = get_unmatched_repo()

        bids = await bids_repo.load()

        for msg in messages:
            bid = _match_bid(msg, bids)
            if bid:
                await _handle_matched(msg, bid, threads_repo, bids_repo, email_service)
                matched += 1
            else:
                await _handle_unmatched(msg, unmatched_repo)
                unmatched += 1

            await email_service.mark_as_read(msg.uid)

        # Use poll start time (not max received) so mail arriving mid-poll is caught next time.
        await _save_poll_state({"lastPolledAt": now.isoformat()})

        log.info("poller.cycle_done", matched=matched, unmatched=unmatched)
        return {"matched": matched, "unmatched": unmatched, "total": len(messages)}


# ── Matching ────────────────────────────────────────────────────────────────────

def _match_bid(msg: InboundEmail, bids: list[dict[str, Any]]) -> dict[str, Any] | None:
    subject = msg.subject or ""
    subject_lower = subject.lower()

    # Tier 1: Bid ID pattern in subject
    # If a bid ID is found but no active bid has that ID, stop — don't fall through
    # to customer-name matching (which would mis-assign emails for deleted bids).
    bid_match = _BID_PATTERN.search(subject)
    if bid_match:
        bid_id_raw = bid_match.group(1).upper()
        for bid in bids:
            if bid.get("id", "").upper() == bid_id_raw:
                return bid
        return None  # explicit bid ID found but bid doesn't exist → unmatched

    # Tier 2: Cleaned subject matches stored solicitation subject (strip all stacked Re:/Fwd: levels)
    cleaned = subject
    while True:
        stripped = _RE_FWD.sub("", cleaned).strip()
        if stripped == cleaned:
            break
        cleaned = stripped
    cleaned = cleaned.lower()
    for bid in bids:
        for thread in _get_solicitation_subjects(bid):
            if cleaned == thread.lower():
                return bid

    # Tier 3: All significant words (4+ chars) from customer name appear in subject.
    # Collect ALL matching bids first — when multiple RFPs share the same customer,
    # a naïve first-match would always attribute replies to the oldest bid.
    candidates = []
    for bid in bids:
        customer = bid.get("customer", "")
        words = [w for w in re.findall(r"\w+", customer) if len(w) >= 4]
        if words and all(w.lower() in subject_lower for w in words):
            candidates.append(bid)

    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]

    # Multiple bids for same customer — prefer the one that actually solicited the sender.
    sender_email = (msg.sender or "").lower()
    if sender_email:
        for bid in candidates:
            for sup in bid.get("solicitedSuppliers", []):
                if (sup.get("email") or "").lower() == sender_email:
                    return bid

    # Fallback: most recently created bid (largest dateCreated or id string).
    return max(candidates, key=lambda b: b.get("dateCreated") or b.get("id") or "")


def _get_solicitation_subjects(bid: dict[str, Any]) -> list[str]:
    """Return distinct solicitation email subjects stored for this bid."""
    subjects: list[str] = []
    for s in bid.get("solicitedSuppliers", []):
        subj = s.get("solicitationSubject", "")
        if subj and subj not in subjects:
            subjects.append(subj)
    return subjects


# ── Handlers ────────────────────────────────────────────────────────────────────

async def _handle_matched(
    msg: InboundEmail,
    bid: dict[str, Any],
    threads_repo: Any,
    bids_repo: Any,
    email_service: AbstractEmailService | None = None,
) -> None:
    bid_id = bid.get("id", "")
    is_bounce = _detect_bounce(msg)

    # Deduplication: for non-bounces, skip if this uid was already processed.
    # Bounces skip this check — their per-(uid, recipient) dedup runs inside the bounce branch,
    # allowing one NDR to fan out multiple records (one per failed BCC address).
    if not is_bounce and msg.uid:
        existing = await threads_repo.find_by_uid(msg.uid)
        if existing:
            return

    email_record: dict[str, Any] = {
        "id": f"E-INBOUND-{uuid.uuid4().hex[:10].upper()}",
        "uid": msg.uid,
        "bidId": bid_id,
        "direction": "inbound",
        "supplierId": None,
        "supplierName": "",
        "supplierEmail": msg.from_addr,
        "from": msg.from_addr,
        "to": "",
        "bcc": [],
        "subject": msg.subject,
        "body": msg.body[:5000],
        "date": msg.date or datetime.now(timezone.utc).isoformat(),
        "attachments": [_att_record(p) for p in msg.attachment_paths],
        "tags": ["inbound"],
        "read": False,
        "analysisResult": None,
        "isBounce": is_bounce,
        "portalSubmission": False,
        "conversationId": msg.conversation_id or "",
        "graphInternetMessageId": msg.internet_message_id or "",
        "spamInfo": msg.spam_info if msg.spam_info else None,
    }

    if is_bounce:
        # Try RFC 3464 structured DSN parsing first — fetches raw MIME via $value endpoint
        # so each supplier gets only their Diagnostic-Code, not the full multi-recipient NDR body.
        # Falls back to text-body regex parsing when raw MIME is unavailable.
        dsn_parsed: dict[str, Any] | None = None
        if email_service and msg.uid:
            raw_mime = await email_service.fetch_raw_mime(msg.uid)
            if raw_mime:
                dsn_parsed = _parse_dsn_mime(raw_mime)
                if dsn_parsed:
                    log.info("poller.bounce_dsn_parsed", recipients=len(dsn_parsed["recipients"]))

        bounce_info = dsn_parsed if dsn_parsed else _parse_bounce(msg)
        per_diag: dict[str, str] = dsn_parsed.get("perRecipientDiagnostics", {}) if dsn_parsed else {}
        recipients  = bounce_info["recipients"]

        # Build email→supplier lookup once — O(solicited), not nested-loop
        email_to_sup: dict[str, dict[str, Any]] = {}
        for s in bid.get("solicitedSuppliers", []):
            if not s.get("supplierId"):
                continue
            for addr in [s.get("email", ""), *s.get("additionalEmails", [])]:
                if addr:
                    email_to_sup[addr.lower()] = s

        # Per-(uid, recipient) dedup — one record per address, safe across poll retries
        existing_pairs: set[tuple[str, str]] = {
            (e.get("uid", ""), (e.get("originalRecipient") or "").lower())
            for e in await threads_repo.get_for_bid(bid_id)
            if e.get("isBounce")
        }

        base_bounce = {
            **email_record,
            "tags": ["inbound", "bounce"],
            "isBounce": True,
            "bounceCode":   bounce_info["bounceCode"],
            "bounceReason": bounce_info["bounceReason"],
        }

        wrote = 0
        _bounce_batch: list[dict[str, Any]] = []
        for recipient in recipients:
            pair = (msg.uid or "", recipient.lower())
            if pair in existing_pairs:
                continue

            sup = email_to_sup.get(recipient.lower())
            if not sup:
                # Not a solicited supplier (e.g. COE mailbox, Exchange relay addresses) — skip.
                # The last-resort regex collects all emails in the NDR body; we only want the ones
                # that belong to solicited suppliers.
                continue

            # Use structured diagnostic text when available (from RFC 3464 DSN MIME),
            # otherwise fall back to extracting the relevant paragraph from the NDR text body.
            diag_body = per_diag.get(recipient) or _extract_recipient_block(msg.body or "", recipient)
            record = {
                **base_bounce,
                "id":                f"E-INBOUND-{uuid.uuid4().hex[:10].upper()}",
                "supplierId":        sup.get("supplierId"),
                "supplierName":      sup.get("supplierName", ""),
                "supplierEmail":     sup.get("email", recipient),
                "originalRecipient": recipient,
                "body":              diag_body,
            }
            _bounce_batch.append(record)
            existing_pairs.add(pair)
            wrote += 1

        # Single batch insert for all bounce records (one DB round-trip instead of N)
        if _bounce_batch:
            await threads_repo.append_many(_bounce_batch)

        # Status updates are sequential — they touch rfp_solicited_suppliers, not email_threads
        for _rec in _bounce_batch:
            await _update_supplier_status(bid_id, _rec["originalRecipient"], "Issues Found", bids_repo)

        # Fallback: no solicited suppliers matched (malformed NDR or unrecognised addresses)
        if wrote == 0:
            first_recipient = recipients[0] if recipients else ""
            fallback_pair = (msg.uid or "", first_recipient.lower())
            if fallback_pair not in existing_pairs:
                await threads_repo.append({**base_bounce, "originalRecipient": first_recipient})
                existing_pairs.add(fallback_pair)
            wrote = 1

        log.info(
            "poller.bounce_matched",
            bid_id=bid_id,
            from_=msg.from_addr,
            subject=msg.subject[:60],
            recipients=len(recipients),
            wrote=wrote,
        )
        return  # bounce path handled; skip the non-bounce append below

    else:
        # Non-bounce: link by the sender's address (primary or alias)
        from_clean = _extract_email_addr(msg.from_addr).lower()
        for s in bid.get("solicitedSuppliers", []):
            known = [e.lower() for e in [s.get("email", ""), *s.get("additionalEmails", [])] if e]
            if from_clean in known:
                email_record["supplierId"]    = s.get("supplierId")
                email_record["supplierName"]  = s.get("supplierName", "")
                email_record["supplierEmail"] = s.get("email", "")
                break

    await threads_repo.append(email_record)

    log.info(
        "poller.email_matched",
        bid_id=bid_id,
        from_=msg.from_addr,
        subject=msg.subject[:60],
        is_bounce=False,
        spam_verdict=msg.spam_info.get("verdict") if msg.spam_info else None,
        spam_scl=msg.spam_info.get("scl") if msg.spam_info else None,
        spam_cat=msg.spam_info.get("cat") if msg.spam_info else None,
    )

    if email_record.get("supplierId"):
        from_clean = _extract_email_addr(msg.from_addr)
        await _update_supplier_status(bid_id, from_clean, "Responded", bids_repo)


async def _handle_unmatched(msg: InboundEmail, repo: Any) -> None:
    all_unmatched = await repo.load()
    # Deduplication by uid
    if msg.uid and any(e.get("uid") == msg.uid for e in all_unmatched):
        return
    all_unmatched.append({
        "id": f"UNMATCHED-{uuid.uuid4().hex[:8].upper()}",
        "uid": msg.uid,
        "from": msg.from_addr,
        "subject": msg.subject,
        "body": msg.body[:2000],
        "date": msg.date or datetime.now(timezone.utc).isoformat(),
        "rawHeaders": msg.raw_headers,
        "spamInfo": msg.spam_info if msg.spam_info else None,
    })
    await repo.save(all_unmatched)
    log.info(
        "poller.unmatched",
        from_=msg.from_addr,
        subject=msg.subject[:60],
        spam_verdict=msg.spam_info.get("verdict") if msg.spam_info else None,
    )


async def _update_supplier_status(
    bid_id: str, email: str, status: str, bids_repo: Any
) -> None:
    MANUAL_OVERRIDE_STATUSES = {"Awarded", "Under Consideration"}

    def updater(bid: dict[str, Any]) -> dict[str, Any]:
        for s in bid.get("solicitedSuppliers", []):
            known = [e.lower() for e in [s.get("email", ""), *s.get("additionalEmails", [])] if e]
            if email.lower() in known:
                if s.get("status") not in MANUAL_OVERRIDE_STATUSES:
                    s["status"] = status
                    s["lastActivity"] = datetime.now(timezone.utc).date().isoformat()
        return bid

    await bids_repo.update_by_id(bid_id, updater)


# ── Bounce detection ────────────────────────────────────────────────────────────

_BOUNCE_SUBJECTS = re.compile(
    r"(delivery\s*(status\s*notification|failure)|undeliverable|mail\s*delivery\s*failed"
    r"|returned\s*mail|bounce|failure\s*notice)",
    re.IGNORECASE,
)

_BOUNCE_FROM = re.compile(r"(mailer-daemon|postmaster|mail\s*delivery)", re.IGNORECASE)

_DSN_RECIPIENT_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"Final-Recipient:.*?rfc822;\s*([^\s\r\n]+)", re.IGNORECASE),
    re.compile(r"Original-Recipient:.*?rfc822;\s*([^\s\r\n]+)", re.IGNORECASE),
    re.compile(r"failed\s+recipient[:\s]+([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})", re.IGNORECASE),
    re.compile(r"(?:to|rcpt\s+to)[:\s<]+([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})", re.IGNORECASE),
]
_ANY_EMAIL_RE = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}")


def _detect_bounce(msg: InboundEmail) -> bool:
    return bool(
        _BOUNCE_SUBJECTS.search(msg.subject or "")
        or _BOUNCE_FROM.search(msg.from_addr or "")
    )


def _parse_bounce(msg: InboundEmail) -> dict[str, Any]:
    body = msg.body or ""

    # 1. Bounce code — e.g. "550 5.1.1" or just "550"
    code_m = re.search(r"\b(5\d{2}(?:\s+[\d.]+)?)\b", body)
    bounce_code = code_m.group(1).strip() if code_m else "550"

    # 2. Human-readable reason
    reason_m = re.search(
        r"(user\s*does\s*not\s*exist|mailbox\s*not\s*found|no\s*such\s*user"
        r"|account\s*disabled|relay\s*access\s*denied)",
        body, re.IGNORECASE,
    )
    reason_fallback = re.search(r"(?:reason|diagnostic[- ]code)[:\s]+(.+)", body, re.IGNORECASE)
    if reason_m:
        bounce_reason = reason_m.group(1)
    elif reason_fallback:
        bounce_reason = reason_fallback.group(1)[:200].strip()
    else:
        bounce_reason = "Unknown delivery failure"

    # 3. All failed recipients — finditer collects every address from a multi-recipient NDR
    recipients: list[str] = []

    # RFC 3464 DSN: Exchange writes one Final-Recipient block per failed BCC address
    for m in re.finditer(r"Final-Recipient\s*:.*?rfc822\s*;\s*<?([^\s>\r\n]+)>?", body, re.IGNORECASE):
        addr = m.group(1).strip().lower().strip("<>")
        if addr and addr not in recipients and not _BOUNCE_FROM.search(addr):
            recipients.append(addr)

    # Fallback: Original-Recipient blocks
    if not recipients:
        for m in re.finditer(r"Original-Recipient\s*:.*?rfc822\s*;\s*<?([^\s>\r\n]+)>?", body, re.IGNORECASE):
            addr = m.group(1).strip().lower().strip("<>")
            if addr and addr not in recipients and not _BOUNCE_FROM.search(addr):
                recipients.append(addr)

    # Fallback: angle-bracket scan — also matches <mailto:email> format used in Exchange NDRs
    if not recipients:
        for m in re.finditer(r"<(?:mailto:)?([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})>", body):
            addr = m.group(1).lower()
            if addr and addr not in recipients and not _BOUNCE_FROM.search(addr):
                recipients.append(addr)

    # Last-resort: any bare email in body — collect ALL, not just the first.
    # MS Graph returns only the human-readable NDR text (no DSN machine-readable MIME part),
    # so the body contains bare addresses mixed with COE/server addresses. Removing `break`
    # lets the fan-out loop filter to only solicited supplier addresses.
    if not recipients:
        for em in _ANY_EMAIL_RE.findall(body):
            em_lower = em.lower()
            if em_lower and em_lower not in recipients and not _BOUNCE_FROM.search(em):
                recipients.append(em_lower)

    # Absolute fallback — keeps old single-recipient behaviour for malformed NDRs
    if not recipients:
        recipients = [_extract_email_addr(msg.from_addr)]

    return {
        "bounceCode":        bounce_code,
        "bounceReason":      bounce_reason,
        "recipients":        recipients,           # list — one entry per failed address
        "originalRecipient": recipients[0] if recipients else "",  # kept for backward-compat
    }


def _extract_recipient_block(body: str, recipient: str) -> str:
    """Extract only the NDR paragraph(s) that describe a specific recipient.

    Exchange NDRs separate each failed address with double newlines.
    We collect every paragraph that mentions the recipient's address so the
    body stored on each per-supplier bounce record contains only that supplier's
    failure message, not the full multi-recipient NDR.

    Uses (?:\\r?\\n){2,} to handle both CRLF (Exchange default) and bare-LF line endings.
    The original r"\\n{2,}" failed on CRLF because the two \\n chars are not consecutive
    (a \\r sits between them), causing the entire NDR body to remain as one unsplit block.
    """
    paragraphs = re.split(r"(?:\r?\n){2,}", body)
    recipient_lower = recipient.lower()
    relevant = [p.strip() for p in paragraphs if recipient_lower in p.lower()]
    if relevant:
        return "\n\n".join(relevant)[:1500]
    return f"Delivery failed for {recipient}."


def _parse_dsn_mime(raw_bytes: bytes) -> dict[str, Any] | None:
    """Parse per-recipient bounce data from RFC 3464 structured DSN MIME bytes.

    NDRs are multipart/report messages. The machine-readable part is
    message/delivery-status, which contains one structured block per failed
    recipient with Final-Recipient, Status, and Diagnostic-Code fields.

    This is more reliable than parsing the human-readable text body because
    it is RFC-standardised and independent of Exchange NDR formatting variations.
    Returns None if no delivery-status part is found (falls back to _parse_bounce).
    """
    import email as stdlib_email

    try:
        msg = stdlib_email.message_from_bytes(raw_bytes)
    except Exception:
        return None

    recipients: list[str] = []
    bounce_code = "5.x.x"
    bounce_reason = "Delivery failed"
    per_recipient_diagnostics: dict[str, str] = {}

    for part in msg.walk():
        if part.get_content_type() != "message/delivery-status":
            continue
        # The payload may be a string (encoded) or bytes depending on how the MIME lib parsed it
        raw_payload = part.get_payload(decode=False)
        if isinstance(raw_payload, bytes):
            text = raw_payload.decode("utf-8", errors="replace")
        elif isinstance(raw_payload, str):
            text = raw_payload
        else:
            continue

        # Split into per-recipient blocks separated by blank lines
        for block in re.split(r"(?:\r?\n){2,}", text):
            final_recip: str | None = None
            block_status: str | None = None
            block_diag: str | None = None
            for line in block.splitlines():
                key, _, val = line.partition(":")
                key = key.strip().lower()
                val = val.strip()
                if key == "final-recipient":
                    # "rfc822; user@example.com" or just "user@example.com"
                    addr_part = val.split(";", 1)[-1].strip().strip("<>").lower()
                    if addr_part and "@" in addr_part:
                        final_recip = addr_part
                elif key == "status":
                    block_status = val
                elif key == "diagnostic-code":
                    block_diag = val.split(";", 1)[-1].strip()[:300] if ";" in val else val[:300]
            if final_recip:
                recipients.append(final_recip)
                if block_status and bounce_code == "5.x.x":
                    bounce_code = block_status
                if block_diag:
                    per_recipient_diagnostics[final_recip] = block_diag
                    if not bounce_reason or bounce_reason == "Delivery failed":
                        bounce_reason = block_diag

    if not recipients:
        return None

    return {
        "bounceCode": bounce_code,
        "bounceReason": bounce_reason,
        "recipients": recipients,
        "originalRecipient": recipients[0],
        "perRecipientDiagnostics": per_recipient_diagnostics,
    }


def _extract_email_addr(raw: str) -> str:
    """Extract plain email from 'Display Name <email@domain.com>' format."""
    match = re.search(r"<([^>]+)>", raw)
    return match.group(1).strip() if match else raw.strip()
