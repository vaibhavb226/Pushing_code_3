"""
Single cached text-extraction chokepoint.

Every flat-text extraction in the backend (RFP/Item-List line-item parsing, BEX RFP parsing,
email pricing extraction, and document embedding) goes through ``get_document_text``. It is keyed
by the document's content hash and cached in a PostgreSQL ``document_text`` table, so a given
document is extracted **exactly once** regardless of which flow (or how many) touches it. This is
also the one place extraction happens — swap the PDF branch for Document AI later and every flow
benefits.

When PostgreSQL is not configured (local JSON mode, ``DB_HOST`` unset) there is no cache and each
call extracts directly — behaviour identical to before this module existed.
"""
from __future__ import annotations

import asyncio
import hashlib
import io
from typing import Any

import structlog

log = structlog.get_logger()

# Per-content-hash locks so concurrent callers in this process (e.g. the RFP-upload line-item
# parse and the embedder firing at the same time) collapse to a single extraction.
_locks: dict[str, asyncio.Lock] = {}


def _get_lock(doc_key: str) -> asyncio.Lock:
    lock = _locks.get(doc_key)
    if lock is None:
        lock = asyncio.Lock()
        _locks[doc_key] = lock
    return lock


_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS document_text (
    doc_key      TEXT PRIMARY KEY,
    text         TEXT        NOT NULL,
    char_count   INTEGER     NOT NULL DEFAULT 0,
    format       TEXT,
    extracted_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
"""

_table_ready = False


async def _ensure_table(conn: Any) -> None:
    global _table_ready
    if _table_ready:
        return
    from sqlalchemy import text
    await conn.execute(text(_CREATE_TABLE_SQL))
    await conn.commit()
    _table_ready = True


# ── Extraction (the single Document-AI swap point) ──────────────────────────────

def _extract(content: bytes, suffix: str) -> str:
    """Extract flat text from document bytes. This is the ONLY extractor in the backend.

    Replace the ``.pdf`` branch with Document AI later — every flow reuses the cached result.
    """
    suffix = suffix.lower()
    if not suffix.startswith("."):
        suffix = "." + suffix

    if suffix == ".pdf":
        return _extract_pdf(content)
    if suffix in (".xlsx", ".xls"):
        return _extract_excel(content)
    if suffix == ".docx":
        return _extract_docx(content)
    # .txt, .csv and anything else — best-effort plain decode
    try:
        return content.decode("utf-8", errors="replace").strip()
    except Exception:
        return ""


def _extract_pdf(content: bytes) -> str:
    try:
        import fitz  # PyMuPDF
        doc = fitz.open(stream=content, filetype="pdf")
        try:
            text = "\n".join(doc[i].get_text("text") for i in range(len(doc))).strip()
        finally:
            doc.close()
        # Apply pdf_char_limit from settings if configured (prevents sending huge PDFs to LLM).
        # The limit is advisory — callers may apply their own slice, but honouring it here
        # means the setting is respected regardless of which code path invokes extraction.
        try:
            from config import get_settings
            limit = get_settings().pdf_char_limit
            if limit and len(text) > limit:
                log.info("document_text.pdf_truncated", original=len(text), limit=limit)
                text = text[:limit]
        except Exception:
            pass  # settings not available (tests) — skip truncation
        return text
    except Exception as exc:
        log.warning("document_text.pdf_extract_failed", error=str(exc))
        return ""


def _extract_excel(content: bytes) -> str:
    """Extract tab-delimited text from Excel files.

    Tries openpyxl first (handles .xlsx). Falls back to xlrd for old binary .xls files
    that openpyxl cannot read. Empty cells preserved as "" so column positions are stable.
    """
    try:
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(content), data_only=True)
        lines: list[str] = []
        for ws in wb.worksheets:
            if ws.sheet_state != 'visible':
                continue
            lines.append(f"=== Sheet: {ws.title} ===")
            for row in ws.iter_rows(values_only=True):
                lines.append("\t".join("" if v is None else str(v) for v in row))
        return "\n".join(lines)
    except Exception as openpyxl_exc:
        # openpyxl cannot read old binary .xls format — try xlrd as fallback.
        # xlrd 2.x only supports .xls (not .xlsx), so this path only activates when openpyxl
        # fails, which in practice means the file is .xls.
        try:
            import xlrd
            wb_xls = xlrd.open_workbook(file_contents=content)
            lines = []
            for sheet in wb_xls.sheets():
                if sheet.visibility != 0:
                    continue
                lines.append(f"=== Sheet: {sheet.name} ===")
                for r in range(sheet.nrows):
                    row_vals = []
                    for c in range(sheet.ncols):
                        cell = sheet.cell(r, c)
                        row_vals.append("" if cell.value is None else str(cell.value))
                    lines.append("\t".join(row_vals))
            return "\n".join(lines)
        except Exception as xlrd_exc:
            log.warning("document_text.excel_extract_failed",
                        openpyxl_error=str(openpyxl_exc),
                        xlrd_error=str(xlrd_exc))
            return ""


def _extract_docx(content: bytes) -> str:
    try:
        from docx import Document  # python-docx (optional dependency)
        doc = Document(io.BytesIO(content))
        return "\n".join(p.text for p in doc.paragraphs if p.text.strip()).strip()
    except Exception as exc:
        log.warning("document_text.docx_extract_failed", error=str(exc))
        return ""


# ── Public API ──────────────────────────────────────────────────────────────────

async def extract_full_text(content: bytes, *, suffix: str) -> str:
    """Extract complete document text with NO char limit — for embedding/indexing only.

    Use get_document_text() for LLM-facing extraction (respects pdf_char_limit).
    Directly calls the internal extractors, bypassing the pdf_char_limit setting.
    """
    suffix = suffix.lower()
    if not suffix.startswith("."):
        suffix = "." + suffix

    if suffix == ".pdf":
        try:
            import fitz  # PyMuPDF
            doc = fitz.open(stream=content, filetype="pdf")
            try:
                text = "\n".join(doc[i].get_text("text") for i in range(len(doc))).strip()
            finally:
                doc.close()
            return text
        except Exception as exc:
            log.warning("document_text.pdf_extract_failed", error=str(exc))
            return ""
    # Excel, docx, txt — char limit was never applied to these; reuse shared extractors
    return await asyncio.to_thread(_extract, content, suffix)


async def get_document_text(content: bytes, *, suffix: str, settings: Any = None) -> str:
    """Return the flat text of a document, extracting at most once per content hash.

    Reads/writes the ``document_text`` cache when PostgreSQL is configured; otherwise extracts
    directly (no cache). Concurrent callers for the same content collapse to one extraction.
    """
    # DISABLED (2026-07-09): document_text caching temporarily switched off per request.
    # Text is extracted directly on every call — nothing is read from or written to the
    # document_text table. Re-enable by uncommenting the cached path below.
    return await asyncio.to_thread(_extract, content, suffix)

    # if settings is None:  # noqa: E800 - cached path disabled 2026-07-09
    #     from config import get_settings
    #     settings = get_settings()
    #
    # doc_key = hashlib.md5(content).hexdigest()
    #
    # from db.connection import get_db_conn, get_engine
    #
    # # No DB configured → behave exactly as before (extract directly, no caching).
    # if get_engine(settings) is None:
    #     return await asyncio.to_thread(_extract, content, suffix)
    #
    # from sqlalchemy import text
    #
    # # Fast path: cache hit without holding the per-key lock.
    # async with get_db_conn(settings) as conn:
    #     if conn is not None:
    #         await _ensure_table(conn)
    #         row = (await conn.execute(
    #             text("SELECT text FROM document_text WHERE doc_key = :k"), {"k": doc_key}
    #         )).first()
    #         if row is not None:
    #             return row[0]
    #
    # # Cache miss → serialise same-content extractions, re-check, then extract once.
    # async with _get_lock(doc_key):
    #     async with get_db_conn(settings) as conn:
    #         if conn is None:
    #             return await asyncio.to_thread(_extract, content, suffix)
    #
    #         row = (await conn.execute(
    #             text("SELECT text FROM document_text WHERE doc_key = :k"), {"k": doc_key}
    #         )).first()
    #         if row is not None:
    #             return row[0]
    #
    #         extracted = await asyncio.to_thread(_extract, content, suffix)
    #
    #         await conn.execute(
    #             text(
    #                 "INSERT INTO document_text (doc_key, text, char_count, format) "
    #                 "VALUES (:k, :t, :c, :f) ON CONFLICT (doc_key) DO NOTHING"
    #             ),
    #             {"k": doc_key, "t": extracted, "c": len(extracted),
    #              "f": suffix.lstrip(".").lower()},
    #         )
    #         await conn.commit()
    #         log.info("document_text.extracted", doc_key=doc_key, chars=len(extracted),
    #                  fmt=suffix.lstrip(".").lower())
    #         return extracted
