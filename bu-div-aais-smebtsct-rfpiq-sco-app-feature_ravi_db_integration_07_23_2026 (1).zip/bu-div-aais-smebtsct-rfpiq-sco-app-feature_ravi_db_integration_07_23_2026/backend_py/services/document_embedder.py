"""
In-process document embedder.

Replaces the standalone ``embed_service/`` for runtime use: uploaded documents are embedded into
the ``document_vectors`` pgvector table by a fire-and-forget background worker while the API keeps
serving. Upload handlers call ``enqueue_document(gcs_uri, metadata)`` (instant, non-blocking); a
single always-on worker (started in ``main.py`` lifespan) consumes the queue and embeds one at a
time.

Text extraction goes through ``services.document_text.get_document_text`` so a document is never
extracted twice — if the RFP/line-item flow already extracted it, the embedder reuses that text.

No-ops safely when PostgreSQL (``DB_HOST``) or GCS (``GCS_BUCKET``) is not configured.
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any

import structlog

log = structlog.get_logger()

CHUNK_SIZE = 800
CHUNK_OVERLAP = 100
BATCH_SIZE = 20
EMBEDDING_DIMS = 768

# Fire-and-forget work queue drained by run_embed_worker().
_queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()


# ── DDL ─────────────────────────────────────────────────────────────────────────

_CREATE_TABLE_SQL = f"""
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS document_vectors (
    id            TEXT PRIMARY KEY,
    gcs_uri       TEXT        NOT NULL,
    bucket        TEXT        NOT NULL,
    object_name   TEXT        NOT NULL,
    file_name     TEXT        NOT NULL,
    file_type     TEXT,
    bid_id        TEXT,
    rfp_id        TEXT,
    document_id   TEXT,
    document_type TEXT,
    region        TEXT,
    segment       TEXT,
    customer_name TEXT,
    opco          TEXT,
    content_type  TEXT,
    size_bytes    BIGINT,
    gcs_updated   TIMESTAMPTZ,
    chunk_index   INTEGER     NOT NULL DEFAULT 0,
    chunk_text    TEXT        NOT NULL,
    embedding     VECTOR({EMBEDDING_DIMS}) NOT NULL,
    metadata      JSONB       NOT NULL DEFAULT '{{}}',
    indexed_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS document_vectors_emb_idx
    ON document_vectors USING ivfflat (embedding vector_cosine_ops) WITH (lists = 20);
CREATE INDEX IF NOT EXISTS document_vectors_gcs_idx    ON document_vectors (gcs_uri);
CREATE INDEX IF NOT EXISTS document_vectors_bid_idx    ON document_vectors (bid_id);
CREATE INDEX IF NOT EXISTS document_vectors_region_idx ON document_vectors (region);
CREATE INDEX IF NOT EXISTS document_vectors_segment_idx ON document_vectors (segment);
"""

_tables_ready = False


async def _ensure_tables(conn: Any) -> None:
    global _tables_ready
    if _tables_ready:
        return
    from sqlalchemy import text
    for stmt in _CREATE_TABLE_SQL.strip().split(";"):
        s = stmt.strip()
        if s:
            await conn.execute(text(s))
    await conn.commit()
    _tables_ready = True


# ── Chunking ────────────────────────────────────────────────────────────────────

def chunk_text(text: str) -> list[str]:
    """Fixed-size overlapping character windows (matches embed_service)."""
    text = text.strip()
    if not text:
        return []
    if len(text) <= CHUNK_SIZE:
        return [text]
    chunks: list[str] = []
    start = 0
    while start < len(text):
        chunk = text[start : start + CHUNK_SIZE].strip()
        if chunk:
            chunks.append(chunk)
        start += CHUNK_SIZE - CHUNK_OVERLAP
    return chunks


# ── DB writes ───────────────────────────────────────────────────────────────────

def _vec(v: list[float]) -> str:
    return "[" + ",".join(str(x) for x in v) + "]"


async def _delete_chunks_for_uri(conn: Any, gcs_uri: str) -> int:
    from sqlalchemy import text
    result = await conn.execute(
        text("DELETE FROM document_vectors WHERE gcs_uri = :uri"), {"uri": gcs_uri}
    )
    return result.rowcount


async def _upsert_chunk(conn: Any, params: dict[str, Any]) -> None:
    from sqlalchemy import text
    await conn.execute(
        text("""
        INSERT INTO document_vectors
            (id, gcs_uri, bucket, object_name, file_name, file_type,
             bid_id, rfp_id, document_id, document_type,
             region, segment, customer_name, opco,
             content_type, size_bytes, gcs_updated,
             chunk_index, chunk_text, embedding, metadata, indexed_at)
        VALUES
            (:id, :gcs_uri, :bucket, :object_name, :file_name, :file_type,
             :bid_id, :rfp_id, :document_id, :document_type,
             :region, :segment, :customer_name, :opco,
             :content_type, :size_bytes, :gcs_updated,
             :chunk_index, :chunk_text, CAST(:embedding AS vector), CAST(:metadata AS jsonb), now())
        ON CONFLICT (id) DO UPDATE
            SET chunk_text = EXCLUDED.chunk_text,
                embedding  = EXCLUDED.embedding,
                metadata   = EXCLUDED.metadata,
                indexed_at = now()
        """),
        params,
    )


# ── GCS download ────────────────────────────────────────────────────────────────

def _parse_gcs_uri(gcs_uri: str) -> tuple[str, str]:
    rest = gcs_uri[len("gs://"):]
    bucket, _, obj = rest.partition("/")
    return bucket, obj


async def _download_gcs(gcs_uri: str, settings: Any) -> tuple[bytes, dict[str, str], Any] | None:
    """Return (content_bytes, custom_metadata, updated) for a gs:// object, or None."""
    from dependencies import get_gcs_client
    client = get_gcs_client(settings)
    if client is None:
        return None
    bucket_name, object_name = _parse_gcs_uri(gcs_uri)

    def _fetch() -> tuple[bytes, dict[str, str], Any]:
        blob = client.bucket(bucket_name).get_blob(object_name)
        if blob is None:
            raise FileNotFoundError(gcs_uri)
        data = blob.download_as_bytes()
        return data, (blob.metadata or {}), blob.updated

    try:
        return await asyncio.to_thread(_fetch)
    except Exception as exc:
        log.warning("embedder.gcs_download_failed", uri=gcs_uri, error=str(exc))
        return None


# ── Core per-document processing ────────────────────────────────────────────────

async def embed_gcs_document(gcs_uri: str, extra_metadata: dict[str, Any] | None = None) -> int:
    """Embed a single GCS document into document_vectors. Returns chunks indexed (0 = skipped)."""
    from config import get_settings
    from db.connection import get_db_conn, get_engine
    from services.document_text import get_document_text
    from services.embedding_service import embed_texts

    settings = get_settings()
    if get_engine(settings) is None:
        log.info("embedder.skip_no_db", uri=gcs_uri)
        return 0

    downloaded = await _download_gcs(gcs_uri, settings)
    if downloaded is None:
        return 0
    content, gcs_meta, gcs_updated = downloaded

    bucket_name, object_name = _parse_gcs_uri(gcs_uri)
    file_name = Path(object_name).name
    file_type = Path(object_name).suffix.lstrip(".").lower()

    extra = extra_metadata or {}
    bid_id        = gcs_meta.get("bid-id")        or extra.get("bid_id")        or ""
    rfp_id        = gcs_meta.get("rfp-id")        or extra.get("rfp_id")        or bid_id
    document_id   = gcs_meta.get("document-id")   or extra.get("document_id")   or ""
    document_type = gcs_meta.get("document-type") or extra.get("document_type") or ""
    region        = gcs_meta.get("region")        or extra.get("region")        or ""
    segment       = gcs_meta.get("segment")       or extra.get("segment")       or ""
    customer_name = gcs_meta.get("customer-name") or extra.get("customer_name") or ""
    opco          = gcs_meta.get("opco")          or extra.get("opco")          or ""

    # Shared cached extraction — reuses text if the RFP/line-item flow already extracted this file.
    raw_text = await get_document_text(content, suffix=f".{file_type}", settings=settings)
    if not raw_text:
        log.info("embedder.skip_no_text", uri=gcs_uri)
        return 0

    header = " | ".join(
        filter(None, [gcs_uri, file_type.upper(), bid_id, document_type, region, segment])
    )
    full_text = f"{header}\n\n{raw_text}" if header else raw_text
    chunks = chunk_text(full_text)
    if not chunks:
        return 0

    row_metadata = {
        "gcs_uri": gcs_uri, "bid_id": bid_id, "rfp_id": rfp_id,
        "document_type": document_type, "region": region, "segment": segment,
    }

    async with get_db_conn(settings) as conn:
        if conn is None:
            return 0
        await _ensure_tables(conn)
        await _delete_chunks_for_uri(conn, gcs_uri)

        indexed = 0
        for start in range(0, len(chunks), BATCH_SIZE):
            batch = chunks[start : start + BATCH_SIZE]
            embeddings = await embed_texts(batch, task_type="RETRIEVAL_DOCUMENT", settings=settings)
            for i, (chunk, emb) in enumerate(zip(batch, embeddings)):
                idx = start + i
                await _upsert_chunk(conn, {
                    "id": f"{gcs_uri}::chunk:{idx}",
                    "gcs_uri": gcs_uri, "bucket": bucket_name, "object_name": object_name,
                    "file_name": file_name, "file_type": file_type,
                    "bid_id": bid_id or None, "rfp_id": rfp_id or None,
                    "document_id": document_id or None, "document_type": document_type or None,
                    "region": region or None, "segment": segment or None,
                    "customer_name": customer_name or None, "opco": opco or None,
                    "content_type": None, "size_bytes": len(content), "gcs_updated": gcs_updated,
                    "chunk_index": idx, "chunk_text": chunk,
                    "embedding": _vec(emb), "metadata": json.dumps(row_metadata),
                })
                indexed += 1
        await conn.commit()

    log.info("embedder.indexed", uri=gcs_uri, chunks=indexed, bid_id=bid_id)
    return indexed


# ── Queue + worker ──────────────────────────────────────────────────────────────

def enqueue_document(gcs_uri: str, metadata: dict[str, Any] | None = None) -> None:
    """Fire-and-forget: queue a GCS document for background embedding. Instant, never blocks."""
    if not gcs_uri or not gcs_uri.startswith("gs://"):
        return
    try:
        _queue.put_nowait({"gcs_uri": gcs_uri, "metadata": metadata or {}})
    except Exception as exc:  # pragma: no cover — queue is unbounded
        log.warning("embedder.enqueue_failed", uri=gcs_uri, error=str(exc))


async def run_embed_worker() -> None:
    """Long-running background worker — drains the queue and embeds one document at a time."""
    log.info("embedder.worker_started")
    while True:
        job = await _queue.get()
        try:
            await embed_gcs_document(job["gcs_uri"], job.get("metadata"))
        except asyncio.CancelledError:
            raise  # clean shutdown
        except Exception as exc:
            log.warning("embedder.job_failed", uri=job.get("gcs_uri"), error=str(exc))
        finally:
            _queue.task_done()
