"""
Vendor-agnostic LLM service wrapper.

All AI call sites use one of two methods:
- chat()              — single user message
- chat_with_history() — multi-turn conversation

Provider dispatch order:
  1. _anthropic_direct() — Anthropic SDK via ChatAnthropic._async_client
  2. _vertex_direct()    — vertexai SDK via GenerativeModel.generate_content_async
  3. LangChain ainvoke() — fallback for OpenAI and other LangChain-wrapped providers
"""
from __future__ import annotations

import functools
from dataclasses import dataclass
import time
from typing import Any

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

import json
import vertexai
from vertexai.generative_models import Content, GenerationConfig, GenerativeModel, Part

import structlog
from google import genai
from google.genai import types as gt

log = structlog.get_logger()

# ── Module-level caches — avoid repeated work on every request ────────────────
# vertexai.init() is idempotent but still runs Python code each call; guard it.
_VERTEX_INITIALIZED: set[tuple[str, str]] = set()
# google-genai Client objects (one per project/location pair)
_GENAI_CLIENTS: dict[tuple[str, str], Any] = {}


def _ensure_vertex_init(project: str, location: str) -> None:
    key = (project, location)
    if key not in _VERTEX_INITIALIZED:
        vertexai.init(project=project, location=location)
        _VERTEX_INITIALIZED.add(key)


@functools.lru_cache(maxsize=16)
def _cached_vertex_schema_for(schema_cls: type) -> dict:
    """Compute _to_vertex_schema once per Pydantic class; reuse on every request."""
    return _to_vertex_schema(schema_cls.model_json_schema())


@dataclass
class LLMResponse:
    content: str


class LLMService:
    def __init__(
        self,
        model: BaseChatModel | None = None,
        *,
        vertex_config: dict | None = None,
    ) -> None:
        self._model = model
        self._vertex_config = vertex_config

    async def chat(
        self,
        system: str,
        user: str,
        max_tokens: int = 1024,
        temperature: float = 0.1,
        top_p: float | None = None,
        top_k: int | None = None,
        seed: int | None = None,
    ) -> LLMResponse:
        """Single-turn: one system prompt + one user message (free-form text response).

        top_p, top_k, seed are forwarded to provider-native calls.
        seed is Vertex AI only — silently ignored by Anthropic.
        """
        messages = [{"role": "user", "content": user}]

        result = await _anthropic_direct(
            self._model, system=system, messages=messages,
            max_tokens=max_tokens, temperature=temperature,
            top_p=top_p, top_k=top_k,
        )
        if result is None:
            result = await _vertex_direct(
                self._vertex_config, system=system, messages=messages,
                max_tokens=max_tokens, temperature=temperature,
                top_p=top_p, top_k=top_k, seed=seed,
            )
        if result is not None:
            return result

        # LangChain fallback (OpenAI / other providers)
        lc_messages: list[Any] = []
        if system:
            lc_messages.append(SystemMessage(content=system))
        lc_messages.append(HumanMessage(content=user))

        response = await self._model.ainvoke(  # type: ignore[union-attr]
            lc_messages, max_tokens=max_tokens, temperature=temperature
        )
        return LLMResponse(content=_extract_content(response.content))

    async def chat_structured(
        self,
        system: str,
        user: str,
        schema: type,
        max_tokens: int = 8000,
        temperature: float = 0.1,
    ) -> Any:
        """
        Structured output returning a Pydantic model instance.
        - Vertex AI: direct SDK call with response_schema (LangChain loses nullable info)
        - Anthropic / OpenAI: LangChain with_structured_output(method="function_calling")
        Returns a Pydantic model instance; caller uses .model_dump(mode="json") as needed.
        """
        if self._vertex_config:
            return await _vertex_structured(
                self._vertex_config,
                system=system, user=user, schema=schema,
                max_tokens=max_tokens, temperature=temperature,
            )
        lc_model = self._resolve_lc_model(max_tokens=max_tokens, temperature=temperature)
        structured = lc_model.with_structured_output(schema, method="function_calling")
        lc_messages: list[Any] = []
        if system:
            lc_messages.append(SystemMessage(content=system))
        lc_messages.append(HumanMessage(content=user))
        return await structured.ainvoke(lc_messages)

    def _resolve_lc_model(self, *, max_tokens: int, temperature: float) -> Any:
        """Return a LangChain chat model ready for structured output calls."""
        if self._model is not None:
            # Anthropic → ChatAnthropic.bind(...)
            # OpenAI   → ChatOpenAI.bind(...)
            return self._model.bind(max_tokens=max_tokens, temperature=temperature)
        if self._vertex_config:
            # ChatVertexAI is deprecated since langchain-google-vertexai 3.2.0.
            # Use ChatGoogleGenerativeAI(vertexai=True) — the current non-deprecated replacement.
            from langchain_google_genai import ChatGoogleGenerativeAI
            vc = self._vertex_config
            return ChatGoogleGenerativeAI(
                model=vc["model"],
                project=vc["project"],
                location=vc["location"],
                vertexai=True,
                max_tokens=max_tokens,
                temperature=temperature,
            )
        raise RuntimeError("No LLM model configured")

    async def chat_with_history(
        self,
        system: str,
        messages: list[dict[str, str]],
        max_tokens: int = 1024,
        temperature: float = 0.1,
    ) -> LLMResponse:
        """
        Multi-turn: system prompt + existing conversation history.
        messages format: [{"role": "user"|"assistant", "content": str}, ...]
        """
        result = await _anthropic_direct(
            self._model, system=system, messages=messages,
            max_tokens=max_tokens, temperature=temperature,
        )
        if result is None:
            result = await _vertex_direct(
                self._vertex_config, system=system, messages=messages,
                max_tokens=max_tokens, temperature=temperature,
            )
        if result is not None:
            return result

        # LangChain fallback (OpenAI / other providers)
        lc_messages: list[Any] = []
        if system:
            lc_messages.append(SystemMessage(content=system))
        for m in messages:
            if m.get("role") == "user":
                lc_messages.append(HumanMessage(content=str(m.get("content", ""))))
            else:
                lc_messages.append(AIMessage(content=str(m.get("content", ""))))
        response = await self._model.ainvoke(  # type: ignore[union-attr]
            lc_messages, max_tokens=max_tokens, temperature=temperature
        )
        return LLMResponse(content=_extract_content(response.content))


# ── Provider-specific direct callers ─────────────────────────────────────────

async def _anthropic_direct(
    model: BaseChatModel | None,
    *,
    system: str,
    messages: list[dict[str, str]],
    max_tokens: int,
    temperature: float,
    top_p: float | None = None,
    top_k: int | None = None,
) -> LLMResponse | None:
    """
    Call the Anthropic SDK directly via ChatAnthropic's cached _async_client.

    Bypasses langchain_anthropic's _agenerate → _acreate → messages.create chain
    which fails on langchain-anthropic 1.4.x + anthropic 0.111.x + Python 3.12/3.14.
    Returns None if the model is not ChatAnthropic so callers fall back.

    For structured output, use LLMService.chat_structured() instead — it routes through
    LangChain ChatAnthropic.with_structured_output(method="function_calling").
    """
    async_client = getattr(model, "_async_client", None)
    model_name: str | None = getattr(model, "model", None)
    if async_client is None or model_name is None:
        return None

    api_messages = [
        {"role": m.get("role", "user"), "content": str(m.get("content", ""))}
        for m in messages
    ]

    create_kwargs: dict = dict(
        model=model_name,
        max_tokens=max_tokens,
        temperature=temperature,
        system=system or "",
        messages=api_messages,
    )
    if top_p is not None:
        create_kwargs["top_p"] = top_p
    if top_k is not None:
        create_kwargs["top_k"] = top_k

    t0 = time.perf_counter()
    response = await async_client.messages.create(**create_kwargs)
    llm_ms = round((time.perf_counter() - t0) * 1000)

    usage = getattr(response, "usage", None)
    log.info(
        "llm.usage",
        provider="anthropic",
        model=model_name,
        prompt_tokens=getattr(usage, "input_tokens", None),
        candidate_tokens=getattr(usage, "output_tokens", None),
        thinking_tokens=None,
        llm_ms=llm_ms,
    )

    text = ""
    for block in response.content:
        if hasattr(block, "text"):
            text += block.text
    return LLMResponse(content=text)


_VERTEX_DROP_KEYS = frozenset({"title", "default", "examples", "additionalProperties", "$schema", "$defs"})


def _to_vertex_schema(schema: dict, defs: dict | None = None) -> dict:
    """
    Convert a Pydantic v2 JSON schema to Vertex AI / Gemini OpenAPI 3.0 format.
    Three transforms applied recursively:
    1. Resolve $ref → inline definitions from $defs
    2. Convert anyOf: [{type: X}, {type: null}] → {type: X, nullable: true}
    3. Strip keys Gemini rejects (title, default, additionalProperties, $defs, etc.)
    """
    if defs is None:
        defs = schema.get("$defs", {})

    # Resolve $ref before anything else
    if "$ref" in schema:
        ref_name = schema["$ref"].split("/")[-1]  # "#/$defs/BEXLineItem" → "BEXLineItem"
        return _to_vertex_schema(defs.get(ref_name, {}), defs)

    # Collapse Optional[X] → {type: X, nullable: true}
    if "anyOf" in schema:
        non_null = [s for s in schema["anyOf"] if s.get("type") != "null"]
        has_null = any(s.get("type") == "null" for s in schema["anyOf"])
        if len(non_null) == 1 and has_null:
            inner = _to_vertex_schema(non_null[0], defs)
            inner["nullable"] = True
            return inner

    result = {k: v for k, v in schema.items() if k not in _VERTEX_DROP_KEYS}

    if "properties" in result:
        result["properties"] = {
            k: _to_vertex_schema(v, defs) for k, v in result["properties"].items()
        }
    if "items" in result:
        result["items"] = _to_vertex_schema(result["items"], defs)

    return result


async def _vertex_direct(
    config: dict | None,
    *,
    system: str,
    messages: list[dict[str, str]],
    max_tokens: int,
    temperature: float,
    top_p: float | None = None,
    top_k: int | None = None,
    seed: int | None = None,
) -> LLMResponse | None:
    """
    Call Vertex AI for free-form text responses.
    Returns None if no vertex_config is set.

    Primary path: google-genai SDK — ThinkingConfig(thinking_budget=0) actually works here.
    Fallback: old vertexai SDK — thinking cannot be disabled there; use only if google-genai unavailable.
    """
    if not config:
        return None

    # ── Primary: google-genai SDK (ThinkingConfig works here) ─────────────────
    try:
        key = (config["project"], config["location"])
        if key not in _GENAI_CLIENTS:
            _GENAI_CLIENTS[key] = genai.Client(
                vertexai=True,
                project=config["project"],
                location=config["location"],
            )
        client = _GENAI_CLIENTS[key]

        # google-genai uses gt.Content/gt.Part for multi-turn
        contents = [
            gt.Content(
                role="model" if m.get("role") == "assistant" else "user",
                parts=[gt.Part(text=str(m.get("content", "")))],
            )
            for m in messages
        ]

        cfg_kwargs: dict = {
            "system_instruction": system or None,
            "temperature": temperature,
            "max_output_tokens": max_tokens,
            "thinking_config": gt.ThinkingConfig(thinking_budget=0),
        }
        if top_p is not None:
            cfg_kwargs["top_p"] = top_p
        if top_k is not None:
            cfg_kwargs["top_k"] = top_k
        if seed is not None:
            cfg_kwargs["seed"] = seed

        t0 = time.perf_counter()
        response = await client.aio.models.generate_content(
            model=config["model"],
            contents=contents,
            config=gt.GenerateContentConfig(**cfg_kwargs),
        )
        llm_ms = round((time.perf_counter() - t0) * 1000)

        um = getattr(response, "usage_metadata", None)
        log.info(
            "llm.usage",
            provider="google-genai",
            model=config["model"],
            prompt_tokens=getattr(um, "prompt_token_count", None),
            candidate_tokens=getattr(um, "candidates_token_count", None),
            thinking_tokens=getattr(um, "thoughts_token_count", None),
            llm_ms=llm_ms,
        )

        try:
            text = response.text or ""
        except (ValueError, AttributeError):
            text = ""
        return LLMResponse(content=text)

    except ImportError:
        pass  # google-genai not installed — fall through to old SDK

    # ── Fallback: old vertexai.generative_models SDK ───────────────────────────
    # Thinking cannot be disabled here — GenerationConfig does not accept thinking_config.
    _ensure_vertex_init(config["project"], config["location"])

    model = GenerativeModel(
        config["model"],
        system_instruction=system or None,
    )

    # Use Content/Part SDK objects — raw dicts cause protobuf int() coercion errors
    contents_legacy = [
        Content(
            role="model" if m.get("role") == "assistant" else "user",
            parts=[Part.from_text(text=str(m.get("content", "")))],
        )
        for m in messages
    ]

    gen_kwargs: dict = {
        "temperature": temperature,
        "max_output_tokens": max_tokens,
    }
    if top_p is not None:
        gen_kwargs["top_p"] = top_p
    if top_k is not None:
        gen_kwargs["top_k"] = top_k
    if seed is not None:
        gen_kwargs["seed"] = seed

    t0 = time.perf_counter()
    response = await model.generate_content_async(
        contents_legacy,
        generation_config=GenerationConfig(**gen_kwargs),
    )
    llm_ms = round((time.perf_counter() - t0) * 1000)

    um = getattr(response, "usage_metadata", None)
    log.info(
        "llm.usage",
        provider="vertexai",
        model=config["model"],
        prompt_tokens=getattr(um, "prompt_token_count", None),
        candidate_tokens=getattr(um, "candidates_token_count", None),
        thinking_tokens=getattr(um, "thoughts_token_count", None),
        llm_ms=llm_ms,
    )

    try:
        text = response.text
    except (ValueError, AttributeError):
        text = ""
    return LLMResponse(content=text)


async def _vertex_structured(
    config: dict,
    *,
    system: str,
    user: str,
    schema: type,
    max_tokens: int,
    temperature: float,
) -> Any:
    """
    Structured output for Vertex AI / Gemini via direct SDK + response_schema.

    Primary path: google-genai SDK — has working ThinkingConfig (disables thinking tokens,
    which Gemini 2.5 Flash runs by default and adds 2-10s of hidden latency).
    Fallback: old vertexai.generative_models SDK (thinking cannot be disabled there).

    Perf fixes vs. original:
    - vertexai.init() guarded — only runs once per project/location
    - schema conversion cached per Pydantic class via lru_cache
    - ThinkingConfig actually applied via google-genai (was silently failing before)
    """
    # ── Primary: google-genai SDK (ThinkingConfig works here) ─────────────────
    try:

        key = (config["project"], config["location"])
        if key not in _GENAI_CLIENTS:
            _GENAI_CLIENTS[key] = genai.Client(
                vertexai=True,
                project=config["project"],
                location=config["location"],
            )
        client = _GENAI_CLIENTS[key]

        # Schema cached per class — not recomputed on every request
        vertex_schema = _cached_vertex_schema_for(schema)

        t0 = time.perf_counter()
        response = await client.aio.models.generate_content(
            model=config["model"],
            contents=user,
            config=gt.GenerateContentConfig(
                system_instruction=system or None,
                temperature=temperature,
                max_output_tokens=max_tokens,
                response_mime_type="application/json",
                response_schema=vertex_schema,
                thinking_config=gt.ThinkingConfig(thinking_budget=0),
                automatic_function_calling=gt.AutomaticFunctionCallingConfig(disable=True),
            ),
        )
        llm_ms = round((time.perf_counter() - t0) * 1000)

        um = getattr(response, "usage_metadata", None)
        log.info(
            "llm.usage",
            provider="google-genai",
            model=config["model"],
            prompt_tokens=getattr(um, "prompt_token_count", None),
            candidate_tokens=getattr(um, "candidates_token_count", None),
            thinking_tokens=getattr(um, "thoughts_token_count", None),
            llm_ms=llm_ms,
        )

        raw = response.text or ""
        try:
            return schema.model_validate(json.loads(raw))
        except (json.JSONDecodeError, ValueError) as exc:
            snippet = raw[:200]
            raise ValueError(
                f"Vertex AI returned malformed JSON (response truncated?): {exc} — "
                f"first 200 chars: {snippet!r}"
            ) from exc

    except ImportError:
        pass  # google-genai not installed — fall through to old SDK

    # ── Fallback: old vertexai.generative_models SDK ───────────────────────────
    # Install google-genai to use the primary path.
    _ensure_vertex_init(config["project"], config["location"])
    model = GenerativeModel(config["model"], system_instruction=system or None)

    vertex_schema = _cached_vertex_schema_for(schema)
    contents = [Content(role="user", parts=[Part.from_text(text=user)])]

    gen_kwargs: dict = {
        "temperature": temperature,
        "max_output_tokens": max_tokens,
        "response_mime_type": "application/json",
        "response_schema": vertex_schema,
    }
    try:
        from vertexai.generative_models import ThinkingConfig
        gen_kwargs["thinking_config"] = ThinkingConfig(thinking_budget=0)
    except (ImportError, TypeError, Exception):
        pass  # Older SDK without ThinkingConfig — skip silently

    t0 = time.perf_counter()
    response = await model.generate_content_async(
        contents,
        generation_config=GenerationConfig(**gen_kwargs),
    )
    llm_ms = round((time.perf_counter() - t0) * 1000)

    um = getattr(response, "usage_metadata", None)
    log.info(
        "llm.usage",
        provider="vertexai-fallback",
        model=config["model"],
        prompt_tokens=getattr(um, "prompt_token_count", None),
        candidate_tokens=getattr(um, "candidates_token_count", None),
        thinking_tokens=getattr(um, "thoughts_token_count", None),
        llm_ms=llm_ms,
    )

    try:
        return schema.model_validate(json.loads(response.text))
    except (json.JSONDecodeError, ValueError) as exc:
        snippet = (response.text or "")[:200]
        raise ValueError(
            f"Vertex AI returned malformed JSON (response truncated?): {exc} — "
            f"first 200 chars: {snippet!r}"
        ) from exc


# ── Helpers ───────────────────────────────────────────────────────────────────

def _extract_content(raw: Any) -> str:
    """Normalise AIMessage.content to a plain string (handles list-of-blocks format)."""
    if isinstance(raw, str):
        return raw
    if isinstance(raw, list):
        parts = []
        for block in raw:
            if isinstance(block, dict):
                parts.append(block.get("text") or block.get("content") or str(block))
            else:
                parts.append(str(block))
        return "".join(parts)
    return str(raw)
