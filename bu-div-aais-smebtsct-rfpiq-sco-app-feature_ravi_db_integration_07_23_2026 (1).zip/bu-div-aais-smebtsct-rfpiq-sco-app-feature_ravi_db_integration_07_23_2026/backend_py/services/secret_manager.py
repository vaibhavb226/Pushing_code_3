"""
GCP Secret Manager loader.

Called once from get_settings() before Settings() is instantiated.
Fetches secrets by name and injects them as os.environ entries so that
pydantic-settings picks them up with higher priority than the .env file.
Secrets not found in Secret Manager are silently skipped — .env fallback applies.
"""
from __future__ import annotations

import logging
import os

log = logging.getLogger(__name__)

# Settings field names (uppercased env var names) that may be stored in
# Secret Manager. Add any new sensitive field here to enable SM overrides.
_SECRET_NAMES = [
    "ANTHROPIC_API_KEY",
    "MS_TENANT_ID",
    "MS_CLIENT_ID",
    "MS_CLIENT_SECRET",
    "DB_USER",
    "DB_PASS",
]


def load_gcp_secrets_to_env(project_id: str) -> None:
    """
    Fetch secrets from GCP Secret Manager and inject into os.environ.

    For each name in _SECRET_NAMES:
      - If the secret exists in SM → os.environ[name] = value  (overrides .env)
      - If the secret does not exist (NOT_FOUND) → skip silently (.env fallback)
      - On any other error → log a warning, continue

    If the SM client cannot be initialised at all (no credentials, network error,
    package not installed) → log a warning and return; all values come from .env.
    """
    try:
        from google.cloud import secretmanager  # type: ignore[import-untyped]
    except ImportError:
        log.debug("google-cloud-secret-manager not installed — skipping Secret Manager")
        return

    try:
        client = secretmanager.SecretManagerServiceClient()
    except Exception as exc:
        log.warning("Secret Manager: client init failed, falling back to .env: %s", exc)
        return

    fetched = 0
    for name in _SECRET_NAMES:
        secret_path = f"projects/{project_id}/secrets/{name}/versions/latest"
        try:
            resp = client.access_secret_version(name=secret_path)
            value = resp.payload.data.decode("utf-8").strip()
            os.environ[name] = value
            fetched += 1
        except Exception as exc:
            err = str(exc)
            # NOT_FOUND / 404 means the secret simply isn't stored in SM — expected
            if "NOT_FOUND" not in err and "404" not in err:
                log.warning("Secret Manager: could not fetch %s: %s", name, exc)

    if fetched:
        log.info("Secret Manager: loaded %d secret(s) from project %s", fetched, project_id)
    else:
        log.debug("Secret Manager: no secrets found in project %s — using .env for all values", project_id)
