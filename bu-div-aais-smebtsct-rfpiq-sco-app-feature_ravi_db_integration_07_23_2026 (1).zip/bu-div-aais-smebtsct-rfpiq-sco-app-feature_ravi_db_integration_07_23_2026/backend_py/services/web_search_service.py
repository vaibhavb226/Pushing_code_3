from __future__ import annotations

import httpx
from fastapi import HTTPException

from config import get_settings

LANGSEARCH_URL = "https://api.langsearch.com/v1/web-search"


async def langsearch_search(
    query: str,
    count: int = 5,
    summary: bool = True,
) -> list[dict]:
    """Call LangSearch web search API.

    Returns a list of result dicts with keys: name, url, snippet, summary.
    Raises HTTPException(503) when API key is not configured.
    Raises HTTPException(502) on LangSearch API errors.
    """
    key = get_settings().langsearch_api_key.get_secret_value()
    if not key:
        raise HTTPException(503, detail="Web search is not configured (LANGSEARCH_API_KEY missing)")

    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(
                LANGSEARCH_URL,
                json={"query": query, "count": min(count, 10), "summary": summary},
                headers={
                    "Authorization": f"Bearer {key}",
                    "Content-Type": "application/json",
                },
            )
            r.raise_for_status()
    except httpx.HTTPStatusError as exc:
        raise HTTPException(502, detail=f"LangSearch API error: {exc.response.status_code}") from exc
    except httpx.RequestError as exc:
        raise HTTPException(502, detail=f"LangSearch request failed: {exc}") from exc

    return r.json().get("data", {}).get("webPages", {}).get("value", [])
