"""
Per-bid SSE client queue registry + global user location registry.

subscribe()            — called when a browser connects to GET /api/bids/{id}/stream
unsubscribe()          — called on disconnect (in the finally block of the SSE generator)
push()                 — called by pg_listener._on_notify() — sync, non-blocking
get_viewers()          — returns display names of all currently connected clients for a bid
update_user_location() — heartbeat call from presence router; upserts location + lastSeen
get_online_users()     — returns all users seen within the TTL window
cleanup_stale_users()  — evicts users whose lastSeen exceeds max_age; called on a 30s loop
"""
from __future__ import annotations

import asyncio
import time
from collections import defaultdict

# bid_id → list of asyncio.Queue (one per connected SSE client)
_channels: dict[str, list[asyncio.Queue]] = defaultdict(list)

# sessionId → {sessionId, name, bidId, tab, cellId, lastSeen}
# Multiple sessions per user are stored separately (same user, different browser tabs).
_user_locations: dict[str, dict] = {}


def subscribe(bid_id: str, user_name: str, session_id: str = "") -> asyncio.Queue:
    q: asyncio.Queue = asyncio.Queue(maxsize=64)
    q.user_name = user_name    # type: ignore[attr-defined]
    q.session_id = session_id  # type: ignore[attr-defined]  — used in presence.left events
    _channels[bid_id].append(q)
    return q


def unsubscribe(bid_id: str, q: asyncio.Queue) -> None:
    try:
        _channels[bid_id].remove(q)
    except ValueError:
        pass
    if not _channels.get(bid_id):
        _channels.pop(bid_id, None)


def push(bid_id: str, event: dict) -> None:
    """Sync, non-blocking — safe to call from asyncio callbacks."""
    for q in list(_channels.get(bid_id, [])):
        try:
            q.put_nowait(event)
        except asyncio.QueueFull:
            pass  # slow client — drop rather than block


def get_viewers(bid_id: str) -> list[str]:
    return [q.user_name for q in _channels.get(bid_id, [])]  # type: ignore[attr-defined]


# ── Global presence registry ──────────────────────────────────────────────────

def update_user_location(
    session_id: str,
    name: str,
    bid_id: str | None,
    tab: str | None,
    cell_id: str | None = None,
) -> None:
    """Upsert a session's location. Each browser tab has a unique session_id so the
    same user in multiple tabs appears as multiple separate entries."""
    key = session_id if session_id else name  # fall back to name for old clients
    _user_locations[key] = {
        "sessionId": key,
        "name": name,
        "bidId": bid_id,
        "tab": tab,
        "cellId": cell_id,
        "lastSeen": time.time(),
    }


def get_online_users(max_age: float = 60.0) -> list[dict]:
    """Return all sessions seen within the last max_age seconds (one entry per browser tab)."""
    cutoff = time.time() - max_age
    return [u for u in _user_locations.values() if u["lastSeen"] >= cutoff]


def cleanup_stale_users(max_age: float = 60.0) -> int:
    """Remove sessions whose lastSeen is older than max_age. Returns eviction count."""
    cutoff = time.time() - max_age
    stale = [sid for sid, u in _user_locations.items() if u["lastSeen"] < cutoff]
    for sid in stale:
        del _user_locations[sid]
    return len(stale)
