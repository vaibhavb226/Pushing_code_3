"""
Production-grade text chunker for document embedding.

Uses a recursive separator-based splitting approach:
  1. Split by paragraph breaks (\\n\\n) first for semantic cohesion
  2. Fall back to line breaks (\\n), then word boundaries ( ), then character splits
  3. Merge small pieces greedily back up to chunk_size
  4. Add context overlap between adjacent chunks so cross-boundary sentences are captured
  5. Prepend metadata header to each chunk so it is self-describing when returned in isolation

Produces chunks in the 600–950 char range (after header) suitable for
Google text-embedding-004 (optimal input: 300–500 tokens ≈ 1200–2000 chars for English).
"""
from __future__ import annotations

import re
from typing import Any

_SEPARATORS = ["\n\n", "\n", " "]

# ── Excel-aware chunker ───────────────────────────────────────────────────────


def chunk_excel_text(
    text: str,
    doc_metadata: dict,
    chunk_size: int = 800,
    min_chunk: int = 50,
) -> list[dict[str, Any]]:
    """Chunk Excel document text (output of _extract_excel) into row-keyed vector chunks.

    Each data row is serialized as 'Header1: val | Header2: val | ...' with column names
    prepended to every chunk so retrieval context is fully self-contained. No character
    overlap is used — row boundaries are atomic and must not be split. Blank rows and
    blank (header + value) column pairs are discarded.

    Args:
        text:          Raw output of _extract_excel: '=== Sheet: X ===\\ntab-delimited rows'
        doc_metadata:  Dict with keys: rfp_id, doc_type, file_name.
        chunk_size:    Max chars per chunk body (before header). 800 ≈ 200 tokens.
        min_chunk:     Minimum body length; shorter chunks are discarded.
    """
    if not text or not text.strip():
        return []

    rfp_id = doc_metadata.get("rfp_id", "")
    doc_type = doc_metadata.get("doc_type", "")
    file_name = doc_metadata.get("file_name", "")

    # Parse === Sheet: X === section markers produced by _extract_excel
    raw_parts = re.split(r"^=== Sheet: (.+?) ===$", text, flags=re.MULTILINE)
    sheet_pairs: list[tuple[str, str]] = []
    i = 1
    while i + 1 < len(raw_parts):
        sheet_pairs.append((raw_parts[i].strip(), raw_parts[i + 1]))
        i += 2
    if not sheet_pairs:
        # No markers found — treat entire text as a single unnamed sheet
        sheet_pairs = [("Sheet1", text)]

    pending: list[dict] = []  # accumulated chunks before final index assignment

    for sheet_name, body in sheet_pairs:
        # Keep only lines that have at least one non-blank cell
        raw_lines = [ln for ln in body.split("\n") if "".join(ln.split("\t")).strip()]
        if not raw_lines:
            continue

        # First non-empty line = header row
        header_cells = raw_lines[0].split("\t")
        headers: list[str] = [
            (c.strip() if c.strip() else f"Col_{j + 1}")
            for j, c in enumerate(header_cells)
        ]
        # Track which column positions had blank original headers (auto-assigned Col_N)
        generated_cols: set[int] = {j for j, c in enumerate(header_cells) if not c.strip()}

        data_lines = raw_lines[1:]
        if not data_lines:
            continue  # header-only sheet — nothing to embed

        # Format each data row as "Header1: val | Header2: val | ..."
        formatted: list[tuple[int, str]] = []  # (1-indexed data row num, formatted text)
        for row_num, line in enumerate(data_lines, start=1):
            cells = line.split("\t")
            row_parts: list[str] = []
            for j, val in enumerate(cells):
                if j >= len(headers):
                    headers.append(f"Col_{j + 1}")
                    generated_cols.add(j)
                v = val.strip()
                # Skip if header was auto-generated AND value is blank (pure empty column)
                if j in generated_cols and not v:
                    continue
                h = headers[j]
                row_parts.append(f"{h}: {v}" if v else f"{h}: —")
            if row_parts:
                formatted.append((row_num, " | ".join(row_parts)))

        if not formatted:
            continue

        # Greedy row packing — no overlap (rows are atomic)
        curr_rows: list[str] = []
        curr_len = 0
        curr_start = formatted[0][0]
        curr_end = curr_start

        for row_num, row_str in formatted:
            sep = 1 if curr_rows else 0  # newline join overhead
            if curr_rows and curr_len + sep + len(row_str) > chunk_size:
                body_text = "\n".join(curr_rows)
                if len(body_text.strip()) >= min_chunk:
                    pending.append({
                        "sheet": sheet_name,
                        "row_start": curr_start,
                        "row_end": curr_end,
                        "body": body_text,
                    })
                curr_rows = [row_str]
                curr_len = len(row_str)
                curr_start = row_num
                curr_end = row_num
            else:
                curr_rows.append(row_str)
                curr_len += sep + len(row_str)
                curr_end = row_num

        if curr_rows:
            body_text = "\n".join(curr_rows)
            if len(body_text.strip()) >= min_chunk:
                pending.append({
                    "sheet": sheet_name,
                    "row_start": curr_start,
                    "row_end": curr_end,
                    "body": body_text,
                })

    if not pending:
        return []

    total = len(pending)
    result: list[dict[str, Any]] = []
    for chunk_idx, ch in enumerate(pending):
        sname = ch["sheet"]
        header = (
            f"[Bid: {rfp_id} | Type: {doc_type} | Src: {file_name}"
            f" | Sheet: {sname} | Rows: {ch['row_start']}-{ch['row_end']}"
            f" | Chunk {chunk_idx + 1}/{total}]"
        )
        result.append({
            "chunk_index": chunk_idx,
            "chunk_text": f"{header}\n{ch['body']}",
            "metadata": {
                "rfp_id": rfp_id,
                "doc_type": doc_type,
                "file_name": file_name,
                "sheet_name": sname,
                "row_start": ch["row_start"],
                "row_end": ch["row_end"],
                "chunk_index": chunk_idx,
                "total_chunks": total,
            },
        })

    return result


# ── Generic text chunker ──────────────────────────────────────────────────────


def _split_to_atoms(text: str, chunk_size: int) -> list[str]:
    """Recursively split text into pieces at natural boundaries.

    Returns a list where every piece fits within chunk_size.
    Tries the softest boundary first (paragraph), falling back to harder
    splits only when needed. Last resort is character split.
    """
    if len(text) <= chunk_size:
        return [text]

    for sep in _SEPARATORS:
        if sep not in text:
            continue
        parts = [p.strip() for p in text.split(sep) if p.strip()]
        if not parts:
            continue
        # Only commit to this separator if it actually helps
        if all(len(p) > chunk_size for p in parts):
            continue  # every part is still too long — try a harder split
        result: list[str] = []
        for p in parts:
            if len(p) <= chunk_size:
                result.append(p)
            else:
                result.extend(_split_to_atoms(p, chunk_size))
        return result

    # Last resort: hard character split
    return [text[i:i + chunk_size] for i in range(0, len(text), chunk_size)]


def _merge_and_overlap(atoms: list[str], chunk_size: int, overlap: int) -> list[str]:
    """Greedily merge atoms into target-sized chunks with trailing context overlap.

    Overlap is taken from the tail of the previous chunk and prepended to the next,
    giving the embedding model cross-boundary context.
    """
    if not atoms:
        return []

    chunks: list[str] = []
    current_parts: list[str] = []
    current_len: int = 0

    for atom in atoms:
        atom_len = len(atom)
        sep_len = 1 if current_parts else 0  # newline join overhead

        if current_len + sep_len + atom_len <= chunk_size:
            current_parts.append(atom)
            current_len += sep_len + atom_len
        else:
            if current_parts:
                chunks.append("\n".join(current_parts))
            # Start next chunk; carry context from the tail of the previous chunk
            if chunks and overlap:
                tail = chunks[-1][-overlap:]
                current_parts = [tail, atom]
                current_len = len(tail) + 1 + atom_len
            else:
                current_parts = [atom]
                current_len = atom_len

    if current_parts:
        chunks.append("\n".join(current_parts))

    return chunks


def chunk_text(
    text: str,
    doc_metadata: dict,
    chunk_size: int = 800,
    overlap: int = 150,
    min_chunk: int = 50,
) -> list[dict[str, Any]]:
    """Split document text into overlapping chunks with metadata headers.

    Args:
        text:          Full extracted document text (no char limit applied).
        doc_metadata:  Dict with keys: rfp_id, doc_type, file_name.
        chunk_size:    Target max chars per chunk body (before header). 800 ≈ 200 tokens.
        overlap:       Chars of previous chunk carried forward as context prefix.
        min_chunk:     Minimum body length; shorter chunks are discarded.

    Returns:
        List of dicts: {chunk_index: int, chunk_text: str, metadata: dict}.
        chunk_text includes a prepended header line:
            "[Bid: X | Type: Y | Src: Z | Chunk n/N]"
    """
    if not text or not text.strip():
        return []

    rfp_id = doc_metadata.get("rfp_id", "")
    doc_type = doc_metadata.get("doc_type", "")
    file_name = doc_metadata.get("file_name", "")

    # Normalise whitespace: collapse 3+ blank lines → 2, collapse horizontal runs
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r"[ \t]+", " ", text).strip()

    atoms = _split_to_atoms(text, chunk_size)
    raw_chunks = _merge_and_overlap(atoms, chunk_size, overlap)

    # Discard chunks that are too short to be meaningful
    raw_chunks = [c for c in raw_chunks if len(c.strip()) >= min_chunk]

    if not raw_chunks:
        return []

    total = len(raw_chunks)
    result: list[dict[str, Any]] = []
    for idx, body in enumerate(raw_chunks):
        header = f"[Bid: {rfp_id} | Type: {doc_type} | Src: {file_name} | Chunk {idx + 1}/{total}]"
        result.append({
            "chunk_index": idx,
            "chunk_text": f"{header}\n{body}",
            "metadata": {
                "rfp_id": rfp_id,
                "doc_type": doc_type,
                "file_name": file_name,
                "chunk_index": idx,
                "total_chunks": total,
            },
        })

    return result
