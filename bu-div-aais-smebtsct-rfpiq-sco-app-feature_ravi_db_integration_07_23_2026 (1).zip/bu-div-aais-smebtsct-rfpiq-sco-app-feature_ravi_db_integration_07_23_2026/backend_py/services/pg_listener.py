"""
Dedicated long-lived PostgreSQL LISTEN connection for real-time bid events.

Uses a separate asyncpg.connect() (NOT the CRUD pool) so the LISTEN session
is never mixed with CRUD queries. Reconnects automatically on failure.

Works across multiple uvicorn workers / Cloud Run instances because PG is the
message broker — each process has its own listener and its own sse_broadcast
registry; pg_notify delivers to all.
"""
from __future__ import annotations

import asyncio
import json

import asyncpg
import structlog

from services.sse_broadcast import push

log = structlog.get_logger()


async def _run_listener(settings) -> None:
    while True:
        conn: asyncpg.Connection | None = None
        try:
            conn = await asyncpg.connect(
                host=settings.db_host,
                port=settings.db_port,
                database=settings.db_name,
                user=settings.db_user,
                password=settings.db_pass.get_secret_value(),
                ssl="require",
                command_timeout=30,
            )
            await conn.add_listener("bid_events", _on_notify)
            log.info("pg_listener.connected", host=settings.db_host)
            # Keep-alive: check every 10 s whether the connection is still alive
            while not conn.is_closed():
                await asyncio.sleep(10)
        except asyncio.CancelledError:
            break
        except Exception as exc:
            log.warning("pg_listener.reconnecting", error=str(exc))
        finally:
            if conn and not conn.is_closed():
                try:
                    await conn.close()
                except Exception:
                    pass
        await asyncio.sleep(5)  # backoff before reconnect


def _on_notify(conn: asyncpg.Connection, pid: int, channel: str, payload: str) -> None:
    try:
        event = json.loads(payload)
        bid_id = event.get("bidId")
        if bid_id:
            push(bid_id, event)
    except Exception:
        pass


def start_pg_listener(settings) -> asyncio.Task:
    """Fire-and-forget task — call once during lifespan startup."""
    return asyncio.create_task(_run_listener(settings))
