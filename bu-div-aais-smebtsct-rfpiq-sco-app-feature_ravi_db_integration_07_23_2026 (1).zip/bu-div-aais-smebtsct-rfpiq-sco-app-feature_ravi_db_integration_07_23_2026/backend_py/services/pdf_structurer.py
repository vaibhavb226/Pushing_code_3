"""
PDF structurer — structure-preserving text extraction for RFP PDFs.

For each page we opportunistically detect tables with PyMuPDF `page.find_tables()` and
emit them as tab-separated grids (preserving column alignment when items ARE tabular),
and we ALWAYS also include the page's plain `get_text("text")`. This means item lists
work whether they appear as a table or as aligned / free-form prose — the design never
depends on a table being found.

Reading is bounded by an optional character cap:
  * cap set   → read up to that many characters (deliberate bound for very large PDFs)
  * cap None  → read the ENTIRE PDF

`pages` is returned separately so the caller can chunk a large PDF by page and run
concurrent LLM calls instead of truncating.
"""
from __future__ import annotations

import asyncio
from dataclasses import dataclass, field

import structlog

log = structlog.get_logger()


@dataclass
class PdfExtractResult:
    text: str = ""                       # combined text (tables as TSV + prose), capped
    pages: list[str] = field(default_factory=list)  # per-page combined text (for chunking)
    truncated: bool = False              # True if a char cap cut the content


def _page_text(page) -> str:
    """Combine any detected tables (as TSV) with the page's plain text."""
    blocks: list[str] = []

    # Tables first — preserves column alignment where the item list is tabular.
    try:
        finder = page.find_tables()
        for t_idx, table in enumerate(getattr(finder, "tables", []) or []):
            try:
                grid = table.extract()
            except Exception:
                continue
            if not grid:
                continue
            rendered = "\n".join(
                "\t".join("" if c is None else str(c).strip() for c in row)
                for row in grid
            )
            blocks.append(f"[TABLE {t_idx + 1}]\n{rendered}")
    except Exception:
        # find_tables unavailable or failed — prose text below still covers items.
        pass

    prose = page.get_text("text") or ""
    if prose.strip():
        blocks.append(prose.strip())

    return "\n".join(blocks).strip()


def _extract(content: bytes, char_limit: int | None) -> PdfExtractResult:
    result = PdfExtractResult()
    try:
        import fitz  # PyMuPDF
    except Exception as exc:  # pragma: no cover
        log.warning("pdf_structurer.import_failed", error=str(exc))
        return result

    try:
        doc = fitz.open(stream=content, filetype="pdf")
    except Exception as exc:
        log.warning("pdf_structurer.open_failed", error=str(exc))
        return result

    try:
        collected: list[str] = []
        running = 0
        for i in range(len(doc)):
            page_txt = _page_text(doc[i])
            if not page_txt:
                continue
            result.pages.append(page_txt)
            if char_limit is not None:
                remaining = char_limit - running
                if remaining <= 0:
                    result.truncated = True
                    break
                if len(page_txt) > remaining:
                    collected.append(page_txt[:remaining])
                    running += remaining
                    result.truncated = True
                    break
            collected.append(page_txt)
            running += len(page_txt)
        result.text = "\n\n".join(collected).strip()
    finally:
        doc.close()

    log.info("pdf_structurer.done",
             pages=len(result.pages), chars=len(result.text), truncated=result.truncated)
    return result


async def extract_pdf_structured(content: bytes, char_limit: int | None) -> PdfExtractResult:
    """Async wrapper — runs the sync PyMuPDF extraction in a thread."""
    if not content:
        return PdfExtractResult()
    return await asyncio.to_thread(_extract, content, char_limit)
