"""
LangGraph node functions for RFP AIQ v3 — agentic ReAct loop.

Four nodes form a planner → agent ⟲ tool_executor → synthesize pipeline.

SSE queue is a contextvars.ContextVar so it propagates to all nodes without
polluting AgentState.
"""
from __future__ import annotations

import asyncio
import contextvars
from typing import Any

import structlog
from pydantic import BaseModel

from services.sql_agent.safety import validate_sql, auto_limit, format_results

log = structlog.get_logger()

# ── SSE queue context variable ────────────────────────────────────────────────
# Set by ai_chat.py before starting the graph; read by every node to emit events.
_sse_queue: contextvars.ContextVar[asyncio.Queue | None] = contextvars.ContextVar(
    "_sse_queue", default=None
)


def set_sse_queue(q: asyncio.Queue) -> contextvars.Token:
    return _sse_queue.set(q)


def reset_sse_queue(token: contextvars.Token) -> None:
    _sse_queue.reset(token)


async def _emit(event: dict) -> None:
    q = _sse_queue.get()
    if q is not None:
        await q.put(event)


async def _thinking_start(node: str, label: str) -> None:
    await _emit({"type": "thinking_start", "node": node, "label": label})


async def _thinking_content(text: str) -> None:
    await _emit({"type": "thinking_content", "text": text})


async def _thinking_end(node: str) -> None:
    await _emit({"type": "thinking_end", "node": node})


# ── Pydantic schemas for structured LLM output ───────────────────────────────

class Plan(BaseModel):
    steps: list[str]


class ToolCall(BaseModel):
    action: str   # "sql_query" | "vector_search"
    input: str


class AgentStep(BaseModel):
    thought: str
    calls: list[ToolCall]
    final_answer: str = ""   # non-Optional for Vertex AI compatibility


# ── Scratchpad formatter ──────────────────────────────────────────────────────

def _format_scratchpad(scratchpad: list[dict], max_result_chars: int = 3000) -> str:
    if not scratchpad:
        return "No tools used yet."
    parts = []
    for e in scratchpad:
        step_label = f"Step {e['step']}" + (f".{e['idx']}" if e.get("idx", 0) > 0 else "")
        parts.append(f"--- {step_label}: {e['action']} ---")
        parts.append(f"Input: {e['input'][:300]}")
        if e.get("error"):
            parts.append(f"Error: {e['error']}")
        elif e.get("result"):
            r = e["result"]
            parts.append(
                f"Result:\n{r[:max_result_chars]}"
                + ("...(truncated)" if len(r) > max_result_chars else "")
            )
        parts.append("")
    return "\n".join(parts)


# ── Private tool execution helpers ────────────────────────────────────────────

async def _run_sql(call: dict, pool: Any) -> dict:
    """Execute one SQL tool call. Returns {action, input, result?, error?}."""
    sql = call["input"]
    base = {"action": call["action"], "input": sql}

    if pool is None:
        return {**base, "error": "Database not connected"}

    try:
        async with pool.acquire() as conn:
            rows = await asyncio.wait_for(conn.fetch(sql), timeout=15.0)
        if not rows:
            return {**base, "result": "0 rows returned — no matching data found"}
        return {**base, "result": format_results(rows)}
    except asyncio.TimeoutError:
        return {**base, "error": "Query timed out after 15 seconds"}
    except Exception as exc:
        return {**base, "error": str(exc)}


async def _run_vector_search(call: dict) -> dict:
    """Execute one vector_search tool call. Returns {action, input, result?, error?}.

    Input is either:
      - a plain string (natural language query)
      - a JSON string: {"query": "...", "bid_id": "RFP-xxx"}  (bid-scoped search)
    """
    import json as _json

    from config import get_settings
    from db.connection import get_db_conn
    from repositories import vector_repo
    from services import embedding_service

    raw_input = call["input"]
    base = {"action": call["action"], "input": raw_input}

    # Parse optional bid_id from JSON input
    query = raw_input
    bid_id: str | None = None
    if isinstance(raw_input, str) and raw_input.strip().startswith("{"):
        try:
            parsed = _json.loads(raw_input)
            query = parsed.get("query", raw_input)
            bid_id = parsed.get("bid_id") or None
        except _json.JSONDecodeError:
            pass  # treat as plain string

    try:
        embedding = await embedding_service.embed_text(
            query, task_type="RETRIEVAL_QUERY", settings=get_settings()
        )
    except Exception as exc:
        return {**base, "error": f"Embedding failed: {exc}"}

    try:
        settings = get_settings()
        async with get_db_conn(settings) as conn:
            if conn is None:
                raise RuntimeError("No database connection — vector search unavailable")
            results = await vector_repo.search_documents(
                conn,
                query_embedding=embedding,
                top_k=8,
                bid_id=bid_id,
                similarity_threshold=0.50,
            )
    except Exception as exc:
        return {**base, "error": f"Document search failed: {exc}"}

    if not results:
        scope = f" for bid {bid_id}" if bid_id else ""
        return {**base, "result": f"No relevant document chunks found{scope} (similarity < 50%)"}

    # Group by source file for cleaner output
    by_source: dict[str, list] = {}
    for r in results:
        src = r.get("file_name") or "unknown"
        by_source.setdefault(src, []).append(r)

    sections = []
    for src, chunks in by_source.items():
        bid_label = chunks[0].get("bid_id", "N/A")
        doc_type = chunks[0].get("document_type", "")
        header = f"**{src}** (Bid: {bid_label}, Type: {doc_type})"
        body = "\n\n".join(
            f"[{c['similarity']:.0%} match] {c['chunk_text']}"
            for c in chunks
        )
        sections.append(f"{header}\n{body}")

    formatted = "\n\n---\n\n".join(sections)
    return {
        **base,
        "result": f"{len(results)} chunk(s) from {len(by_source)} file(s):\n\n{formatted}",
    }


async def _run_one_call(call: dict, pool: Any) -> dict:
    """Dispatch a single tool call to the appropriate handler."""
    if call["action"] == "sql_query":
        return await _run_sql(call, pool)
    elif call["action"] == "vector_search":
        return await _run_vector_search(call)
    else:
        return {**call, "error": f"Unknown action: {call['action']}"}


# ── Node factory functions ────────────────────────────────────────────────────

def make_planner_node(llm):
    """Return a planner node that creates a brief execution plan."""

    async def planner(state: dict) -> dict:
        from config import get_settings
        from routers.prompts import AGENT_PLANNER_SYSTEM

        await _thinking_start("plan", "Building approach")

        query = state.get("query", "")

        try:
            result = await llm.chat_structured(
                system=AGENT_PLANNER_SYSTEM,
                user=f"Question: {query}",
                schema=Plan,
                max_tokens=get_settings().llm_max_tokens,
                temperature=0.0,
            )
            plan_text = "\n".join(f"{i + 1}. {s}" for i, s in enumerate(result.steps))
        except Exception as exc:
            log.warning("sql_agent.planner_failed", error=str(exc))
            plan_text = "1. Query the database for relevant data\n2. Answer the question"

        await _thinking_content(plan_text)
        await _thinking_end("plan")

        log.info("sql_agent.plan_created")
        return {"plan": plan_text, "scratchpad": [], "agent_step": 0}

    return planner


def make_agent_node(llm):
    """Return a ReAct agent node that decides what tool calls to make next."""

    async def agent(state: dict) -> dict:
        from config import get_settings
        from routers.prompts import AGENT_REACT_SYSTEM
        from services.sql_agent.schema import SCHEMA_SUMMARY

        query = state.get("query", "")
        plan = state.get("plan", "")
        scratchpad = list(state.get("scratchpad") or [])
        step_num = state.get("agent_step", 0) + 1
        messages = state.get("messages", [])

        scratchpad_text = _format_scratchpad(scratchpad)

        # Brief history snippet for multi-turn context
        history_snippet = ""
        for m in messages[-4:]:
            role = "User" if m.get("role") == "user" else "Assistant"
            history_snippet += f"{role}: {m.get('content', '')[:150]}\n"

        user_msg = (
            f"Question: {query}\n\n"
            f"Plan:\n{plan}\n\n"
            f"Steps so far:\n{scratchpad_text}\n\n"
            f"Step {step_num} of 8. What next?"
        )
        if history_snippet:
            user_msg = f"Chat context:\n{history_snippet}\n\n{user_msg}"

        system_with_schema = AGENT_REACT_SYSTEM.replace("{schema}", SCHEMA_SUMMARY)

        thought = ""
        final_answer = ""
        valid_calls = []

        try:
            result = await llm.chat_structured(
                system=system_with_schema,
                user=user_msg,
                schema=AgentStep,
                max_tokens=get_settings().llm_max_tokens,
                temperature=0.0,
            )
            thought = result.thought or ""
            final_answer = result.final_answer or ""
            raw_calls = result.calls or []

            # Validate SQL calls; drop invalid ones so agent can self-correct
            for c in raw_calls:
                if c.action == "sql_query":
                    try:
                        validate_sql(c.input)
                        safe_sql = auto_limit(c.input)
                        valid_calls.append({"action": c.action, "input": safe_sql})
                    except ValueError as ve:
                        scratchpad.append({
                            "step": step_num, "idx": len(valid_calls),
                            "action": c.action, "input": c.input,
                            "error": f"SQL safety check failed: {ve}",
                        })
                elif c.action == "vector_search":
                    valid_calls.append({"action": c.action, "input": c.input})

        except Exception as exc:
            log.warning("sql_agent.agent_step_failed", error=str(exc), step=step_num)
            thought = f"Error in agent step: {exc}"

        # Determine routing
        if final_answer:
            action = "final_answer"
        elif not valid_calls:
            # No valid calls and no final_answer — force final to avoid infinite loop
            action = "final_answer"
            final_answer = thought or "I was unable to retrieve data for this query."
        else:
            action = "tool"

        # Build thinking block content
        content_parts = [f"**Thought:** {thought}"]
        if valid_calls and action == "tool":
            calls_list = "\n".join(
                f"  {i + 1}. `{c['action']}`: {c['input'][:100]}"
                for i, c in enumerate(valid_calls)
            )
            content_parts.append(f"\n**Tool calls ({len(valid_calls)}):**\n{calls_list}")
        elif action == "final_answer":
            content_parts.append("\n*→ Composing final answer*")

        await _thinking_start("think", f"Step {step_num}: {thought[:55]}")
        await _thinking_content("\n".join(content_parts))
        await _thinking_end("think")

        log.info("sql_agent.agent_step", step=step_num, action=action, num_calls=len(valid_calls))
        return {
            "agent_step": step_num,
            "last_calls": valid_calls,
            "last_action": action,
            "last_action_input": final_answer,
            "scratchpad": scratchpad,
        }

    return agent


def make_tool_executor_node(pool):
    """Return a tool executor node that runs all tool calls in parallel."""

    async def tool_executor(state: dict) -> dict:
        calls = state.get("last_calls") or []
        scratchpad = list(state.get("scratchpad") or [])
        step_num = state.get("agent_step", 1)

        if not calls:
            return {"scratchpad": scratchpad}

        # Run all calls concurrently
        raw_results = await asyncio.gather(
            *[_run_one_call(c, pool) for c in calls],
            return_exceptions=True,
        )

        new_entries = []
        for idx, res in enumerate(raw_results):
            call = calls[idx]
            if isinstance(res, Exception):
                entry = {
                    "step": step_num, "idx": idx,
                    "action": call["action"], "input": call["input"],
                    "result": "", "error": str(res),
                }
            else:
                entry = {
                    "step": step_num, "idx": idx,
                    "action": res.get("action", call["action"]),
                    "input": res.get("input", call["input"]),
                    "result": res.get("result", ""),
                    "error": res.get("error", ""),
                }
            new_entries.append(entry)

        # Emit one thinking block per result sequentially (after all parallel calls complete)
        for entry in new_entries:
            is_sql = entry["action"] == "sql_query"
            node_key = "query" if is_sql else "search"
            error = entry.get("error", "")
            result = entry.get("result", "")

            if error:
                label = f"{'SQL' if is_sql else 'Documents'} · Error"
                content = f"```\n{error}\n```"
            elif result.startswith("0 rows"):
                label = "SQL · 0 rows"
                content = result
            else:
                label = f"{'SQL' if is_sql else 'Documents'} · results"
                content = result[:600] + ("..." if len(result) > 600 else "")

            await _thinking_start(node_key, label)
            await _thinking_content(content)
            await _thinking_end(node_key)

        scratchpad.extend(new_entries)
        log.info("sql_agent.tools_executed", count=len(new_entries), step=step_num)
        return {"scratchpad": scratchpad}

    return tool_executor


def make_synthesize_node(llm):
    """Return a synthesize node that streams the final response as SSE tokens."""

    async def synthesize_response(state: dict) -> dict:
        from config import get_settings
        from routers.prompts import SQL_SYNTHESIS_SYSTEM

        last_action = state.get("last_action", "tool")
        last_action_input = state.get("last_action_input", "")
        scratchpad = state.get("scratchpad") or []
        query = state.get("query", "")
        messages = state.get("messages", [])

        if last_action == "final_answer" and last_action_input:
            # Fast path — stream the agent's final answer directly (no extra LLM call)
            response_text = last_action_input
        else:
            # Slow path (max steps hit) — synthesize from scratchpad via LLM
            context = _format_scratchpad(scratchpad, max_result_chars=5000)
            synthesis_user = (
                f"All data gathered:\n{context}\n\n"
                f"Question: {query}\n\n"
                "Please synthesize a complete answer from the data above."
            )
            history_for_llm = messages[:-1]
            try:
                result = await llm.chat_with_history(
                    system=SQL_SYNTHESIS_SYSTEM,
                    messages=[*history_for_llm, {"role": "user", "content": synthesis_user}],
                    max_tokens=get_settings().llm_max_tokens,
                    temperature=0.0,
                )
                response_text = result.content
            except Exception as exc:
                log.error("sql_agent.synthesize_failed", error=str(exc))
                response_text = (
                    f"I encountered an error while preparing the answer: {exc}. "
                    "Please try rephrasing your question."
                )

        # Stream as SSE token events
        q = _sse_queue.get()
        if q is not None:
            chunk_size = 40
            for i in range(0, len(response_text), chunk_size):
                await q.put({"type": "token", "text": response_text[i:i + chunk_size]})
                await asyncio.sleep(0)

        log.info("sql_agent.synthesized", chars=len(response_text))
        return {"final_response": response_text}

    return synthesize_response
