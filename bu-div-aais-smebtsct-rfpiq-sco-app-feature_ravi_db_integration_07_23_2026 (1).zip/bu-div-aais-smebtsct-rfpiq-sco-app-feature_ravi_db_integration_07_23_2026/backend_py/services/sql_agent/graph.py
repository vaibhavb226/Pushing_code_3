"""
LangGraph StateGraph for RFP AIQ v3 — agentic ReAct loop.

State flow:
  planner → agent → execute_tool → agent (loop) ... → synthesize → END

The agent loop runs until it sets last_action="final_answer" or hits MAX_AGENT_STEPS.
The compiled graph is a module-level singleton (_GRAPH) built at startup via
init_sql_agent_graph(). Thread-safe — ainvoke() creates independent state per call.

AgentState must be at module level so LangGraph's get_type_hints() can resolve it.
(from __future__ import annotations stores annotations as strings; resolving them
 requires the name to be in the module's global namespace.)
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any, TypedDict

import structlog

if TYPE_CHECKING:
    from services.llm.provider import LLMService
    import asyncpg

log = structlog.get_logger()

_GRAPH: Any = None

MAX_AGENT_STEPS = 8


class AgentState(TypedDict, total=False):
    messages: list[dict]       # conversation history from frontend
    query: str                 # current user question
    plan: str                  # planner output (numbered steps)
    scratchpad: list[dict]     # [{step, idx, action, input, result?, error?}] — grows per step
    agent_step: int            # loop iteration count; ceiling MAX_AGENT_STEPS
    last_calls: list[dict]     # [{action, input}] from latest AgentStep (for tool executor)
    last_action: str           # "tool" | "final_answer" (routing signal)
    last_action_input: str     # final answer text (when last_action == "final_answer")
    final_response: str        # streamed by synthesize node


def get_graph() -> Any:
    return _GRAPH


def init_sql_agent_graph() -> None:
    """Compile the agent graph at startup. Call once from main.py lifespan."""
    global _GRAPH
    try:
        from db.connection import get_asyncpg_pool
        from dependencies import get_llm_service

        llm = get_llm_service()
        pool = get_asyncpg_pool()

        _GRAPH = build_graph(llm=llm, pool=pool)
        log.info("sql_agent.graph_compiled")
        print("SQL Agent Graph: compiled (v3 agentic ReAct)")
    except Exception as exc:
        log.error("sql_agent.graph_compile_failed", error=str(exc))
        print(f"SQL Agent Graph: failed to compile — {exc}")


def build_graph(*, llm: Any, pool: Any) -> Any:
    """Build and compile the LangGraph StateGraph."""
    from langgraph.graph import StateGraph, END

    from services.sql_agent.nodes import (
        make_planner_node,
        make_agent_node,
        make_tool_executor_node,
        make_synthesize_node,
    )

    workflow = StateGraph(AgentState)

    # ── Register nodes ────────────────────────────────────────────────────────
    workflow.add_node("planner",      make_planner_node(llm))
    workflow.add_node("agent",        make_agent_node(llm))
    workflow.add_node("execute_tool", make_tool_executor_node(pool))
    workflow.add_node("synthesize",   make_synthesize_node(llm))

    # ── Entry point ───────────────────────────────────────────────────────────
    workflow.set_entry_point("planner")

    # ── planner → agent ───────────────────────────────────────────────────────
    workflow.add_edge("planner", "agent")

    # ── agent → routing ───────────────────────────────────────────────────────
    def route_after_agent(state: AgentState) -> str:
        action = state.get("last_action", "tool")
        step   = state.get("agent_step", 0)
        if action == "final_answer" or step >= MAX_AGENT_STEPS:
            return "synthesize"
        return "execute_tool"

    workflow.add_conditional_edges(
        "agent",
        route_after_agent,
        {
            "execute_tool": "execute_tool",
            "synthesize":   "synthesize",
        },
    )

    # ── execute_tool → agent (loop back) ─────────────────────────────────────
    workflow.add_edge("execute_tool", "agent")

    # ── synthesize → END ──────────────────────────────────────────────────────
    workflow.add_edge("synthesize", END)

    return workflow.compile()
