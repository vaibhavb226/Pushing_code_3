"""
SQL safety layer for the SQL agent.

validate_sql  — blocks DDL/DML and access to system tables
auto_limit    — appends LIMIT 200 if missing
format_results — converts asyncpg Record list to a markdown table string
"""
from __future__ import annotations

import re
from typing import Any

_BLOCKED_KEYWORDS = frozenset({
    "INSERT", "UPDATE", "DELETE", "DROP", "CREATE", "ALTER",
    "TRUNCATE", "GRANT", "REVOKE", "EXEC", "EXECUTE", "COPY",
    "VACUUM", "ANALYZE", "REINDEX", "CLUSTER",
})

_BLOCKED_SCHEMA_PREFIXES = ("pg_", "information_schema")

# Tables the SQL agent is allowed to query
ALLOWED_TABLES = frozenset({
    "rfps", "rfp_line_items", "rfp_solicited_suppliers",
    "email_threads", "suppliers", "customers",
    "bids", "bid_line_items", "submission_messages",
    "documents", "document_vectors",
    "poll_state",
})


def validate_sql(sql: str) -> None:
    """Raise ValueError if the SQL is not a safe read-only SELECT."""
    # Strip single-line comments before checking
    stripped = re.sub(r"--[^\n]*", " ", sql).strip()
    normalised = stripped.upper()

    tokens = normalised.split()
    if not tokens:
        raise ValueError("Empty SQL query")

    first_token = tokens[0]
    # WITH starts a CTE (Common Table Expression) — still a read-only SELECT overall.
    # The blocked-keywords scan below catches any DML (INSERT/UPDATE/DELETE) inside CTEs.
    if first_token not in ("SELECT", "WITH"):
        raise ValueError(f"Only SELECT queries allowed, got: {first_token!r}")

    for kw in _BLOCKED_KEYWORDS:
        if re.search(rf"\b{kw}\b", normalised):
            raise ValueError(f"Blocked keyword in query: {kw}")

    sql_lower = sql.lower()
    for prefix in _BLOCKED_SCHEMA_PREFIXES:
        if prefix in sql_lower:
            raise ValueError(f"Access to {prefix}* tables not allowed")


def auto_limit(sql: str) -> str:
    """Append LIMIT 100 if the query has no LIMIT clause."""
    stripped = sql.strip().rstrip(";")
    if re.search(r"\bLIMIT\b", stripped, re.IGNORECASE):
        return sql.strip()
    return stripped + " LIMIT 100"


def format_results(rows: list[Any]) -> str:
    """Format asyncpg Record list as a markdown table.

    Returns empty string for zero rows (caller handles no-rows case).
    """
    if not rows:
        return ""

    # asyncpg Records support .keys() via the record type
    try:
        cols = list(rows[0].keys())
    except AttributeError:
        # Fallback for plain dicts
        cols = list(rows[0].keys()) if rows else []

    if not cols:
        return ""

    header = " | ".join(cols)
    sep = " | ".join("---" for _ in cols)

    data_lines = []
    for row in rows:
        cells = []
        for c in cols:
            val = row[c]
            if val is None:
                cells.append("")
            elif isinstance(val, float):
                cells.append(f"{val:.4f}" if val != int(val) else str(int(val)))
            else:
                cells.append(str(val).replace("|", "\\|").replace("\n", " "))
        data_lines.append(" | ".join(cells))

    return "\n".join([header, sep] + data_lines)
