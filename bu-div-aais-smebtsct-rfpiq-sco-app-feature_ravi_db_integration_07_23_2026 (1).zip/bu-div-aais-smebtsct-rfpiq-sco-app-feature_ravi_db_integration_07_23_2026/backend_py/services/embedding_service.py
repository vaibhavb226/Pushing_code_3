"""
Text embedding service using Google Vertex AI text-embedding-004 (768 dims).
Used for supplier RAG matching — both indexing suppliers and embedding bid queries.

Reuses the google-genai client already cached in provider.py via the same
_GENAI_CLIENTS dict pattern (separate client instance here is fine; google-genai
Client objects are lightweight).
"""
from __future__ import annotations

from typing import Any

import structlog

log = structlog.get_logger()

_client: Any = None  # google.genai.Client


async def _get_client(settings) -> Any:
    global _client
    if _client is None:
        from google import genai
        _client = genai.Client(
            vertexai=True,
            project=settings.gcp_project,
            location=settings.gcp_location,
        )
    return _client


async def embed_text(text: str, *, task_type: str = "RETRIEVAL_DOCUMENT", settings=None) -> list[float]:
    """
    Return a 768-dim embedding vector for text.

    task_type:
      "RETRIEVAL_DOCUMENT" — use when indexing supplier profiles
      "RETRIEVAL_QUERY"    — use when embedding a bid query at search time
    """
    if settings is None:
        from config import get_settings
        settings = get_settings()

    from google.genai import types as gt
    client = await _get_client(settings)

    result = await client.aio.models.embed_content(
        model="text-embedding-004",
        contents=text,
        config=gt.EmbedContentConfig(task_type=task_type),
    )
    return result.embeddings[0].values


async def embed_texts(
    texts: list[str], *, task_type: str = "RETRIEVAL_DOCUMENT", settings=None
) -> list[list[float]]:
    """Batch variant of embed_text — one 768-dim vector per input text (order preserved)."""
    if not texts:
        return []
    if settings is None:
        from config import get_settings
        settings = get_settings()

    from google.genai import types as gt
    client = await _get_client(settings)

    result = await client.aio.models.embed_content(
        model="text-embedding-004",
        contents=texts,
        config=gt.EmbedContentConfig(task_type=task_type),
    )
    return [e.values for e in result.embeddings]


def supplier_to_text(supplier: dict) -> str:
    """Convert a supplier record to a dense text blob suitable for embedding."""
    parts = [f"Supplier name: {supplier.get('name', '')}"]

    if supplier.get("category"):
        parts.append(f"Category: {supplier['category']}")
    if supplier.get("subcategories"):
        parts.append(f"Subcategories: {', '.join(supplier['subcategories'])}")
    if supplier.get("segments"):
        parts.append(f"Serves segments: {', '.join(supplier['segments'])}")
    if supplier.get("tags"):
        parts.append(f"Compliance tags: {', '.join(supplier['tags'])}")
    if supplier.get("region"):
        parts.append(f"Region: {supplier['region']}")
    if supplier.get("notes"):
        parts.append(f"Notes: {supplier['notes']}")

    return ". ".join(parts)


def bid_context_to_text(
    *,
    customer_name: str = "",
    segment: str = "",
    compliance_flags: list[str] | None = None,
    item_categories: list[str] | None = None,
    top_line_items: list[str] | None = None,
) -> str:
    """Build a query text blob from bid context for embedding at search time."""
    parts: list[str] = []

    if customer_name:
        parts.append(f"Customer: {customer_name}")
    if segment:
        parts.append(f"Market segment: {segment}")
    if compliance_flags:
        parts.append(f"Compliance requirements: {', '.join(compliance_flags)}")
    if item_categories:
        parts.append(f"Item categories needed: {', '.join(item_categories)}")
    if top_line_items:
        parts.append(f"Key items: {'; '.join(top_line_items[:8])}")

    return ". ".join(parts)
