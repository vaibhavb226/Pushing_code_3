"""
Live document indexer: extract → chunk → embed → store in document_vectors.

Designed to be called as asyncio.ensure_future(index_document_background(...))
immediately after a document record is saved to the DB. Never raises — all errors
are logged so a background failure never surfaces to the user. Skips silently
when DB is not configured (JSON/local-dev mode).
"""
from __future__ import annotations

import asyncio
import time
from pathlib import Path
from typing import Any

import structlog

from services.document_chunker import chunk_text
from services.document_text import extract_full_text

log = structlog.get_logger()

_EMBED_BATCH_SIZE = 20   # max texts per Vertex AI embed_content call


async def _read_content(file_path: str, gcs_client: Any) -> bytes | None:
    """Read document bytes from a GCS URI or local path. Returns None on failure."""
    if file_path.startswith("gs://"):
        if gcs_client is None:
            log.warning("doc_indexer.no_gcs_client", path=file_path)
            return None
        try:
            # gs://bucket/object/path
            path_part = file_path[5:]
            bucket_name, _, object_name = path_part.partition("/")
            blob = gcs_client.bucket(bucket_name).blob(object_name)
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, blob.download_as_bytes)
        except Exception as exc:
            log.warning("doc_indexer.gcs_read_failed", path=file_path, error=str(exc))
            return None
    else:
        # Local path — may be relative (e.g. "uploads/file.pdf")
        p = Path(file_path)
        if not p.is_absolute():
            from dependencies import UPLOADS_DIR
            p = UPLOADS_DIR / p.name
        try:
            return await asyncio.to_thread(p.read_bytes)
        except Exception as exc:
            log.warning("doc_indexer.local_read_failed", path=str(p), error=str(exc))
            return None


def _parse_gcs_uri(file_path: str) -> tuple[str, str, str]:
    """Return (gcs_uri, bucket, object_name) from a file_path.

    For local paths, gcs_uri/bucket/object_name are all empty strings.
    """
    if file_path.startswith("gs://"):
        path_part = file_path[5:]
        bucket, _, obj = path_part.partition("/")
        return file_path, bucket, obj
    return "", "", ""


async def index_document_background(
    doc_record: dict,
    gcs_client: Any,
    settings: Any,
) -> None:
    """Fire-and-forget pipeline: extract → chunk → embed → store.

    Args:
        doc_record:  Document metadata record (id, filePath, bidId, documentType, fileName).
        gcs_client:  google.cloud.storage.Client or None (local dev).
        settings:    App settings (get_settings()).

    Never raises. All errors are logged at error/warning level.
    """
    t0 = time.time()
    doc_id = doc_record.get("id", "")
    rfp_id = doc_record.get("bidId") or doc_record.get("rfpId") or ""
    file_name = doc_record.get("fileName", "")
    doc_type = doc_record.get("documentType", "")
    file_path = doc_record.get("filePath", "")

    if not file_path:
        log.warning("doc_indexer.no_file_path", doc_id=doc_id)
        return

    try:
        # 1. Read raw bytes
        content = await _read_content(file_path, gcs_client)
        if not content:
            return

        # 2. Extract full text — no char limit (chunker handles sizing, not the extractor)
        suffix = Path(file_name).suffix if file_name else ".pdf"
        text = await extract_full_text(content, suffix=suffix)
        if not text or not text.strip():
            log.info("doc_indexer.empty_text", doc_id=doc_id, file=file_name)
            return

        # 3. Chunk — Excel uses structure-aware row chunker; all other types use generic splitter
        file_ext = Path(file_name).suffix.lower() if file_name else ""
        if file_ext in (".xlsx", ".xls"):
            from services.document_chunker import chunk_excel_text
            chunks = chunk_excel_text(
                text,
                {"rfp_id": rfp_id, "doc_type": doc_type, "file_name": file_name},
            )
        else:
            chunks = chunk_text(
                text,
                {"rfp_id": rfp_id, "doc_type": doc_type, "file_name": file_name},
            )
        if not chunks:
            log.info("doc_indexer.no_chunks", doc_id=doc_id)
            return

        # 4. Embed in batches (Vertex AI text-embedding-004, 768 dims)
        from services import embedding_service
        texts = [c["chunk_text"] for c in chunks]
        embeddings: list[list[float]] = []
        for i in range(0, len(texts), _EMBED_BATCH_SIZE):
            batch_embs = await embedding_service.embed_texts(
                texts[i:i + _EMBED_BATCH_SIZE],
                task_type="RETRIEVAL_DOCUMENT",
                settings=settings,
            )
            embeddings.extend(batch_embs)

        # 5. Upsert into document_vectors via SQLAlchemy/pgvector
        from db.connection import get_db_conn
        from repositories import vector_repo

        gcs_uri, bucket, object_name = _parse_gcs_uri(file_path)
        file_type = Path(file_name).suffix.lstrip(".").lower() if file_name else ""

        rows = [
            {
                "id":            f"{doc_id}::chunk:{chunk['chunk_index']}",
                "gcs_uri":       gcs_uri,
                "bucket":        bucket,
                "object_name":   object_name,
                "file_name":     file_name,
                "file_type":     file_type,
                "bid_id":        rfp_id,
                "document_id":   doc_id,
                "document_type": doc_type,
                "chunk_index":   chunk["chunk_index"],
                "chunk_text":    chunk["chunk_text"],
                "embedding":     emb,
                "metadata":      chunk.get("metadata", {}),
            }
            for chunk, emb in zip(chunks, embeddings)
        ]

        async with get_db_conn(settings) as conn:
            if conn is None:
                log.warning("doc_indexer.no_db_conn", doc_id=doc_id)
                return
            await vector_repo.upsert_document_chunks(conn, doc_id, rows)

        elapsed_ms = int((time.time() - t0) * 1000)
        log.info(
            "doc_indexer.indexed",
            doc_id=doc_id,
            rfp_id=rfp_id,
            chunks=len(chunks),
            elapsed_ms=elapsed_ms,
        )

    except Exception as exc:
        log.error("doc_indexer.failed", doc_id=doc_id, file=file_name, error=str(exc))


async def delete_document_index(doc_id: str, settings: Any) -> None:
    """Delete all vector chunks for a single document. Best-effort — errors are logged, not raised."""
    try:
        from db.connection import get_db_conn
        from repositories import vector_repo

        async with get_db_conn(settings) as conn:
            if conn is None:
                return
            deleted = await vector_repo.delete_document_chunks(conn, doc_id)
            log.info("doc_indexer.deleted", doc_id=doc_id, chunks_deleted=deleted)
    except Exception as exc:
        log.warning("doc_indexer.delete_failed", doc_id=doc_id, error=str(exc))


async def delete_bid_index(bid_id: str, settings: Any) -> None:
    """Delete ALL vector chunks for every document in a bid (called when a bid is deleted).

    Uses a single DELETE WHERE bid_id = :bid_id — no need to enumerate document IDs.
    Best-effort — errors are logged, not raised.
    """
    try:
        from db.connection import get_db_conn
        from repositories import vector_repo

        async with get_db_conn(settings) as conn:
            if conn is None:
                return
            deleted = await vector_repo.delete_bid_chunks(conn, bid_id)
            log.info("doc_indexer.bid_deleted", bid_id=bid_id, chunks_deleted=deleted)
    except Exception as exc:
        log.warning("doc_indexer.bid_delete_failed", bid_id=bid_id, error=str(exc))
