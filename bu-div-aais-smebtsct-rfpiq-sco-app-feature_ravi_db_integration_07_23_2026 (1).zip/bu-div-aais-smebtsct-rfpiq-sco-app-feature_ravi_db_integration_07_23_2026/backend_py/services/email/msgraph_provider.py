"""
Microsoft Graph API email provider.

Auth: MSAL client credentials flow (Azure AD app registration)
Send: POST /v1.0/users/{userId}/sendMail
Poll: GET  /v1.0/users/{userId}/mailFolders/Inbox/messages?$filter=receivedDateTime ge {lookback}
Read: PATCH /v1.0/users/{userId}/messages/{msgId}  → {"isRead": true}

Required env vars (all in config.py):
    MS_TENANT_ID, MS_CLIENT_ID, MS_CLIENT_SECRET, MS_MAILBOX_USER_ID
"""
from __future__ import annotations

import asyncio
import base64
import hashlib
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

import structlog

from .base import AbstractEmailService, EmailMessage, InboundEmail

log = structlog.get_logger()

_GRAPH_BASE = "https://graph.microsoft.com/v1.0"
_SCOPE = "https://graph.microsoft.com/.default"
_DEFAULT_LOOKBACK_HOURS = 72  # cold-start window when the poller passes no `since`
_MAX_MESSAGES = 200           # safety cap to prevent runaway pagination

# Inbound attachments are saved here so the /api/files/ endpoint can serve them
_UPLOADS_DIR = Path(__file__).parent.parent.parent / "uploads"


def _parse_antispam_headers(headers: list[dict[str, str]]) -> dict[str, str | int]:
    """Parse Exchange antispam headers into a structured dict.

    Sources:
    - X-Forefront-Antispam-Report: SCL (spam confidence level), SFV (verdict), CAT (category)
    - X-Microsoft-Antispam:        BCL (bulk complaint level)

    Returns an empty dict when neither header is present (e.g. local dev, no Graph headers).
    """
    result: dict[str, str | int] = {}
    header_map: dict[str, str] = {h.get("name", "").lower(): h.get("value", "") for h in headers}

    # ── X-Forefront-Antispam-Report ──────────────────────────────────────────
    # Format: "CIP:1.2.3.4;CTRY:US;SFV:SPM;SCL:9;CAT:SPM;"
    forefront = header_map.get("x-forefront-antispam-report", "")
    if forefront:
        parts: dict[str, str] = {}
        for segment in forefront.split(";"):
            if ":" in segment:
                k, _, v = segment.partition(":")
                parts[k.strip().upper()] = v.strip()

        if "SCL" in parts:
            try:
                result["scl"] = int(parts["SCL"])
            except ValueError:
                pass
        if "SFV" in parts:
            result["sfv"] = parts["SFV"]
        if "CAT" in parts:
            result["cat"] = parts["CAT"]

    # ── X-Microsoft-Antispam ─────────────────────────────────────────────────
    # Format: "BCL:4;"
    ms_antispam = header_map.get("x-microsoft-antispam", "")
    if ms_antispam:
        ms_parts: dict[str, str] = {}
        for segment in ms_antispam.split(";"):
            if ":" in segment:
                k, _, v = segment.partition(":")
                ms_parts[k.strip().upper()] = v.strip()
        if "BCL" in ms_parts:
            try:
                result["bcl"] = int(ms_parts["BCL"])
            except ValueError:
                pass

    # ── Synthesised verdict ───────────────────────────────────────────────────
    if result:
        cat = str(result.get("cat", ""))
        sfv = str(result.get("sfv", ""))
        scl = result.get("scl")
        bcl = result.get("bcl")

        if cat in ("PHISH", "HPHISH") or sfv in ("PHSH", "PHISH"):
            result["verdict"] = "phishing"
        elif cat == "MALW":
            result["verdict"] = "malware"
        elif cat == "BULK" or (isinstance(bcl, int) and bcl >= 7):
            result["verdict"] = "bulk"
        elif cat == "SPM" or sfv == "SPM" or (isinstance(scl, int) and scl >= 5):
            result["verdict"] = "spam"
        else:
            result["verdict"] = "clean"

    return result


class MsGraphEmailService(AbstractEmailService):
    def __init__(
        self,
        tenant_id: str,
        client_id: str,
        client_secret: str,
        mailbox_user_id: str,
        poll_lookback_hours: int = _DEFAULT_LOOKBACK_HOURS,
        gcs_client: object | None = None,
        gcs_bucket: str = "",
    ) -> None:
        self._tenant_id = tenant_id
        self._client_id = client_id
        self._client_secret = client_secret
        self._user_id = mailbox_user_id
        self._poll_lookback_hours = poll_lookback_hours
        self._gcs = gcs_client
        self._gcs_bucket = gcs_bucket
        # Build the MSAL app once so its internal token cache survives across poll cycles.
        # Acquiring a token on a reused app object returns the cached token until expiry (~1 hour).
        import msal  # type: ignore[import]
        self._msal_app = msal.ConfidentialClientApplication(
            client_id=self._client_id,
            client_credential=self._client_secret,
            authority=f"https://login.microsoftonline.com/{self._tenant_id}",
        )

    # ──────────────────────────────────────────────────────────────────────────
    # Token acquisition (MSAL client credentials — no user interaction)
    # ──────────────────────────────────────────────────────────────────────────

    async def _get_token(self) -> str:
        # acquire_token_for_client is synchronous — run in executor so it
        # doesn't block the event loop during initial acquisition or hourly refresh.
        loop = asyncio.get_event_loop()
        result = await loop.run_in_executor(
            None,
            lambda: self._msal_app.acquire_token_for_client(scopes=[_SCOPE]),
        )
        if "access_token" not in result:
            raise RuntimeError(
                f"MSAL token acquisition failed: {result.get('error_description', result)}"
            )
        return str(result["access_token"])

    async def _headers(self) -> dict[str, str]:
        token = await self._get_token()
        return {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        }

    # ──────────────────────────────────────────────────────────────────────────
    # Outbound — two-step draft+send with optional createReply threading
    # ──────────────────────────────────────────────────────────────────────────

    async def send_email(self, msg: EmailMessage) -> dict[str, str]:
        """Send via Graph draft+send.

        If `msg.in_reply_to_internet_message_id` is set, looks up that message and uses
        createReply so Exchange sets In-Reply-To / References / conversationId automatically
        — making all emails to the same supplier appear as one Outlook conversation thread.
        Falls back to a fresh draft+send if the prior message is not found or createReply fails.
        Returns {"messageId": ..., "graphInternetMessageId": <RFC-2822-id-assigned-by-Exchange>}.
        """
        import httpx

        async with httpx.AsyncClient(timeout=30) as client:
            hdrs = await self._headers()

            if msg.in_reply_to_internet_message_id:
                try:
                    return await self._create_reply_and_send(client, hdrs, msg)
                except Exception as exc:
                    log.error(
                        "email.createReply_failed_fallback",
                        prior_id=msg.in_reply_to_internet_message_id[:40],
                        error=str(exc),
                        note="Falling back to new thread — supplier will see a separate email",
                    )

            return await self._draft_and_send(client, hdrs, msg)

    async def _build_attachments(self, attachment_paths: list[str]) -> list[dict]:
        """Build Graph fileAttachment nodes from local paths or gs:// URIs."""
        nodes: list[dict] = []
        loop = asyncio.get_event_loop()
        for path_str in attachment_paths:
            if path_str.startswith("gs://"):
                if not (self._gcs and self._gcs_bucket):
                    log.warning("msgraph.gcs_not_configured_for_attachment", path=path_str)
                    continue
                try:
                    without_scheme = path_str[5:]  # strip "gs://"
                    bucket_name, _, obj_name = without_scheme.partition("/")
                    blob = self._gcs.bucket(bucket_name).blob(obj_name)  # type: ignore[union-attr]
                    content = await loop.run_in_executor(None, blob.download_as_bytes)
                    nodes.append({
                        "@odata.type": "#microsoft.graph.fileAttachment",
                        "name": Path(obj_name).name,
                        "contentBytes": base64.b64encode(content).decode(),
                    })
                except Exception as exc:
                    log.warning("msgraph.gcs_attachment_failed", path=path_str, error=str(exc))
            else:
                path = Path(path_str)
                if path.exists():
                    nodes.append({
                        "@odata.type": "#microsoft.graph.fileAttachment",
                        "name": path.name,
                        "contentBytes": base64.b64encode(path.read_bytes()).decode(),
                    })
        return nodes

    async def _draft_and_send(
        self,
        client: "httpx.AsyncClient",
        hdrs: dict[str, str],
        msg: EmailMessage,
    ) -> dict[str, str]:
        """Create a draft in Graph, then send it.  Returns graphInternetMessageId from Exchange."""
        to_recipients  = [{"emailAddress": {"address": msg.to}}] if msg.to else []
        bcc_recipients = [{"emailAddress": {"address": a}} for a in msg.bcc]
        cc_recipients  = [{"emailAddress": {"address": a}} for a in msg.cc]

        draft_payload: dict = {
            "subject": msg.subject,
            "body": {"contentType": "HTML" if msg.body_is_html else "Text", "content": msg.body},
            "toRecipients": to_recipients,
            "ccRecipients": cc_recipients,
            "bccRecipients": bcc_recipients,
            "attachments": await self._build_attachments(msg.attachment_paths),
        }

        create_url = f"{_GRAPH_BASE}/users/{self._user_id}/messages"
        resp = await client.post(create_url, headers=hdrs, json=draft_payload)
        if resp.status_code not in (200, 201):
            raise RuntimeError(f"Graph create draft failed {resp.status_code}: {resp.text[:200]}")

        draft = resp.json()
        draft_id = draft["id"]
        internet_message_id: str = draft.get("internetMessageId") or ""

        send_url = f"{_GRAPH_BASE}/users/{self._user_id}/messages/{draft_id}/send"
        resp = await client.post(send_url, headers=hdrs)
        if resp.status_code not in (200, 202):
            raise RuntimeError(f"Graph send draft failed {resp.status_code}: {resp.text[:200]}")

        log.info(
            "email.sent_graph_draft",
            to=msg.to,
            subject=msg.subject[:60],
            internet_message_id=internet_message_id[:40] if internet_message_id else "",
        )
        return {"messageId": "", "graphInternetMessageId": internet_message_id}

    async def _create_reply_and_send(
        self,
        client: "httpx.AsyncClient",
        hdrs: dict[str, str],
        msg: EmailMessage,
    ) -> dict[str, str]:
        """Find prior message by RFC-2822 ID, createReply for Exchange threading, then send.

        Raises LookupError if the message is not found (triggers fallback in send_email).
        Raises RuntimeError on Graph API failures.
        """
        import httpx  # already imported at call site; re-importing is a no-op

        # 1. Resolve RFC 2822 internetMessageId → current Graph message id.
        #    Exchange indexes SentItems reliably; fall back to it when the all-messages
        #    search returns empty (e.g. if the message was moved to a subfolder).
        search_params = {
            "$filter": f"internetMessageId eq '{msg.in_reply_to_internet_message_id}'",
            "$top": "1",
            "$select": "id,subject,conversationId",
        }

        search_url = f"{_GRAPH_BASE}/users/{self._user_id}/messages"
        search_resp = await client.get(search_url, headers=hdrs, params=search_params)
        if search_resp.status_code != 200:
            raise RuntimeError(f"Graph message lookup failed {search_resp.status_code}")
        items = search_resp.json().get("value", [])

        if not items:
            # SentItems is always indexed — try it explicitly as a fallback
            sent_url = f"{_GRAPH_BASE}/users/{self._user_id}/mailFolders/SentItems/messages"
            sent_resp = await client.get(sent_url, headers=hdrs, params=search_params)
            if sent_resp.status_code == 200:
                items = sent_resp.json().get("value", [])

        if not items:
            raise LookupError(
                f"Prior message not found in mailbox or SentItems: {msg.in_reply_to_internet_message_id}"
            )
        prior_graph_id = items[0]["id"]

        # 2. Create a reply draft (Exchange sets In-Reply-To / References / conversationId)
        reply_url = f"{_GRAPH_BASE}/users/{self._user_id}/messages/{prior_graph_id}/createReply"
        reply_resp = await client.post(reply_url, headers=hdrs, json={})
        if reply_resp.status_code not in (200, 201):
            raise RuntimeError(f"Graph createReply failed {reply_resp.status_code}: {reply_resp.text[:200]}")

        draft = reply_resp.json()
        draft_id = draft["id"]

        # 3. Patch the draft with our actual content and recipients
        to_recipients = [{"emailAddress": {"address": msg.to}}] if msg.to else []
        cc_recipients = [{"emailAddress": {"address": a}} for a in msg.cc]
        bcc_recipients = [{"emailAddress": {"address": a}} for a in msg.bcc]
        patch_payload: dict = {
            "subject": msg.subject,
            "body": {"contentType": "HTML" if msg.body_is_html else "Text", "content": msg.body},
            "toRecipients": to_recipients,
            "ccRecipients": cc_recipients,
            "bccRecipients": bcc_recipients,
            "attachments": await self._build_attachments(msg.attachment_paths),
        }
        patch_url = f"{_GRAPH_BASE}/users/{self._user_id}/messages/{draft_id}"
        patch_resp = await client.patch(patch_url, headers=hdrs, json=patch_payload)
        if patch_resp.status_code not in (200, 201):
            raise RuntimeError(f"Graph patch draft failed {patch_resp.status_code}: {patch_resp.text[:200]}")

        patched = patch_resp.json()
        internet_message_id: str = patched.get("internetMessageId") or draft.get("internetMessageId") or ""

        # 4. Send the reply draft
        send_url = f"{_GRAPH_BASE}/users/{self._user_id}/messages/{draft_id}/send"
        send_resp = await client.post(send_url, headers=hdrs)
        if send_resp.status_code not in (200, 202):
            raise RuntimeError(f"Graph send reply failed {send_resp.status_code}: {send_resp.text[:200]}")

        log.info(
            "email.sent_graph_reply",
            to=msg.to,
            subject=msg.subject[:60],
            internet_message_id=internet_message_id[:40] if internet_message_id else "",
        )
        return {"messageId": "", "graphInternetMessageId": internet_message_id}

    # ──────────────────────────────────────────────────────────────────────────
    # Inbound polling
    # ──────────────────────────────────────────────────────────────────────────

    async def poll_inbox(self, since: datetime | None = None) -> list[InboundEmail]:
        import httpx

        # Filter by receivedDateTime (not isRead) so replies opened in Outlook before the poll
        # are still captured. The caller (email_poller) passes an incremental high-water mark as
        # `since`; when absent (cold start / no pollState), fall back to a lookback window.
        # Keeping filter + $orderby on the same property avoids Graph's "inefficient filter" error.
        if since is None:
            since = datetime.now(timezone.utc) - timedelta(hours=self._poll_lookback_hours)
        elif since.tzinfo is None:
            since = since.replace(tzinfo=timezone.utc)
        lookback_str = since.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

        url = (
            f"{_GRAPH_BASE}/users/{self._user_id}/mailFolders/Inbox/messages"
            f"?$filter=receivedDateTime ge {lookback_str}"
            "&$select=id,from,subject,body,receivedDateTime,hasAttachments,"
            "conversationId,internetMessageId,internetMessageHeaders"
            "&$orderby=receivedDateTime desc"
            "&$top=50"
        )

        messages: list[InboundEmail] = []
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                # Build poll-specific headers — add Prefer so Graph returns plain-text body.
                # Outlook replies are HTML by default; this avoids storing raw HTML markup.
                poll_headers = await self._headers()
                poll_headers["Prefer"] = 'outlook.body-content-type="text"'

                # Collect all items across pages (cap at _MAX_MESSAGES)
                all_items: list[dict] = []
                next_url: str | None = url
                while next_url and len(all_items) < _MAX_MESSAGES:
                    resp = await client.get(next_url, headers=poll_headers)
                    if resp.status_code != 200:
                        log.warning("graph.poll_failed", status=resp.status_code, body=resp.text[:200])
                        break
                    data = resp.json()
                    all_items.extend(data.get("value", []))
                    next_url = data.get("@odata.nextLink")

                for item in all_items:
                    # Only download attachments when the message actually has them
                    if item.get("hasAttachments"):
                        attachments = await self._download_attachments(client, item["id"])
                    else:
                        attachments = []

                    inet_headers: list[dict[str, str]] = item.get("internetMessageHeaders") or []
                    messages.append(InboundEmail(
                        uid=item["id"],
                        from_addr=item.get("from", {}).get("emailAddress", {}).get("address", ""),
                        subject=item.get("subject", ""),
                        body=item.get("body", {}).get("content", ""),
                        attachment_paths=attachments,
                        date=item.get("receivedDateTime", ""),
                        raw_headers={},
                        message_id=item["id"],
                        conversation_id=item.get("conversationId", ""),
                        internet_message_id=item.get("internetMessageId", ""),
                        spam_info=_parse_antispam_headers(inet_headers),
                    ))
        except Exception as exc:
            log.warning("graph.poll_exception", error=str(exc))

        return messages

    async def _download_attachments(self, client: "httpx.AsyncClient", msg_id: str) -> list[str]:
        url = f"{_GRAPH_BASE}/users/{self._user_id}/messages/{msg_id}/attachments"
        saved: list[str] = []
        try:
            resp = await client.get(url, headers=await self._headers())
            if resp.status_code != 200:
                return []
            _UPLOADS_DIR.mkdir(exist_ok=True)
            # Use a short hash of the message ID as a prefix so filenames are unique
            # across poll cycles but stable for the same message (idempotent).
            uid_prefix = hashlib.md5(msg_id.encode()).hexdigest()[:8].upper()
            for att in resp.json().get("value", []):
                if att.get("@odata.type") == "#microsoft.graph.fileAttachment":
                    content = base64.b64decode(att.get("contentBytes", ""))
                    original_name = att.get("name", "attachment")
                    saved_name = f"INBOUND_{uid_prefix}_{original_name}"
                    dest = _UPLOADS_DIR / saved_name
                    dest.write_bytes(content)

                    # Also upload to GCS so the file is durable and accessible cross-instance
                    if self._gcs and self._gcs_bucket:
                        try:
                            blob = self._gcs.bucket(self._gcs_bucket).blob(f"inbound/{saved_name}")  # type: ignore[union-attr]
                            loop = asyncio.get_event_loop()
                            await loop.run_in_executor(
                                None,
                                lambda c=content, b=blob: b.upload_from_string(
                                    c, content_type="application/octet-stream"
                                ),
                            )
                        except Exception as gcs_exc:
                            log.warning(
                                "msgraph.inbound_gcs_upload_failed",
                                name=saved_name,
                                error=str(gcs_exc),
                            )

                    saved.append(str(dest))
        except Exception as exc:
            log.warning("graph.attachment_download_failed", error=str(exc))
        return saved

    async def mark_as_read(self, uid: str) -> None:
        import httpx

        url = f"{_GRAPH_BASE}/users/{self._user_id}/messages/{uid}"
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                await client.patch(
                    url,
                    headers=await self._headers(),
                    json={"isRead": True},
                )
        except Exception as exc:
            log.warning("graph.mark_read_failed", uid=uid[:20], error=str(exc))

    async def fetch_raw_mime(self, message_id: str) -> bytes | None:
        """Return the complete raw RFC 2822 MIME bytes for a message.

        Uses the Graph $value endpoint which returns the full MIME stream, including
        structured MIME parts (message/delivery-status for NDRs) that the JSON API omits.
        Returns None on any error so callers can fall back gracefully.
        """
        import httpx

        url = f"{_GRAPH_BASE}/users/{self._user_id}/messages/{message_id}/$value"
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.get(url, headers=await self._headers())
                if resp.status_code == 200:
                    return resp.content
                log.warning("graph.fetch_raw_mime_failed", status=resp.status_code, msg_id=message_id[:20])
                return None
        except Exception as exc:
            log.warning("graph.fetch_raw_mime_exception", error=str(exc), msg_id=message_id[:20])
            return None

    # ──────────────────────────────────────────────────────────────────────────
    # Config verification
    # ──────────────────────────────────────────────────────────────────────────

    async def verify_config(self) -> bool:
        if not all([self._tenant_id, self._client_id, self._client_secret, self._user_id]):
            return False
        try:
            await self._get_token()
            return True
        except Exception as exc:
            log.warning("msgraph.verify_failed", error=str(exc))
            return False
