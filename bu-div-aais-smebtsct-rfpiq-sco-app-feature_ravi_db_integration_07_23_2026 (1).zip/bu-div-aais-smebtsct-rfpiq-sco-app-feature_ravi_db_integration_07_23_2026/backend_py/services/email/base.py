"""
Abstract email service interface.

Concrete implementation:
- MsGraphEmailService — MSAL + httpx → Microsoft Graph API

The abstraction is retained so send/poll call sites depend on the interface, not the provider.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class EmailMessage:
    to: str
    bcc: list[str]
    subject: str
    body: str
    attachment_paths: list[str] = field(default_factory=list)
    cc: list[str] = field(default_factory=list)
    # Exchange thread linking — store the prior email's RFC 2822 internetMessageId here;
    # MsGraphEmailService uses createReply so Exchange sets In-Reply-To/References/conversationId
    in_reply_to_internet_message_id: str | None = None
    body_is_html: bool = False  # when True, Graph sends contentType HTML instead of Text


@dataclass
class InboundEmail:
    uid: str
    from_addr: str
    subject: str
    body: str
    attachment_paths: list[str]
    date: str
    raw_headers: dict[str, str]
    message_id: str = ""
    conversation_id: str = ""
    internet_message_id: str = ""  # RFC 2822 Message-ID assigned by Exchange (for createReply threading)
    # Parsed Exchange antispam header fields — empty dict when headers unavailable.
    # Keys: scl (int), sfv (str), cat (str), bcl (int), verdict (str: clean/spam/phishing/bulk/malware)
    spam_info: dict[str, str | int] = field(default_factory=dict)


class AbstractEmailService(ABC):

    @abstractmethod
    async def send_email(self, msg: EmailMessage) -> dict[str, str]:
        """Send an outbound email.

        Returns {"messageId": ..., "graphInternetMessageId": ...}.
        `graphInternetMessageId` is the RFC 2822 Message-ID assigned by Exchange — store it on
        the thread record and pass it as `in_reply_to_internet_message_id` on the next send to
        the same supplier so subsequent emails thread correctly in Outlook.
        Raises on SMTP failure.
        """

    @abstractmethod
    async def poll_inbox(self, since: datetime | None = None) -> list[InboundEmail]:
        """Fetch messages received at/after `since` (provider default if None).

        Does NOT mark as read — the caller dedups by uid and calls mark_as_read().
        """

    @abstractmethod
    async def verify_config(self) -> bool:
        """Return True if credentials are present and reachable; do not raise."""

    @abstractmethod
    async def mark_as_read(self, uid: str) -> None:
        """Mark a message as seen/read so it is not returned by poll_inbox() again."""

    async def fetch_raw_mime(self, message_id: str) -> bytes | None:
        """Return the raw RFC 2822 MIME bytes for a message, or None if unsupported.

        Optional — only implemented by MS Graph provider. Used by the bounce handler to
        parse the structured message/delivery-status MIME part (RFC 3464) so each supplier
        gets only their own failure text, not the full multi-recipient NDR body.
        """
        return None
