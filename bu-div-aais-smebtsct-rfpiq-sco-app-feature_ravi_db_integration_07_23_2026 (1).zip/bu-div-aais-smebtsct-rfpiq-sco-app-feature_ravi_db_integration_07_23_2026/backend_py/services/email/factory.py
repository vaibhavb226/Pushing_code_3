"""
Build the email service from settings.

Microsoft Graph is the only email provider. The abstraction (AbstractEmailService) is retained
so send/poll call sites depend on the interface rather than the concrete provider.
"""
from __future__ import annotations

from config import Settings
from dependencies import get_gcs_client

from .base import AbstractEmailService


def build_email_service(settings: Settings) -> AbstractEmailService:
    from .msgraph_provider import MsGraphEmailService

    gcs = get_gcs_client(settings)
    return MsGraphEmailService(
        tenant_id=settings.ms_tenant_id,
        client_id=settings.ms_client_id,
        client_secret=settings.ms_client_secret.get_secret_value(),
        mailbox_user_id=settings.ms_mailbox_user_id,
        poll_lookback_hours=settings.poll_lookback_hours,
        gcs_client=gcs,
        gcs_bucket=settings.gcs_bucket,
    )
