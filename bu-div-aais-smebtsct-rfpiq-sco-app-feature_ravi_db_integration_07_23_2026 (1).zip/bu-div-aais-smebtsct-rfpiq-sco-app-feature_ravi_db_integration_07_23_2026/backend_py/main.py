"""
FoodCorp RFP AIQ — FastAPI backend entry point.

Start:
    uvicorn main:app --reload --port 3001
"""
from __future__ import annotations

# ── SSL fix: must run before any network imports ──────────────────────────────
# The EXL corporate network sets SSL_CERT_FILE to a file containing only the
# internal corporate CA, which causes Python's ssl module to reject Google's
# certificates (GTS Root R1 / GlobalSign). We build a combined bundle that
# includes both the standard Mozilla roots (via certifi) AND the corporate CA,
# then override SSL_CERT_FILE so all outbound TLS connections work correctly.
import os as _os
import pathlib as _pathlib
import tempfile as _tempfile


def _patch_ssl_cert_file() -> None:
    corp_ca = _os.environ.get("SSL_CERT_FILE", "")
    if not corp_ca or not _pathlib.Path(corp_ca).exists():
        return  # not on EXL network or already valid — nothing to do

    try:
        import certifi as _certifi
    except ImportError:
        return  # certifi not installed — skip

    # Write a combined bundle to a temp file that persists for the process lifetime
    tmp = _tempfile.NamedTemporaryFile(
        prefix="rfpiq_ssl_bundle_", suffix=".pem", delete=False
    )
    with open(_certifi.where(), "rb") as f:
        tmp.write(f.read())
    tmp.write(b"\n# === EXL / Corporate CA ===\n")
    with open(corp_ca, "rb") as f:
        tmp.write(f.read())
    tmp.close()

    combined = tmp.name
    _os.environ["SSL_CERT_FILE"] = combined
    _os.environ["REQUESTS_CA_BUNDLE"] = combined
    # gRPC uses its own bundle unless this env var is set
    _os.environ["GRPC_DEFAULT_SSL_ROOTS_FILE_PATH"] = combined


_patch_ssl_cert_file()

# ── UTF-8 stdout/stderr fix (Windows cp1252 can't encode emoji) ───────────────
import sys as _sys
if hasattr(_sys.stdout, "reconfigure"):
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(_sys.stderr, "reconfigure"):
    _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
# ─────────────────────────────────────────────────────────────────────────────

import asyncio
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any
    
import structlog
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from config import get_settings
from dependencies import LOGS_DIR, UPLOADS_DIR
from logging_config import configure_logging
from middleware.request_id import RequestIDMiddleware, get_request_id

configure_logging(LOGS_DIR)
log = structlog.get_logger()
_startup_time = datetime.now(timezone.utc)


# ── Lifespan ──────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    UPLOADS_DIR.mkdir(exist_ok=True)
    
    from time import time
    t0 = time()

    # ── Verify email (Microsoft Graph) config (non-fatal) ─────
    # Run as a background task instead of awaiting — don't block app startup
    async def verify_email_config():
        try:
            from services.email.factory import build_email_service
            email_svc = build_email_service(settings)
            ok = await email_svc.verify_config()
            status = "✅ Ready" if ok else "⚠️  Not configured"
            print(f"Email (MSGRAPH): {status}")
        except Exception as exc:
            print(f"Email config check failed: {exc}")
    
    asyncio.create_task(verify_email_config())
    print(f"⏱️  Email verification: {time() - t0:.2f}s (queued as background task)")

    # ── Verify PostgreSQL connection (non-fatal) ──────────────
    async def verify_pg_connection():
        if not settings.db_host:
            print("PostgreSQL (PSC):  ⚠️  Not configured (DB_HOST not set)")
            return
        try:
            from db.connection import get_engine
            from sqlalchemy import text as sa_text
            engine = get_engine(settings)
            if engine is None:
                print("PostgreSQL (PSC):  ⚠️  Engine not initialised (DB_HOST set but engine creation failed)")
                return
            async with engine.connect() as conn:
                await conn.execute(sa_text("SELECT 1"))
            print(f"PostgreSQL (PSC):  ✅ Connected ({settings.db_host}:{settings.db_port}/{settings.db_name})")
        except Exception as exc:
            print(f"PostgreSQL (PSC):  ⚠️  Connection failed — {exc}")

    asyncio.create_task(verify_pg_connection())

    # ── asyncpg CRUD pool (blocking — repos need it before requests) ──
    from db.connection import create_asyncpg_pool
    pg_pool = await create_asyncpg_pool(settings)
    if pg_pool:
        print("PostgreSQL (asyncpg): ✅ CRUD pool ready")
        # ── Real-time event listener (LISTEN/NOTIFY) ──────────
        try:
            from services.pg_listener import start_pg_listener
            start_pg_listener(settings)
            print("PostgreSQL (asyncpg): ✅ LISTEN/NOTIFY listener started")
        except Exception as _exc:
            print(f"PostgreSQL (asyncpg): ⚠️  LISTEN/NOTIFY listener failed — {_exc}")
        # Ensure poll_state table and seed row exist (safe no-op if already present)
        try:
            async with pg_pool.acquire() as _conn:
                await _conn.execute(
                    """
                    CREATE TABLE IF NOT EXISTS poll_state (
                        id             INTEGER     PRIMARY KEY,
                        last_polled_at TIMESTAMPTZ,
                        updated_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
                        CONSTRAINT poll_state_single_row CHECK (id = 1)
                    )
                    """
                )
                await _conn.execute(
                    "INSERT INTO poll_state (id) VALUES (1) ON CONFLICT DO NOTHING"
                )
            print("PostgreSQL (asyncpg): ✅ poll_state ready")
        except Exception as _exc:
            print(f"PostgreSQL (asyncpg): ⚠️  poll_state init failed — {_exc}")
    else:
        print("PostgreSQL (asyncpg): ⚠️  CRUD pool not started (DB_HOST not set — using JSON repos)")

    # ── LLM config display ────────────────────────────────────
    t_llm = time()
    provider = settings.llm_provider.lower()
    
    if provider == "anthropic":
        api_key = settings.anthropic_api_key.get_secret_value()
        llm_status = "✅ Configured" if api_key else "⚠️  Not set"
        model_info = f"{settings.anthropic_model}"
    elif provider == "vertexai":
        import os as _os
        if settings.google_application_credentials:
            _os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = settings.google_application_credentials
        project = settings.gcp_project
        llm_status = "✅ Configured" if project else "⚠️  Not set (need GCP_PROJECT)"
        model_info = f"{settings.vertex_model} (IAM-based auth)"
    else:
        llm_status = "⚠️  Unknown provider"
        model_info = ""
    
    print(f"LLM Provider:   {settings.llm_provider} / {model_info}")
    print(f"LLM Status:     {llm_status}")
    print(f"⏱️  LLM config: {time() - t_llm:.2f}s")

    # ── Startup backfills (non-blocking background tasks) ─────
    t_backfill = time()
    try:
        from utils.backfill import (
            backfill_email_attachments,
            backfill_line_items_from_files,
            backfill_solicited_suppliers,
            backfill_uploaded_files,
        )
        asyncio.create_task(backfill_uploaded_files())
        asyncio.create_task(backfill_solicited_suppliers())
        asyncio.create_task(backfill_email_attachments())
        asyncio.create_task(backfill_line_items_from_files())
        print(f"⏱️  Backfill tasks: {time() - t_backfill:.2f}s (queued)")
    except ImportError:
        pass  # Backfill module created in Phase 5

    # ── Demo data injection ───────────────────────────────────
    t_demo = time()
    try:
        from services.demo_data import ensure_bounce_demo
        asyncio.create_task(ensure_bounce_demo())
        print(f"⏱️  Demo data: {time() - t_demo:.2f}s (queued)")
    except ImportError:
        pass

    # ── IMAP email poller ─────────────────────────────────────
    t_poller = time()
    poller_task: asyncio.Task | None = None
    try:
        from services.email_poller import start_email_poller
        from dependencies import get_email_service
        poller_task = asyncio.create_task(start_email_poller(get_email_service()))
        print(f"⏱️  IMAP Poller: {time() - t_poller:.2f}s (✅ Started, polling every 15s)")
    except Exception as exc:
        print(f"IMAP Poller:    ⚠️  {exc}")

    # ── SQL Agent graph — compile once at startup ─────────────
    try:
        from services.sql_agent.graph import init_sql_agent_graph
        init_sql_agent_graph()
    except Exception as exc:
        print(f"SQL Agent Graph:  ⚠️  {exc}")

    # Document indexing is fire-and-forget via asyncio.ensure_future in bids.py / documents.py.
    # No persistent worker task needed — each upload spawns its own indexing coroutine.
    embed_worker_task: asyncio.Task | None = None

    # ── Presence TTL cleanup (30s loop, evicts after 60s idle) ──
    async def _presence_cleanup() -> None:
        from services.sse_broadcast import cleanup_stale_users
        while True:
            await asyncio.sleep(30)
            cleanup_stale_users(max_age=60.0)

    asyncio.create_task(_presence_cleanup())

    # ── Hourly auto-reminder scheduler ───────────────────────
    t_scheduler = time()
    scheduler = None
    try:
        from apscheduler.schedulers.asyncio import AsyncIOScheduler
        from services.auto_reminder import run_auto_reminders
        scheduler = AsyncIOScheduler(timezone="UTC")
        scheduler.add_job(run_auto_reminders, "interval", hours=1, id="auto_reminders")
        scheduler.start()
        print(f"⏱️  Scheduler: {time() - t_scheduler:.2f}s (✅ Started)")
    except Exception as exc :
        print(f"Scheduler:      ⚠️  {exc}")

    total_time = time() - t0
    print(f"FoodCorp RFP AIQ backend running on port {settings.port}")
    print(f"⏱️  Total startup: {total_time:.2f}s")

    yield  # ← app serves requests

    # ── Shutdown ──────────────────────────────────────────────
    if poller_task:
        poller_task.cancel()
        try:
            await poller_task
        except asyncio.CancelledError:
            pass
    if scheduler:
        scheduler.shutdown(wait=False)
    from db.connection import close_engine, close_asyncpg_pool
    await close_engine()
    await close_asyncpg_pool()


# ── App ───────────────────────────────────────────────────────────────────────

app = FastAPI(
    title="FoodCorp RFP AIQ",
    version="1.0.0",
    description="AI-powered procurement tool for FoodCorp's Bid COE team",
    lifespan=lifespan,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    redirect_slashes=False,
)

# ── Middleware (order matters — applied bottom-up by Starlette) ──────────────

settings = get_settings()

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(RequestIDMiddleware)

# ── Static files ──────────────────────────────────────────────────────────────

UPLOADS_DIR.mkdir(exist_ok=True)
app.mount("/uploads", StaticFiles(directory=str(UPLOADS_DIR)), name="uploads")

# ── Global exception handlers ─────────────────────────────────────────────────

@app.exception_handler(ValueError)
async def value_error_handler(request: Request, exc: ValueError) -> JSONResponse:
    return JSONResponse(
        status_code=400,
        content={"error": str(exc), "request_id": get_request_id()},
    )


@app.exception_handler(FileNotFoundError)
async def file_not_found_handler(request: Request, exc: FileNotFoundError) -> JSONResponse:
    return JSONResponse(
        status_code=404,
        content={"error": str(exc), "request_id": get_request_id()},
    )


@app.exception_handler(Exception)
async def generic_handler(request: Request, exc: Exception) -> JSONResponse:
    import traceback
    log.error(
        "unhandled_exception",
        error=str(exc),
        exc_type=type(exc).__name__,
        path=request.url.path,
        traceback=traceback.format_exc(),
    )
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "request_id": get_request_id()},
    )


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/api/health", tags=["system"])
@app.get("/api/v1/health", tags=["system"], include_in_schema=False)
async def health() -> dict[str, Any]:
    """Service health check — returns LLM provider, email provider, uptime, and DB backend."""
    settings = get_settings()
    uptime = (datetime.now(timezone.utc) - _startup_time).total_seconds()
    return {
        "status": "ok",
        "service": "FoodCorp RFP AIQ Backend",
        "version": "1.0.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "uptime_seconds": round(uptime),
        "llmProvider": settings.llm_provider,
        "anthropicConfigured": bool(settings.anthropic_api_key.get_secret_value()),
        "emailProvider": "msgraph",
    }


@app.get("/api/email/poll-now", tags=["system"])
async def poll_now() -> dict[str, Any]:
    """Manually trigger the IMAP inbox poller (dev/testing). Normally runs every 15 seconds automatically."""
    try:
        from services.email_poller import run_poll
        from dependencies import get_email_service
        result = await run_poll(get_email_service())
        return {"ok": True, **result, "timestamp": datetime.now(timezone.utc).isoformat()}
    except Exception as exc:
        return {"ok": False, "error": str(exc), "timestamp": datetime.now(timezone.utc).isoformat()}


# ── Router registration ───────────────────────────────────────────────────────

from routers.suppliers import router as suppliers_router
from routers.documents import router as documents_router

app.include_router(suppliers_router, prefix="/api/suppliers")
app.include_router(suppliers_router, prefix="/api/v1/suppliers")
app.include_router(documents_router, prefix="/api/documents")
app.include_router(documents_router, prefix="/api/v1/documents")

# AI + bids routers registered after Phase 2/3 modules are created
try:
    from routers.rfp_parser import router as rfp_router
    app.include_router(rfp_router, prefix="/api/parse-rfp")
    app.include_router(rfp_router, prefix="/api/v1/parse-rfp")
except ImportError:
    pass

try:
    from routers.analyse_response import router as analyse_router
    app.include_router(analyse_router, prefix="/api/analyse-response")
    app.include_router(analyse_router, prefix="/api/v1/analyse-response")
except ImportError:
    pass

try:
    from routers.ai_chat import router as ai_router
    app.include_router(ai_router, prefix="/api/ai")
    app.include_router(ai_router, prefix="/api/v1/ai")
except ImportError:
    pass

try:
    from routers.bids import router as bids_router
    app.include_router(bids_router, prefix="/api/bids")
    app.include_router(bids_router, prefix="/api/v1/bids")
except ImportError:
    pass

try:
    from routers.submissions import router as submissions_router
    app.include_router(submissions_router, prefix="/api/submit")
    app.include_router(submissions_router, prefix="/api/v1/submit")
except ImportError:
    pass

try:
    from routers.logs import router as logs_router
    app.include_router(logs_router, prefix="/api/logs")
    app.include_router(logs_router, prefix="/api/v1/logs")
except ImportError:
    pass

try:
    from routers.files import router as files_router
    app.include_router(files_router, prefix="/api")
    app.include_router(files_router, prefix="/api/v1")
except ImportError:
    pass

from routers.reports import router as reports_router
app.include_router(reports_router, prefix="/api/reports")
app.include_router(reports_router, prefix="/api/v1/reports")

try:
    from routers.customers import router as customers_router
    app.include_router(customers_router, prefix="/api/customers")
    app.include_router(customers_router, prefix="/api/v1/customers")
except ImportError:
    pass

from routers.web_search import router as web_search_router
app.include_router(web_search_router, prefix="/api/web-search")
app.include_router(web_search_router, prefix="/api/v1/web-search")

try:
    from routers.presence import router as presence_router
    app.include_router(presence_router, prefix="/api/presence")
    app.include_router(presence_router, prefix="/api/v1/presence")
except ImportError:
    pass
