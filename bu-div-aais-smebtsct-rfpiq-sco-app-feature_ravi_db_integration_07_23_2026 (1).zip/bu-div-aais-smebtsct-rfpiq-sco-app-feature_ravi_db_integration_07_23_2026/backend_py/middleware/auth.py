# INTERNAL_API_KEY middleware removed — authentication is handled at the infrastructure
# level (Cloud Run IAM + VPC Service Controls). This file is intentionally empty.
