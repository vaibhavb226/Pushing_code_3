"""
Simulate chat_structured() step-by-step to reveal hidden latency.

Breaks _vertex_structured() into individual timed steps so you can see
exactly where time goes beyond the LLM call itself.

Usage (from backend_py/):
    python scripts/simulate_chat_structured.py

Requires GCP_PROJECT in backend_py/.env
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path

# Allow importing project modules
sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent / ".env", override=True)

PROJECT  = os.environ["GCP_PROJECT"]
LOCATION = os.environ.get("GCP_LOCATION", "us-central1")
MODEL    = os.environ.get("VERTEX_MODEL", "gemini-2.5-flash")

SYSTEM = (
    "You are BEX AI, the FoodCorp Bid Extraction expert. "
    "Extract bid metadata and line items from the provided RFP content. "
    "Return only valid JSON — no markdown, no preamble. "
    "CRITICAL: Start your response with { and end with }."
)

USER_PROMPT = """PDF CONTENT:
Customer: Riverdale School District | Bid ID: BID-TEST-001 | Segment: K-12
Due: 2026-08-01 | Compliance: Child Nutrition, Buy American

EXCEL ITEM LIST:
Item#\tMPC\tBrand\tDescription\tPack\tSize\tUOM\tVolume
0001\tMPC001\tTyson\tChicken Nuggets\t6\t10 oz\tCS\t500
0002\tMPC002\tHeinz\tKetchup\t6\t114 oz\tCS\t200

CRITICAL: 2 data rows — line_items MUST contain exactly 2 objects."""


async def simulate() -> None:
    from routers.bex_schemas import BEXResponse
    from services.llm.provider import _to_vertex_schema

    print(f"\n{'='*65}")
    print("  chat_structured() step-by-step timing simulation")
    print(f"  Model: {MODEL}  |  Project: {PROJECT}")
    print(f"{'='*65}\n")

    steps: list[tuple[str, float, str]] = []  # (label, elapsed, note)

    # ── Step 1: vertexai.init() ───────────────────────────────────────────────
    import vertexai
    from vertexai.generative_models import Content, GenerationConfig, GenerativeModel, Part

    t0 = time.perf_counter()
    vertexai.init(project=PROJECT, location=LOCATION)
    steps.append(("vertexai.init()", time.perf_counter() - t0, "runs on EVERY request"))

    # ── Step 2: GenerativeModel() ─────────────────────────────────────────────
    t0 = time.perf_counter()
    model = GenerativeModel(MODEL, system_instruction=SYSTEM)
    steps.append(("GenerativeModel()", time.perf_counter() - t0, "recreated on every request"))

    # ── Step 3: schema.model_json_schema() ───────────────────────────────────
    t0 = time.perf_counter()
    raw_schema = BEXResponse.model_json_schema()
    steps.append(("BEXResponse.model_json_schema()", time.perf_counter() - t0, "Pydantic schema export"))

    # ── Step 4: _to_vertex_schema() ──────────────────────────────────────────
    t0 = time.perf_counter()
    vertex_schema = _to_vertex_schema(raw_schema)
    steps.append(("_to_vertex_schema()", time.perf_counter() - t0, "runs on EVERY request"))

    # ── Step 5: ThinkingConfig import attempt ─────────────────────────────────
    t0 = time.perf_counter()
    thinking_applied = False
    try:
        from vertexai.generative_models import ThinkingConfig  # noqa: F401
        thinking_applied = True
    except ImportError:
        pass
    steps.append((
        "ThinkingConfig import",
        time.perf_counter() - t0,
        "OK" if thinking_applied else "FAILED — thinking runs on EVERY call!",
    ))

    # ── Step 6: Content + GenerationConfig build ──────────────────────────────
    t0 = time.perf_counter()
    contents = [Content(role="user", parts=[Part.from_text(text=USER_PROMPT)])]
    gen_kwargs: dict = {
        "temperature": 0.1,
        "max_output_tokens": 65536,
        "response_mime_type": "application/json",
        "response_schema": vertex_schema,
    }
    cfg = GenerationConfig(**gen_kwargs)
    steps.append(("Content + GenerationConfig build", time.perf_counter() - t0, ""))

    # ── Step 7: LLM call (the real wait) ──────────────────────────────────────
    print("  Calling LLM... (this is the main wait)\n")
    t0 = time.perf_counter()
    response = await model.generate_content_async(contents, generation_config=cfg)
    llm_elapsed = time.perf_counter() - t0

    thinking_note = ""
    if not thinking_applied:
        thinking_note = " [includes THINKING tokens — not disabled!]"
    steps.append((f"generate_content_async() [LLM]{thinking_note}", llm_elapsed, ""))

    # ── Step 8: JSON parse ─────────────────────────────────────────────────────
    t0 = time.perf_counter()
    raw = response.text or ""
    parse_ok = False
    data: dict = {}
    try:
        data = json.loads(raw)
        parse_ok = True
    except json.JSONDecodeError as exc:
        steps.append((f"json.loads() FAILED: {exc}", time.perf_counter() - t0, ""))

    if parse_ok:
        steps.append(("json.loads()", time.perf_counter() - t0, f"{len(raw)} chars"))

    # ── Step 9: Pydantic validate ──────────────────────────────────────────────
    t0 = time.perf_counter()
    items_found = 0
    try:
        result = BEXResponse.model_validate(data)
        items_found = len(result.line_items)
        steps.append(("BEXResponse.model_validate()", time.perf_counter() - t0, f"{items_found} items"))
    except Exception as exc:
        steps.append((f"model_validate() FAILED: {exc}", time.perf_counter() - t0, ""))

    # ── Print results ──────────────────────────────────────────────────────────
    total = sum(t for _, t, _ in steps)
    non_llm = sum(t for label, t, _ in steps if "LLM" not in label and "generate_content" not in label)

    print(f"  {'Step':<50} {'Time':>8}  {'% Total':>8}  Note")
    print(f"  {'─'*90}")
    for label, elapsed, note in steps:
        pct = (elapsed / total * 100) if total > 0 else 0
        warn = " ⚠" if (elapsed > 0.05 and "LLM" not in label and "generate_content" not in label) else ""
        note_str = f"  ← {note}" if note else ""
        print(f"  {label:<50} {elapsed:>7.3f}s  {pct:>7.1f}%{warn}{note_str}")

    print(f"  {'─'*90}")
    print(f"  {'TOTAL':<50} {total:>7.3f}s")
    print(f"  {'Non-LLM overhead':<50} {non_llm:>7.3f}s  overhead per request\n")

    # ── Diagnoses ──────────────────────────────────────────────────────────────
    print("  DIAGNOSES:")
    if not thinking_applied:
        print("  ❌ ThinkingConfig NOT applied — Gemini 2.5 Flash is using thinking tokens")
        print("     This adds 2–10s of hidden latency on every structured output call.")
        print("     Fix: migrate to google-genai SDK (ThinkingConfig works there).")
    else:
        print("  ✅ ThinkingConfig applied — thinking disabled")

    schema_time = next((t for l, t, _ in steps if "_to_vertex_schema" in l), 0)
    init_time   = next((t for l, t, _ in steps if "vertexai.init" in l), 0)
    if schema_time > 0.001:
        print(f"  ⚠  Schema conversion takes {schema_time:.3f}s on every request — should be cached.")
    if init_time > 0.001:
        print(f"  ⚠  vertexai.init() takes {init_time:.3f}s on every request — should run once.")

    if not thinking_applied:
        print()
        print("  Run the fixed version (after applying provider.py patch) to compare.")


if __name__ == "__main__":
    asyncio.run(simulate())
