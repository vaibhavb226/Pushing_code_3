"""
Embed all documents from documents.json into the document_vectors table.

For each document in documents.json:
  1. Locate the file in uploads/
  2. Extract plain text  (PDF via PyMuPDF, Excel via openpyxl, txt/csv direct)
  3. Split into overlapping chunks (~800 chars, 100-char overlap)
  4. Embed each chunk with Vertex AI text-embedding-004 (768 dims)
  5. Upsert into document_vectors in Cloud SQL (pgvector)

Run once to bootstrap, then re-run whenever documents are added or changed.

Usage (from backend_py/):
    python scripts/embed_documents.py                       # embed all
    python scripts/embed_documents.py --doc-id DOC-001      # one document
    python scripts/embed_documents.py --dry-run             # extract + chunk only, no DB writes

Requires in backend_py/.env:
    CLOUD_SQL_CONNECTION_NAME=project:region:instance
    DB_NAME=...
    DB_USER=...
    DB_PASS=...
    GCP_PROJECT=...
    GCP_LOCATION=us-central1
"""
from __future__ import annotations

# ── SSL fix (must run before any network import) ──────────────────────────────
# EXL corporate network sets SSL_CERT_FILE to only the internal CA cert, which
# causes Python's ssl module to reject public CA chains (Google Trust Services).
# We build a combined bundle: Mozilla roots (certifi) + corporate CA.
import os as _os
import pathlib as _pathlib
import tempfile as _tempfile


def _patch_ssl() -> None:
    corp = _os.environ.get("SSL_CERT_FILE", "")
    if not corp or not _pathlib.Path(corp).exists():
        return
    try:
        import certifi as _certifi
    except ImportError:
        return
    tmp = _tempfile.NamedTemporaryFile(
        prefix="rfpiq_ssl_", suffix=".pem", delete=False
    )
    with open(_certifi.where(), "rb") as f:
        tmp.write(f.read())
    tmp.write(b"\n# === Corporate CA ===\n")
    with open(corp, "rb") as f:
        tmp.write(f.read())
    tmp.close()
    combined = tmp.name
    _os.environ["SSL_CERT_FILE"] = combined
    _os.environ["REQUESTS_CA_BUNDLE"] = combined
    _os.environ["GRPC_DEFAULT_SSL_ROOTS_FILE_PATH"] = combined


_patch_ssl()
# ─────────────────────────────────────────────────────────────────────────────

import argparse
import asyncio
import json
import os
import sys
import types
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent / ".env", override=True)


# ── Settings (read directly from env — no Secret Manager for scripts) ─────────

class _SecretStr:
    """Minimal stand-in for pydantic SecretStr so db.connection works unchanged."""
    def __init__(self, value: str) -> None:
        self._value = value

    def get_secret_value(self) -> str:
        return self._value


def _settings_from_env() -> Any:
    return types.SimpleNamespace(
        db_host=os.environ.get("DB_HOST", ""),
        db_port=int(os.environ.get("DB_PORT", "5432")),
        db_name=os.environ.get("DB_NAME", "postgres"),
        db_user=os.environ.get("DB_USER", ""),
        db_pass=_SecretStr(os.environ.get("DB_PASS", "")),
        pg_dsn=(
            f"postgresql+asyncpg://{os.environ.get('DB_USER', '')}:"
            f"{os.environ.get('DB_PASS', '')}@{os.environ.get('DB_HOST', '')}:"
            f"{os.environ.get('DB_PORT', '5432')}/{os.environ.get('DB_NAME', 'postgres')}"
        ),
        gcp_project=os.environ.get("GCP_PROJECT", ""),
        gcp_location=os.environ.get("GCP_LOCATION", "us-central1"),
    )


# ── Constants ─────────────────────────────────────────────────────────────────
EMBEDDING_MODEL = "text-embedding-004"
EMBEDDING_DIMS  = 768
CHUNK_SIZE      = 800   # characters per chunk
CHUNK_OVERLAP   = 100   # overlap between consecutive chunks
BATCH_SIZE      = 20    # texts per embed_content API call (max 250)

BASE_DIR    = Path(__file__).parent.parent
DATA_DIR    = BASE_DIR / "data"
UPLOADS_DIR = BASE_DIR / "uploads"


# ── Text extraction ───────────────────────────────────────────────────────────

def extract_pdf_text(path: Path) -> str:
    try:
        import fitz  # pymupdf
        doc = fitz.open(str(path))
        text = "\n".join(page.get_text() for page in doc)
        doc.close()
        return text.strip()
    except Exception as exc:
        print(f"    ⚠  PDF extract failed: {exc}")
        return ""


def extract_excel_text(path: Path) -> str:
    try:
        import openpyxl
        wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
        rows: list[str] = []
        for sheet in wb.worksheets:
            if sheet.sheet_state != 'visible':
                continue
            rows.append(f"[Sheet: {sheet.title}]")
            for row in sheet.iter_rows(values_only=True):
                cells = " | ".join(str(v) for v in row if v is not None)
                if cells.strip():
                    rows.append(cells)
        wb.close()
        return "\n".join(rows).strip()
    except Exception as exc:
        print(f"    ⚠  Excel extract failed: {exc}")
        return ""


def extract_text(file_path: Path, file_type: str) -> str:
    ft = file_type.lower().lstrip(".")
    if ft == "pdf":
        return extract_pdf_text(file_path)
    if ft in ("xlsx", "xls"):
        return extract_excel_text(file_path)
    # txt, csv, or anything else — read directly
    try:
        return file_path.read_text(encoding="utf-8", errors="replace").strip()
    except Exception as exc:
        print(f"    ⚠  Text read failed: {exc}")
        return ""


# ── Chunking ──────────────────────────────────────────────────────────────────

def chunk_text(text: str) -> list[str]:
    text = text.strip()
    if not text:
        return []
    if len(text) <= CHUNK_SIZE:
        return [text]
    chunks: list[str] = []
    start = 0
    while start < len(text):
        chunk = text[start : start + CHUNK_SIZE].strip()
        if chunk:
            chunks.append(chunk)
        start += CHUNK_SIZE - CHUNK_OVERLAP
    return chunks


# ── Embedding ─────────────────────────────────────────────────────────────────

_genai_client: Any = None


async def _get_client(settings: Any) -> Any:
    global _genai_client
    if _genai_client is None:
        from google import genai
        _genai_client = genai.Client(
            vertexai=True,
            project=settings.gcp_project,
            location=settings.gcp_location,
        )
    return _genai_client


async def embed_batch(texts: list[str], settings: Any) -> list[list[float]]:
    """Embed a batch of texts; returns one 768-dim vector per input."""
    from google.genai import types as gt
    client = await _get_client(settings)
    result = await client.aio.models.embed_content(
        model=EMBEDDING_MODEL,
        contents=texts,
        config=gt.EmbedContentConfig(task_type="RETRIEVAL_DOCUMENT"),
    )
    return [e.values for e in result.embeddings]


# ── Postgres helpers ──────────────────────────────────────────────────────────

CREATE_TABLE_SQL = f"""
CREATE EXTENSION IF NOT EXISTS vector;

CREATE TABLE IF NOT EXISTS document_vectors (
    id            TEXT PRIMARY KEY,
    gcs_uri       TEXT        NOT NULL,
    bucket        TEXT        NOT NULL,
    object_name   TEXT        NOT NULL,
    file_name     TEXT        NOT NULL,
    file_type     TEXT,
    bid_id        TEXT,
    rfp_id        TEXT,
    document_id   TEXT,
    document_type TEXT,
    region        TEXT,
    segment       TEXT,
    customer_name TEXT,
    opco          TEXT,
    content_type  TEXT,
    size_bytes    BIGINT,
    gcs_updated   TIMESTAMPTZ,
    chunk_index   INTEGER     NOT NULL DEFAULT 0,
    chunk_text    TEXT        NOT NULL,
    embedding     VECTOR({EMBEDDING_DIMS}) NOT NULL,
    metadata      JSONB       NOT NULL DEFAULT '{{}}',
    indexed_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS document_vectors_emb_idx
    ON document_vectors USING ivfflat (embedding vector_cosine_ops) WITH (lists = 20);

CREATE INDEX IF NOT EXISTS document_vectors_gcs_idx
    ON document_vectors (gcs_uri);

CREATE INDEX IF NOT EXISTS document_vectors_bid_idx
    ON document_vectors (bid_id);

CREATE INDEX IF NOT EXISTS document_vectors_doc_idx
    ON document_vectors (document_id);

CREATE INDEX IF NOT EXISTS document_vectors_region_idx
    ON document_vectors (region);

CREATE INDEX IF NOT EXISTS document_vectors_segment_idx
    ON document_vectors (segment);
"""


def _vec(v: list[float]) -> str:
    return "[" + ",".join(str(x) for x in v) + "]"


async def setup_table(conn: Any) -> None:
    from sqlalchemy import text
    for statement in CREATE_TABLE_SQL.strip().split(";"):
        stmt = statement.strip()
        if stmt:
            await conn.execute(text(stmt))
    await conn.commit()


async def delete_document_chunks(conn: Any, document_id: str) -> int:
    """Delete all existing chunks for a document; returns count removed."""
    from sqlalchemy import text
    result = await conn.execute(
        text("DELETE FROM document_vectors WHERE document_id = :doc_id"),
        {"doc_id": document_id},
    )
    await conn.commit()
    return result.rowcount


async def insert_chunk(
    conn: Any,
    *,
    row_id: str,
    document_id: str,
    doc: dict,
    file_name: str,
    file_type: str,
    chunk_index: int,
    chunk_text: str,
    embedding: list[float],
) -> None:
    from sqlalchemy import text
    # Local docs use a synthetic gcs_uri so the canonical schema's NOT NULL constraint is met
    gcs_uri = f"local://{document_id}/{file_name}"
    metadata = {
        "tags":        doc.get("tags", []),
        "upload_date": doc.get("uploadDate"),
        "status":      doc.get("status"),
        "description": doc.get("description", ""),
        "size_kb":     doc.get("sizeKb"),
        "supplier":    doc.get("supplier", ""),
        "supplier_id": doc.get("supplierId", ""),
    }
    await conn.execute(
        text("""
        INSERT INTO document_vectors
            (id, gcs_uri, bucket, object_name, file_name, file_type,
             bid_id, rfp_id, document_id, document_type,
             chunk_index, chunk_text, embedding, metadata, indexed_at)
        VALUES
            (:id, :gcs_uri, :bucket, :object_name, :file_name, :file_type,
             :bid_id, :bid_id, :document_id, :document_type,
             :chunk_index, :chunk_text, CAST(:embedding AS vector), CAST(:metadata AS jsonb), now())
        ON CONFLICT (id) DO UPDATE
            SET chunk_text    = EXCLUDED.chunk_text,
                embedding     = EXCLUDED.embedding,
                metadata      = EXCLUDED.metadata,
                document_type = EXCLUDED.document_type,
                bid_id        = EXCLUDED.bid_id,
                indexed_at    = now()
        """),
        {
            "id":            row_id,
            "gcs_uri":       gcs_uri,
            "bucket":        "local",
            "object_name":   file_name,
            "file_name":     file_name,
            "file_type":     file_type.lstrip("."),
            "bid_id":        doc.get("bidId"),
            "document_id":   document_id,
            "document_type": doc.get("documentType"),
            "chunk_index":   chunk_index,
            "chunk_text":    chunk_text,
            "embedding":     _vec(embedding),
            "metadata":      json.dumps(metadata),
        },
    )
    await conn.commit()


# ── Main logic ────────────────────────────────────────────────────────────────

async def process_document(
    doc: dict,
    *,
    conn: Any,
    settings: Any,
    dry_run: bool,
) -> tuple[int, int]:
    """
    Process one document record.
    Returns (chunks_indexed, chunks_skipped).
    """
    doc_id = doc.get("id", "?")
    file_name = doc.get("fileName", "")
    file_type = doc.get("fileType", Path(file_name).suffix)

    # Locate file in uploads/
    file_path = UPLOADS_DIR / file_name
    if not file_path.exists():
        # Some documents are metadata-only (no uploaded file)
        print(f"    ⚠  File not found: {file_name} — skipping")
        return 0, 0

    # Extract text
    raw_text = extract_text(file_path, file_type)
    if not raw_text:
        print(f"    ⚠  No text extracted from {file_name} — skipping")
        return 0, 0

    # Prepend document metadata so the embedding encodes context, not just content
    meta_header = " | ".join(filter(None, [
        doc.get("documentType"),
        doc.get("supplier"),
        doc.get("bidId"),
        ", ".join(doc.get("tags", [])),
        doc.get("description", ""),
    ]))
    full_text = f"{meta_header}\n\n{raw_text}" if meta_header else raw_text

    chunks = chunk_text(full_text)
    if not chunks:
        return 0, 0

    print(f"    {len(chunks)} chunk(s) from {len(raw_text):,} chars")

    if dry_run:
        for i, c in enumerate(chunks):
            print(f"      chunk {i}: {c[:80]!r}...")
        return len(chunks), 0

    # Delete old chunks for this document so re-indexing is clean
    removed = await delete_document_chunks(conn, doc_id)
    if removed:
        print(f"    removed {removed} old chunk(s)")

    # Embed in batches, then insert
    indexed = 0
    for batch_start in range(0, len(chunks), BATCH_SIZE):
        batch = chunks[batch_start : batch_start + BATCH_SIZE]
        embeddings = await embed_batch(batch, settings)

        for i, (chunk, emb) in enumerate(zip(batch, embeddings)):
            global_idx = batch_start + i
            row_id = f"{doc_id}::chunk:{global_idx}"
            await insert_chunk(
                conn,
                row_id=row_id,
                document_id=doc_id,
                doc=doc,
                file_name=file_name,
                file_type=file_type,
                chunk_index=global_idx,
                chunk_text=chunk,
                embedding=emb,
            )
            indexed += 1

    return indexed, 0


async def main(doc_id_filter: str | None, dry_run: bool) -> None:
    from db.connection import get_db_conn

    settings = _settings_from_env()

    if not settings.db_host:
        print("❌  DB_HOST not set in .env")
        print("    Add: DB_HOST=<PSC_endpoint_IP>")
        return

    docs: list[dict] = json.loads((DATA_DIR / "documents.json").read_text())

    if doc_id_filter:
        docs = [d for d in docs if d.get("id") == doc_id_filter]
        if not docs:
            print(f"❌  No document with id={doc_id_filter!r} in documents.json")
            return

    print(f"\nConnecting to PostgreSQL ({settings.db_host}:{settings.db_port})...")

    total_chunks = 0
    ok = skipped = errors = 0

    if dry_run:
        print("⚠   DRY RUN — no DB writes\n")
        print(f"Processing {len(docs)} document(s)...\n")
        for doc in docs:
            doc_id = doc.get("id", "?")
            file_name = doc.get("fileName", "?")
            doc_type = doc.get("documentType", "")
            print(f"  [{doc_id}] {file_name}  ({doc_type})")
            try:
                indexed, _ = await process_document(doc, conn=None, settings=settings, dry_run=True)
                if indexed:
                    total_chunks += indexed
                    ok += 1
                    print(f"    ✅  {indexed} chunk(s) indexed")
                else:
                    skipped += 1
            except Exception as exc:
                print(f"    ❌  ERROR: {exc}")
                errors += 1
            print()
    else:
        async with get_db_conn(settings) as conn:
            if conn is None:
                print("❌  Could not connect to PostgreSQL — check DB_HOST and credentials.")
                return
            print("✅  Connected\n")
            print("Setting up document_vectors table...")
            await setup_table(conn)
            print("✅  Table ready\n")
            print(f"Processing {len(docs)} document(s)...\n")

            for doc in docs:
                doc_id = doc.get("id", "?")
                file_name = doc.get("fileName", "?")
                doc_type = doc.get("documentType", "")
                print(f"  [{doc_id}] {file_name}  ({doc_type})")
                try:
                    indexed, _ = await process_document(
                        doc, conn=conn, settings=settings, dry_run=False
                    )
                    if indexed:
                        total_chunks += indexed
                        ok += 1
                        print(f"    ✅  {indexed} chunk(s) indexed")
                    else:
                        skipped += 1
                except Exception as exc:
                    print(f"    ❌  ERROR: {exc}")
                    errors += 1
                print()

    width = 50
    print("─" * width)
    print(f"  Documents processed : {ok}")
    print(f"  Total chunks indexed: {total_chunks}")
    print(f"  Skipped (no file)   : {skipped}")
    print(f"  Errors              : {errors}")

    if dry_run:
        print("\n  ⚠   Dry run — nothing written to PostgreSQL.")
    elif errors == 0:
        print("\n  ✅  All done. document_vectors table is ready for RAG queries.")
    else:
        print(f"\n  ⚠   {errors} document(s) failed — re-run to retry.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Embed documents into pgvector (Cloud SQL)")
    parser.add_argument(
        "--doc-id",
        metavar="ID",
        help="Re-index only this document (e.g. DOC-001)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Extract and chunk text but do not write to the database",
    )
    args = parser.parse_args()

    asyncio.run(main(doc_id_filter=args.doc_id, dry_run=args.dry_run))
