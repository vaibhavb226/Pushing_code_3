"""
Benchmark: pdfplumber vs PyMuPDF for RFP PDF text extraction.

Usage (from backend_py/):
    python scripts/benchmark_pdf.py path/to/rfp.pdf

Outputs: extraction time + char count for each library, and a short diff
showing whether the same line-item content is present in both outputs.
"""
from __future__ import annotations

import io
import sys
import time
from pathlib import Path


def _mupdf(pdf_bytes: bytes) -> str:
    import fitz  # PyMuPDF
    doc = fitz.open(stream=pdf_bytes, filetype="pdf")
    text = "\n".join(doc[i].get_text("text") for i in range(len(doc)))
    doc.close()
    return text


def _plumber(pdf_bytes: bytes) -> str:
    import pdfplumber
    with pdfplumber.open(io.BytesIO(pdf_bytes)) as pdf:
        return "\n".join(page.extract_text() or "" for page in pdf.pages)


def _bench(label: str, fn, pdf_bytes: bytes) -> str:
    t0 = time.perf_counter()
    text = fn(pdf_bytes)
    elapsed = time.perf_counter() - t0
    print(f"{label:12s}  {elapsed:.2f}s   {len(text):,} chars")
    return text


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python scripts/benchmark_pdf.py <path_to_rfp.pdf>")
        sys.exit(1)

    pdf_path = Path(sys.argv[1])
    if not pdf_path.exists():
        print(f"File not found: {pdf_path}")
        sys.exit(1)

    pdf_bytes = pdf_path.read_bytes()
    print(f"\nFile: {pdf_path.name}  ({len(pdf_bytes):,} bytes)\n")
    print(f"{'Library':<12}  {'Time':>6}   {'Chars':>10}")
    print("-" * 36)

    text_mupdf   = _bench("PyMuPDF",   _mupdf,   pdf_bytes)
    text_plumber = _bench("pdfplumber", _plumber, pdf_bytes)

    # Quick content similarity check — look for words that appear in both
    words_mupdf   = set(text_mupdf.lower().split())
    words_plumber = set(text_plumber.lower().split())
    common = words_mupdf & words_plumber
    only_plumber = words_plumber - words_mupdf
    only_mupdf   = words_mupdf - words_plumber

    print(f"\nContent overlap: {len(common):,} shared words")
    print(f"Only in pdfplumber: {len(only_plumber):,} words")
    print(f"Only in PyMuPDF:    {len(only_mupdf):,} words")

    if only_plumber:
        sample = sorted(w for w in only_plumber if len(w) > 4)[:10]
        print(f"  pdfplumber-only sample: {sample}")
    if only_mupdf:
        sample = sorted(w for w in only_mupdf if len(w) > 4)[:10]
        print(f"  PyMuPDF-only sample:    {sample}")

    print("\n✅ Run complete. If PyMuPDF is faster and overlap is high, it is safe to switch.")


if __name__ == "__main__":
    main()
