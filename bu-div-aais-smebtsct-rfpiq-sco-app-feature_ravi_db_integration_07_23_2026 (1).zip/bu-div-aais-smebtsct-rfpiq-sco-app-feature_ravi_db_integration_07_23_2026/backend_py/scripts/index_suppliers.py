"""
Index all suppliers from suppliers.json into the pgvector table.

Run once to bootstrap, then re-run after bulk supplier updates.
New suppliers added via POST /api/suppliers are auto-indexed by the API.

Usage (from backend_py/):
    python scripts/index_suppliers.py

Requires in backend_py/.env:
    CLOUD_SQL_CONNECTION_NAME=project:region:instance
    DB_NAME=sysco_rfp
    DB_USER=...
    DB_PASS=...
    GCP_PROJECT=...
    GCP_LOCATION=us-central1  (optional, default us-central1)
"""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from dotenv import load_dotenv
load_dotenv(Path(__file__).parent.parent / ".env", override=True)


async def main() -> None:
    from config import get_settings
    from db.connection import get_db_conn
    from repositories.vector_repo import upsert_supplier
    from services.embedding_service import embed_text, supplier_to_text

    settings = get_settings()

    if not settings.db_host:
        print("❌  DB_HOST is not set in .env — cannot index.")
        print("    Add: DB_HOST=<PSC_endpoint_IP>")
        return

    data_path = Path(__file__).parent.parent / "data" / "suppliers.json"
    suppliers: list[dict] = json.loads(data_path.read_text())

    print(f"\nIndexing {len(suppliers)} suppliers into pgvector ({settings.db_host})...\n")
    ok = skipped = errors = 0

    async with get_db_conn(settings) as conn:
        if conn is None:
            print("❌  Could not connect to PostgreSQL — check DB_HOST and credentials.")
            return

        for supplier in suppliers:
            sid = supplier.get("id", "?")
            name = supplier.get("name", "?")

            if supplier.get("bounce"):
                print(f"  ⚠   {sid} — {name}  (skipped: bounced)")
                skipped += 1
                continue

            try:
                supplier_text = supplier_to_text(supplier)
                embedding = await embed_text(
                    supplier_text, task_type="RETRIEVAL_DOCUMENT", settings=settings
                )
                await upsert_supplier(conn, supplier, embedding)
                print(f"  ✅  {sid} — {name}")
                ok += 1
            except Exception as exc:
                print(f"  ❌  {sid} — {name}  ERROR: {exc}")
                errors += 1

    print(f"\n{'─'*50}")
    print(f"  Indexed : {ok}")
    print(f"  Skipped : {skipped}  (bounced)")
    print(f"  Errors  : {errors}")
    if errors == 0:
        print("\n  ✅  All done. Supplier recommend endpoint is ready.")
    else:
        print(f"\n  ⚠   {errors} supplier(s) failed — re-run to retry.")


if __name__ == "__main__":
    asyncio.run(main())
