#!/usr/bin/env python3
"""
seed_database.py — Load JSON flat files into PostgreSQL tables.

Run from backend_py/:
    python scripts/seed_database.py

Connection params are hardcoded below (DB_HOST / DB_PORT / DB_NAME / DB_USER / DB_PASS).

Idempotent: all inserts use ON CONFLICT (id) DO NOTHING — safe to re-run.

Seeding order (respects FK dependencies):
  1.  customers               derived from bids.json — unique customer → CUST-NNN
  2.  suppliers               suppliers.json
  3.  portal_templates        portalTemplates.json
  4.  poll_state              pollState.json  (UPDATE, not INSERT)
  5.  rfps                     bids.json
  6.  rfp_line_items          lineItems.json
  7.  rfp_solicited_suppliers bids.json → solicitedSuppliers[]
  8.  email_threads           emailThreads.json
  9.  documents               documents.json
  10. unmatched_emails        unmatchedEmails.json
"""
from __future__ import annotations

import asyncio
import json
from datetime import date, datetime, timezone
from pathlib import Path
from typing import Any

import asyncpg

DATA_DIR = Path(__file__).parent.parent / "data"


# ── helpers ──────────────────────────────────────────────────────────────────

def load(filename: str) -> Any:
    path = DATA_DIR / filename
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _date(val: str | None) -> date | None:
    """ISO date string → date, or None."""
    if not val:
        return None
    try:
        return date.fromisoformat(val[:10])
    except (ValueError, TypeError):
        return None


def _dt(val: str | None) -> datetime | None:
    """ISO datetime (with or without 'Z') → aware datetime, or None."""
    if not val:
        return None
    try:
        return datetime.fromisoformat(val.replace("Z", "+00:00"))
    except (ValueError, TypeError):
        return None


def _dt_flex(val: str | None) -> datetime | None:
    """Parse ISO datetime or date-only string → aware datetime, or None."""
    if not val:
        return None
    dt = _dt(val)
    if dt:
        return dt
    d = _date(val)
    if d:
        return datetime(d.year, d.month, d.day, tzinfo=timezone.utc)
    return None


def _js(val: Any) -> str:
    """Serialize value as JSON string (for ::jsonb params)."""
    return json.dumps(val if val is not None else [])


def _jo(val: Any) -> str | None:
    """Serialize dict as JSON string, or None if falsy."""
    if not val:
        return None
    return json.dumps(val)


def _confidence_label(score: int | float | None) -> str | None:
    if score is None:
        return None
    if score >= 90:
        return "High"
    if score >= 75:
        return "Medium"
    return "Low"


# ── 1. customers ─────────────────────────────────────────────────────────────

async def seed_customers(conn: asyncpg.Connection) -> dict[str, str]:
    """Derive unique customers from bids.json. Returns name→id lookup dict."""
    bids = load("bids.json")

    seen: dict[str, dict] = {}
    for b in bids:
        key = b["customer"].strip().lower()
        if key not in seen:
            seen[key] = b

    unique = sorted(seen.values(), key=lambda b: b["customer"].strip().lower())
    name_to_id: dict[str, str] = {}
    rows = []
    for n, b in enumerate(unique, start=1):
        cust_id = f"CUST-{n:03d}"
        name_to_id[b["customer"].strip()] = cust_id
        rows.append((
            cust_id,
            b["customer"].strip(),
            b.get("segment", ""),
            b.get("opco", ""),
            b.get("opcoName", ""),
            b.get("region", ""),
        ))

    await conn.executemany(
        """
        INSERT INTO customers (id, organization_name, segment, opco, opco_name, region)
        VALUES ($1, $2, $3, $4, $5, $6)
        ON CONFLICT (id) DO NOTHING
        """,
        rows,
    )
    print(f"  ✓ {len(rows)} rows → customers")
    return name_to_id


# ── 2. suppliers ─────────────────────────────────────────────────────────────

async def seed_suppliers(conn: asyncpg.Connection) -> None:
    suppliers = load("suppliers.json")
    rows = []
    for s in suppliers:
        rows.append((
            s["id"],                                            # $1  id
            s["name"],                                          # $2  name
            s.get("category", ""),                              # $3  category
            _js(s.get("subcategories", [])),                    # $4  subcategories
            s.get("contactName", ""),                           # $5  contact_name
            s.get("contact", ""),                               # $6  contact_email (renamed from contact)
            s.get("phone", ""),                                 # $7  phone
            s.get("region", "National"),                        # $8  region
            bool(s.get("broker", False)),                       # $9  broker
            _js(s.get("segments", [])),                         # $10 segments
            _js(s.get("tags", [])),                             # $11 tags
            bool(s.get("bounce", False)),                       # $12 bounce
            s.get("notes", ""),                                 # $13 notes
            _js(s.get("additionalEmails", [])),                 # $14 additional_emails
        ))

    await conn.executemany(
        """
        INSERT INTO suppliers
            (id, name, category, subcategories, contact_name, contact_email, phone,
             region, broker, segments, tags, bounce, notes, additional_emails)
        VALUES ($1, $2, $3, $4::jsonb, $5, $6, $7, $8, $9, $10::jsonb, $11::jsonb, $12, $13, $14::jsonb)
        ON CONFLICT (id) DO NOTHING
        """,
        rows,
    )
    print(f"  ✓ {len(rows)} rows → suppliers")


# ── 3. portal_templates ──────────────────────────────────────────────────────

async def seed_portal_templates(conn: asyncpg.Connection) -> None:
    templates = load("portalTemplates.json")
    rows = []
    for t in templates:
        seg = t.get("segment", "")
        rows.append((
            t["id"],                            # $1  id
            t["name"],                          # $2  name
            seg,                                # $3  label  (kept for compat)
            seg,                                # $4  segment (proper column added by add_missing_columns.sql)
            t.get("description", ""),           # $5  description
            _js(t.get("customFields", [])),     # $6  custom_fields
        ))

    await conn.executemany(
        """
        INSERT INTO portal_templates (id, name, label, segment, description, custom_fields)
        VALUES ($1, $2, $3, $4, $5, $6::jsonb)
        ON CONFLICT (id) DO NOTHING
        """,
        rows,
    )
    print(f"  ✓ {len(rows)} rows → portal_templates")


# ── 4. poll_state ─────────────────────────────────────────────────────────────

async def seed_poll_state(conn: asyncpg.Connection) -> None:
    try:
        state = load("pollState.json")
        last_polled = _dt(state.get("lastPolledAt"))
    except FileNotFoundError:
        last_polled = None

    await conn.execute(
        "UPDATE poll_state SET last_polled_at = $1, updated_at = now() WHERE id = 1",
        last_polled,
    )
    print(f"  ✓ poll_state updated  (lastPolledAt={last_polled})")


# ── 5. rfp ────────────────────────────────────────────────────────────────────

async def seed_rfp(conn: asyncpg.Connection, name_to_id: dict[str, str]) -> None:
    bids = load("bids.json")
    rows = []
    for b in bids:
        customer_id = name_to_id.get(b["customer"].strip())
        rows.append((
            b["id"],                                            # $1  id
            b.get("rfpNumber"),                                 # $2  rfp_number
            customer_id,                                        # $3  customer_id
            b["customer"],                                      # $4  customer_name
            b.get("segment", ""),                               # $5  segment
            b.get("opco", ""),                                  # $6  opco
            b.get("opcoName", ""),                              # $7  opco_name
            b.get("region", ""),                                # $8  region
            b.get("status", "Active"),                          # $9  status
            _date(b.get("intakeDate")),                         # $10 intake_date
            _date(b.get("bidRelease")),                         # $11 bid_release
            _date(b.get("customerDue")),                        # $12 customer_due
            _date(b.get("internalDue")),                        # $13 internal_due
            _js(b.get("compliance", [])),                       # $14 compliance
            _js(b.get("itemCategories", [])),                   # $15 item_categories
            b.get("items", 0),                                  # $16 items
            b.get("suppliersContacted", 0),                     # $17 suppliers_contacted
            b.get("responsesReceived", 0),                      # $18 responses_received
            b.get("uploadedRfpPath", ""),                       # $19 uploaded_rfp_path
            b.get("uploadedItemListPath", ""),                  # $20 uploaded_item_list_path
            b.get("_lineItemSource", ""),                       # $21 line_item_source
            _jo(b.get("autoReminder")),                         # $22 auto_reminder
            _jo(b.get("portalConfig")),                         # $23 portal_config
            _jo(b.get("workingFileConfig")),                    # $24 working_file_config
            _date(b.get("lastSolicitationDate")),               # $25 last_solicitation_date
            b.get("notes", ""),                                 # $26 notes
        ))

    await conn.executemany(
        """
        INSERT INTO rfps (
            id, rfp_number, customer_id, customer_name,
            segment, opco, opco_name, region, status,
            intake_date, bid_release, customer_due, internal_due,
            compliance, item_categories,
            items, suppliers_contacted, responses_received,
            uploaded_rfp_path, uploaded_item_list_path, line_item_source,
            auto_reminder, portal_config, working_file_config,
            last_solicitation_date, notes
        ) VALUES (
            $1,  $2,  $3,  $4,
            $5,  $6,  $7,  $8,  $9,
            $10, $11, $12, $13,
            $14::jsonb, $15::jsonb,
            $16, $17, $18,
            $19, $20, $21,
            $22::jsonb, $23::jsonb, $24::jsonb,
            $25, $26
        )
        ON CONFLICT (id) DO NOTHING
        """,
        rows,
    )
    print(f"  ✓ {len(rows)} rows → rfps")


# ── 6. rfp_line_items ────────────────────────────────────────────────────────

async def seed_rfp_line_items(conn: asyncpg.Connection) -> None:
    items = load("lineItems.json")
    valid_rfp_ids = {b["id"] for b in load("bids.json")}
    rows = []
    skipped = 0
    for li in items:
        if li["bidId"] not in valid_rfp_ids:
            skipped += 1
            continue
        bid_item = li.get("bidItem", "0001")
        try:
            line_number = int(bid_item)
        except (ValueError, TypeError):
            line_number = 0

        rows.append((
            li["id"],                                           # $1  id
            li["bidId"],                                        # $2  rfp_id
            bid_item,                                           # $3  bid_item
            line_number,                                        # $4  line_number
            li.get("mpcCode", ""),                              # $5  mpc_code (MPC only — mfgCode is separate)
            li.get("mfgCode", ""),                              # $6  mfg_code
            li.get("gtin", ""),                                 # $7  gtin
            li.get("subcategory", ""),                          # $8  subcategory
            li.get("supc"),                                     # $9  supc (nullable — filled later from item master)
            li.get("brand", ""),                                # $10 brand
            li.get("description", ""),                          # $11 description
            li.get("pack", ""),                                 # $12 pack
            li.get("size", ""),                                 # $13 size
            li.get("unit", ""),                                 # $14 unit
            li.get("category", ""),                             # $15 category
            li.get("qty", 0),                                   # $16 qty
            li.get("storage", ""),                              # $17 storage
            li.get("cw", "N"),                                  # $18 cw
            li.get("stkType", "A"),                             # $19 stk_type
            bool(li.get("buyAmerican", False)),                 # $20 buy_american
            bool(li.get("childNutrition", False)),              # $21 child_nutrition
            bool(li.get("pfsRequired", False)),                 # $22 pfs_required
            bool(li.get("exactSpec", False)),                   # $23 exact_spec
            bool(li.get("rfpPopulated", True)),                 # $24 rfp_populated
            li.get("_source", ""),                              # $25 source
            li.get("trueVendor"),                               # $26 true_vendor
            li.get("suppliedPrice"),                            # $27 supplied_price
            li.get("allw"),                                     # $28 allw
            li.get("dl"),                                       # $29 dl
            li.get("priceCase"),                                # $30 price_case
            li.get("devType"),                                  # $31 dev_type
            bool(li.get("openReview", False)),                  # $32 open_review
            li.get("status", "No Response"),                    # $33 status
            li.get("confidence"),                               # $34 confidence
        ))

    await conn.executemany(
        """
        INSERT INTO rfp_line_items (
            id, rfp_id,
            bid_item, line_number, mpc_code, mfg_code, gtin, subcategory, supc,
            brand, description, pack, size, unit, category,
            qty, storage, cw, stk_type,
            buy_american, child_nutrition, pfs_required, exact_spec, rfp_populated, source,
            true_vendor, supplied_price, allw, dl, price_case, dev_type,
            open_review, status, confidence
        ) VALUES (
            $1,  $2,
            $3,  $4,  $5,  $6,  $7,  $8,  $9,
            $10, $11, $12, $13, $14, $15,
            $16, $17, $18, $19,
            $20, $21, $22, $23, $24, $25,
            $26, $27, $28, $29, $30, $31,
            $32, $33, $34
        )
        ON CONFLICT (id) DO NOTHING
        """,
        rows,
    )
    print(f"  ✓ {len(rows)} rows → rfp_line_items ({skipped} skipped — orphaned bidId)")


# ── 7. rfp_solicited_suppliers ───────────────────────────────────────────────

async def seed_rfp_solicited_suppliers(conn: asyncpg.Connection) -> None:
    bids = load("bids.json")
    valid_supplier_ids = {s["id"] for s in load("suppliers.json")}
    rows = []
    for b in bids:
        for idx, ss in enumerate(b.get("solicitedSuppliers", [])):
            row_id = f"RSS-{b['id']}-{idx:03d}"
            raw_sid = ss.get("supplierId")
            supplier_id = raw_sid if raw_sid in valid_supplier_ids else None
            rows.append((
                row_id,                                         # $1  id
                b["id"],                                        # $2  rfp_id
                supplier_id,                                    # $3  supplier_id (None if not in suppliers table)
                ss.get("supplierName", ""),                     # $4  supplier_name
                ss.get("email", ""),                            # $5  email
                ss.get("category", ""),                         # $6  category
                ss.get("status", "Awaiting"),                   # $7  status
                _date(ss.get("solicitedDate")),                 # $8  solicited_date
                _dt_flex(ss.get("lastActivity")),               # $9  last_activity
                bool(ss.get("hasIssues", False)),               # $10 has_issues
                ss.get("issueType"),                            # $11 issue_type
                _dt(ss.get("bouncedAt")),                       # $12 bounced_at
                ss.get("channel", "Email"),                     # $13 channel
                ss.get("threadId"),                             # $14 thread_id
                _js(ss.get("additionalEmails", [])),            # $15 additional_emails
            ))

    await conn.executemany(
        """
        INSERT INTO rfp_solicited_suppliers (
            id, rfp_id, supplier_id, supplier_name, email, category,
            status, solicited_date, last_activity,
            has_issues, issue_type, bounced_at,
            channel, thread_id, additional_emails
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15::jsonb)
        ON CONFLICT (id) DO NOTHING
        """,
        rows,
    )
    print(f"  ✓ {len(rows)} rows → rfp_solicited_suppliers")


# ── 8. email_threads ─────────────────────────────────────────────────────────

async def seed_email_threads(conn: asyncpg.Connection) -> None:
    emails = load("emailThreads.json")
    valid_rfp_ids = {b["id"] for b in load("bids.json")}
    valid_supplier_ids = {s["id"] for s in load("suppliers.json")}
    rows = []
    skipped = 0
    now_utc = datetime.now(timezone.utc)
    for e in emails:
        if e["bidId"] not in valid_rfp_ids:
            skipped += 1
            continue
        raw_sid = e.get("supplierId")
        supplier_id = raw_sid if raw_sid in valid_supplier_ids else None
        rows.append((
            e["id"],                                            # $1  id
            e["bidId"],                                         # $2  rfp_id
            supplier_id,                                        # $3  supplier_id (None if not in suppliers table)
            e.get("supplierName") or "",                        # $4  supplier_name
            e.get("supplierEmail") or "",                       # $5  supplier_email
            e["direction"],                                     # $6  direction
            e.get("subject", ""),                               # $7  subject
            e.get("body", ""),                                  # $8  body
            _dt(e.get("date")) or now_utc,                      # $9  email_date
            e.get("from", ""),                                  # $10 from_address
            e.get("to", ""),                                    # $11 to_address
            _js(e.get("bcc", [])),                              # $12 bcc_addresses
            _js(e.get("tags", [])),                             # $13 tags
            bool(e.get("isBounce", False)),                     # $14 is_bounce
            _jo(e.get("bounceDetails")),                        # $15 bounce_info (column renamed from bounce_details)
            _js(e.get("attachments", [])),                      # $16 attachments
            _jo(e.get("analysisResult")),                       # $17 analysis_result
            e.get("pricingFilePath") or "",                     # $18 pricing_file_path
            bool(e.get("read", False)),                         # $19 read
            e.get("uid"),                                       # $20 uid
            e.get("type"),                                      # $21 type
            e.get("messageId"),                                 # $22 message_id
            bool(e.get("autoMatched", False)),                  # $23 auto_matched
            e.get("originalRecipient"),                         # $24 original_recipient
            e.get("bounceCode"),                                # $25 bounce_code
            e.get("bounceReason"),                              # $26 bounce_reason
        ))

    await conn.executemany(
        """
        INSERT INTO email_threads (
            id, rfp_id, supplier_id, supplier_name, supplier_email,
            direction, subject, body, email_date,
            from_address, to_address, bcc_addresses, tags,
            is_bounce, bounce_info, attachments, analysis_result,
            pricing_file_path, read,
            uid, type, message_id, auto_matched,
            original_recipient, bounce_code, bounce_reason
        ) VALUES (
            $1,  $2,  $3,  $4,  $5,
            $6,  $7,  $8,  $9,
            $10, $11, $12::jsonb, $13::jsonb,
            $14, $15::jsonb, $16::jsonb, $17::jsonb,
            $18, $19,
            $20, $21, $22, $23,
            $24, $25, $26
        )
        ON CONFLICT (id) DO NOTHING
        """,
        rows,
    )
    print(f"  ✓ {len(rows)} rows → email_threads ({skipped} skipped — orphaned bidId)")


# ── 9. documents ─────────────────────────────────────────────────────────────

async def seed_documents(conn: asyncpg.Connection) -> None:
    docs = load("documents.json")
    valid_rfp_ids = {b["id"] for b in load("bids.json")}
    rows = []
    now_utc = datetime.now(timezone.utc)
    for d in docs:
        rfp_id = d.get("bidId")
        if not rfp_id or rfp_id == "ALL" or rfp_id not in valid_rfp_ids:
            rfp_id = None

        rows.append((
            d["id"],                                            # $1  id
            rfp_id,                                             # $2  rfp_id
            d.get("supplierId"),                                # $3  supplier_id
            d.get("fileName", ""),                              # $4  file_name
            d.get("fileType", ""),                              # $5  file_type
            d.get("sizeKb") or 0,                               # $6  size_kb
            d.get("documentType", ""),                          # $7  document_type
            _js(d.get("tags", [])),                             # $8  tags
            _dt_flex(d.get("uploadDate")) or now_utc,           # $9  upload_date
            d.get("uploadedBy", ""),                            # $10 uploaded_by
            d.get("status", "Filed"),                           # $11 status
            d.get("filePath", "") or "",                        # $12 file_path
            d.get("description", "") or "",                     # $13 description
            d.get("category", "") or "",                        # $14 category (from fix_schema_columns.sql)
            d.get("notes", "") or "",                           # $15 notes (from fix_schema_columns.sql)
            d.get("supplier", "") or "",                        # $16 supplier (denorm name)
            d.get("supplierCategory", "") or "",                # $17 supplier_category
            d.get("extractionConfidence"),                      # $18 extraction_confidence (nullable int)
            _js(d.get("linkedLineItems", [])),                  # $19 linked_line_items
        ))

    await conn.executemany(
        """
        INSERT INTO documents (
            id, rfp_id, supplier_id, file_name, file_type, size_kb,
            document_type, tags, upload_date, uploaded_by, status,
            file_path, description, category, notes,
            supplier, supplier_category, extraction_confidence, linked_line_items
        ) VALUES (
            $1, $2, $3, $4, $5, $6,
            $7, $8::jsonb, $9, $10, $11,
            $12, $13, $14, $15,
            $16, $17, $18, $19::jsonb
        )
        ON CONFLICT (id) DO NOTHING
        """,
        rows,
    )
    print(f"  ✓ {len(rows)} rows → documents")


# ── 10. unmatched_emails ─────────────────────────────────────────────────────

async def seed_unmatched_emails(conn: asyncpg.Connection) -> None:
    emails = load("unmatchedEmails.json")
    rows = []
    for e in emails:
        rows.append((
            e["id"],                                            # $1  id
            e.get("subject", ""),                               # $2  subject
            e.get("from", ""),                                  # $3  from_address
            e.get("body", ""),                                  # $4  body
            _dt(e.get("date")),                                 # $5  received_at
            json.dumps(e),                                      # $6  raw_payload
        ))

    await conn.executemany(
        """
        INSERT INTO unmatched_emails (id, subject, from_address, body, received_at, raw_payload)
        VALUES ($1, $2, $3, $4, $5, $6::jsonb)
        ON CONFLICT (id) DO NOTHING
        """,
        rows,
    )
    print(f"  ✓ {len(rows)} rows → unmatched_emails")


# ── main ─────────────────────────────────────────────────────────────────────

async def main() -> None:
    # ── Connection parameters — update before running ──────────────────────────
    DB_HOST = "10.151.179.4"
    DB_PORT = 5432
    DB_NAME = "postgres"
    DB_USER = "postgres"
    DB_PASS = "Rfpiq-usc1"
    # ──────────────────────────────────────────────────────────────────────────

    print(f"Connecting to {DB_HOST}:{DB_PORT}/{DB_NAME} …")
    conn = await asyncpg.connect(
        host=DB_HOST, port=DB_PORT, database=DB_NAME, user=DB_USER, password=DB_PASS
    )
    print("Connected.\n")

    try:
        name_to_id = await seed_customers(conn)
        await seed_suppliers(conn)
        await seed_portal_templates(conn)
        await seed_poll_state(conn)
        await seed_rfp(conn, name_to_id)
        await seed_rfp_line_items(conn)
        await seed_rfp_solicited_suppliers(conn)
        await seed_email_threads(conn)
        await seed_documents(conn)
        await seed_unmatched_emails(conn)
    finally:
        await conn.close()

    print("\n✅ Seed complete.")
    print(
        "\nVerify with:\n"
        "  SELECT 'customers' AS t, COUNT(*) FROM customers\n"
        "  UNION ALL SELECT 'suppliers',               COUNT(*) FROM suppliers\n"
        "  UNION ALL SELECT 'portal_templates',        COUNT(*) FROM portal_templates\n"
        "  UNION ALL SELECT 'rfps',                     COUNT(*) FROM rfps\n"
        "  UNION ALL SELECT 'rfp_line_items',          COUNT(*) FROM rfp_line_items\n"
        "  UNION ALL SELECT 'rfp_solicited_suppliers', COUNT(*) FROM rfp_solicited_suppliers\n"
        "  UNION ALL SELECT 'email_threads',           COUNT(*) FROM email_threads\n"
        "  UNION ALL SELECT 'documents',               COUNT(*) FROM documents\n"
        "  UNION ALL SELECT 'unmatched_emails',        COUNT(*) FROM unmatched_emails;"
    )


if __name__ == "__main__":
    asyncio.run(main())
