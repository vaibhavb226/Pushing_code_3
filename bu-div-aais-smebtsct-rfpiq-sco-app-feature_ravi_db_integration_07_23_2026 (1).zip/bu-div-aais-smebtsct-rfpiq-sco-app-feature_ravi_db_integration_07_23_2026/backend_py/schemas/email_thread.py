from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class EmailAttachment(BaseModel):
    originalName: str
    savedName: str
    path: str
    mimeType: str = ""


class EmailCreate(BaseModel):
    direction: str  # inbound | outbound
    supplierId: str | None = None
    supplierName: str | None = None
    supplierEmail: str | None = None
    from_: str | None = None
    to: str | None = None
    bcc: list[str] = []
    subject: str = ""
    body: str = ""
    tags: list[str] = []
    attachmentNames: list[str] = []
    attachmentPaths: list[str] = []


class EmailThreadResponse(BaseModel):
    model_config = {"extra": "allow"}

    id: str
    bidId: str
    direction: str
    supplierId: str | None = None
    supplierName: str | None = None
    supplierEmail: str | None = None
    subject: str = ""
    body: str = ""
    date: str
    tags: list[str] = []
    read: bool = False
    attachments: list[dict[str, Any]] = []
    isBounce: bool = False
    analysisResult: dict[str, Any] | None = None
