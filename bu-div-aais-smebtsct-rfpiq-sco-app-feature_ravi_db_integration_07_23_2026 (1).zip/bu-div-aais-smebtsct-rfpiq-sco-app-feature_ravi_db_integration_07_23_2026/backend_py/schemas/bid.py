from __future__ import annotations

from datetime import date
from typing import Any

from pydantic import BaseModel, Field


class SolicitedSupplier(BaseModel):
    supplierId: str | None = None
    supplierName: str
    email: str
    status: str = "Awaiting"
    lastActivity: str | None = None
    solicitedDate: str | None = None
    awardNotificationSent: bool = False
    awardNotificationSentAt: str | None = None


class AutoReminder(BaseModel):
    enabled: bool = False
    daysAfterSolicitation: int = 3
    lastReminderSent: str | None = None


class PortalConfig(BaseModel):
    templateId: str | None = None
    appliedAt: str | None = None
    customFields: list[dict[str, Any]] = []


class UploadedFile(BaseModel):
    id: str
    name: str
    type: str
    mimetype: str
    size: str
    uploadedAt: str
    path: str
    notes: str | None = None


class BidCreate(BaseModel):
    customer: str = Field(..., min_length=1)
    id: str | None = None
    rfpNumber: str | None = None
    opco: str | None = None
    opcoName: str | None = None
    region: str | None = None
    segment: str | None = None
    status: str = "Active"
    intakeDate: str | None = None
    customerDue: str | None = None
    internalDue: str | None = None
    bidRelease: str | None = None
    items: int = 0
    suppliersContacted: int = 0
    responsesReceived: int = 0
    notes: str | None = None
    compliance: list[str] = []
    itemCategories: list[str] = []


class BidUpdate(BaseModel):
    customer: str | None = None
    rfpNumber: str | None = None
    opco: str | None = None
    opcoName: str | None = None
    region: str | None = None
    segment: str | None = None
    status: str | None = None
    customerDue: str | None = None
    internalDue: str | None = None
    bidRelease: str | None = None
    notes: str | None = None
    compliance: list[str] | None = None
    itemCategories: list[str] | None = None
    solicitedSuppliers: list[dict[str, Any]] | None = None
    lastSolicitationDate: str | None = None
    autoReminder: dict[str, Any] | None = None
    portalConfig: dict[str, Any] | None = None
    workingFileConfig: dict[str, Any] | None = None


class BidResponse(BaseModel):
    model_config = {"extra": "allow"}

    id: str
    rfpNumber: str | None = None
    customer: str
    status: str
    segment: str | None = None
    opco: str | None = None
    opcoName: str | None = None
    region: str | None = None
    intakeDate: str | None = None
    customerDue: str | None = None
    internalDue: str | None = None
    bidRelease: str | None = None
    items: int = 0
    suppliersContacted: int = 0
    responsesReceived: int = 0
    notes: str | None = None
    compliance: list[str] = []
    itemCategories: list[str] = []
    solicitedSuppliers: list[dict[str, Any]] = []
    uploadedFiles: list[dict[str, Any]] = []
    autoReminder: dict[str, Any] | None = None
    portalConfig: dict[str, Any] | None = None


class DeleteResult(BaseModel):
    success: bool
    deleted: str
    removed: dict[str, int]
