from __future__ import annotations

from pydantic import BaseModel, EmailStr, Field


class SupplierCreate(BaseModel):
    name: str = Field(..., min_length=1)
    category: str = "Grocery"
    categories: list[str] = []     # multi-select; primary = categories[0]; overrides category when non-empty
    subcategories: list[str] = []
    region: str = "National"
    contact: str = ""
    contactName: str = ""
    phone: str = ""
    broker: bool = False
    segments: list[str] = []
    tags: list[str] = []
    notes: str = ""
    additionalEmails: list[str] = []


class SupplierResponse(BaseModel):
    model_config = {"extra": "allow"}

    id: str
    name: str
    category: str
    categories: list[str] = []
    subcategories: list[str] = []
    region: str
    contact: str = ""
    contactName: str = ""
    phone: str = ""
    broker: bool = False
    segments: list[str] = []
    tags: list[str] = []
    notes: str = ""
    bounce: bool = False
    additionalEmails: list[str] = []


class AutoPopulateRequest(BaseModel):
    itemCategories: list[str]
    segment: str = ""
    complianceFlags: list[str] = []
    excludeBounced: bool = True


class RecommendRequest(BaseModel):
    customerName: str = ""
    segment: str = ""
    complianceFlags: list[str] = []
    itemCategories: list[str] = []
    topLineItems: list[str] = []   # top item descriptions (brand + description + size)
    topK: int = 20
    excludeBounced: bool = True
