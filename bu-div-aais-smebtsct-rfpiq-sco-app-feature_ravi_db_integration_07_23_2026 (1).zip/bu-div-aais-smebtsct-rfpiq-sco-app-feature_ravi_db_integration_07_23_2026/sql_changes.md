I already have all the files in context from the prior review. Let me do the performance analysis now.

I have all the data I need. Comprehensive performance review follows.

---

## Performance Review — FoodCorp RFP AIQ Backend

---

## CRITICAL

---

### P-C1 — Email Poller Full Table Scan Every 15 Seconds

**File:** [`backend_py/services/email_poller.py:198`](backend_py/services/email_poller.py), [`backend_py/repositories/pg_bids_repo.py:85-103`](backend_py/repositories/pg_bids_repo.py)

```python
# email_poller.py — runs every 15 seconds
bids = await bids_repo.load()    # ← fires on EVERY poll cycle
```

```python
# pg_bids_repo.py — load()
bid_rows = await conn.fetch("SELECT * FROM rfps ORDER BY created_at")
ss_rows  = await conn.fetch("SELECT * FROM rfp_solicited_suppliers ORDER BY rfp_id, id")
```

Every 15 seconds the poller issues two unbounded `SELECT *` queries:

1. Deserializes every `rfps` row including 6 JSONB columns (`uploaded_files`, `compliance`, `item_categories`, `auto_reminder`, `portal_config`, `working_file_config`)
2. Deserializes every `rfp_solicited_suppliers` row
3. Stitches them into Python dicts via `defaultdict`
4. Then pattern-matches incoming emails against the in-memory list

This happens regardless of whether any new email arrived. When the inbox is empty (the common case — most polls return 0 messages), the poller still does a full two-table load and throws the result away.

**DB calls per cycle:** 2 unconditional full table scans + 1 poll_state read = **3 queries minimum every 15 seconds**

**Expected impact:**
- 100 users: ~240 poll-triggered queries/minute just from the poller alone; competes for pool connections with real user requests
- 1 000 users: bid table and ss table grow proportionally; queries take longer; pool starvation begins
- 10 000 users: poller and UI compete for the same 10 pool connections; median request latency spikes to seconds

**Fix:** Cache the bid list in memory with a short TTL (30 seconds is fine — longer than the poll interval). Invalidate on any bid write.

```python
import time
_bid_cache: list[dict] | None = None
_bid_cache_ts: float = 0.0
_BID_CACHE_TTL = 30.0  # seconds

async def _get_bids_cached(bids_repo) -> list[dict]:
    global _bid_cache, _bid_cache_ts
    now = time.monotonic()
    if _bid_cache is None or (now - _bid_cache_ts) > _BID_CACHE_TTL:
        _bid_cache = await bids_repo.load()
        _bid_cache_ts = now
    return _bid_cache
```

Alternatively, only reload the specific bid when tier-1 matching finds a bid ID in the subject — the hot path for replies.

---

### P-C2 — N+1 Query Explosion: PgSubmissionsRepository

**File:** [`backend_py/repositories/pg_submissions_repo.py:231-249`](backend_py/repositories/pg_submissions_repo.py)

```python
async def load(self) -> dict[str, list]:
    async with _pool().acquire() as conn:
        bid_rows = await conn.fetch("SELECT * FROM bids ORDER BY submitted_at")
        grouped: dict[str, list] = {}
        for row in bid_rows:
            sub = await _build_submission(conn, row)   # 2 queries per row ← N+1
            grouped.setdefault(row["rfp_id"], []).append(sub)
    return grouped

async def get_for_bid(self, bid_id: str) -> list:
    async with _pool().acquire() as conn:
        bid_rows = await conn.fetch("SELECT * FROM bids WHERE rfp_id = $1 ...", bid_id)
        for row in bid_rows:
            result.append(await _build_submission(conn, row))   # same N+1
```

`_build_submission` fires:
- `SELECT * FROM bid_line_items WHERE bid_id = $1`
- `SELECT * FROM submission_messages WHERE bid_id = $1`

**Total queries per `load()` call:** `1 + 2N` where N = total submission count  
**Total queries per `get_for_bid()`:** `1 + 2N` where N = submissions for that bid

`get_for_bid` is called from:
- `GET /api/submit/{bid_id}/thread/{thread_id}` — polled every 15s by every open supplier browser tab
- `POST /api/submit/{bid_id}/message`
- `GET /api/submit/{bid_id}/submissions`

**At 50 submissions per bid, `get_for_bid` = 101 queries per call. With 20 supplier tabs open and 15s polling: 101 × 80/min = 8 080 queries/minute from portal polling alone.**

**Fix:** Batch-load with `ANY($1::text[])`:

```python
async def get_for_bid(self, bid_id: str) -> list:
    async with _pool().acquire() as conn:
        bid_rows = await conn.fetch(
            "SELECT * FROM bids WHERE rfp_id = $1 ORDER BY submitted_at", bid_id
        )
        if not bid_rows:
            return []
        pks = [r["id"] for r in bid_rows]
        li_rows  = await conn.fetch(
            "SELECT * FROM bid_line_items WHERE bid_id = ANY($1::text[]) ORDER BY item_no", pks
        )
        msg_rows = await conn.fetch(
            "SELECT * FROM submission_messages WHERE bid_id = ANY($1::text[]) ORDER BY message_ts", pks
        )
    # join in Python — O(N), zero extra queries
    li_by_bid  = defaultdict(list)
    msg_by_bid = defaultdict(list)
    for r in li_rows:  li_by_bid[r["bid_id"]].append(_line_item_to_app(r))
    for r in msg_rows: msg_by_bid[r["bid_id"]].append(_msg_to_app(r))
    return [_bid_to_app(row, li_by_bid[row["id"]], msg_by_bid[row["id"]]) for row in bid_rows]
```

**Query count after fix:** always 3, regardless of submission count.

---

### P-C3 — Full Table Scan on Every Predicate-Based Write (line items, suppliers, etc.)

**File:** [`backend_py/repositories/pg_base.py:138-156`](backend_py/repositories/pg_base.py)

```python
async def find_one(self, predicate: Callable) -> dict | None:
    rows = await self.load()             # SELECT * FROM {table} ORDER BY {col}
    return next((r for r in rows if predicate(r)), None)

async def update_one(self, predicate, updater) -> dict | None:
    item = await self.find_one(predicate)   # full table scan
    ...
    async with self._pool().acquire() as conn:
        await self._update_in_place(conn, updated)

async def delete_where(self, predicate) -> int:
    rows = await self.load()             # full table scan
    ids  = [r["id"] for r in rows if predicate(r)]
```

Every call to `update_one` or `delete_where` in any PG repository triggers a `SELECT *` of the entire table, returns all rows to Python, applies the predicate in Python, then writes. There is no WHERE clause pushed to the database.

**Affected hot paths:**
- `PATCH /api/bids/{id}/line-items/{line_id}` → `repo.update_one(lambda x: x["id"] == line_id)` — loads ALL line items for ALL bids
- `DELETE /api/bids/{id}/line-items/{line_id}` → `repo.delete_where(...)` — same
- `DELETE /api/bids/{id}/line-items/{line_id}/supplier-pricing` → same
- `update_customer` → `customers_repo.update_one(lambda c: c["id"] == customer_id)` — loads ALL customers
- Every Working File save → full `rfp_line_items` table scan

**Fix:** Each PG repo subclass must override `update_one` and `delete_where` with targeted queries. The base class default is only safe for tiny tables. Example for line items:

```python
# pg_line_items_repo.py
async def update_by_id(self, line_id: str, updater) -> dict | None:
    async with self._pool().acquire() as conn:
        async with conn.transaction():
            row = await conn.fetchrow(
                "SELECT * FROM rfp_line_items WHERE id = $1 FOR UPDATE", line_id
            )
            if row is None:
                return None
            updated = updater(self._to_app(row))
            await self._update_in_place(conn, updated)
    return updated

async def delete_by_id(self, line_id: str, bid_id: str) -> int:
    async with self._pool().acquire() as conn:
        result = await conn.execute(
            "DELETE FROM rfp_line_items WHERE id = $1 AND bid_id = $2", line_id, bid_id
        )
    return int(result.split()[-1])
```

---

### P-C4 — `GET /api/bids/{id}/emails/by-supplier` Loads Entire Suppliers Table Per Request (Polled Every 15s)

**File:** [`backend_py/routers/bids.py:850`](backend_py/routers/bids.py)

```python
@router.get("/{bid_id}/emails/by-supplier")
async def get_emails_by_supplier(bid_id, bids_repo, email_threads_repo, suppliers_repo):
    bid        = await bids_repo.find_by_id(bid_id)      # 2 queries
    all_emails = await email_threads_repo.get_for_bid(bid_id)   # 1 query
    all_suppliers = await suppliers_repo.load()          # SELECT * FROM suppliers ← full scan
    supplier_by_id = {s["id"]: s for s in all_suppliers if s.get("id")}
```

This endpoint:
1. Fires `suppliers_repo.load()` = `SELECT * FROM suppliers ORDER BY created_at` — all 20+ supplier records with all fields — **on every call**
2. Only uses `sup_record.get("broker", False)` — one boolean field per supplier
3. Is polled every 15 seconds from the Email Repo tab while it's open
4. Has an O(N²) inner loop: `next((s for s in solicited if s.get("supplierId") == supplier_id), None)` — linear scan of `solicited` list for each entry in `relevant_ids`

**DB calls:** 4 sequential (find_by_id × 2, get_for_bid × 1, suppliers.load × 1)  
**With 5 open Email Repo tabs:** 20 queries/minute just for the broker flag

**Fix:**  
1. Only load supplier IDs needed: `SELECT id, broker FROM suppliers WHERE id = ANY($1::text[])` using the supplier IDs from `solicited`  
2. Pre-build solicited dict before the loop: `sol_by_id = {s["supplierId"]: s for s in solicited if s.get("supplierId")}`  
3. Cache the supplier broker map (it changes almost never)

```python
# Replace full load with targeted query
supplier_ids = [s["supplierId"] for s in solicited if s.get("supplierId")]
broker_rows  = await conn.fetch(
    "SELECT id, broker FROM suppliers WHERE id = ANY($1::text[])", supplier_ids
)
broker_by_id = {r["id"]: r["broker"] for r in broker_rows}

# Replace O(N²) loop
sol_by_id = {s["supplierId"]: s for s in solicited if s.get("supplierId")}
for supplier_id in relevant_ids:
    sol_entry = sol_by_id.get(supplier_id)
```

---

## HIGH

---

### P-H1 — `GET /api/bids` Returns Full Dataset with 6 JSONB Columns, No Pagination

**File:** [`backend_py/routers/bids.py:150-165`](backend_py/routers/bids.py), [`backend_py/repositories/pg_bids_repo.py:85-103`](backend_py/repositories/pg_bids_repo.py)

```python
async def list_bids(segment=None, status=None, repo=...):
    bids = await repo.load()           # SELECT * — all rows, all columns
    if segment:
        bids = [b for b in bids if b.get("segment") == segment]
    if status:
        bids = [b for b in bids if b.get("status") == status]
    return bids
```

- `SELECT *` on `rfps` includes `uploaded_files` (JSONB array of file objects), `auto_reminder`, `portal_config`, `working_file_config`
- Segment and status filters run in Python after full table fetch — the DB does no filtering
- No `LIMIT`/`OFFSET` — returns all bids to all callers
- `SELECT * FROM rfp_solicited_suppliers` also loaded — every supplier email, status, etc. for every bid

**With 500 bids × 30 suppliers each, the homepage response is 500 × (rfp row + 30 solicited rows) = ~15 500 DB rows deserialized, stitched, serialized to JSON, transmitted on every page load.**

**Fix:**

```sql
-- Push filters to DB
SELECT id, rfp_number, customer_name, customer_id, segment, status,
       customer_due, internal_due, items, suppliers_contacted, responses_received,
       compliance, item_categories, created_at
FROM rfps
WHERE ($1::text IS NULL OR segment = $1)
  AND ($2::text IS NULL OR status = $2)
ORDER BY created_at DESC
LIMIT 100 OFFSET $3;
```

Add indexes:
```sql
CREATE INDEX rfps_segment_status_idx ON rfps (segment, status);
CREATE INDEX rfps_created_at_idx ON rfps (created_at DESC);
```

Lazy-load `solicitedSuppliers` only when the individual bid detail page opens — the homepage only needs counts.

---

### P-H2 — `get_thread` Has 7+ Sequential DB Round Trips Per 15-Second Poll

**File:** [`backend_py/routers/submissions.py:315-389`](backend_py/routers/submissions.py)

```python
all_subs   = await submissions_repo.get_for_bid(bid_id)    # 1 + 2N queries (N+1)
sub        = next(...)
# ... mark read ...
await submissions_repo.update_submission(bid_id, thread_id, ...)  # 3 queries
line_items = await line_items_repo.get_for_bid(bid_id)             # 1 query  ← sequential
bid        = await bids_repo.find_by_id(bid_id)                    # 2 queries ← sequential
```

Steps are fully sequential; `line_items_repo.get_for_bid` and `bids_repo.find_by_id` have no data dependency on each other. Called every 15 seconds per open supplier portal tab.

**Fix:** After resolving P-C2 (so `get_for_bid` is 3 queries not N+1), parallelize the final two reads:

```python
# After finding sub and marking read:
line_items, bid = await asyncio.gather(
    line_items_repo.get_for_bid(bid_id),
    bids_repo.find_by_id(bid_id),
)
```

---

### P-H3 — `submit_pricing` Issues 13+ Sequential DB Calls for a Single Submission

**File:** [`backend_py/routers/submissions.py:93-280`](backend_py/routers/submissions.py)

```python
bid    = await bids_repo.find_by_id(bid_id)          # 2 queries
# file write — blocking I/O
# GCS upload — network I/O
await submissions_repo.append_for_bid(bid_id, sub)   # 3 inserts
await email_threads_repo.append(email_record)        # 1 insert
await _update_supplier_responded(...)                # find_by_id(2) + UPDATE + DELETE + INSERT
```

All are sequential. `append_for_bid` and `email_threads_repo.append` are independent and can run concurrently after the insert-bid step. `_update_supplier_responded` must wait for `find_by_id` but the email append does not depend on it.

**Minimum DB calls:** 2 + 3 + 1 + (2+3) = **11 round trips** on the critical path of a supplier submitting pricing.

**Fix:**

```python
bid = await bids_repo.find_by_id(bid_id)
# ... file handling ...

# Run DB writes that don't depend on each other in parallel
await asyncio.gather(
    submissions_repo.append_for_bid(bid_id, submission),
    email_threads_repo.append(email_record),
)
await _update_supplier_responded(bid_id, supplier_email, thread_id, bids_repo)
```

---

### P-H4 — Customer Search Uses Leading-Wildcard LIKE — No Index Possible

**File:** [`backend_py/repositories/pg_customers_repo.py:131-143`](backend_py/repositories/pg_customers_repo.py)

```python
async def search(self, query: str) -> list[dict]:
    rows = await conn.fetch(
        "SELECT * FROM customers WHERE lower(organization_name) LIKE lower($1) LIMIT 50",
        f"%{query}%",    # ← leading wildcard forces full table scan
    )
```

A leading `%` in `LIKE` prevents B-tree index use. PostgreSQL will do a sequential scan of every customer row, applying `lower()` to each `organization_name`. At 10 000 customers this is slow; at 100 000 it is unacceptable.

**Fix:** Enable `pg_trgm` and create a GIN index:

```sql
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX customers_org_name_trgm_idx
    ON customers USING GIN (lower(organization_name) gin_trgm_ops);
```

The existing query then uses the trigram index automatically. No code change needed.

Also add for `find_by_name`:
```sql
CREATE UNIQUE INDEX customers_org_name_lower_idx ON customers (lower(organization_name));
```

---

### P-H5 — Connection Pool (max=10) Will Exhaust Under Multi-Instance Cloud Run

**File:** [`backend_py/db/connection.py:112-122`](backend_py/db/connection.py)

```python
_pg_pool = await asyncpg.create_pool(
    ...
    min_size=2,
    max_size=10,   # ← 10 connections per Cloud Run instance
    command_timeout=30,
)
```

Cloud Run auto-scales instances under load. Each instance holds its own pool:
- 5 Cloud Run instances × 10 = 50 asyncpg connections
- Plus 5 × 10 = 50 SQLAlchemy connections (pgvector pool)
- **Total: 100 connections to Cloud SQL** before PgBouncer

Cloud SQL for PostgreSQL defaults to 100 max connections for `db-f1-micro` / `db-g1-small`. At 10 Cloud Run instances you hit the limit. At 20 instances, new connection attempts fail with `FATAL: remaining connection slots are reserved for non-replication superuser connections`.

**The P-C1 full-table-scan + P-C2 N+1 issues compound this**: connections are held longer, reducing effective throughput further.

**Fix:**
1. **Immediate:** Reduce `min_size` to 1, keep `max_size` at 10. Min-size connections are created at pool creation and held even when idle, consuming Cloud SQL connections across all instances 24/7.
2. **Short-term:** Add PgBouncer in transaction pooling mode between Cloud Run and Cloud SQL. PgBouncer can multiplex 100+ asyncpg connections through 5–10 actual Cloud SQL connections.
3. **Long-term:** Use `command_timeout=10` (not 30) so slow queries don't hold connections indefinitely.

```python
# In Cloud Run, scale max_size with CLOUD_RUN_CONCURRENCY env var
import os
max_conns = max(2, int(os.getenv("DB_POOL_MAX", "5")))  # lower default
_pg_pool = await asyncpg.create_pool(..., min_size=1, max_size=max_conns)
```

---

### P-H6 — Two Separate Connection Acquisitions in `update_by_id` (Read-Then-Write)

**File:** [`backend_py/repositories/pg_bids_repo.py:126-142`](backend_py/repositories/pg_bids_repo.py)

```python
async def update_by_id(self, bid_id, updater):
    item = await self.find_by_id(bid_id)      # acquires conn, releases it
    updated = updater(item)
    async with self._pool().acquire() as conn:    # acquires a SECOND conn
        await self._update_rfp(conn, updated)
        await conn.execute("DELETE FROM rfp_solicited_suppliers ...")
        await self._insert_solicited(conn, ...)
```

Two pool acquisitions per update. Under high concurrency, the pool is drained twice as fast per update. The gap between release and reacquire is also where a concurrent writer can step in (lost update — already flagged in the correctness review, but it also means extra pool churn per update).

**Fix:** Combine into one connection context with a transaction (as noted in the correctness review). The performance benefit is one pool checkout instead of two plus the transaction gives serialization.

---

### P-H7 — `GET /api/bids` Triggers `SELECT *` Including All JSONB on Every React Navigation

The homepage fetches `GET /api/bids` on mount and on every route change that includes the bid list. The response includes for every bid:
- `uploadedFiles` (JSONB array — can be multiple MB of file metadata for old bids)
- `workingFileConfig` (JSONB — column config array)
- `portalConfig` (JSONB — template + custom fields)
- `autoReminder` (JSONB)

These are only needed on the individual bid detail page, not the list. If `uploadedFiles` has 10 documents per bid × 200 bids = 2 000 file objects serialized and sent to the browser on every homepage load.

**Fix:** Create a list-view projection that excludes large JSONB columns:

```sql
SELECT id, rfp_number, customer_name, customer_id, segment, opco, opco_name,
       region, status, intake_date, bid_release, customer_due, internal_due,
       compliance, item_categories, items, suppliers_contacted, responses_received,
       created_at, notes
FROM rfps
ORDER BY created_at DESC;
```

Load `uploaded_files`, `portal_config`, `working_file_config`, `auto_reminder` only on `GET /api/bids/{id}`.

---

## MEDIUM

---

### P-M1 — Line Item Updates Do Full Table Scan Across ALL Bids' Line Items

**File:** [`backend_py/routers/bids.py:757`](backend_py/routers/bids.py)

```python
updated = await repo.update_one(lambda x: x.get("id") == line_id, updater)
```

`PgLineItemsRepository.update_one` inherits the base class, which calls `load()` = `SELECT * FROM rfp_line_items ORDER BY created_at`. This returns ALL line items across ALL bids — if you have 200 bids × 300 items each = 60 000 rows loaded, Python-filtered to 1, then 1 row updated.

**Fix:** Add `update_by_id(line_id)` to `PgLineItemsRepository`:

```python
async def update_by_id(self, line_id: str, updater) -> dict | None:
    async with self._pool().acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM rfp_line_items WHERE id = $1", line_id)
        if not row:
            return None
        updated = updater(self._to_app(row))
        await self._update_in_place(conn, updated)
    return updated
```

---

### P-M2 — `_handle_unmatched` Loads All Unmatched Emails for UID Deduplication

**File:** [`backend_py/services/email_poller.py:449-464`](backend_py/services/email_poller.py)

```python
async def _handle_unmatched(msg, repo):
    all_unmatched = await repo.load()          # SELECT * FROM unmatched_emails
    if msg.uid and any(e.get("uid") == msg.uid for e in all_unmatched):
        return
```

Loads the entire `unmatched_emails` table on every unmatched email. In a spam-heavy inbox, this table can grow to thousands of rows, and every unmatched email triggers a full load. The poller also holds the `_poll_lock` during this, blocking any concurrent poll-now requests.

**Fix:** Add targeted lookup:

```python
async def find_by_uid(self, uid: str) -> bool:
    async with self._pool().acquire() as conn:
        row = await conn.fetchrow(
            "SELECT id FROM unmatched_emails WHERE uid = $1 LIMIT 1", uid
        )
    return row is not None
```

Also add: `CREATE INDEX unmatched_emails_uid_idx ON unmatched_emails (uid);`

---

### P-M3 — `get_emails_by_supplier` Computes Status Entirely in Python on Every 15s Poll

**File:** [`backend_py/routers/bids.py:911-946`](backend_py/routers/bids.py)

```python
for supplier_id in relevant_ids:
    sup_emails = sorted(emails_by_sid.get(supplier_id, []), key=lambda e: e.get("date", ""))
    inbound  = [e for e in sup_emails if e.get("direction") == "inbound"]
    outbound = [e for e in sup_emails if e.get("direction") == "outbound"]
    # ... status computation ...
    last_activity = max((e.get("date", "") for e in sup_emails), default=None)
    has_bounce    = any(e.get("isBounce") for e in sup_emails)
    issue_count   = sum(len(v) for v in (inbound[-1].get("analysisResult") or {}).get("issues", {}).values() if isinstance(v, list))
```

For a bid with 50 suppliers each having 20 emails: 1 000 Python dict lookups, 50 sort operations, 50 linear scans for bounces. All on the hot path polled every 15 seconds.

The `solicitedSuppliers` status field already exists on the bid and contains the authoritative status — the Python recomputation duplicates what's already stored. 

**Fix:** Trust `solicitedSuppliers[].status` as the truth (the poller already maintains it), use it directly, and only fall back to email inspection for a "live count" badge. At minimum, push `last_activity` and `has_bounce` to a pre-aggregated column rather than recomputing from raw email list every 15 seconds.

---

### P-M4 — `update_submission` Reloads Existing Message IDs Before Every Append

**File:** [`backend_py/repositories/pg_submissions_repo.py:311-318`](backend_py/repositories/pg_submissions_repo.py)

```python
existing_ids = {r["id"] for r in await conn.fetch(
    "SELECT id FROM submission_messages WHERE bid_id = $1", bid_pk
)}
new_msgs = [m for m in (updated.get("messages") or []) if m.get("id") not in existing_ids]
await _insert_messages(conn, bid_pk, new_msgs)
```

`SELECT id FROM submission_messages WHERE bid_id = $1` fires on every `update_submission` call. The `_insert_messages` already uses `ON CONFLICT (id) DO NOTHING` — the dedup query is redundant. Every read receipt (15s poll × open tabs) runs this extra query.

**Fix:** Remove the pre-check entirely. `ON CONFLICT DO NOTHING` is the correct mechanism. Removing the extra query halves the write path of `update_submission`.

---

### P-M5 — `SELECT *` on `rfp_solicited_suppliers` Returns All Rows to Python for Every `load()`

**File:** [`backend_py/repositories/pg_bids_repo.py:88-96`](backend_py/repositories/pg_bids_repo.py)

```python
ss_rows = await conn.fetch(
    "SELECT * FROM rfp_solicited_suppliers ORDER BY rfp_id, id"
)
```

This returns all solicited supplier rows regardless of whether the caller needs them. For the email poller's `_match_bid` function, only `email`, `additionalEmails`, `supplierId`, and `solicitationSubject` are used — not `status`, `hasIssues`, `bounceAt`, `channel`, `threadId`, etc.

**Fix:** Add a `load_summary()` variant used by the poller that only fetches matching columns:

```sql
SELECT rfp_id, supplier_id, supplier_name, email, additional_emails, solicitation_subject
FROM rfp_solicited_suppliers
ORDER BY rfp_id, id;
```

---

### P-M6 — SQLAlchemy Engine and asyncpg Pool Both Use Their Own `pool_pre_ping`/Keepalive — Double Overhead

**File:** [`backend_py/db/connection.py:37-44`](backend_py/db/connection.py)

```python
# SQLAlchemy
_engine = create_async_engine(
    settings.pg_dsn,
    pool_size=5,
    max_overflow=5,
    pool_pre_ping=True,    # ← sends "SELECT 1" before every checkout
    pool_recycle=1800,
)
# asyncpg: command_timeout=30, no equivalent pre-ping but has idle connection eviction
```

`pool_pre_ping=True` in SQLAlchemy fires a `SELECT 1` before every connection checkout from the pgvector pool. Since the pgvector pool is only used for ANN search (embedding queries) and is currently disabled in production (embed worker is commented out), this sends unnecessary health-check queries to Cloud SQL on every `get_db_conn()` call that isn't guarded.

**Fix:** Set `pool_pre_ping=False` while the embedding pipeline is disabled. Re-enable with a smarter approach (e.g., asyncpg's `min_size=1` with implicit keepalive) when the pipeline is restored.

---

## LOW

---

### P-L1 — Customer Combobox Fetches Entire Customer Table on Every Page Mount

**File:** [`frontend/src/components/UI/CustomerCombobox.jsx:31-37`](frontend/src/components/UI/CustomerCombobox.jsx)

```javascript
useEffect(() => {
    fetch('/api/customers')      // all customers, every mount
      .then(r => r.ok ? r.json() : [])
      .then(data => setCustomers(Array.isArray(data) ? data : []))
```

`GET /api/customers` does `SELECT * FROM customers ORDER BY organization_name` — all rows, all columns. The component then filters client-side. Every BEX AI page open and bid edit fires this request. At 10 000 customers this is a 1 MB+ JSON payload on every form render.

---

### P-L2 — `_save_poll_state` Is Called Even When No Emails Were Processed

**File:** [`backend_py/services/email_poller.py:184-186`](backend_py/services/email_poller.py)

```python
if not messages:
    await _save_poll_state({"lastPolledAt": now.isoformat()})  # DB write every 15s on empty inbox
    return ...
```

An `INSERT ... ON CONFLICT DO UPDATE` fires every 15 seconds even when the inbox is empty. This is a tiny write but it holds a connection for each write, adds to Cloud SQL write IOPS, and is unnecessary since the watermark only needs to advance when messages are actually processed.

**Fix:** Only write poll state when at least one message was processed, or batch-update every N cycles.

---

### P-L3 — Missing Indexes for Common Query Patterns

**Files:** [`backend_py/migrations/add_july2026_columns.sql`](backend_py/migrations/add_july2026_columns.sql)

The migration adds columns but is missing several indexes that will be needed:

```sql
-- Customer search (covered in P-H4) and exact lookups
CREATE INDEX IF NOT EXISTS customers_org_name_lower_idx 
    ON customers (lower(organization_name));

-- Email threads: by-supplier hot path
CREATE INDEX IF NOT EXISTS email_threads_bid_id_idx 
    ON email_threads (bid_id);
CREATE INDEX IF NOT EXISTS email_threads_uid_idx 
    ON email_threads (uid) WHERE uid IS NOT NULL;

-- Solicited suppliers: hot path for find_by_id and poller
CREATE INDEX IF NOT EXISTS rss_rfp_id_idx 
    ON rfp_solicited_suppliers (rfp_id);

-- Submissions: hot path
CREATE INDEX IF NOT EXISTS bids_rfp_id_idx 
    ON bids (rfp_id);
CREATE INDEX IF NOT EXISTS bids_thread_id_idx 
    ON bids (thread_id) WHERE thread_id IS NOT NULL;

-- Unmatched emails: UID dedup
CREATE INDEX IF NOT EXISTS unmatched_emails_uid_idx 
    ON unmatched_emails (uid) WHERE uid IS NOT NULL;

-- RFPs: list filtering
CREATE INDEX IF NOT EXISTS rfps_segment_status_idx 
    ON rfps (segment, status);
```

---

## Per-Endpoint Analysis

| Endpoint | DB Calls (current) | DB Calls (after fixes) | Bottleneck |
|---|---|---|---|
| `GET /api/bids` | 2 (full scans) | 1 (indexed, projected) | Full-table SELECT * |
| `GET /api/bids/{id}` | 2 | 2 | Reasonable |
| `GET /api/bids/{id}/emails/by-supplier` | 4 (+ full suppliers scan) | 3 (targeted) | suppliers.load() |
| `PATCH /api/bids/{id}/line-items/{lid}` | 1 (full scan ALL line items) | 1 (PK lookup) | Full table scan |
| `DELETE /api/bids/{id}/line-items/{lid}` | 1 (full scan) | 1 (PK delete) | Full table scan |
| `GET /api/submit/{id}/thread/{tid}` | 1+2N+3+1+2 = 7+2N | 7 (after N+1 fix) | N+1 in get_for_bid |
| `POST /api/submit/{id}` | 13 sequential | 8 (parallelized) | Sequential I/O |
| `GET /api/submit/{id}/submissions` | 1+2N | 3 | N+1 |
| `PUT /api/customers/{id}` | 1 (PK) + full scan | 2 (PK both) | update_one full scan |
| `DELETE /api/customers/{id}` | full scan | 1 (PK delete) | delete_where full scan |
| Email poller (every 15s) | 3 + 6×emails | 1 (cached) + 6×emails | bids.load() on idle cycles |

---

## Concurrency Impact Model

| Fix | 100 users | 1 000 users | 10 000 users |
|---|---|---|---|
| **No fixes** | p50 ~200ms, p99 ~2s | Pool exhaustion, timeouts | Cloud SQL CPU saturates |
| **P-C1** (poller cache) | -40% Cloud SQL IOPS | Prevents pool starvation from poller | Enables scaling to work at all |
| **P-C2** (N+1 fix) | -80% queries from portal | Portal becomes usable | Portal doesn't kill DB |
| **P-C3** (targeted updates) | -95% data transferred per write | Working File usable | Line item edits won't timeout |
| **P-H1** (pagination) | -70% response size | Frontend usable | Response latency acceptable |
| **P-H5** (pool sizing + PgBouncer) | Correct | Correct | Required for survivability |

---

## Top 10 Issues by Production Impact

| Rank | Issue | Estimated Latency Impact | Cloud SQL IOPS Impact |
|---|---|---|---|
| 1 | P-C1 — Poller full table scan every 15s | −40% background load | −35% write IOPS |
| 2 | P-C2 — N+1 in submissions (portal polled 15s) | −80ms p50 on portal | −80% portal queries |
| 3 | P-C3 — Full table scan every line-item edit | −500ms p50 on Working File | −90% line item query data |
| 4 | P-C4 — Suppliers full load on 15s poll | −30ms p50 on Email Repo | −25% read IOPS |
| 5 | P-H1 — No pagination on GET /api/bids | −60% homepage payload | −40% read IOPS |
| 6 | P-H5 — Pool exhaustion at scale | Prevents timeouts entirely | Enables multi-instance |
| 7 | P-H3 — Sequential submit_pricing I/O | −200ms p50 on submit | −30% submit queries |
| 8 | P-H4 — Leading LIKE for customer search | −100ms on search | −50% CPU per search |
| 9 | P-H2 — Sequential calls in get_thread | −80ms p50 on thread load | −20% thread queries |
| 10 | P-C3 — Full scan on update_customer/delete | −200ms p50 customer edit | −99% data transferred |

---

## Estimated Impact After Fixes

- **API latency reduction:** p50 homepage: 450ms → 80ms. p50 Working File save: 600ms → 60ms. p99 portal thread load: 3s → 200ms.
- **Cloud SQL load reduction:** ~75% fewer queries at steady state; ~85% fewer rows transferred per second.
- **Connection pool:** current headroom of ~5 free connections under load → comfortable pool utilization below 60% with PgBouncer.

---

## Quick Wins (<1 hour each)

1. **P-C1** — Add a 30-second in-memory bid cache in the poller (`_bid_cache` global dict)
2. **P-M4** — Delete the pre-dedup SELECT in `update_submission` (trust `ON CONFLICT DO NOTHING`)
3. **P-L2** — Skip `_save_poll_state` when `not messages`
4. **P-M6** — Set `pool_pre_ping=False` on the disabled SQLAlchemy pool
5. **P-L3** — Run the 8 missing indexes via `psql` (copy-paste from P-L3 above)
6. **P-C4** (partial) — Replace `supplier_by_id.get(supplier_id)` broker lookup with a targeted 2-column query

---

## Medium Effort (1–2 days each)

1. **P-C2** — Batch-load `bid_line_items` and `submission_messages` using `ANY($1::text[])` in `PgSubmissionsRepository`
2. **P-C3** — Add `update_by_id`/`delete_by_id` to `PgLineItemsRepository`, `PgCustomersRepository`, `PgEmailThreadsRepository`
3. **P-H1** — Add `LIMIT`/`OFFSET` pagination to `GET /api/bids` and push segment/status filters to SQL
4. **P-H4** — Add `pg_trgm` extension + GIN index; test customer search latency
5. **P-H3** — Parallelize independent DB writes in `submit_pricing` with `asyncio.gather`
6. **P-H2** — Parallelize `line_items_repo.get_for_bid` + `bids_repo.find_by_id` in `get_thread`

---

## Major Architecture Improvements

1. **PgBouncer in transaction mode** — single most impactful infrastructure change. Reduces Cloud SQL connection count from `instances × pool_size` to a fixed 10–20 regardless of Cloud Run scale-out. Required before going to production with auto-scaling enabled.

2. **Projected list/detail split for bids** — `GET /api/bids` returns a slim DTO (no JSONB blobs); `GET /api/bids/{id}` returns the full record. This alone removes the biggest serialization bottleneck on the most frequently-called endpoint.

3. **SSE or WebSocket for 15s polls** — `GET /api/bids/{id}/emails/by-supplier` and `GET /api/submit/{id}/thread/{tid}` are polled every 15 seconds by every open browser tab. Replacing with server-sent events or a WebSocket eliminates the majority of read traffic: instead of 4 DB calls per tab per 15 seconds, you push only diffs when state actually changes.

4. **Read replica for `GET /api/bids` and Email Repo** — separate the high-frequency read traffic (homepage, Email Repo 15s poll) from the write traffic (poller updates, submissions). Cloud SQL supports read replicas; route all `load()`-based reads to the replica.