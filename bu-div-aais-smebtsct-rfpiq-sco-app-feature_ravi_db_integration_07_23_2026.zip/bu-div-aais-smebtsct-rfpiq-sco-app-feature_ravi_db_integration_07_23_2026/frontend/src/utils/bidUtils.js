// ============================================================
// bidUtils.js — Shared helpers for bid data display
// ============================================================

// Segment display config — FULL explicit Tailwind class strings only
export const SEGMENT_CONFIG = {
  'K-12': {
    headerBg: 'bg-blue-700',
    pillBg: 'bg-blue-100',
    pillText: 'text-blue-800',
    borderAccent: 'border-l-blue-700',
    icon: '🎓',
    label: 'K-12 Schools',
  },
  'DoD': {
    headerBg: 'bg-slate-700',
    pillBg: 'bg-slate-100',
    pillText: 'text-slate-800',
    borderAccent: 'border-l-slate-700',
    icon: '🎖️',
    label: 'Dept. of Defense',
  },
  'University': {
    headerBg: 'bg-purple-700',
    pillBg: 'bg-purple-100',
    pillText: 'text-purple-800',
    borderAccent: 'border-l-purple-700',
    icon: '🏛️',
    label: 'University',
  },
  'Healthcare': {
    headerBg: 'bg-emerald-700',
    pillBg: 'bg-emerald-100',
    pillText: 'text-emerald-800',
    borderAccent: 'border-l-emerald-700',
    icon: '🏥',
    label: 'Healthcare',
  },
  'Restaurant': {
    headerBg: 'bg-amber-600',
    pillBg: 'bg-amber-100',
    pillText: 'text-amber-800',
    borderAccent: 'border-l-amber-600',
    icon: '🍽️',
    label: 'Restaurant',
  },
  'Lodging': {
    headerBg: 'bg-cyan-700',
    pillBg: 'bg-cyan-100',
    pillText: 'text-cyan-800',
    borderAccent: 'border-l-cyan-700',
    icon: '🏨',
    label: 'Lodging',
  },
  'Government': {
    headerBg: 'bg-red-700',
    pillBg: 'bg-red-100',
    pillText: 'text-red-800',
    borderAccent: 'border-l-red-700',
    icon: '🏛',
    label: 'Government',
  },
}

export const SEGMENT_ORDER = ['K-12', 'DoD', 'University', 'Healthcare', 'Restaurant', 'Lodging', 'Government']

// Status badge config
export const STATUS_CONFIG = {
  'Active': {
    bg: 'bg-green-100', text: 'text-green-800', dot: 'bg-green-500',
    ring: 'ring-green-200',
  },
  'Solicitation': {
    bg: 'bg-blue-100', text: 'text-blue-800', dot: 'bg-blue-500',
    ring: 'ring-blue-200',
  },
  'Working File': {
    bg: 'bg-amber-100', text: 'text-amber-800', dot: 'bg-amber-500',
    ring: 'ring-amber-200',
  },
  'Review': {
    bg: 'bg-purple-100', text: 'text-purple-800', dot: 'bg-purple-500',
    ring: 'ring-purple-200',
  },
  'At Risk': {
    bg: 'bg-red-100', text: 'text-red-800', dot: 'bg-red-500',
    ring: 'ring-red-200',
  },
  'Awarded': {
    bg: 'bg-gray-100', text: 'text-gray-600', dot: 'bg-gray-400',
    ring: 'ring-gray-200',
  },
  'Cancelled': {
    bg: 'bg-gray-100', text: 'text-gray-500', dot: 'bg-gray-300',
    ring: 'ring-gray-200',
  },
}

export const ALL_STATUSES = ['Active', 'Solicitation', 'Working File', 'Review', 'At Risk', 'Awarded', 'Cancelled']

// Compliance flag config
export const COMPLIANCE_CONFIG = {
  'Child Nutrition': { bg: 'bg-green-100', text: 'text-green-800', abbr: 'CN' },
  'Buy American':    { bg: 'bg-blue-100',  text: 'text-blue-800',  abbr: 'Buy Am.' },
  'PFS':             { bg: 'bg-purple-100',text: 'text-purple-800',abbr: 'PFS' },
  'SOX':             { bg: 'bg-orange-100',text: 'text-orange-800',abbr: 'SOX' },
  'Halal':           { bg: 'bg-teal-100',  text: 'text-teal-800',  abbr: 'Halal' },
  'Kosher':          { bg: 'bg-indigo-100',text: 'text-indigo-800',abbr: 'Kosher' },
  'Vegan':           { bg: 'bg-lime-100',   text: 'text-lime-800',   abbr: 'Vegan' },
  'Whole Grain':     { bg: 'bg-yellow-100', text: 'text-yellow-800', abbr: 'WG' },
  'Exact Spec':      { bg: 'bg-amber-100',  text: 'text-amber-800',  abbr: 'ES' },
}

// ── Date helpers ──────────────────────────────────────────
/**
 * Returns integer days from today to dateStr.
 * Negative = overdue.
 */
export const getDaysUntilDue = (dateStr) => {
  const due = new Date(dateStr)
  const now = new Date()
  now.setHours(0, 0, 0, 0)
  due.setHours(0, 0, 0, 0)
  return Math.ceil((due - now) / (1000 * 60 * 60 * 24))
}

export const formatDate = (dateStr) => {
  if (!dateStr) return '—'
  return new Date(dateStr).toLocaleDateString('en-US', {
    month: 'short', day: 'numeric', year: 'numeric',
  })
}

// ── Dynamic supplier counts (source of truth: solicitedSuppliers array) ──
const RESPONDED_STATUSES = ['Responded', 'Issues Found', 'Follow-up Sent', 'Complete']

export const getSuppliersContacted = (bid) =>
  bid.solicitedSuppliers?.length ?? bid.suppliersContacted ?? 0

export const getResponsesReceived = (bid) =>
  bid.solicitedSuppliers
    ? bid.solicitedSuppliers.filter(s => RESPONDED_STATUSES.includes(s.status)).length
    : bid.responsesReceived ?? 0

// ── Response rate ─────────────────────────────────────────
export const getResponseRate = (bid) => {
  const contacted = getSuppliersContacted(bid)
  if (contacted === 0) return 0
  return Math.round((getResponsesReceived(bid) / contacted) * 100)
}

// ── At-risk predicate (used by stat card + card border) ──
export const isAtRisk = (bid) =>
  bid.status === 'At Risk' || getDaysUntilDue(bid.internalDue) <= 7

// ── Stat card computations ────────────────────────────────
export const computeStats = (bids) => {
  // Exclude Awarded and Cancelled from all stat card calculations
  const EXCLUDE    = ['Awarded', 'Cancelled']
  const activeBids = bids.filter(b => !EXCLUDE.includes(b.status))

  const atRisk = activeBids.filter(isAtRisk).length

  // Response rate: only bids currently in Solicitation stage
  const solicitationBids = activeBids.filter(
    b => b.status === 'Solicitation' && getSuppliersContacted(b) > 0
  )
  const avgRate = solicitationBids.length
    ? Math.round(
        solicitationBids.map(b => getResponseRate(b)).reduce((s, r) => s + r, 0) /
        solicitationBids.length
      )
    : 0

  const segmentSet   = new Set(activeBids.map(b => b.segment).filter(Boolean))
  const segments     = segmentSet.size
  const segmentNames = [...segmentSet]   // e.g. ['K-12', 'DoD', 'University', …]

  return { total: activeBids.length, atRisk, avgRate, segments, segmentNames }
}

// ── Filter helpers ────────────────────────────────────────
// "Active" in the status dropdown means "in progress" — all bids
// except Awarded and Cancelled (mirrors the Active Bids stat card).
// Every other status value is a strict match.
const IN_PROGRESS_EXCLUDE = ['Awarded', 'Cancelled']

export const filterBids = (bids, { segment, status, search }) => {
  let out = [...bids]
  if (segment && segment !== 'All') out = out.filter(b => b.segment === segment)
  if (status  && status  !== 'All') {
    if (status === 'Active') {
      // "Active" = all in-progress bids (excludes Awarded and Cancelled)
      // This matches what the Active Bids stat card counts.
      out = out.filter(b => !IN_PROGRESS_EXCLUDE.includes(b.status))
    } else {
      out = out.filter(b => b.status === status)
    }
  }
  if (search) {
    const q = search.toLowerCase()
    out = out.filter(b =>
      b.customer.toLowerCase().includes(q) ||
      b.id.toLowerCase().includes(q) ||
      b.opcoName.toLowerCase().includes(q)
    )
  }
  return out
}

export const groupBySegment = (bids) => {
  const groups = {}
  SEGMENT_ORDER.forEach(seg => {
    const items = bids.filter(b => b.segment === seg)
    if (items.length > 0) groups[seg] = items
  })
  return groups
}
