import React, { useState, useEffect, useRef } from 'react'
import { useNavigate } from 'react-router-dom'
import { MapPin, Calendar, AlertCircle, MoreHorizontal, Trash2, Loader, Pencil } from 'lucide-react'
import {
  STATUS_CONFIG,
  COMPLIANCE_CONFIG,
  getDaysUntilDue,
  getResponseRate,
  getSuppliersContacted,
  isAtRisk,
} from '../../utils/bidUtils'

// ── Sub-components ────────────────────────────────────────

function StatusBadge({ status }) {
  const cfg = STATUS_CONFIG[status] || STATUS_CONFIG['Active']
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${cfg.bg} ${cfg.text}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${cfg.dot}`} />
      {status}
    </span>
  )
}

function CompliancePill({ flag }) {
  const cfg = COMPLIANCE_CONFIG[flag]
  if (!cfg) return null
  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${cfg.bg} ${cfg.text}`}>
      {cfg.abbr}
    </span>
  )
}

function ResponseBar({ rate, contacted }) {
  const barColor =
    rate >= 75 ? 'bg-emerald-500' :
    rate >= 50 ? 'bg-amber-500' :
    rate > 0   ? 'bg-red-400' :
                 'bg-gray-200'
  return (
    <div>
      <div className="flex justify-between items-center mb-1">
        <span className="text-xs text-gray-500">Response rate</span>
        <span className="text-xs font-semibold text-gray-700">
          {contacted === 0 ? 'Not solicited' : `${rate}% (${Math.round(contacted * rate / 100)}/${contacted})`}
        </span>
      </div>
      <div className="w-full bg-gray-100 rounded-full h-1.5">
        <div
          className={`h-1.5 rounded-full transition-all duration-500 ${barColor}`}
          style={{ width: `${rate}%` }}
        />
      </div>
    </div>
  )
}

function DueBadge({ daysUntil }) {
  if (daysUntil === null || daysUntil === undefined) return null
  if (daysUntil < 0) return (
    <span className="inline-flex items-center gap-1 text-xs font-bold text-red-800 bg-red-100 px-2 py-0.5 rounded-full border border-red-300">
      <AlertCircle className="w-3 h-3" />{Math.abs(daysUntil)}d overdue
    </span>
  )
  if (daysUntil === 0) return (
    <span className="inline-flex items-center gap-1 text-xs font-bold text-red-700 bg-red-50 px-2 py-0.5 rounded-full border border-red-300">
      <AlertCircle className="w-3 h-3" />Due Today
    </span>
  )
  if (daysUntil <= 7) return (
    <span className="inline-flex items-center gap-1 text-xs font-semibold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
      <AlertCircle className="w-3 h-3" />{daysUntil}d left
    </span>
  )
  return (
    <span className="inline-flex items-center gap-1 text-xs text-gray-500 bg-gray-50 px-2 py-0.5 rounded-full">
      <Calendar className="w-3 h-3" />{daysUntil}d left
    </span>
  )
}

// ── Delete confirmation modal ─────────────────────────────
function DeleteBidModal({ bid, onCancel, onConfirm, deleting }) {
  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={e => e.stopPropagation()}>
      <div className="bg-white dark:bg-[#1E293B] rounded-2xl shadow-2xl w-full max-w-md overflow-hidden max-h-[90vh] flex flex-col">
        <div className="px-6 py-5 flex-1 min-h-0 overflow-y-auto">
          <div className="w-12 h-12 bg-red-100 dark:bg-red-900/30 rounded-xl flex items-center justify-center mb-4">
            <Trash2 className="w-6 h-6 text-red-600 dark:text-red-400" />
          </div>
          <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-2">Delete RFP?</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
            This will permanently delete <span className="font-mono font-semibold text-gray-900 dark:text-gray-200">{bid.id}</span> —{' '}
            <span className="font-semibold">{bid.customer}</span> and all associated line items and emails.
            This cannot be undone.
          </p>
        </div>
        <div className="px-6 pb-5 flex gap-3 flex-shrink-0">
          <button
            onClick={onCancel}
            disabled={deleting}
            className="btn-secondary flex-1"
          >
            Cancel
          </button>
          <button
            onClick={onConfirm}
            disabled={deleting}
            className="flex-1 flex items-center justify-center gap-2 py-2 bg-red-600 hover:bg-red-700 disabled:opacity-50 text-white font-semibold text-sm rounded-xl transition-colors"
          >
            {deleting
              ? <><Loader className="w-4 h-4 animate-spin" /> Deleting…</>
              : <><Trash2 className="w-4 h-4" /> Delete RFP</>
            }
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Main BidCard ──────────────────────────────────────────
export default function BidCard({ bid, onDeleted }) {
  const navigate = useNavigate()
  const days     = getDaysUntilDue(bid.internalDue)
  const rate     = getResponseRate(bid)
  const urgent   = isAtRisk(bid)

  const [menuOpen,      setMenuOpen]      = useState(false)
  const [showConfirm,   setShowConfirm]   = useState(false)
  const [deleting,      setDeleting]      = useState(false)
  const menuRef = useRef(null)

  // Close dropdown when clicking outside
  useEffect(() => {
    if (!menuOpen) return
    const handler = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false)
    }
    document.addEventListener('mousedown', handler)
    return () => document.removeEventListener('mousedown', handler)
  }, [menuOpen])

  const handleDelete = async () => {
    setDeleting(true)
    try {
      const res = await fetch(`/api/bids/${bid.id}`, { method: 'DELETE' })
      if (!res.ok) throw new Error('Delete failed')
      const data = await res.json()
      setShowConfirm(false)
      onDeleted?.(bid.id, data.removed)
    } catch {
      setDeleting(false)
    }
  }

  return (
    <>
      <div
        onClick={() => navigate(`/bids/${bid.id}`)}
        className={`
          card p-4 cursor-pointer hover:shadow-md hover:-translate-y-0.5
          transition-all duration-150 border-l-4 group
          ${urgent ? 'border-l-red-500' : 'border-l-transparent hover:border-l-exl-orange'}
        `}
      >
        {/* Row 1 — Customer + Bid ID + ⋯ menu */}
        <div className="flex items-start justify-between gap-2 mb-2">
          <div className="min-w-0">
            <h3 className="font-semibold text-gray-900 dark:text-gray-100 text-sm leading-tight truncate group-hover:text-exl-navy dark:group-hover:text-blue-300">
              {bid.customer}
            </h3>
            <span className="text-xs font-mono text-gray-400">{bid.id}</span>
          </div>

          {/* Three-dot menu — stopPropagation so card click doesn't fire */}
          <div
            ref={menuRef}
            className="relative flex-shrink-0"
            onClick={e => e.stopPropagation()}
          >
            <button
              onClick={() => setMenuOpen(o => !o)}
              className={`w-7 h-7 rounded-lg flex items-center justify-center transition-colors
                ${menuOpen ? 'bg-gray-200 text-gray-700' : 'text-gray-300 hover:bg-gray-100 hover:text-gray-600'}`}
              title="More options"
            >
              <MoreHorizontal className="w-4 h-4" />
            </button>

            {menuOpen && (
              <div className="absolute right-0 top-full mt-1 w-44 bg-white dark:bg-[#1E293B] border border-gray-200 dark:border-gray-700 rounded-xl shadow-lg z-20 py-1 overflow-hidden">
                <button
                  onClick={() => { setMenuOpen(false); navigate(`/bids/${bid.id}`) }}
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-[#253347] transition-colors"
                >
                  Open RFP
                </button>
                <button
                  onClick={() => { setMenuOpen(false); navigate(`/bids/${bid.id}?tab=overview&edit=1`) }}
                  className="w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-[#253347] transition-colors flex items-center gap-2"
                >
                  <Pencil className="w-3.5 h-3.5 text-gray-400" /> Edit RFP Details
                </button>
                <div className="h-px bg-gray-100 dark:bg-gray-700 mx-2" />
                <button
                  onClick={() => { setMenuOpen(false); setShowConfirm(true) }}
                  className="w-full text-left px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors flex items-center gap-2"
                >
                  <Trash2 className="w-3.5 h-3.5" /> Delete RFP
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Row 2 — OpCo + Region */}
        <div className="flex items-center gap-3 mb-3">
          <span className="text-xs text-gray-600 font-medium">
            <span className="font-mono text-exl-navy dark:text-blue-300 font-bold">{bid.opco}</span>
            {' '}· {bid.opcoName}
          </span>
          <span className="inline-flex items-center gap-1 text-xs text-gray-400">
            <MapPin className="w-3 h-3" />{bid.region}
          </span>
        </div>

        {/* Row 3 — Status + Compliance flags */}
        <div className="flex flex-wrap items-center gap-1.5 mb-3">
          <StatusBadge status={bid.status} />
          {bid.compliance.map(flag => (
            <CompliancePill key={flag} flag={flag} />
          ))}
        </div>

        {/* Row 4 — Response progress bar */}
        <div className="mb-3">
          <ResponseBar rate={rate} contacted={getSuppliersContacted(bid)} />
        </div>

        {/* Row 5 — Items count + Due badge */}
        <div className="flex items-center justify-between">
          <span className="text-xs text-gray-400">{bid.items} items</span>
          <DueBadge daysUntil={days} />
        </div>
      </div>

      {/* Delete confirmation modal */}
      {showConfirm && (
        <DeleteBidModal
          bid={bid}
          onCancel={() => setShowConfirm(false)}
          onConfirm={handleDelete}
          deleting={deleting}
        />
      )}
    </>
  )
}
