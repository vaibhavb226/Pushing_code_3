import React, { useState, useMemo, useEffect, useRef } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import { Search, LayoutGrid, List, ChevronDown, Filter, Brain, ChevronUp, Cloud, CheckCircle, Upload, Plus, Download, Mail, X } from 'lucide-react'
import { Button } from '../UI/Button'
import { Badge } from '../UI/Badge'
import { EmptyState } from '../UI/EmptyState'
import staticBids from '../../data/bids.json'
import BidCard from './BidCard'
import StatCards from './StatCards'
import {
  SEGMENT_CONFIG,
  SEGMENT_ORDER,
  STATUS_CONFIG,
  ALL_STATUSES,
  filterBids,
  groupBySegment,
  getDaysUntilDue,
  getResponseRate,
  formatDate,
  COMPLIANCE_CONFIG,
  computeStats,
} from '../../utils/bidUtils'

// ── Segment filter pill ───────────────────────────────────
function SegmentPill({ segment, active, count, onClick }) {
  const cfg = SEGMENT_CONFIG[segment]
  return (
    <button
      onClick={onClick}
      className={`
        inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium
        transition-all duration-150 border
        ${active
          ? `${cfg?.headerBg ?? 'bg-exl-navy'} text-white border-transparent shadow-sm`
          : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300 hover:text-gray-900'
        }
      `}
    >
      {cfg?.icon ?? '📋'} {segment}
      {count > 0 && (
        <span className={`text-xs px-1.5 py-0.5 rounded-full font-semibold ${
          active ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-600'
        }`}>{count}</span>
      )}
    </button>
  )
}

// ── Segment group header ──────────────────────────────────
function SegmentHeader({ segment, count }) {
  const cfg = SEGMENT_CONFIG[segment] ?? { headerBg: 'bg-gray-600', icon: '📋' }
  return (
    <div className={`${cfg.headerBg} rounded-t-xl px-4 py-2.5 flex items-center justify-between`}>
      <div className="flex items-center gap-2">
        <span className="text-lg">{cfg.icon}</span>
        <span className="text-white font-semibold text-sm">{segment}</span>
      </div>
      <span className="bg-white/20 text-white text-xs font-bold px-2 py-0.5 rounded-full">
        {count} RFP{count !== 1 ? 's' : ''}
      </span>
    </div>
  )
}

// ── Flat list row ─────────────────────────────────────────
function FlatRow({ bid, onClick, idx }) {
  const days = getDaysUntilDue(bid.internalDue)
  const rate = getResponseRate(bid)
  const isUrgent = days <= 7
  const statusCfg = STATUS_CONFIG[bid.status] ?? STATUS_CONFIG['Active']
  const segCfg = SEGMENT_CONFIG[bid.segment] ?? {}

  return (
    <tr
      onClick={onClick}
      className={`cursor-pointer border-b border-gray-100 dark:border-gray-700 group transition-colors hover:bg-[#F8FAFC] dark:hover:bg-[#334155] ${idx % 2 === 1 ? 'bg-gray-50/40 dark:bg-[#253347]' : 'bg-white dark:bg-[#1E293B]'}`}
    >
      {/* Customer + Bid ID */}
      <td className="px-4 py-3">
        <div className="font-medium text-sm text-gray-900 dark:text-gray-100 group-hover:text-exl-navy dark:group-hover:text-blue-300">{bid.customer}</div>
        <div className="text-xs font-mono text-gray-400 dark:text-gray-500">{bid.id}</div>
      </td>
      {/* Segment */}
      <td className="px-4 py-3">
        <span className={`badge ${segCfg.pillBg ?? 'bg-gray-100'} ${segCfg.pillText ?? 'text-gray-700'}`}>
          {bid.segment}
        </span>
      </td>
      {/* OpCo */}
      <td className="px-4 py-3 text-xs text-gray-600">
        <span className="font-mono font-bold text-exl-navy dark:text-blue-300">{bid.opco}</span>
        {' '}· {bid.opcoName}
      </td>
      {/* Status */}
      <td className="px-4 py-3">
        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold ${statusCfg.bg} ${statusCfg.text}`}>
          <span className={`w-1.5 h-1.5 rounded-full ${statusCfg.dot}`} />
          {bid.status}
        </span>
      </td>
      {/* Response rate */}
      <td className="px-4 py-3 min-w-[120px]">
        <div className="flex items-center gap-2">
          <div className="flex-1 bg-gray-100 rounded-full h-1.5">
            <div
              className={`h-1.5 rounded-full ${rate >= 75 ? 'bg-emerald-500' : rate >= 50 ? 'bg-amber-500' : 'bg-red-400'}`}
              style={{ width: `${rate}%` }}
            />
          </div>
          <span className="text-xs font-medium text-gray-600 w-8 text-right">{rate}%</span>
        </div>
      </td>
      {/* Due date */}
      <td className="px-4 py-3 text-xs">
        <span className={`font-medium ${isUrgent ? 'text-red-600' : 'text-gray-600'}`}>
          {days < 0 ? `${Math.abs(days)}d overdue` : days <= 7 ? `⚠ ${days}d` : formatDate(bid.internalDue)}
        </span>
      </td>
      {/* Compliance */}
      <td className="px-4 py-3">
        <div className="flex flex-wrap gap-1">
          {bid.compliance.slice(0, 3).map(flag => {
            const cfg = COMPLIANCE_CONFIG[flag]
            return cfg ? (
              <span key={flag} className={`inline-flex px-1.5 py-0.5 rounded text-xs font-medium ${cfg.bg} ${cfg.text}`}>
                {cfg.abbr}
              </span>
            ) : null
          })}
        </div>
      </td>
    </tr>
  )
}

// ── Delete toast ──────────────────────────────────────────
function DeleteToast({ bidId, removed, onDone }) {
  useEffect(() => {
    const t = setTimeout(onDone, 4500)
    return () => clearTimeout(t)
  }, [onDone])

  const parts = []
  if (removed?.lineItems > 0) parts.push(`${removed.lineItems} line item${removed.lineItems !== 1 ? 's' : ''}`)
  if (removed?.emails     > 0) parts.push(`${removed.emails} email${removed.emails !== 1 ? 's' : ''}`)
  if (removed?.documents  > 0) parts.push(`${removed.documents} document${removed.documents !== 1 ? 's' : ''}`)

  const detail = parts.length > 0
    ? ` — ${parts.join(', ')} removed`
    : ''

  return (
    <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2.5 px-4 py-3 bg-gray-900 text-white text-sm font-medium rounded-xl shadow-2xl animate-fade-in pointer-events-none">
      <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" />
      <span>RFP <span className="font-mono text-gray-300">{bidId}</span> deleted{detail}</span>
    </div>
  )
}

// ── Add New RFP Panel ─────────────────────────────────────
function AddNewBidPanel({ onUploadRFP }) {
  const [open, setOpen] = useState(true)

  return (
    <div className="card mb-6 overflow-hidden">
      {/* Panel header / toggle */}
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-5 py-3.5 bg-gray-50 border-b border-gray-200 hover:bg-gray-100 transition-colors"
      >
        <div className="flex items-center gap-2">
          <span className="text-sm font-semibold text-exl-navy dark:text-blue-300">+ Add New RFP</span>
        </div>
        <span className="flex items-center gap-1 text-xs text-gray-500 font-medium">
          {open ? 'Hide' : 'Show'}
          {open ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
        </span>
      </button>

      {/* Collapsible body */}
      {open && (
        <div className="px-5 py-5">
          <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-4 items-stretch">

            {/* Option A — Upload RFP */}
            <div className="border-2 border-exl-orange/30 dark:border-gray-600 rounded-xl p-5 bg-exl-orange/[0.03] dark:bg-[#253347] flex flex-col gap-3 hover:border-exl-orange/60 dark:hover:border-exl-orange/50 hover:bg-exl-orange/[0.06] dark:hover:bg-[#2a3855] transition-all">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-exl-orange/10 dark:bg-orange-900/30 rounded-xl flex items-center justify-center text-xl">
                  📄
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-900">Upload RFP</p>
                  <p className="text-xs text-gray-500 mt-0.5">Recommended</p>
                </div>
              </div>
              <p className="text-xs text-gray-600 leading-relaxed">
                Upload a PDF or Excel RFP file. BEX AI will parse it and create the working file automatically.
              </p>
              <Button
                variant="primary"
                size="md"
                icon={Brain}
                onClick={onUploadRFP}
                className="mt-auto w-full justify-center"
              >
                Upload RFP
              </Button>
            </div>

            {/* OR divider */}
            <div className="flex md:flex-col items-center justify-center gap-2 px-1">
              <div className="flex-1 h-px md:h-auto md:w-px bg-gray-200 md:flex-1" />
              <span className="text-xs font-semibold text-gray-400 bg-white px-2 py-1 rounded-full border border-gray-200">OR</span>
              <div className="flex-1 h-px md:h-auto md:w-px bg-gray-200 md:flex-1" />
            </div>

            {/* Option B — Import from Salesforce (disabled) */}
            <div className="relative border-2 border-gray-200 rounded-xl p-5 bg-gray-50/50 flex flex-col gap-3 opacity-60 cursor-not-allowed">
              {/* Phase 2 badge */}
              <span className="absolute top-3 right-3 text-xs font-semibold text-gray-400 bg-gray-100 border border-gray-200 px-2 py-0.5 rounded-full">
                Phase 2
              </span>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-xl">
                  ☁️
                </div>
                <div>
                  <p className="font-semibold text-sm text-gray-700">Import from Salesforce</p>
                </div>
              </div>
              <p className="text-xs text-gray-500 leading-relaxed">
                Pull a bid directly from Salesforce submitted by the sales team.
              </p>
              <button
                disabled
                className="text-sm px-4 py-2 rounded-lg bg-gray-200 text-gray-400 font-semibold cursor-not-allowed mt-auto"
              >
                Coming Soon
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  )
}

// ── Export / Email report modal ───────────────────────────
function ReportModal({ onClose }) {
  const [email, setEmail]     = useState('')
  const [sending, setSending] = useState(false)
  const [sent, setSent]       = useState(false)
  const [error, setError]     = useState('')

  const handleSend = async () => {
    if (!email.trim()) return
    setSending(true)
    setError('')
    try {
      const res = await fetch('/api/reports/send-email', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ to: email.trim() }),
      })
      if (!res.ok) {
        const d = await res.json().catch(() => ({}))
        throw new Error(d.detail || 'Send failed')
      }
      setSent(true)
    } catch (err) {
      setError(err.message || 'Failed to send. Please try again.')
    } finally {
      setSending(false)
    }
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm"
      onClick={e => { if (e.target === e.currentTarget) onClose() }}
    >
      <div className="bg-white dark:bg-[#1E293B] rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-gray-100 dark:border-gray-700">
          <div>
            <p className="font-bold text-gray-900 dark:text-gray-100 text-base">Export Bid Pipeline Report</p>
            <p className="text-xs text-gray-400 mt-0.5">Download or send via email</p>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-400 transition-colors">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Download — hits /api/reports/live so the file has current bid data baked in */}
          <a
            href="/api/reports/live"
            onClick={onClose}
            className="flex items-center gap-3 w-full px-4 py-3.5 rounded-xl border-2 border-gray-200 dark:border-gray-600 hover:border-exl-orange hover:bg-orange-50 dark:hover:bg-orange-900/10 transition-all group"
          >
            <div className="w-9 h-9 rounded-lg bg-blue-50 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0">
              <Download className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            </div>
            <div className="text-left">
              <p className="text-sm font-semibold text-gray-800 dark:text-gray-200">Download HTML</p>
              <p className="text-xs text-gray-400">Live data · saves to your device</p>
            </div>
          </a>

          {/* Divider */}
          <div className="flex items-center gap-3">
            <div className="flex-1 h-px bg-gray-100 dark:bg-gray-700" />
            <span className="text-xs text-gray-400 font-medium">or send by email</span>
            <div className="flex-1 h-px bg-gray-100 dark:bg-gray-700" />
          </div>

          {/* Email */}
          {sent ? (
            <div className="flex items-center gap-2.5 px-4 py-3 rounded-xl bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800">
              <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
              <p className="text-sm text-green-700 dark:text-green-300 font-medium">Report sent to {email}</p>
            </div>
          ) : (
            <div className="space-y-2">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
                  <input
                    type="email"
                    value={email}
                    onChange={e => { setEmail(e.target.value); setError('') }}
                    placeholder="recipient@example.com"
                    onKeyDown={e => e.key === 'Enter' && handleSend()}
                    className="w-full pl-8 pr-3 py-2.5 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange"
                  />
                </div>
                <button
                  onClick={handleSend}
                  disabled={sending || !email.trim()}
                  className="px-4 py-2.5 rounded-lg text-sm font-semibold text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  style={{ backgroundColor: '#E05A2B' }}
                >
                  {sending ? 'Sending…' : 'Send'}
                </button>
              </div>
              {error && <p className="text-xs text-red-500">{error}</p>}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

// ── Main BidQueue page ────────────────────────────────────
export default function BidQueue() {
  const [selectedSegment, setSelectedSegment] = useState('All')
  const [selectedStatus,  setSelectedStatus]  = useState('All')
  const [viewMode, setViewMode] = useState('grouped') // 'grouped' | 'flat'
  const [search, setSearch] = useState('')
  const [reportModal, setReportModal] = useState(false)

  // ── Live bids — start with static data, refresh every 5 min and on window focus ──
  const [bids, setBids] = useState(staticBids)
  useEffect(() => {
    const fetchBids = () =>
      fetch('/api/bids')
        .then(r => r.ok ? r.json() : null)
        .then(data => { if (Array.isArray(data) && data.length > 0) setBids(data) })
        .catch(() => {})

    fetchBids()
    const id = setInterval(fetchBids, 300_000)
    window.addEventListener('focus', fetchBids)
    return () => {
      clearInterval(id)
      window.removeEventListener('focus', fetchBids)
    }
  }, [])

  // Segment counts (unfiltered by segment so pills always show totals)
  const segmentCounts = useMemo(() => {
    const counts = {}
    SEGMENT_ORDER.forEach(seg => {
      counts[seg] = bids.filter(b => b.segment === seg).length
    })
    return counts
  }, [bids])

  // Filtered bids
  const filtered = useMemo(() =>
    filterBids(bids, { segment: selectedSegment, status: selectedStatus, search }),
    [bids, selectedSegment, selectedStatus, search]
  )

  const grouped = useMemo(() => groupBySegment(filtered), [filtered])

  const navigate = useNavigate()
  const location = useLocation()

  // Delete toast state
  const [deleteToast, setDeleteToast] = useState(null)
  const toastShownRef = useRef(false)

  // Show toast when navigating back from BidDetail after a delete
  useEffect(() => {
    if (location.state?.deleted && !toastShownRef.current) {
      toastShownRef.current = true
      setDeleteToast(location.state.deleted)
      // Clear the navigation state so refresh doesn't re-show it
      window.history.replaceState({}, '')
    }
  }, [location.state])

  // Called by BidCard after a successful delete — removes bid from local state + shows toast
  const handleBidDeleted = (bidId, removed) => {
    setBids(prev => prev.filter(b => b.id !== bidId))
    setDeleteToast({ bidId, removed })
  }

  return (
    <div className="max-w-screen-xl mx-auto">

      {/* ── Page header ── */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-exl-navy dark:text-white">Bid Queue</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Bid COE — Contract Customer Procurement · {computeStats(bids).total} RFPs in progress
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setReportModal(true)}
            className="flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 hover:border-gray-300 transition-colors dark:border-gray-600 dark:text-gray-400 dark:hover:bg-gray-700"
          >
            <Download className="w-3.5 h-3.5" />
            Export Report
          </button>
          <span className="text-xs bg-gray-100 text-gray-500 font-medium px-3 py-1 rounded-full">
            {new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}
          </span>
        </div>
      </div>

      {/* ── Stat cards ── */}
      <StatCards bids={bids} />

      {/* ── Add New RFP panel ── */}
      <AddNewBidPanel onUploadRFP={() => navigate('/bex')} />

      {/* ── Filter bar ── */}
      <div className="card px-4 py-3 mb-6">
        <div className="flex flex-wrap items-center gap-3">

          {/* Search */}
          <div className="relative flex-shrink-0">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search bids, customers…"
              className="pl-8 pr-3 py-1.5 text-sm border border-gray-200 rounded-lg w-48 focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange"
            />
          </div>

          {/* Divider */}
          <div className="h-6 w-px bg-gray-200" />

          {/* Segment pills */}
          <div className="flex flex-wrap gap-1.5">
            <button
              onClick={() => setSelectedSegment('All')}
              className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-all ${
                selectedSegment === 'All'
                  ? 'bg-exl-navy text-white border-transparent shadow-sm'
                  : 'bg-white text-gray-600 border-gray-200 hover:border-gray-300'
              }`}
            >
              All <span className={`text-xs px-1.5 py-0.5 rounded-full font-semibold ${selectedSegment === 'All' ? 'bg-white/20 text-white' : 'bg-gray-100 text-gray-600'}`}>{bids.length}</span>
            </button>
            {SEGMENT_ORDER.map(seg => (
              <SegmentPill
                key={seg}
                segment={seg}
                active={selectedSegment === seg}
                count={segmentCounts[seg] ?? 0}
                onClick={() => setSelectedSegment(selectedSegment === seg ? 'All' : seg)}
              />
            ))}
          </div>

          {/* Divider */}
          <div className="h-6 w-px bg-gray-200 ml-auto" />

          {/* Status dropdown */}
          <div className="relative">
            <select
              value={selectedStatus}
              onChange={e => setSelectedStatus(e.target.value)}
              className="appearance-none pl-3 pr-8 py-1.5 text-sm border border-gray-200 rounded-lg bg-white focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange cursor-pointer"
            >
              <option value="All">All Statuses</option>
              {ALL_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
            <ChevronDown className="absolute right-2 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" />
          </div>

          {/* View toggle */}
          <div className="flex items-center bg-gray-100 rounded-lg p-0.5">
            <button
              onClick={() => setViewMode('grouped')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                viewMode === 'grouped' ? 'bg-white dark:bg-[#253347] shadow-sm text-exl-navy dark:text-blue-300' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
              }`}
            >
              <LayoutGrid className="w-3.5 h-3.5" /> Grouped
            </button>
            <button
              onClick={() => setViewMode('flat')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-all ${
                viewMode === 'flat' ? 'bg-white dark:bg-[#253347] shadow-sm text-exl-navy dark:text-blue-300' : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'
              }`}
            >
              <List className="w-3.5 h-3.5" /> Flat
            </button>
          </div>
        </div>
      </div>

      {/* ── Result count ── */}
      {(selectedSegment !== 'All' || selectedStatus !== 'All' || search) && (
        <p className="text-sm text-gray-500 mb-4">
          Showing <strong>{filtered.length}</strong> of {bids.length} RFPs
          {selectedSegment !== 'All' && <> · Segment: <strong>{selectedSegment}</strong></>}
          {selectedStatus !== 'All'  && <> · Status: <strong>{selectedStatus}</strong></>}
          {search && <> · Search: <strong>"{search}"</strong></>}
          <button
            onClick={() => { setSelectedSegment('All'); setSelectedStatus('All'); setSearch('') }}
            className="ml-2 text-exl-orange hover:underline"
          >
            Clear filters
          </button>
        </p>
      )}

      {/* ── Empty state ── */}
      {filtered.length === 0 && bids.length > 0 && (
        <div className="card">
          <EmptyState
            icon={Filter}
            title="No RFPs found"
            description="No RFPs match your current filters. Try adjusting the segment or status filter, or add a new RFP."
            action={{ label: 'Upload RFP', icon: Plus, onClick: () => navigate('/bex') }}
            secondaryAction={{ label: 'Clear filters', onClick: () => { setSelectedSegment('All'); setSelectedStatus('All'); setSearch('') } }}
          />
        </div>
      )}
      {bids.length === 0 && (
        <div className="card">
          <EmptyState
            icon={LayoutDashboard}
            title="No RFPs yet"
            description="Get started by uploading your first RFP. BEX AI will parse it and create the RFP automatically."
            action={{ label: 'Upload First RFP', icon: Upload, onClick: () => navigate('/bex') }}
            size="lg"
          />
        </div>
      )}

      {/* ── GROUPED VIEW ── */}
      {viewMode === 'grouped' && filtered.length > 0 && (
        <div className="space-y-8">
          {Object.entries(grouped).map(([segment, segBids]) => (
            <div key={segment}>
              <SegmentHeader segment={segment} count={segBids.length} />
              <div className="bg-gray-50 rounded-b-xl p-4 border border-t-0 border-gray-200">
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
                  {segBids.map(bid => (
                    <BidCard key={bid.id} bid={bid} onDeleted={handleBidDeleted} />
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── FLAT VIEW ── */}
      {viewMode === 'flat' && filtered.length > 0 && (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="sticky top-0 z-10">
              <tr className="bg-exl-navy text-white text-xs uppercase tracking-wide">
                <th className="px-4 py-3 text-left font-semibold">Customer / RFP ID</th>
                <th className="px-4 py-3 text-left font-semibold">Segment</th>
                <th className="px-4 py-3 text-left font-semibold">OpCo</th>
                <th className="px-4 py-3 text-left font-semibold">Status</th>
                <th className="px-4 py-3 text-left font-semibold">Response</th>
                <th className="px-4 py-3 text-left font-semibold">Internal Due</th>
                <th className="px-4 py-3 text-left font-semibold">Compliance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {filtered.map((bid, idx) => (
                <FlatRow
                  key={bid.id}
                  bid={bid}
                  idx={idx}
                  onClick={() => window.location.href = `/bids/${bid.id}`}
                />
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ── Delete toast ── */}
      {deleteToast && (
        <DeleteToast
          bidId={deleteToast.bidId}
          removed={deleteToast.removed}
          onDone={() => { setDeleteToast(null); toastShownRef.current = false }}
        />
      )}

      {/* ── Export report modal ── */}
      {reportModal && <ReportModal onClose={() => setReportModal(false)} />}
    </div>
  )
}
