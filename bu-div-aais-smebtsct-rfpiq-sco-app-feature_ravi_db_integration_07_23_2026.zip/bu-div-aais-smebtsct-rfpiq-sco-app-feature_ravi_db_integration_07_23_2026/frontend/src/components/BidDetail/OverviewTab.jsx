import React, { useState, useEffect, useRef } from 'react'
import {
  Calendar, Package, Users, TrendingUp,
  CheckCircle, AlertCircle, Clock, Pencil, X, Loader,
  FileText, Download, Eye, Upload, Plus, File, Globe, Mail, Bell,
} from 'lucide-react'
import { EmptyState } from '../UI/EmptyState'
import CustomerSelector from '../UI/CustomerSelector'
import {
  STATUS_CONFIG, SEGMENT_CONFIG, COMPLIANCE_CONFIG, ALL_STATUSES,
  getDaysUntilDue, getResponseRate, getSuppliersContacted, getResponsesReceived, formatDate,
} from '../../utils/bidUtils'

// ── Constants ─────────────────────────────────────────────
const SEGMENTS   = ['K-12', 'DoD', 'University', 'Healthcare', 'Restaurant', 'Lodging', 'Government']
const REGIONS    = ['Northeast', 'Southeast', 'Midwest', 'Mountain', 'Southwest', 'Northwest', 'National']
const COMP_FLAGS = ['Buy American', 'Child Nutrition', 'PFS', 'SOX', 'Halal', 'Kosher', 'Whole Grain', 'Exact Spec']

const subtractDays = (dateStr, n) => {
  if (!dateStr) return ''
  const d = new Date(dateStr)
  d.setDate(d.getDate() - n)
  return d.toISOString().split('T')[0]
}

// ── Info row ──────────────────────────────────────────────
function InfoRow({ label, value, mono }) {
  return (
    <div className="flex items-start justify-between py-2.5 border-b border-gray-100 last:border-0">
      <span className="text-xs text-gray-500 font-medium">{label}</span>
      <span className={`text-sm text-gray-900 text-right max-w-[60%] ${mono ? 'font-mono' : 'font-medium'}`}>
        {value ?? '—'}
      </span>
    </div>
  )
}

// ── Section card ──────────────────────────────────────────
function Section({ title, icon: Icon, action, children }) {
  return (
    <div className="card p-5">
      <div className="flex items-center justify-between gap-2 mb-3 pb-2 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 text-exl-orange" />
          <h3 className="text-sm font-semibold text-exl-navy dark:text-blue-300">{title}</h3>
        </div>
        {action}
      </div>
      {children}
    </div>
  )
}

// ── BidDocuments helpers ──────────────────────────────────
const DOC_TYPES = ['RFP Document', 'Item List', 'Contract', 'CN Label', 'PFS', 'Compliance', 'Spec Sheet', 'Other']

const DOC_TYPE_BADGE = {
  'RFP Document': 'bg-blue-100 text-blue-700',
  'Item List':    'bg-emerald-100 text-emerald-700',
  'Contract':     'bg-purple-100 text-purple-700',
  'CN Label':     'bg-amber-100 text-amber-700',
  'PFS':          'bg-orange-100 text-orange-700',
  'Compliance':   'bg-red-100 text-red-700',
  'Spec Sheet':   'bg-indigo-100 text-indigo-700',
  'Other':        'bg-gray-100 text-gray-600',
}

function DocFileIcon({ mimetype }) {
  const isPdf = mimetype?.includes('pdf')
  const isXls = mimetype?.includes('spreadsheet') || mimetype?.includes('excel') || mimetype?.includes('csv')
  if (isPdf) return (
    <div className="w-10 h-10 rounded-xl bg-red-50 border border-red-100 flex items-center justify-center flex-shrink-0">
      <FileText className="w-5 h-5 text-red-500" />
    </div>
  )
  if (isXls) return (
    <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center flex-shrink-0">
      <FileText className="w-5 h-5 text-emerald-600" />
    </div>
  )
  return (
    <div className="w-10 h-10 rounded-xl bg-gray-100 border border-gray-200 flex items-center justify-center flex-shrink-0">
      <File className="w-5 h-5 text-gray-400" />
    </div>
  )
}

// ── BidDocuments section ──────────────────────────────────
function BidDocuments({ bid }) {
  const [files,       setFiles]       = useState(null)  // null = loading
  const [drawerOpen,  setDrawerOpen]  = useState(false)
  const [uploading,   setUploading]   = useState(false)
  const [uploadForm,  setUploadForm]  = useState({ docType: 'Other', notes: '' })
  const [selectedFile,setSelectedFile]= useState(null)
  const [dragOver,    setDragOver]    = useState(false)
  const [toast,       setToast]       = useState(null)
  const fileInputRef = useRef(null)

  useEffect(() => {
    fetch(`/api/bids/${bid.id}/files`)
      .then(r => r.json())
      .then(d => setFiles(Array.isArray(d) ? d : []))
      .catch(() => setFiles([]))
  }, [bid.id])

  const showToast = (msg, type = 'success') => {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 3500)
  }

  const handleFilePick = (file) => {
    if (!file) return
    setSelectedFile(file)
    const ext = file.name.split('.').pop().toLowerCase()
    if (ext === 'pdf') setUploadForm(f => ({ ...f, docType: 'RFP Document' }))
    else if (['xlsx', 'xls', 'csv'].includes(ext)) setUploadForm(f => ({ ...f, docType: 'Item List' }))
  }

  const handleUpload = async () => {
    if (!selectedFile) return
    setUploading(true)
    const fd = new FormData()
    fd.append('file', selectedFile)
    fd.append('docType', uploadForm.docType)
    fd.append('notes',   uploadForm.notes)
    try {
      const res  = await fetch(`/api/bids/${bid.id}/files`, { method: 'POST', body: fd })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Upload failed')
      setFiles(prev => [...(prev || []), data.file])
      setDrawerOpen(false)
      setSelectedFile(null)
      setUploadForm({ docType: 'Other', notes: '' })
      showToast('Document uploaded successfully')
    } catch (err) {
      showToast(`Upload failed: ${err.message}`, 'error')
    } finally {
      setUploading(false)
    }
  }

  const loading = files === null

  return (
    <>
      {/* Toast */}
      {toast && (
        <div className={`flex items-center gap-2 text-xs font-medium px-3 py-2 rounded-lg mb-3 border
          ${toast.type === 'error'
            ? 'bg-red-50 border-red-200 text-red-700'
            : 'bg-emerald-50 border-emerald-200 text-emerald-700'
          }`}
        >
          <CheckCircle className="w-3.5 h-3.5 flex-shrink-0" /> {toast.msg}
        </div>
      )}

      <div className="card p-5">
        {/* Header */}
        <div className="flex items-center justify-between mb-4 pb-2 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-exl-orange" />
            <h3 className="text-sm font-semibold text-exl-navy dark:text-blue-300">RFP Documents</h3>
            {!loading && files.length > 0 && (
              <span className="text-xs font-semibold bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">
                {files.length}
              </span>
            )}
          </div>
          <button
            onClick={() => setDrawerOpen(true)}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white bg-exl-orange hover:bg-exl-orange/90 rounded-lg transition-colors"
          >
            <Plus className="w-3.5 h-3.5" /> Upload Document
          </button>
        </div>

        {/* Loading */}
        {loading && (
          <div className="flex items-center gap-2 text-sm text-gray-400 py-6 justify-center">
            <Loader className="w-4 h-4 animate-spin" /> Loading documents…
          </div>
        )}

        {/* Empty state */}
        {!loading && files.length === 0 && (
          <EmptyState
            icon={FileText}
            title="No documents yet"
            description="Upload the RFP PDF and item list Excel to get started."
            action={{ label: 'Upload Document', icon: Upload, onClick: () => setDrawerOpen(true) }}
            size="sm"
          />
        )}

        {/* File grid */}
        {!loading && files.length > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {files.map((file, idx) => {
              // Normalise field names — handle both API-uploaded shape
              // (name/type/mimetype/size-string/path) and manually-added shape
              // (filename/originalName/docType/size-bytes/uploadedAt-ISO)
              const displayName = file.originalName || file.name || file.filename || 'Document'
              const docType     = file.docType || file.type || 'Other'
              const filename    = file.filename || (file.path ? file.path.split('/').pop() : file.name) || ''
              const badgeCls    = DOC_TYPE_BADGE[docType] ?? DOC_TYPE_BADGE['Other']

              // Format size: bytes number → "X KB", already-formatted string → use as-is
              const sizeDisplay = typeof file.size === 'number'
                ? `${Math.max(1, Math.round(file.size / 1024))} KB`
                : file.size || '—'

              // Format date: ISO string → YYYY-MM-DD, short string → use as-is
              const dateDisplay = file.uploadedAt
                ? file.uploadedAt.length > 10
                  ? file.uploadedAt.slice(0, 10)
                  : file.uploadedAt
                : '—'

              // Derive mimetype for icon if not stored
              const mimetype = file.mimetype || (
                filename.endsWith('.pdf')  ? 'application/pdf' :
                /\.(xlsx|xls|csv)$/i.test(filename) ? 'application/vnd.ms-excel' : ''
              )

              return (
                <div
                  key={file.id || idx}
                  className="flex flex-col gap-2.5 p-3.5 border border-gray-200 dark:border-gray-700 rounded-xl hover:border-gray-300 dark:hover:border-gray-600 hover:shadow-sm transition-all bg-white dark:bg-[#1E293B]"
                >
                  <div className="flex items-start gap-3">
                    <DocFileIcon mimetype={mimetype} />
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-gray-900 truncate leading-tight" title={displayName}>
                        {displayName}
                      </p>
                      <span className={`inline-block mt-1 text-xs font-semibold px-2 py-0.5 rounded-full ${badgeCls}`}>
                        {docType}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-400 px-0.5">
                    <span>{sizeDisplay}</span>
                    <span>{dateDisplay}</span>
                  </div>
                  <div className="flex gap-2">
                    <a
                      href={`/api/bids/${bid.id}/files/${encodeURIComponent(filename)}/view`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex-1 flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-exl-navy dark:text-blue-300 border border-exl-navy/30 dark:border-blue-400/40 rounded-lg hover:bg-exl-navy dark:hover:bg-blue-600 hover:text-white transition-colors"
                    >
                      <Eye className="w-3 h-3" /> View
                    </a>
                    <a
                      href={`/api/bids/${bid.id}/files/${encodeURIComponent(filename)}/download`}
                      download={displayName}
                      className="flex-1 flex items-center justify-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <Download className="w-3 h-3" /> Download
                    </a>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </div>

      {/* ── Upload Drawer ─────────────────────────────────── */}
      {drawerOpen && (
        <div className="fixed inset-0 z-40 flex justify-end">
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-black/30 backdrop-blur-[1px]"
            onClick={() => !uploading && setDrawerOpen(false)}
          />
          {/* Panel */}
          <div className="relative z-50 w-full max-w-sm bg-white dark:bg-[#1E293B] shadow-2xl flex flex-col h-full">
            {/* Drawer header */}
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-200 dark:border-gray-700 bg-gray-50/80 dark:bg-[#253347]">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-exl-orange/10 dark:bg-orange-900/30 flex items-center justify-center">
                  <Upload className="w-3.5 h-3.5 text-exl-orange" />
                </div>
                <div>
                  <p className="text-sm font-bold text-exl-navy dark:text-blue-300">Upload Document</p>
                  <p className="text-xs text-gray-400">{bid.id} · {bid.customer}</p>
                </div>
              </div>
              <button
                onClick={() => !uploading && setDrawerOpen(false)}
                className="w-7 h-7 flex items-center justify-center rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-200 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="flex-1 min-h-0 overflow-y-auto px-5 py-5 space-y-5">

              {/* Drop zone */}
              <div>
                <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide mb-2">File</p>
                <div
                  onDragOver={e => { e.preventDefault(); setDragOver(true) }}
                  onDragLeave={() => setDragOver(false)}
                  onDrop={e => { e.preventDefault(); setDragOver(false); handleFilePick(e.dataTransfer.files[0]) }}
                  onClick={() => fileInputRef.current?.click()}
                  className={`border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all
                    ${dragOver
                      ? 'border-exl-orange bg-exl-orange/5 dark:bg-orange-900/20 scale-[1.01]'
                      : selectedFile
                        ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-900/20'
                        : 'border-gray-200 hover:border-exl-orange/50 hover:bg-gray-50 dark:hover:bg-[#253347]'
                    }`}
                >
                  <input
                    ref={fileInputRef}
                    type="file"
                    className="sr-only"
                    accept=".pdf,.xlsx,.xls,.csv,.docx"
                    onChange={e => handleFilePick(e.target.files[0])}
                  />
                  {selectedFile ? (
                    <div className="flex items-center justify-center gap-3">
                      <div className="w-8 h-8 rounded-lg bg-emerald-100 flex items-center justify-center flex-shrink-0">
                        <FileText className="w-4 h-4 text-emerald-600" />
                      </div>
                      <div className="text-left min-w-0">
                        <p className="text-sm font-semibold text-gray-800 truncate max-w-[180px]">{selectedFile.name}</p>
                        <p className="text-xs text-gray-400">{(selectedFile.size / 1024).toFixed(0)} KB · click to change</p>
                      </div>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-7 h-7 mx-auto mb-2 text-gray-300" />
                      <p className="text-sm font-medium text-gray-500">Drop a file or click to browse</p>
                      <p className="text-xs text-gray-400 mt-1">PDF, Excel, CSV, Word — max 25 MB</p>
                    </>
                  )}
                </div>
              </div>

              {/* Document type */}
              <div>
                <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">
                  Document Type
                </label>
                <select
                  value={uploadForm.docType}
                  onChange={e => setUploadForm(f => ({ ...f, docType: e.target.value }))}
                  className="w-full px-3 py-2 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-[#253347] dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange"
                >
                  {DOC_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>

              {/* Notes */}
              <div>
                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 uppercase tracking-wide mb-1.5">
                  Notes <span className="text-gray-400 font-normal normal-case">(optional)</span>
                </label>
                <textarea
                  rows={3}
                  value={uploadForm.notes}
                  onChange={e => setUploadForm(f => ({ ...f, notes: e.target.value }))}
                  placeholder="e.g. Revised pricing schedule from Tyson Foods Q4 2026…"
                  className="w-full px-3 py-2 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-white dark:bg-[#253347] dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-exl-orange/30 focus:border-exl-orange resize-none"
                />
              </div>

            </div>

            {/* Drawer footer */}
            <div className="px-5 py-4 border-t border-gray-200 dark:border-gray-700 bg-gray-50/60 dark:bg-[#253347] flex gap-3 flex-shrink-0">
              <button
                onClick={() => !uploading && setDrawerOpen(false)}
                disabled={uploading}
                className="flex-1 px-4 py-2.5 text-sm font-semibold text-gray-600 border border-gray-200 rounded-xl hover:bg-gray-100 transition-colors disabled:opacity-40"
              >
                Cancel
              </button>
              <button
                onClick={handleUpload}
                disabled={!selectedFile || uploading}
                className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-white bg-exl-orange hover:bg-exl-orange/90 rounded-xl transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {uploading
                  ? <><Loader className="w-4 h-4 animate-spin" /> Uploading…</>
                  : <><Upload className="w-4 h-4" /> Upload</>
                }
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

// ── Timeline ──────────────────────────────────────────────
const TIMELINE_STEPS = [
  { key: 'intakeDate',   label: 'Intake',       icon: Package },
  { key: 'bidRelease',   label: 'RFP Release',  icon: Clock },
  { key: 'customerDue',  label: 'Customer Due', icon: Calendar },
  { key: 'internalDue',  label: 'Internal Due', icon: AlertCircle },
]

function Timeline({ bid }) {
  const today = new Date()
  return (
    <div className="relative">
      <div className="absolute top-4 left-4 right-4 h-0.5 bg-gray-200 z-0" />
      <div className="relative z-10 flex justify-between">
        {TIMELINE_STEPS.map(({ key, label, icon: Icon }) => {
          const date  = new Date(bid[key])
          const isPast = date < today
          return (
            <div key={key} className="flex flex-col items-center gap-1.5 flex-1">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center border-2 bg-white dark:bg-[#1E293B] ${
                isPast ? 'border-exl-orange bg-exl-orange/10 dark:bg-orange-900/30' : 'border-gray-200'
              }`}>
                <Icon className={`w-3.5 h-3.5 ${isPast ? 'text-exl-orange' : 'text-gray-300'}`} />
              </div>
              <div className="text-center">
                <p className={`text-xs font-semibold ${isPast ? 'text-exl-navy dark:text-blue-300' : 'text-gray-400'}`}>{label}</p>
                <p className="text-xs text-gray-400">{formatDate(bid[key])}</p>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── Form field wrapper ────────────────────────────────────
function FormField({ label, required, hint, error, children }) {
  return (
    <div>
      <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1.5">
        {label}
        {required && <span className="text-red-500 ml-1">*</span>}
        {hint && <span className="text-gray-400 font-normal ml-2 normal-case tracking-normal">{hint}</span>}
      </label>
      {children}
      {error && (
        <p className="mt-1 text-xs text-red-600 flex items-center gap-1">
          <AlertCircle className="w-3 h-3" /> {error}
        </p>
      )}
    </div>
  )
}

const inputCls = (err) =>
  `w-full px-3 py-2 text-sm border rounded-lg focus:outline-none focus:ring-2 transition-colors dark:text-gray-200
   ${err
     ? 'border-red-400 bg-red-50 dark:bg-red-900/20 focus:ring-red-200 focus:border-red-500'
     : 'border-gray-200 dark:border-gray-600 bg-white dark:bg-[#253347] focus:ring-exl-orange/30 focus:border-exl-orange'
   }`

// ── Edit Bid Form ─────────────────────────────────────────
function EditBidForm({ bid, onCancel, onSaved }) {
  const [form, setForm] = useState({
    customerName:    bid.customer     || '',
    customerId:      bid.customerId   || '',
    bidId:           bid.id           || '',
    segment:         bid.segment      || 'K-12',
    status:          bid.status       || 'Active',
    opcoCode:        bid.opco         || '',
    opcoName:        bid.opcoName     || '',
    region:          bid.region       || '',
    bidRelease:      bid.bidRelease   || '',
    customerDue:     bid.customerDue  || '',
    internalDue:     bid.internalDue  || '',
    complianceFlags: Array.isArray(bid.compliance) ? [...bid.compliance] : [],
    notes:           bid.notes        || '',
  })
  const [errors,    setErrors]    = useState({})
  const [saving,    setSaving]    = useState(false)
  const [saveError, setSaveError] = useState(null)

  const update = (key, val) => {
    setForm(prev => {
      const next = { ...prev, [key]: val }
      if (key === 'customerDue') next.internalDue = subtractDays(val, 5)
      return next
    })
    if (errors[key]) setErrors(prev => { const e = { ...prev }; delete e[key]; return e })
  }

  const toggleFlag = (flag) => {
    setForm(prev => ({
      ...prev,
      complianceFlags: prev.complianceFlags.includes(flag)
        ? prev.complianceFlags.filter(f => f !== flag)
        : [...prev.complianceFlags, flag],
    }))
  }

  const validate = () => {
    const errs = {}
    if (!form.customerName.trim()) errs.customerName = 'Required'
    if (!form.segment)             errs.segment      = 'Required'
    if (!form.customerDue)         errs.customerDue  = 'Required'
    return errs
  }

  const handleSave = async () => {
    const errs = validate()
    if (Object.keys(errs).length > 0) { setErrors(errs); return }

    setSaving(true)
    setSaveError(null)
    try {
      const res = await fetch(`/api/bids/${bid.id}`, {
        method:  'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customer:    form.customerName.trim(),
          customerId:  form.customerId || undefined,
          status:      form.status,
          opco:        form.opcoCode    || bid.opco,
          opcoName:    form.opcoName    || bid.opcoName,
          region:      form.region      || bid.region,
          segment:     form.segment,
          bidRelease:  form.bidRelease  || bid.bidRelease,
          customerDue: form.customerDue,
          internalDue: form.internalDue || subtractDays(form.customerDue, 5),
          notes:       form.notes,
          compliance:  form.complianceFlags,
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Save failed')
      onSaved(data.bid)
    } catch (err) {
      setSaveError(err.message)
    } finally {
      setSaving(false)
    }
  }

  return (
    <div className="card overflow-hidden mb-5">
      {/* Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-gray-200 bg-blue-50/60">
        <div className="flex items-center gap-3">
          <div className="w-7 h-7 bg-exl-navy rounded-full flex items-center justify-center">
            <Pencil className="w-3.5 h-3.5 text-white" />
          </div>
          <div>
            <p className="text-sm font-bold text-gray-900">Edit RFP Details</p>
            <p className="text-xs text-gray-500 mt-0.5">Changes are saved immediately to the RFP record</p>
          </div>
        </div>
        <button
          onClick={onCancel}
          className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-gray-600 hover:bg-gray-100 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <div className="px-6 py-5 space-y-5">

        {/* Row 1 — Customer + Bid ID */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField label="Customer Name" required error={errors.customerName}>
            <CustomerSelector
              value={form.customerName}
              customerId={form.customerId}
              onChange={(id, name) => setForm(f => ({ ...f, customerId: id, customerName: name }))}
              placeholder="Search or add customer…"
            />
          </FormField>
          <FormField label="RFP ID" hint="Read-only">
            <input
              type="text"
              value={form.bidId}
              readOnly
              className="w-full px-3 py-2 text-sm border border-gray-200 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-[#253347] text-gray-500 dark:text-gray-400 font-mono cursor-not-allowed"
            />
          </FormField>
        </div>

        {/* Row 2 — Segment + Status + OpCo */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <FormField label="Segment" required error={errors.segment}>
            <select value={form.segment} onChange={e => update('segment', e.target.value)} className={inputCls(errors.segment)}>
              <option value="">— Select —</option>
              {SEGMENTS.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </FormField>
          <FormField label="Status">
            <select value={form.status} onChange={e => update('status', e.target.value)} className={inputCls(null)}>
              {ALL_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </FormField>
          <FormField label="OpCo Code">
            <input type="text" value={form.opcoCode} onChange={e => update('opcoCode', e.target.value)} placeholder="e.g. 028" className={inputCls(null)} />
          </FormField>
          <FormField label="OpCo Name">
            <input type="text" value={form.opcoName} onChange={e => update('opcoName', e.target.value)} placeholder="e.g. FoodCorp Chicago" className={inputCls(null)} />
          </FormField>
        </div>

        {/* Row 3 — Region + Dates */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <FormField label="Region">
            <select value={form.region} onChange={e => update('region', e.target.value)} className={inputCls(null)}>
              <option value="">— Select —</option>
              {REGIONS.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </FormField>
          <FormField label="RFP Release Date">
            <input type="date" value={form.bidRelease} onChange={e => update('bidRelease', e.target.value)} className={inputCls(null)} />
          </FormField>
          <FormField label="Customer Due Date" required error={errors.customerDue}>
            <input type="date" value={form.customerDue} onChange={e => update('customerDue', e.target.value)} className={inputCls(errors.customerDue)} />
          </FormField>
          <FormField label="Internal Due Date" hint="Auto: −5 days">
            <input type="date" value={form.internalDue} onChange={e => update('internalDue', e.target.value)} className={inputCls(null)} />
          </FormField>
        </div>

        {/* Row 4 — Compliance flags */}
        <div>
          <p className="text-xs font-semibold text-gray-600 uppercase tracking-wide mb-2.5">Compliance Flags</p>
          <div className="flex flex-wrap gap-2">
            {COMP_FLAGS.map(flag => {
              const checked = form.complianceFlags.includes(flag)
              return (
                <label
                  key={flag}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold cursor-pointer border transition-all select-none
                    ${checked
                      ? 'bg-exl-navy text-white border-exl-navy shadow-sm'
                      : 'bg-white text-gray-600 border-gray-200 hover:border-gray-400'
                    }`}
                >
                  <input type="checkbox" checked={checked} onChange={() => toggleFlag(flag)} className="sr-only" />
                  {checked && <CheckCircle className="w-3 h-3" />}
                  {flag}
                </label>
              )
            })}
          </div>
        </div>

        {/* Row 5 — Notes */}
        <FormField label="Notes (Optional)">
          <textarea
            rows={3}
            value={form.notes}
            onChange={e => update('notes', e.target.value)}
            placeholder="Any internal notes for the Bid COE team…"
            className={`${inputCls(null)} resize-none`}
          />
        </FormField>

        {/* Error */}
        {saveError && (
          <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg px-4 py-3 text-sm text-red-700">
            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" /> {saveError}
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-end gap-3 pt-1 border-t border-gray-100">
          <button onClick={onCancel} disabled={saving} className="btn-secondary text-sm px-5">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex items-center gap-2 px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-sm font-semibold rounded-xl transition-colors"
          >
            {saving
              ? <><Loader className="w-4 h-4 animate-spin" /> Saving…</>
              : <><CheckCircle className="w-4 h-4" /> Save Changes</>
            }
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Main OverviewTab ──────────────────────────────────────
export default function OverviewTab({ bid, onBidUpdate, autoEdit }) {
  const [editing, setEditing] = useState(false)
  const [saved,   setSaved]   = useState(false)

  // PORTAL-DEMO: portal channel breakdown state
  const [portalCount,    setPortalCount]    = useState(0)
  const [autoReminder,   setAutoReminder]   = useState(
    bid.autoReminder ?? { enabled: false, daysAfterSolicitation: 3, lastReminderSent: null }
  )
  const [savingReminder, setSavingReminder] = useState(false)
  useEffect(() => {
    fetch(`/api/submit/${bid.id}/submissions`)
      .then(r => r.ok ? r.json() : [])
      .then(subs => setPortalCount(Array.isArray(subs) ? subs.length : 0))
      .catch(() => {})
  }, [bid.id])
  const saveAutoReminder = async (patch) => {
    const updated = { ...autoReminder, ...patch }
    setAutoReminder(updated)
    setSavingReminder(true)
    try {
      await fetch(`/api/bids/${bid.id}/auto-reminder`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      })
    } catch { /* best-effort */ }
    finally { setSavingReminder(false) }
  }

  // Auto-open edit form when navigated via ?edit=1 (from three-dot menu)
  useEffect(() => {
    if (autoEdit) {
      setEditing(true)
      // Clean the ?edit=1 from the URL without a page reload
      const url = new URL(window.location.href)
      url.searchParams.delete('edit')
      window.history.replaceState({}, '', url.toString())
    }
  }, [autoEdit])

  const days = getDaysUntilDue(bid.internalDue)
  const rate = getResponseRate(bid)
  const statusCfg = STATUS_CONFIG[bid.status] ?? STATUS_CONFIG['Active']
  const segCfg    = SEGMENT_CONFIG[bid.segment] ?? {}

  const handleSaved = (updatedBid) => {
    setEditing(false)
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
    onBidUpdate?.(updatedBid)
  }

  return (
    <div>
      {/* ── Edit form (replaces content when editing) ── */}
      {editing && (
        <EditBidForm
          bid={bid}
          onCancel={() => setEditing(false)}
          onSaved={handleSaved}
        />
      )}

      {/* ── Save confirmation toast ── */}
      {saved && (
        <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200 text-emerald-700 text-sm font-medium px-4 py-2.5 rounded-xl mb-5">
          <CheckCircle className="w-4 h-4" /> RFP details updated successfully
        </div>
      )}

      {/* ── Overview grid (always visible) ── */}
      <div className="grid grid-cols-3 gap-5">

        {/* ── Left column (2/3 width) ── */}
        <div className="col-span-2 space-y-5">

          {/* Timeline */}
          <Section title="RFP Timeline" icon={Calendar}>
            <Timeline bid={bid} />
          </Section>

          {/* RFP details */}
          <Section
            title="RFP Details"
            icon={Package}
            action={
              !editing && (
                <button
                  onClick={() => setEditing(true)}
                  className="inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold text-gray-600 border border-gray-200 rounded-lg hover:border-exl-orange hover:text-exl-orange transition-colors"
                >
                  <Pencil className="w-3 h-3" /> Edit RFP Details
                </button>
              )
            }
          >
            <InfoRow label="RFP ID"       value={bid.rfpNumber || bid.id} mono />
            <InfoRow label="Customer"     value={bid.customer} />
            {bid.customerId && <InfoRow label="Customer ID"  value={bid.customerId} mono />}
            <InfoRow label="Segment"      value={bid.segment} />
            <InfoRow label="OpCo"         value={`${bid.opco} — ${bid.opcoName}`} />
            <InfoRow label="Region"       value={bid.region} />
            <InfoRow label="Item Count"   value={`${bid.items} line items`} />
            <InfoRow label="Intake Date"  value={formatDate(bid.intakeDate)} />
            <InfoRow label="RFP Release"  value={formatDate(bid.bidRelease)} />
            <InfoRow label="Customer Due" value={formatDate(bid.customerDue)} />
            <InfoRow label="Internal Due" value={
              <span className={days <= 7 ? 'text-red-600 font-bold' : ''}>
                {formatDate(bid.internalDue)}{days <= 7 ? ` (${days}d)` : ''}
              </span>
            } />
            {bid.notes && <InfoRow label="Notes" value={bid.notes} />}
          </Section>

          {/* Item categories */}
          <Section title="Item Categories" icon={Package}>
            {(bid.itemCategories || []).length > 0 ? (
              <div className="flex flex-wrap gap-2 pt-1">
                {bid.itemCategories.map(cat => (
                  <span key={cat} className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">
                    {cat}
                  </span>
                ))}
              </div>
            ) : (
              <p className="text-xs text-gray-400 italic">No categories set</p>
            )}
          </Section>
        </div>

        {/* ── Right column (1/3 width) ── */}
        <div className="space-y-5">

          {/* Status + Segment */}
          <Section title="Status" icon={TrendingUp}>
            <div className="space-y-3">
              <div>
                <p className="text-xs text-gray-500 mb-1">Current status</p>
                <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-semibold ${statusCfg.bg} ${statusCfg.text}`}>
                  <span className={`w-2 h-2 rounded-full ${statusCfg.dot}`} />
                  {bid.status}
                </span>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Segment</p>
                <span className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-medium ${segCfg.pillBg ?? 'bg-gray-100'} ${segCfg.pillText ?? 'text-gray-700'}`}>
                  {segCfg.icon} {bid.segment}
                </span>
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Internal due</p>
                <div className={`flex items-center gap-1.5 text-sm font-semibold ${days <= 7 ? 'text-red-600' : 'text-gray-700'}`}>
                  {days <= 0 ? (
                    <><AlertCircle className="w-4 h-4" /> {Math.abs(days)}d overdue</>
                  ) : days <= 7 ? (
                    <><AlertCircle className="w-4 h-4" /> {days} days left</>
                  ) : (
                    <><Clock className="w-4 h-4 text-gray-400" /> {days} days left</>
                  )}
                </div>
              </div>

              {/* PORTAL-DEMO: auto-reminder config section additive */}
              <div className="border-t border-gray-100 pt-3">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-1.5">
                    <Bell className="w-3.5 h-3.5 text-amber-500" />
                    <span className="text-xs font-semibold text-gray-700">Auto-Reminders</span>
                  </div>
                  <button onClick={() => saveAutoReminder({ enabled: !autoReminder.enabled })} disabled={savingReminder}
                    className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${autoReminder.enabled ? 'bg-amber-500' : 'bg-gray-200'}`}>
                    <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow transition-transform ${autoReminder.enabled ? 'translate-x-4' : 'translate-x-0.5'}`} />
                  </button>
                </div>
                {autoReminder.enabled && (
                  <div className="space-y-2 text-xs text-gray-600">
                    <div className="flex items-center gap-2">
                      <span>Send after</span>
                      <select value={autoReminder.daysAfterSolicitation}
                        onChange={e => saveAutoReminder({ daysAfterSolicitation: Number(e.target.value) })}
                        className="border border-gray-200 rounded px-1.5 py-0.5 text-xs">
                        {[2,3,5,7,10].map(d => <option key={d} value={d}>{d}</option>)}
                      </select>
                      <span>days with no response</span>
                    </div>
                    {autoReminder.lastReminderSent && (
                      <p className="text-gray-400">Last sent: {new Date(autoReminder.lastReminderSent).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</p>
                    )}
                    <p className="text-amber-600 font-medium">Sends portal URL to non-responding suppliers</p>
                  </div>
                )}
                {!autoReminder.enabled && (
                  <p className="text-xs text-gray-400">Off — enable to automatically remind non-responding suppliers</p>
                )}
              </div>
            </div>
          </Section>

          {/* Supplier response */}
          <Section title="Supplier Response" icon={Users}>
            <div className="space-y-3">
              <div className="text-center py-2">
                <div className={`text-4xl font-bold ${
                  rate >= 75 ? 'text-emerald-600' : rate >= 50 ? 'text-amber-600' : rate > 0 ? 'text-red-500' : 'text-gray-300'
                }`}>
                  {rate}%
                </div>
                <p className="text-xs text-gray-500 mt-1">response rate</p>
              </div>
              <div className="w-full bg-gray-100 rounded-full h-2">
                <div
                  className={`h-2 rounded-full transition-all ${rate >= 75 ? 'bg-emerald-500' : rate >= 50 ? 'bg-amber-500' : rate > 0 ? 'bg-red-400' : 'bg-gray-200'}`}
                  style={{ width: `${rate}%` }}
                />
              </div>
              <div className="grid grid-cols-2 gap-2 text-center">
                <div className="bg-gray-50 dark:bg-[#253347] rounded-lg p-2">
                  <p className="text-lg font-bold text-exl-navy dark:text-blue-300">{getSuppliersContacted(bid)}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Contacted</p>
                </div>
                <div className="bg-gray-50 dark:bg-[#253347] rounded-lg p-2">
                  <p className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{getResponsesReceived(bid)}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">Responded</p>
                </div>
              </div>
              {getSuppliersContacted(bid) === 0 && (
                <p className="text-xs text-gray-400 text-center italic">Solicitation not yet sent</p>
              )}

              {/* PORTAL-DEMO: channel breakdown additive */}
              {getResponsesReceived(bid) > 0 && (
                <div className="border-t border-gray-100 pt-2">
                  <p className="text-xs font-semibold text-gray-500 mb-1.5">By channel</p>
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-xs">
                      <span className="flex items-center gap-1 text-emerald-700">
                        <Globe className="w-3 h-3" /> Via Portal
                      </span>
                      <span className="font-bold text-emerald-700">{portalCount}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs">
                      <span className="flex items-center gap-1 text-gray-500">
                        <Mail className="w-3 h-3" /> Via Email
                      </span>
                      <span className="font-bold text-gray-600">{Math.max(0, getResponsesReceived(bid) - portalCount)}</span>
                    </div>
                  </div>
                </div>
              )}

              {/* Award progress */}
              {(() => {
                const awardedSuppliers = (bid.solicitedSuppliers || []).filter(s => s.status === 'Awarded' || s.status === 'Complete')
                if (awardedSuppliers.length === 0) return null
                const total = getSuppliersContacted(bid)
                return (
                  <div className="border-t border-gray-100 pt-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="flex items-center gap-1 font-semibold text-teal-700">
                        🏆 Awarded
                      </span>
                      <span className="font-bold text-teal-700">
                        {awardedSuppliers.length}{total > 0 ? ` of ${total}` : ''} supplier{awardedSuppliers.length !== 1 ? 's' : ''}
                      </span>
                    </div>
                    <p className="text-xs text-gray-400 mt-0.5">
                      {awardedSuppliers.map(s => s.supplierName).join(', ')}
                    </p>
                  </div>
                )
              })()}
            </div>
          </Section>

          {/* Compliance flags */}
          <Section title="Compliance Requirements" icon={CheckCircle}>
            {(bid.compliance || []).length === 0 ? (
              <p className="text-xs text-gray-400 italic">No special compliance requirements</p>
            ) : (
              <div className="space-y-2">
                {bid.compliance.map(flag => {
                  const cfg = COMPLIANCE_CONFIG[flag]
                  return (
                    <div key={flag} className={`flex items-center gap-2 px-3 py-2 rounded-lg ${cfg?.bg ?? 'bg-gray-100'}`}>
                      <CheckCircle className={`w-3.5 h-3.5 ${cfg?.text ?? 'text-gray-600'}`} />
                      <span className={`text-xs font-semibold ${cfg?.text ?? 'text-gray-700'}`}>{flag}</span>
                    </div>
                  )
                })}
              </div>
            )}
          </Section>

        </div>
      </div>

      {/* ── Bid Documents (full-width, below 2-col grid) ── */}
      <div className="mt-5">
        <BidDocuments bid={bid} />
      </div>
    </div>
  )
}
