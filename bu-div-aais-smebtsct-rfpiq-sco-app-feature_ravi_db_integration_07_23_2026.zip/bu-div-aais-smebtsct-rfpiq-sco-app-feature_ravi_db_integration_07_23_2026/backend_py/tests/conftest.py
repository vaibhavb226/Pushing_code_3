"""
Shared pytest fixtures for all route and service tests.

Key fixtures:
- tmp_data_dir  — isolated temporary directory with fresh JSON files
- client        — httpx.AsyncClient wired to a test FastAPI app
- mock_llm      — LLMService backed by a predictable mock
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path
from typing import Any, AsyncGenerator
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
import pytest_asyncio
from httpx import ASGITransport, AsyncClient

# ── Seed data ─────────────────────────────────────────────────────────────────

SAMPLE_BID: dict[str, Any] = {
    "id": "BID-TEST-001",
    "customer": "Test School District",
    "opco": "016",
    "opcoName": "FoodCorp Boston",
    "region": "Northeast",
    "segment": "K-12",
    "status": "Active",
    "intakeDate": "2026-06-01",
    "customerDue": "2026-07-15",
    "internalDue": "2026-07-10",
    "bidRelease": "2026-06-15",
    "items": 0,
    "suppliersContacted": 0,
    "responsesReceived": 0,
    "notes": "",
    "compliance": ["Child Nutrition"],
    "itemCategories": [],
    "solicitedSuppliers": [],
    "uploadedFiles": [],
}

SAMPLE_SUPPLIER: dict[str, Any] = {
    "id": "SM-001",
    "name": "Test Supplier Inc",
    "category": "Protein",
    "contact": "supplier@test-demo.test",
    "segments": ["K-12"],
    "region": "Northeast",
    "broker": False,
    "bounce": False,
}

SAMPLE_LINE_ITEM: dict[str, Any] = {
    "id": "LI-BID-TEST-001-001",
    "bidId": "BID-TEST-001",
    "bidItem": "0001",
    "mpcCode": "MPC123",
    "brand": "Brand A",
    "description": "Test Product",
    "pack": "6",
    "size": "10 oz",
    "unit": "CS",
    "category": "Protein",
    "qty": 100,
    "storage": "Freezer",
    "cw": "N",
    "stkType": "A",
    "buyAmerican": True,
    "childNutrition": True,
    "pfsRequired": False,
    "exactSpec": False,
    "rfpPopulated": True,
    "_source": "excel",
    "trueVendor": None,
    "suppliedPrice": None,
    "allw": None,
    "dl": None,
    "priceCase": None,
    "devType": None,
    "openReview": False,
    "status": "No Response",
    "confidence": None,
    "supplierPricing": [],
}


# ── Fixtures ───────────────────────────────────────────────────────────────────

@pytest.fixture
def tmp_data_dir(tmp_path: Path) -> Path:
    """Create an isolated data directory with seed JSON files."""
    data = tmp_path / "data"
    data.mkdir()
    (tmp_path / "uploads").mkdir()

    (data / "bids.json").write_text(json.dumps([SAMPLE_BID]))
    (data / "suppliers.json").write_text(json.dumps([SAMPLE_SUPPLIER]))
    (data / "lineItems.json").write_text(json.dumps([SAMPLE_LINE_ITEM]))
    (data / "emailThreads.json").write_text(json.dumps([]))
    (data / "pricingData.json").write_text(json.dumps([]))
    (data / "documents.json").write_text(json.dumps([]))
    (data / "unmatchedEmails.json").write_text(json.dumps([]))
    (data / "submissions.json").write_text(json.dumps({}))
    (data / "portalTemplates.json").write_text(json.dumps([]))

    return tmp_path


@pytest_asyncio.fixture
async def client(tmp_data_dir: Path) -> AsyncGenerator[AsyncClient, None]:
    """AsyncClient pointing to the FastAPI test app with isolated JSON files."""
    # Patch dependencies to use tmp_data_dir
    with patch("dependencies.DATA_DIR", tmp_data_dir / "data"), \
         patch("dependencies.UPLOADS_DIR", tmp_data_dir / "uploads"), \
         patch("dependencies._bids", _make_bids_repo(tmp_data_dir)), \
         patch("dependencies._line_items", _make_items_repo(tmp_data_dir)), \
         patch("dependencies._email_threads", _make_threads_repo(tmp_data_dir)), \
         patch("dependencies._suppliers", _make_suppliers_repo(tmp_data_dir)), \
         patch("dependencies._documents", _make_docs_repo(tmp_data_dir)), \
         patch("dependencies._pricing", _make_pricing_repo(tmp_data_dir)), \
         patch("dependencies._submissions", _make_subs_repo(tmp_data_dir)), \
         patch("dependencies._portal_templates", _make_pt_repo(tmp_data_dir)), \
         patch("dependencies._unmatched", _make_unmatched_repo(tmp_data_dir)), \
         patch("dependencies._llm_service", _mock_llm()):

        from main import app
        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as ac:
            yield ac


@pytest.fixture
def mock_llm() -> MagicMock:
    return _mock_llm()


# ── Internal helpers ───────────────────────────────────────────────────────────

def _mock_llm() -> MagicMock:
    from services.llm.provider import LLMService, LLMResponse
    svc = MagicMock(spec=LLMService)
    svc.chat = AsyncMock(return_value=LLMResponse(content='{"items": [], "metadata": {}}'))
    svc.chat_with_history = AsyncMock(return_value=LLMResponse(content="Test AI response"))
    return svc


def _make_bids_repo(root: Path):
    from repositories.bids_repo import BidsRepository
    return BidsRepository(root / "data" / "bids.json")


def _make_items_repo(root: Path):
    from repositories.line_items_repo import LineItemsRepository
    return LineItemsRepository(root / "data" / "lineItems.json")


def _make_threads_repo(root: Path):
    from repositories.email_threads_repo import EmailThreadsRepository
    return EmailThreadsRepository(root / "data" / "emailThreads.json")


def _make_suppliers_repo(root: Path):
    from repositories.suppliers_repo import SuppliersRepository
    return SuppliersRepository(root / "data" / "suppliers.json")


def _make_docs_repo(root: Path):
    from repositories.documents_repo import DocumentsRepository
    return DocumentsRepository(root / "data" / "documents.json")


def _make_pricing_repo(root: Path):
    from repositories.pricing_repo import PricingRepository
    return PricingRepository(root / "data" / "pricingData.json")


def _make_subs_repo(root: Path):
    from repositories.submissions_repo import SubmissionsRepository
    return SubmissionsRepository(root / "data" / "submissions.json")


def _make_pt_repo(root: Path):
    from repositories.portal_templates_repo import PortalTemplatesRepository
    return PortalTemplatesRepository(root / "data" / "portalTemplates.json")


def _make_unmatched_repo(root: Path):
    from repositories.unmatched_emails_repo import UnmatchedEmailsRepository
    return UnmatchedEmailsRepository(root / "data" / "unmatchedEmails.json")
