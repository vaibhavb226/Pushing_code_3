from __future__ import annotations

from typing import Any

from pydantic import BaseModel


class SupplierPricing(BaseModel):
    supplierName: str
    supplierEmail: str = ""
    supplierItemNo: str = ""
    fobPrice: float | None = None
    freightAmount: float | None = None
    allowance: float | None = None
    ptvValue: float | None = None
    unitPrice: float | None = None
    commercialPrice: float | None = None
    casePrice: float | None = None
    devType: str | None = None
    notes: str = ""
    noBid: bool = False
    awardStatus: str | None = None
    awardedAt: str | None = None
    emailId: str | None = None
    confidence: str | None = None
    confidenceScore: int | None = None
    confidenceReasons: list[str] = []
    matchSource: str = "email"


class LineItemUpdate(BaseModel):
    trueVendor: str | None = None
    suppliedPrice: float | None = None
    allw: float | None = None
    dl: float | None = None
    priceCase: float | None = None
    devType: str | None = None
    openReview: bool | None = None
    status: str | None = None
    confidence: float | None = None
    supplierPricing: list[dict[str, Any]] | None = None


class LineItemResponse(BaseModel):
    model_config = {"extra": "allow"}

    id: str
    bidId: str
    bidItem: str
    mpcCode: str = ""
    brand: str = ""
    description: str = ""
    pack: str = ""
    size: str = ""
    unit: str = ""
    category: str = ""
    qty: int = 0
    storage: str = ""
    cw: str = "N"
    stkType: str = "A"
    buyAmerican: bool = False
    childNutrition: bool = False
    pfsRequired: bool = False
    exactSpec: bool = False
    rfpPopulated: bool = True
    trueVendor: str | None = None
    suppliedPrice: float | None = None
    allw: float | None = None
    dl: float | None = None
    priceCase: float | None = None
    devType: str | None = None
    openReview: bool = False
    status: str = "No Response"
    confidence: float | None = None
    supplierPricing: list[dict[str, Any]] = []
