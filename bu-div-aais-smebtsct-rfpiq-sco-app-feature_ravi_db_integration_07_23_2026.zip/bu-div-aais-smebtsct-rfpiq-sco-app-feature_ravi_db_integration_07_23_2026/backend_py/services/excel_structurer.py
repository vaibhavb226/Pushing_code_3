"""
Excel structurer — LLM-guided structure discovery + chunked LLM row mapping.

Strategy (see the RFP Extraction v2 plan):
  1. A cheap LLM "structure locator" runs on a SMALL sample of each sheet and returns, per sheet,
     whether it is an item sheet, the header row index (semantic — handles headers not in row 1),
     and a column map (used only by the deterministic fallback).
  2. The header row is rendered once and the data rows below it are split into chunks of
     `_CHUNK_ROWS`. Each chunk is mapped to line items by the LLM **in parallel**, with a STABLE
     prefix (system + header + PDF compliance context) that is byte-identical across a file's chunks
     → Gemini 2.5 implicit caching reuses it. Because the LLM maps every field per row, all inferred
     fields (category, compliance flags) come back like the original combined-context call.
  3. Per-chunk reconciliation warns on row-count mismatch; if a chunk's LLM call fails (after one
     retry) it falls back to a deterministic column read so rows are never lost.

Output items use the BEX snake_case field vocabulary so build_line_item() consumes them unchanged.
"""
from __future__ import annotations

import asyncio
import io
from dataclasses import dataclass, field
from typing import Any, Optional

import structlog
from pydantic import BaseModel, Field

from config import get_settings
from routers.bex_schemas import BEXLineItem
from routers.prompts import EXCEL_CHUNK_MAP_SYSTEM, EXCEL_STRUCTURE_LOCATOR_SYSTEM
from services.line_item_parser import _COLUMN_KEYWORDS, _is_truthy

log = structlog.get_logger()


# Field keys we read from a row (aligns with _COLUMN_KEYWORDS and BEXLineItem).
_SCHEMA_FIELDS: tuple[str, ...] = (
    "line_number", "mpc_code", "uom", "volume", "pack", "size", "brand",
    "description", "category", "storage", "buy_american", "child_nutrition",
    "pfs_required", "exact_spec",
)
_BOOL_FIELDS: frozenset[str] = frozenset(
    {"buy_american", "child_nutrition", "pfs_required", "exact_spec"}
)
# Map BEX schema field → the _COLUMN_KEYWORDS key (used only by the deterministic fallback).
_FIELD_TO_KEYWORD_KEY: dict[str, str] = {
    "line_number": "itemNo",
    "mpc_code": "mpcCode",
    "uom": "unit",
    "volume": "qty",
    "pack": "pack",
    "size": "size",
    "brand": "brand",
    "description": "description",
    "category": "category",
    "storage": "storage",
    "buy_american": "buyAmerican",
    "child_nutrition": "cn",
    "pfs_required": "pfs",
    "exact_spec": "exactSpec",
}

_SAMPLE_ROWS = 15        # rows per sheet shown to the locator
_SAMPLE_COLS = 40        # columns per sheet shown to the locator
_CHUNK_ROWS = 100        # data rows per LLM mapping call (~10k chars: rows are short)
_MAP_CONCURRENCY = 6     # max concurrent chunk-mapping calls
_LLM_CONFIDENCE = 90     # LLM-mapped row
_FALLBACK_CONFIDENCE = 75  # deterministic fallback row (no category/compliance inference)


# ── LLM schemas (fixed objects — reliable with Vertex structured output) ────────

class _ColumnMap(BaseModel):
    line_number: Optional[int] = None
    mpc_code: Optional[int] = None
    uom: Optional[int] = None
    volume: Optional[int] = None
    pack: Optional[int] = None
    size: Optional[int] = None
    brand: Optional[int] = None
    description: Optional[int] = None
    category: Optional[int] = None
    storage: Optional[int] = None
    buy_american: Optional[int] = None
    child_nutrition: Optional[int] = None
    pfs_required: Optional[int] = None
    exact_spec: Optional[int] = None


class _SheetStructure(BaseModel):
    sheet_index: int = 0
    is_item_sheet: bool = False
    header_row_index: Optional[int] = None
    column_map: _ColumnMap = Field(default_factory=_ColumnMap)


class _WorkbookStructure(BaseModel):
    sheets: list[_SheetStructure] = Field(default_factory=list)


class _ChunkResponse(BaseModel):
    """Line-items-only schema for chunk mapping (keeps output tokens tight)."""
    line_items: list[BEXLineItem] = Field(default_factory=list)


@dataclass
class ExcelStructureResult:
    items: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    detected_row_count: int = 0
    used_fallback: bool = False


# ── Cell helpers ────────────────────────────────────────────────────────────────

def _cell_to_str(val: Any) -> str:
    """Stringify a cell, rendering integral floats without the trailing '.0'."""
    if val is None:
        return ""
    if isinstance(val, float) and val.is_integer():
        return str(int(val))
    return str(val).strip()


def _row_is_empty(row: tuple[Any, ...]) -> bool:
    # xlrd returns "" for empty cells; openpyxl returns None — handle both
    return not any(c is not None and c != "" for c in row)


def _render_row(row: tuple[Any, ...], ncols: int) -> str:
    """Tab-separated cells aligned to `ncols` columns (blanks preserved for stable positions)."""
    return "\t".join(_cell_to_str(row[c]) if c < len(row) else "" for c in range(ncols))


# ── Sampling for the locator ─────────────────────────────────────────────────────

def _build_locator_user_prompt(sheets: list[tuple[str, list[tuple[Any, ...]]]]) -> str:
    """Render each sheet's first rows as a tab grid with 0-based row/column labels."""
    hint_lines = [
        f"  {f_name}: {', '.join(_COLUMN_KEYWORDS.get(_FIELD_TO_KEYWORD_KEY[f_name], []))}"
        for f_name in _SCHEMA_FIELDS
    ]
    parts: list[str] = [
        "Column-header hint words per field (not exhaustive — use judgement, clients vary wording):",
        *hint_lines,
        "",
    ]
    for idx, (name, rows) in enumerate(sheets):
        sample = rows[:_SAMPLE_ROWS]
        ncols = min(_SAMPLE_COLS, max((len(r) for r in sample), default=0))
        col_hdr = "ROW\t" + "\t".join(f"C{c}" for c in range(ncols))
        parts.append(f'SHEET {idx} "{name}" — first {len(sample)} rows, 0-based columns:')
        parts.append(col_hdr)
        for r_idx, row in enumerate(sample):
            parts.append(f"{r_idx}\t{_render_row(row, ncols)}")
        parts.append("")
    return "\n".join(parts)


# ── Deterministic per-row mapping (fallback only) ────────────────────────────────

def _map_row(row: tuple[Any, ...], col_map: dict[str, int], confidence: int) -> Optional[dict[str, Any]]:
    """Map one row via a column map into a BEXLineItem dict. None if the row has no content."""
    raw: dict[str, Any] = {}
    for f_name, c_idx in col_map.items():
        if c_idx is None or c_idx < 0 or c_idx >= len(row):
            continue
        cell = row[c_idx]
        if f_name in _BOOL_FIELDS:
            raw[f_name] = _is_truthy(cell)
        elif f_name == "volume":
            raw[f_name] = cell  # BEXLineItem.volume validator cleans commas/units
        else:
            s = _cell_to_str(cell)
            if s:
                raw[f_name] = s

    if not any(raw.get(f) for f in _SCHEMA_FIELDS if f not in _BOOL_FIELDS):
        return None
    raw.setdefault("description", "")
    try:
        item = BEXLineItem(**raw).model_dump(mode="json")
    except Exception as exc:  # pragma: no cover - defensive
        log.warning("excel_structurer.row_validate_failed", error=str(exc))
        return None
    item["confidence"] = confidence
    return item


# ── Deterministic header detection (used only if the locator call fails entirely) ─

def _score_header_row(row: tuple[Any, ...]) -> tuple[int, dict[str, int]]:
    header = [_cell_to_str(c).lower() for c in row]
    col_map: dict[str, int] = {}
    for f_name in _SCHEMA_FIELDS:
        keywords = _COLUMN_KEYWORDS.get(_FIELD_TO_KEYWORD_KEY[f_name], [])
        for kw in keywords:
            idx = next((i for i, h in enumerate(header) if kw in h), None)
            if idx is not None:
                col_map[f_name] = idx
                break
    return len(col_map), col_map


def _deterministic_structure(rows: list[tuple[Any, ...]]) -> Optional[tuple[int, dict[str, int]]]:
    """Keyword-scored header detection — last resort when the LLM locator call fails."""
    best_score = 0
    best: Optional[tuple[int, dict[str, int]]] = None
    for i, row in enumerate(rows[:_SAMPLE_ROWS]):
        if _row_is_empty(row):
            continue
        score, col_map = _score_header_row(row)
        if score > best_score:
            best_score = score
            best = (i, col_map)
    if best and best_score >= 2 and "description" in best[1]:
        return best
    return None


# ── Chunk mapping (primary path) ─────────────────────────────────────────────────

async def _map_chunk(
    llm: Any,
    prefix: str,
    data_rows: list[tuple[Any, ...]],
    ncols: int,
    col_map: dict[str, int],
    sem: asyncio.Semaphore,
) -> tuple[list[dict[str, Any]], bool]:
    """Map one chunk of data rows to line items. Returns (items, used_fallback)."""
    n = len(data_rows)
    rows_block = "\n".join(_render_row(r, ncols) for r in data_rows)
    user = (
        prefix
        + f"{n} DATA ROWS follow (tab-separated, same columns as the header). "
        + f"Return EXACTLY {n} line_items, one per row, in the same order:\n{rows_block}"
    )
    async with sem:
        for attempt in range(2):
            try:
                resp: _ChunkResponse = await llm.chat_structured(
                    system=EXCEL_CHUNK_MAP_SYSTEM,
                    user=user,
                    schema=_ChunkResponse,
                    max_tokens=get_settings().llm_max_tokens,
                    temperature=0.0,
                )
                items = [it.model_dump(mode="json") for it in resp.line_items]
                # line_number is always assigned by code (idx+1 in build_line_item) — discard any LLM guess.
                for it in items:
                    it["line_number"] = None
                for it in items:
                    if it.get("confidence") is None:
                        it["confidence"] = _LLM_CONFIDENCE
                return items, False
            except Exception as exc:
                log.warning("excel_structurer.chunk_map_failed", attempt=attempt, error=str(exc))
    # Both attempts failed → deterministic fallback so rows aren't lost.
    log.warning("excel_structurer.chunk_fallback_deterministic", rows=n)
    fb = [_map_row(r, col_map, _FALLBACK_CONFIDENCE) for r in data_rows]
    return [it for it in fb if it], True


# ── Public entry point ────────────────────────────────────────────────────────────

async def structure_excel(
    excel_bytes: bytes,
    llm: Any,
    pdf_context: str = "",
) -> ExcelStructureResult:
    """Parse an Excel item list into line-item dicts via chunked LLM mapping.

    `pdf_context` is the compact RFP compliance context; it is placed in each chunk's stable
    prefix so the LLM can set per-item compliance flags by cross-referencing the RFP.
    """
    result = ExcelStructureResult()
    if not excel_bytes:
        return result

    sheets: list[tuple[str, list[tuple[Any, ...]]]] = []
    try:
        import openpyxl
        wb = openpyxl.load_workbook(io.BytesIO(excel_bytes), data_only=True)
        sheets = [
            (ws.title, list(ws.iter_rows(values_only=True)))
            for ws in wb.worksheets
            if ws.sheet_state == 'visible'
        ]
    except Exception:
        # openpyxl only handles .xlsx — fall back to xlrd for legacy .xls files
        try:
            import xlrd
            wb_xls = xlrd.open_workbook(file_contents=excel_bytes)
            for sheet in wb_xls.sheets():
                if sheet.visibility != 0:
                    continue
                rows: list[tuple[Any, ...]] = [
                    tuple(sheet.cell_value(r, c) for c in range(sheet.ncols))
                    for r in range(sheet.nrows)
                ]
                sheets.append((sheet.name, rows))
        except Exception as exc:
            log.warning("excel_structurer.open_failed", error=str(exc))
            result.warnings.append("Could not open the Excel workbook.")
            return result
    sheets = [(name, rows) for name, rows in sheets if rows]
    if not sheets:
        result.warnings.append("The Excel workbook contained no rows.")
        return result

    # ── 1. LLM structure locator on the samples (semantic header + sheet selection) ──
    structures: dict[int, _SheetStructure] = {}
    try:
        locator_user = _build_locator_user_prompt(sheets)
        parsed: _WorkbookStructure = await llm.chat_structured(
            system=EXCEL_STRUCTURE_LOCATOR_SYSTEM,
            user=locator_user,
            schema=_WorkbookStructure,
            max_tokens=2000,
            temperature=0.0,
        )
        structures = {s.sheet_index: s for s in parsed.sheets}
        log.info("excel_structurer.locator_done",
                 sheets=len(sheets),
                 item_sheets=sum(1 for s in parsed.sheets if s.is_item_sheet))
    except Exception as exc:
        log.warning("excel_structurer.locator_failed", error=str(exc))

    sem = asyncio.Semaphore(_MAP_CONCURRENCY)

    # ── 2-3. Per item sheet: split header/data, chunk, map concurrently ──────────
    for s_idx, (name, rows) in enumerate(sheets):
        header_idx: Optional[int] = None
        col_map: dict[str, int] = {}

        st = structures.get(s_idx)
        if st and st.is_item_sheet and st.header_row_index is not None:
            cm = {k: v for k, v in st.column_map.model_dump().items() if v is not None}
            if 0 <= st.header_row_index < len(rows):
                header_idx, col_map = st.header_row_index, cm

        if header_idx is None:
            # Skip non-item sheets when the locator ran successfully.
            # `st is None` means the locator omitted this sheet (only returned item sheets) —
            # treat as non-item. `not st.is_item_sheet` is the explicit flag.
            if structures and (st is None or not st.is_item_sheet):
                continue
            fb = _deterministic_structure(rows)
            if fb is None:
                continue
            header_idx, col_map = fb

        header_cells = rows[header_idx]
        ncols = max(len(header_cells), max((len(r) for r in rows[header_idx + 1:]), default=0))
        header_line = _render_row(header_cells, ncols)
        data_rows = [r for r in rows[header_idx + 1:] if not _row_is_empty(r)]
        if not data_rows:
            continue

        # STABLE prefix — identical across this sheet's chunks → implicit caching.
        prefix = (
            "COLUMN HEADER (tab-separated, columns are 0-based left to right):\n"
            f"{header_line}\n\n"
            f"RFP PDF COMPLIANCE CONTEXT:\n{pdf_context or 'none'}\n\n"
        )

        chunks = [data_rows[i:i + _CHUNK_ROWS] for i in range(0, len(data_rows), _CHUNK_ROWS)]
        mapped = await asyncio.gather(
            *[_map_chunk(llm, prefix, ch, ncols, col_map, sem)
              for ch in chunks]
        )

        sheet_items: list[dict[str, Any]] = []
        for (items, used_fb), chunk in zip(mapped, chunks):
            if used_fb:
                result.used_fallback = True
            if len(items) != len(chunk):
                result.warnings.append(
                    f'Sheet "{name}": a chunk returned {len(items)} items for {len(chunk)} rows.'
                )
            for it in items:
                it["_sheet"] = name
            sheet_items.extend(items)

        result.items.extend(sheet_items)
        result.detected_row_count += len(data_rows)
        log.info("excel_structurer.sheet_read",
                 sheet=name, header_idx=header_idx,
                 items=len(sheet_items), data_rows=len(data_rows), chunks=len(chunks))

    if not result.items and not result.warnings:
        result.warnings.append("No recognisable item rows were found in the Excel.")

    log.info("excel_structurer.done",
             items=len(result.items),
             detected_rows=result.detected_row_count,
             used_fallback=result.used_fallback)
    return result
