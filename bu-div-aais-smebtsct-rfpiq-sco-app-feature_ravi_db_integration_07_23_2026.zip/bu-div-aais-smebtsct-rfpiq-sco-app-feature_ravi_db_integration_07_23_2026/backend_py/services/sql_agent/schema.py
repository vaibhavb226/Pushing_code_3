"""
Compact PostgreSQL schema summary injected into the SQL generation prompt.
Describes tables, columns, relationships, and common query patterns.
"""

SCHEMA_SUMMARY = """
Tables available for querying:

• rfps (id TEXT PK, customer_name, segment, status, intake_date DATE, customer_due DATE,
         internal_due DATE, compliance JSONB, item_categories JSONB, items INT,
         suppliers_contacted INT, responses_received INT, last_solicitation_date DATE,
         notes, opco, opco_name, region, solicitation_subject, created_at TIMESTAMPTZ)

• rfp_line_items (id TEXT PK, rfp_id→rfps, bid_item, description, mpc_code, brand,
                   category, qty, pack, size, unit, storage, cw, stk_type,
                   buy_american BOOL, child_nutrition BOOL, pfs_required BOOL,
                   exact_spec BOOL, whole_grain BOOL, halal BOOL, kosher BOOL,
                   true_vendor, supplied_price NUMERIC, allw NUMERIC,
                   dl NUMERIC, price_case NUMERIC, dev_type, status, confidence,
                   supplier_pricing JSONB, open_review BOOL, line_number INT,
                   rfp_populated BOOL)
  -- true_vendor = COE-selected supplier (the winner); price_case = final selected price/case
  -- supplier_pricing JSONB array = all offers received (extraction + portal + manual)
  -- whole_grain = USDA NSLP WGR (≥51% whole grain by weight, K-12 grain items)
  -- halal/kosher = dietary law certifications (DoD, Healthcare bids)

• rfp_solicited_suppliers (id TEXT PK, rfp_id→rfps, supplier_id→suppliers,
                            supplier_name, email, status, solicited_date TIMESTAMPTZ,
                            last_activity TIMESTAMPTZ, has_issues BOOL, issue_type,
                            channel, additional_emails JSONB)

• email_threads (id TEXT PK, rfp_id→rfps, supplier_name, supplier_id,
                  direction, subject, body, email_date TIMESTAMPTZ,
                  tags JSONB, is_bounce BOOL, bounce_code, bounce_reason,
                  graph_internet_message_id, uid)

• suppliers (id TEXT PK, name, category, subcategories JSONB, region,
              broker BOOL, segments JSONB, tags JSONB, bounce BOOL,
              status, contact)

• customers (id TEXT PK, organization_name, segment, opco, region, status)

• bids (id TEXT PK, rfp_id→rfps, supplier_name, supplier_email, supplier_id,
         contact_name, phone, submitted_at TIMESTAMPTZ, bid_status,
         priced_count INT, no_bid_count INT, dl_count INT, allw_count INT,
         confirmation_id, thread_id)
  -- one row per supplier submission (portal or email extraction)

• bid_line_items (id TEXT PK, bid_id→bids, description, unit_price NUMERIC,
                   case_price NUMERIC, no_bid BOOL, dev_type, notes)
  -- individual line-item offers from each supplier; JOIN bids to get supplier context

• submission_messages (id TEXT PK, bid_id→bids, body, sender, sender_name,
                        sent_at TIMESTAMPTZ, read_by_bid_coe BOOL,
                        read_by_supplier BOOL, attachments JSONB)

• documents (id TEXT PK, rfp_id→rfps, file_name, document_type,
              gcs_uri, upload_date TIMESTAMPTZ, status)

• document_vectors (id TEXT PK, chunk_text, file_name, bid_id,
                     document_type, chunk_index INT, page_number INT)
  -- Note: do NOT query embedding column (vector type) — use vector_search path

Key relationships:
  rfps.id ← rfp_line_items.rfp_id
  rfps.id ← rfp_solicited_suppliers.rfp_id
  rfps.id ← email_threads.rfp_id
  rfps.id ← bids.rfp_id
  rfps.id ← documents.rfp_id
  bids.id ← bid_line_items.bid_id
  bids.id ← submission_messages.bid_id

Status values:
  rfps.status:                       'Draft' | 'Active' | 'Solicitation' | 'Under Review' | 'Awarded' | 'Cancelled' | 'At Risk'
  rfp_solicited_suppliers.status:    'Awaiting' | 'Responded' | 'Issues Found' | 'Follow-up Sent' | 'Awarded'
  email_threads.direction:           'inbound' | 'outbound'
  rfp_line_items.dev_type:           'ALLW' | 'DL' | null

Example queries:

-- How many suppliers responded to each bid?
SELECT r.id, r.customer_name,
  COUNT(*) FILTER (WHERE s.status = 'Responded') AS responded,
  COUNT(*) AS total_solicited
FROM rfps r
LEFT JOIN rfp_solicited_suppliers s ON s.rfp_id = r.id
GROUP BY r.id, r.customer_name
ORDER BY responded DESC;

-- All line items for a specific bid with COE-selected pricing
SELECT li.bid_item, li.description, li.qty, li.category,
       li.true_vendor, li.price_case, li.confidence
FROM rfp_line_items li
WHERE li.rfp_id = 'RFP-xxx' AND li.true_vendor IS NOT NULL
ORDER BY li.line_number NULLS LAST;

-- All supplier offers submitted for a bid (portal + email extraction)
SELECT b.supplier_name, bli.description, bli.case_price, bli.no_bid, bli.dev_type
FROM bid_line_items bli
JOIN bids b ON bli.bid_id = b.id
WHERE b.rfp_id = 'RFP-xxx'
ORDER BY b.supplier_name, bli.description;

-- Suppliers who have not yet responded
SELECT s.supplier_name, s.email, s.status, s.solicited_date
FROM rfp_solicited_suppliers s
JOIN rfps r ON r.id = s.rfp_id
WHERE s.status = 'Awaiting'
ORDER BY r.customer_name, s.supplier_name;

-- Portal submissions for a bid
SELECT b.supplier_name, b.submitted_at, b.priced_count, b.no_bid_count
FROM bids b
WHERE b.rfp_id = 'RFP-xxx'
ORDER BY b.submitted_at DESC;
"""
