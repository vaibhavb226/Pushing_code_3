﻿"""
POST /api/parse-rfp         — Upload PDF + Excel, call BEX AI, return parsed bid + line items
POST /api/parse-rfp/create  — Save parsed data to JSON files, return created bid
"""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from datetime import date
from typing import Any, Optional

import aiofiles
import structlog
from fastapi import APIRouter, Depends, Form, HTTPException, UploadFile

from pydantic import BaseModel, Field

from config import get_settings
from dependencies import UPLOADS_DIR, get_bids_repo, get_gcs_client, get_line_items_repo, get_llm_service
from repositories.bids_repo import BidsRepository
from repositories.line_items_repo import LineItemsRepository
from routers.bex_schemas import BEXMetadata, BEXResponse
from routers.prompts import (
    BEX_SYSTEM_PROMPT,
    BEX_USER_PDF_WITH_ITEMS,
    PDF_CONTEXT_EXTRACTION_SYSTEM,
)
from services.llm.provider import LLMService

# PDF item extraction: single call under this many chars; otherwise chunk by page.
_PDF_SINGLE_CALL_LIMIT = 40_000
_PDF_CHUNK_SIZE = 30_000


class PdfContext(BaseModel):
    """One upfront PDF extraction: bid metadata + a compact compliance context.

    `compliance_context` rides with each Excel chunk so per-item compliance can be
    cross-referenced without resending the whole PDF.
    """
    metadata: BEXMetadata = Field(default_factory=BEXMetadata)
    compliance_context: str = ""
    supplier_targeting: Optional[dict[str, Any]] = None

log = structlog.get_logger()
router = APIRouter(tags=["rfp-parser"])


# ── Shared helper — also used by bids.py ────────────────────────────────────

def _s(val: Any) -> str:
    """Coerce to string, treating None and the literal string 'null' as empty."""
    if val is None:
        return ""
    s = str(val).strip()
    return "" if s.lower() == "null" else s


def build_line_item(li: dict[str, Any], bid_id: str, idx: int) -> dict[str, Any]:
    """
    Construct a lineItems.json record from a parsed AI line item.
    Mirrors buildLineItem() in backend/routes/rfpParser.js exactly.
    """
    return {
        "id": f"LI-{bid_id}-{idx + 1:03d}",
        "bidId": bid_id,
        "bidItem": _s(li.get("line_number")) or str(idx + 1).zfill(4),
        "mpcCode": _s(li.get("mpc_code")) or _s(li.get("mfg_code")),
        "brand": _s(li.get("brand")),
        "description": _s(li.get("description")),
        "pack": _s(li.get("pack")),
        "size": _s(li.get("size")),
        "unit": _s(li.get("uom")),
        "category": _s(li.get("category")),
        "qty": int(float(li.get("volume") or li.get("est_qty") or 0)),
        "storage": _s(li.get("storage")),
        "cw": "N",
        "stkType": "A",
        "buyAmerican": bool(li.get("buy_american")),
        "childNutrition": bool(li.get("child_nutrition")),
        "pfsRequired": bool(li.get("pfs_required")),
        "exactSpec": bool(li.get("exact_spec")),
        "wholeGrain": bool(li.get("whole_grain")),
        "halal": bool(li.get("halal")),
        "kosher": bool(li.get("kosher")),
        "rfpPopulated": True,
        "_source": "pdf",
        "trueVendor": None,
        "suppliedPrice": None,
        "allw": None,
        "dl": None,
        "priceCase": None,
        "devType": None,
        "openReview": False,
        "status": "No Response",
        "confidence": li.get("confidence"),
        "supplierPricing": [],
    }


# ── Routes ────────────────────────────────────────────────────────────────────

@router.post("", response_model=dict[str, Any])
async def parse_rfp(
    pdf: UploadFile | None = None,
    excel: UploadFile | None = None,
    demo: bool = Form(False),
    llm: LLMService = Depends(get_llm_service),
    line_items_repo: LineItemsRepository = Depends(get_line_items_repo),
) -> dict[str, Any]:
    """Parse an RFP PDF and/or Excel item list using BEX AI to extract bid metadata and line items.

    Multipart form fields: `pdf` (RFP document), `excel` (item list), `demo` (bool, use demo data).
    PDF text is used for bid metadata only; Excel is used for line item extraction.
    Returns `{ metadata, line_items, supplier_targeting, parsing_warnings, tempPdfPath, tempExcelPath }`.

    Sample response (metadata):
    ```json
    { "bid_id": "B2600042", "customer_name": "Lakeview Unified School District", "segment": "K-12", "compliance_flags": ["Child Nutrition", "Buy American"], "total_items": 33 }
    ```
    """
    # ── Stage uploaded files (before any processing) ────────────────────────
    # When GCS is configured we upload to a staging prefix and do NOT write local temp
    # files — extraction runs off the in-memory bytes, and create_bid moves the staged
    # object to the final structured path on Save. Local temp is a fallback for local-dev
    # (no bucket) and for staging-upload failures, so a file is never lost.
    ts = int(time.time() * 1000)
    temp_pdf_path = temp_excel_path = ""
    staging_pdf_uri = staging_excel_uri = ""
    pdf_original_name = excel_original_name = ""
    pdf_size = excel_size = 0
    pdf_bytes = excel_bytes = b""

    cfg = get_settings()
    gcs = get_gcs_client(cfg)

    async def _stage_to_gcs(content: bytes, safe_name: str, mime: str) -> str:
        """Upload to a GCS _staging/{uuid}/ object and return its URI, or '' on failure/disabled."""
        if not gcs:
            return ""
        object_name = f"_staging/{uuid.uuid4().hex}/{safe_name}"
        try:
            blob = gcs.bucket(cfg.gcs_bucket).blob(object_name)
            loop = asyncio.get_event_loop()
            await loop.run_in_executor(
                None, lambda: blob.upload_from_string(content, content_type=mime)
            )
            return f"gs://{cfg.gcs_bucket}/{object_name}"
        except Exception as exc:
            log.warning("rfp_parser.staging_upload_failed", name=safe_name, error=str(exc))
            return ""

    async def _save_local(content: bytes, fname: str) -> str:
        async with aiofiles.open(UPLOADS_DIR / fname, "wb") as fh:
            await fh.write(content)
        return f"uploads/{fname}"

    if pdf:
        pdf_bytes = await pdf.read()
        pdf_original_name = pdf.filename or "rfp.pdf"
        pdf_size = len(pdf_bytes)
        if pdf_size > cfg.max_upload_bytes:
            raise HTTPException(
                status_code=413,
                detail=f"PDF exceeds {cfg.max_upload_bytes // (1024 * 1024)} MB limit "
                       f"({pdf_size // (1024 * 1024)} MB received)",
            )
        staging_pdf_uri = await _stage_to_gcs(pdf_bytes, "rfp.pdf", "application/pdf")
        if not staging_pdf_uri:
            temp_pdf_path = await _save_local(pdf_bytes, f"temp_{ts}_rfp.pdf")
        log.info("rfp_parser.staged_pdf", staging=bool(staging_pdf_uri),
                 local=temp_pdf_path, size=pdf_size)

    if excel:
        excel_bytes = await excel.read()
        excel_original_name = excel.filename or "items.xlsx"
        excel_size = len(excel_bytes)
        if excel_size > cfg.max_upload_bytes:
            raise HTTPException(
                status_code=413,
                detail=f"Excel exceeds {cfg.max_upload_bytes // (1024 * 1024)} MB limit "
                       f"({excel_size // (1024 * 1024)} MB received)",
            )
        ext = excel_original_name.rsplit(".", 1)[-1].lower() if "." in excel_original_name else "xlsx"
        mime_xl = ("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                   if ext == "xlsx" else "application/vnd.ms-excel")
        staging_excel_uri = await _stage_to_gcs(excel_bytes, f"items.{ext}", mime_xl)
        if not staging_excel_uri:
            temp_excel_path = await _save_local(excel_bytes, f"temp_{ts}_items.{ext}")
        log.info("rfp_parser.staged_excel", staging=bool(staging_excel_uri),
                 local=temp_excel_path, size=excel_size)

    suggested_bid_id = f"RFP-{uuid.uuid4().hex[:8]}"

    file_meta = {
        "tempPdfPath":       temp_pdf_path,
        "tempExcelPath":     temp_excel_path,
        "stagingPdfUri":     staging_pdf_uri,
        "stagingExcelUri":   staging_excel_uri,
        "pdfOriginalName":   pdf_original_name,
        "excelOriginalName": excel_original_name,
        "pdfSize":           pdf_size,
        "excelSize":         excel_size,
        "suggestedBidId":    suggested_bid_id,
    }

    if demo:
        return {**await _demo_response(line_items_repo), **file_meta}

    t0 = time.perf_counter()
    try:
        metadata, line_items_raw, supplier_targeting, warnings = await _run_extraction(
            pdf_bytes, excel_bytes, llm, cfg
        )
    except HTTPException:
        raise
    except Exception as exc:
        log.error("rfp_parser.ai_failed", error=str(exc))
        raise HTTPException(
            status_code=422,
            detail="AI parsing failed — the document may be too complex or unreadable. "
                   "Please check the file and try again.",
        ) from exc

    log.info("rfp_parser.done",
             customer=metadata.get("customer_name"),
             items=len(line_items_raw),
             total_ms=round((time.perf_counter() - t0) * 1000))

    # Surface LLM-detected file anomaly as a parsing warning (shown as yellow banner in BEX UI)
    fw = metadata.get("file_warning") if isinstance(metadata, dict) else None
    if fw:
        warnings.append(fw)

    return {
        "metadata":           metadata,
        "line_items":         line_items_raw,
        "supplier_targeting": supplier_targeting or {},
        "parsing_warnings":   warnings,
        **file_meta,
    }




# ── Helpers ───────────────────────────────────────────────────────────────────

async def _run_extraction(
    pdf_bytes: bytes,
    excel_bytes: bytes,
    llm: LLMService,
    cfg: Any,
) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any], list[str]]:
    """Hybrid extraction — deterministic Excel structurer + PDF LLM extraction.

    Returns (metadata_dict, line_items_raw, supplier_targeting, warnings).

    - Excel present → items from the deterministic structurer; metadata from the PDF (if any).
    - PDF only      → both metadata AND items from the PDF (tabular or free text).
    - Neither has extractable content → HTTP 422.
    """
    from services.excel_structurer import structure_excel
    from services.pdf_structurer import extract_pdf_structured

    warnings: list[str] = []
    metadata: dict[str, Any] = {}
    supplier_targeting: dict[str, Any] = {}
    line_items_raw: list[dict[str, Any]] = []

    excel_present = bool(excel_bytes)
    pdf_present = bool(pdf_bytes)

    pdf_result = await extract_pdf_structured(pdf_bytes, cfg.pdf_char_limit) if pdf_present else None
    pdf_text = pdf_result.text if pdf_result else ""

    if excel_present:
        # One upfront PDF call → bid metadata + a compact compliance context that rides
        # with each Excel chunk (so per-item compliance can be cross-referenced).
        compliance_context = ""
        if pdf_text:
            pdf_ctx = await _extract_pdf_context(llm, pdf_text)
            metadata = pdf_ctx.metadata.model_dump(mode="json")
            supplier_targeting = pdf_ctx.supplier_targeting or {}
            compliance_context = pdf_ctx.compliance_context or ""
        else:
            # Excel-only upload → sparse metadata (defaults; user fills the confirm form).
            metadata = BEXResponse().metadata.model_dump(mode="json")

        # LLM maps every field per row (incl. category + compliance) from chunks.
        excel_res = await structure_excel(excel_bytes, llm, compliance_context)
        line_items_raw = excel_res.items
        warnings.extend(excel_res.warnings)

    elif pdf_present:
        if not pdf_text:
            # Text PDFs only (product decision) — a scanned/image PDF yields nothing.
            raise HTTPException(
                status_code=422,
                detail="Could not extract text from the PDF. Scanned/image-only PDFs are not "
                       "supported — please upload a text-based PDF or an Excel item list.",
            )
        metadata, line_items_raw, supplier_targeting, pdf_warn = await _extract_from_pdf(pdf_result, llm)
        warnings.extend(pdf_warn)

    else:
        raise HTTPException(status_code=422, detail="Could not extract text from the uploaded file(s)")

    if isinstance(metadata, dict):
        metadata["total_items"] = len(line_items_raw)

    return metadata, line_items_raw, supplier_targeting, warnings


async def _bex_call(llm: LLMService, user: str, *, max_tokens: int) -> BEXResponse:
    """One BEX structured-output call."""
    return await llm.chat_structured(
        system=BEX_SYSTEM_PROMPT, user=user, schema=BEXResponse, max_tokens=max_tokens,
    )


async def _extract_from_pdf(
    pdf_result: Any,
    llm: LLMService,
) -> tuple[dict[str, Any], list[dict[str, Any]], dict[str, Any], list[str]]:
    """Extract metadata + line items from a PDF (items may be tabular OR free text).

    Single call for small PDFs; chunk by page + concurrent calls for large ones.
    """
    warnings: list[str] = []
    text = pdf_result.text
    if pdf_result.truncated:
        warnings.append("PDF was long — only the configured character limit was read.")

    if len(text) <= _PDF_SINGLE_CALL_LIMIT:
        user_msg = BEX_USER_PDF_WITH_ITEMS.format(pdf=text)
        bex = await _bex_call(llm, user_msg, max_tokens=get_settings().llm_max_tokens)
        items = [it.model_dump(mode="json") for it in bex.line_items]
        return bex.metadata.model_dump(mode="json"), items, bex.supplier_targeting or {}, warnings

    # Large → chunk by whole pages, run concurrently, merge; metadata from first chunk.
    chunks = _chunk_pages(pdf_result.pages, _PDF_CHUNK_SIZE)
    warnings.append(f"Large PDF processed in {len(chunks)} concurrent chunks.")
    chunk_msgs = [BEX_USER_PDF_WITH_ITEMS.format(pdf=c) for c in chunks]
    results = await asyncio.gather(
        *[_bex_call(llm, msg, max_tokens=get_settings().llm_max_tokens) for msg in chunk_msgs],
        return_exceptions=True,
    )
    metadata: dict[str, Any] = {}
    supplier_targeting: dict[str, Any] = {}
    items: list[dict[str, Any]] = []
    for res in results:
        if isinstance(res, Exception):
            warnings.append("One PDF chunk failed to parse.")
            continue
        if not metadata and res.metadata:
            metadata = res.metadata.model_dump(mode="json")
            supplier_targeting = res.supplier_targeting or {}
        items.extend(it.model_dump(mode="json") for it in res.line_items)
    if not metadata:
        metadata = BEXResponse().metadata.model_dump(mode="json")
    return metadata, items, supplier_targeting, warnings


def _chunk_pages(pages: list[str], chunk_size: int) -> list[str]:
    """Group whole pages into chunks each up to ~chunk_size characters."""
    chunks: list[str] = []
    cur: list[str] = []
    cur_len = 0
    for pg in pages:
        if cur and cur_len + len(pg) > chunk_size:
            chunks.append("\n\n".join(cur))
            cur, cur_len = [], 0
        cur.append(pg)
        cur_len += len(pg)
    if cur:
        chunks.append("\n\n".join(cur))
    return chunks or [""]


# ── PDF context extraction (metadata + compliance context) ──────────────────────

async def _extract_pdf_context(llm: LLMService, pdf_text: str) -> PdfContext:
    """One structured PDF call → bid metadata + a compact compliance context.

    The compliance context is threaded into each Excel chunk so the LLM can set per-item
    compliance flags by cross-referencing the RFP, without resending the whole PDF.
    """
    user_msg = f"RFP PDF CONTENT:\n{pdf_text}"
    return await llm.chat_structured(
        system=PDF_CONTEXT_EXTRACTION_SYSTEM,
        user=user_msg,
        schema=PdfContext,
        max_tokens=get_settings().llm_max_tokens,
    )

 
async def _read_source_bytes(ref: str) -> bytes:
    """Read bytes from a source reference — either a gs:// staging URI or a local uploads/ path."""
    if not ref:
        return b""
    if ref.startswith("gs://"):
        cfg = get_settings()
        gcs = get_gcs_client(cfg)
        if not gcs:
            return b""
        rest = ref[len("gs://"):]
        bucket_name, _, object_name = rest.partition("/")
        try:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(
                None, lambda: gcs.bucket(bucket_name).blob(object_name).download_as_bytes()
            )
        except Exception as exc:
            log.warning("rfp_parser.staging_download_failed", uri=ref, error=str(exc))
            return b""
    path = UPLOADS_DIR / ref.replace("uploads/", "", 1).replace("uploads\\", "", 1)
    return path.read_bytes() if path.exists() else b""




async def _demo_response(line_items_repo: LineItemsRepository) -> dict[str, Any]:
    """Return demo data when no file is uploaded or AI is unavailable."""
    all_items = await line_items_repo.load()
    demo_items = [it for it in all_items if it.get("bidId") == "B2600042"][:5]
    return {
        "metadata": {
            "bid_id": "DEMO-001",
            "customer_name": "Demo School District",
            "segment": "K-12",
            "opco_code": "016",
            "opco_name": "FoodCorp Boston",
            "region": "Northeast",
            "customer_due_date": None,
            "compliance_flags": ["Child Nutrition", "Buy American"],
            "total_items": len(demo_items),
            "parsing_confidence": 85,
        },
        "line_items": demo_items,
        "supplier_targeting": {},
        "parsing_warnings": ["Demo mode — upload a real RFP to parse"],
    }


