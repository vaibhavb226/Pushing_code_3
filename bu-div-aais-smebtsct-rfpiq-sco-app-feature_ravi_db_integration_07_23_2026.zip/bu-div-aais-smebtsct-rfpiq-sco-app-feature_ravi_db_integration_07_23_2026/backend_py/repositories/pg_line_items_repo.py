"""
PostgreSQL repository for rfp_line_items table.

Field renames (DB → app):
  rfp_id       → bidId
  bid_item     → bidItem
  line_number  → (not exposed in app dict)
  mpc_code     → mpcCode
  mfg_code     → mfgCode
  stk_type     → stkType
  buy_american → buyAmerican
  child_nutrition → childNutrition
  pfs_required → pfsRequired
  exact_spec   → exactSpec
  whole_grain  → wholeGrain
  halal        → halal
  kosher       → kosher
  rfp_populated → rfpPopulated
  source       → _source
  true_vendor  → trueVendor
  supplied_price → suppliedPrice
  price_case   → priceCase
  dev_type     → devType
  open_review  → openReview
  supplier_pricing → supplierPricing (JSONB array)

Extra methods:
  get_for_bid(bid_id)              — indexed by rfp_id
  smart_merge_pricing(id, pricing) — read-modify-write on supplier_pricing JSONB
"""
from __future__ import annotations

import json
from typing import Any

from repositories.pg_base import PgRepository


def _safe_list(val) -> list:
    """Return a list from a JSONB value.

    asyncpg decodes JSONB columns automatically via the registered codec.  If a
    previous write used json.dumps() before passing to asyncpg the value got
    double-encoded (array → JSON string); json.loads then decoded it back to a
    Python string.  This helper detects that case and re-parses, so corrupted
    rows self-heal on next read.
    """
    if val is None:
        return []
    if isinstance(val, list):
        return val
    if isinstance(val, str):
        try:
            parsed = json.loads(val)
            return parsed if isinstance(parsed, list) else []
        except Exception:
            return []
    return []


class PgLineItemsRepository(PgRepository):
    TABLE = "rfp_line_items"
    ORDER_BY = "line_number, bid_item"

    def _to_app(self, row) -> dict:
        d = dict(row)
        return {
            "id":               d["id"],
            "bidId":            d.get("rfp_id") or "",
            "bidItem":          d.get("bid_item") or "",
            "mpcCode":          d.get("mpc_code") or "",
            "mfgCode":          d.get("mfg_code") or "",
            "gtin":             d.get("gtin") or "",
            "subcategory":      d.get("subcategory") or "",
            "supc":             d.get("supc"),
            "brand":            d.get("brand") or "",
            "description":      d.get("description") or "",
            "pack":             d.get("pack") or "",
            "size":             d.get("size") or "",
            "unit":             d.get("unit") or "",
            "category":         d.get("category") or "",
            "qty":              d.get("qty") or 0,
            "storage":          d.get("storage") or "",
            "cw":               d.get("cw") or "N",
            "stkType":          d.get("stk_type") or "A",
            "buyAmerican":      bool(d.get("buy_american", False)),
            "childNutrition":   bool(d.get("child_nutrition", False)),
            "pfsRequired":      bool(d.get("pfs_required", False)),
            "exactSpec":        bool(d.get("exact_spec", False)),
            "wholeGrain":       bool(d.get("whole_grain", False)),
            "halal":            bool(d.get("halal", False)),
            "kosher":           bool(d.get("kosher", False)),
            "rfpPopulated":     bool(d.get("rfp_populated", True)),
            "_source":          d.get("source") or "",
            "trueVendor":       d.get("true_vendor"),
            "suppliedPrice":    d.get("supplied_price"),
            "allw":             d.get("allw"),
            "dl":               d.get("dl"),
            "priceCase":        d.get("price_case"),
            "devType":          d.get("dev_type"),
            "openReview":       bool(d.get("open_review", False)),
            "status":           d.get("status") or "No Response",
            "confidence":       d.get("confidence"),
            "supplierPricing":  _safe_list(d.get("supplier_pricing")),
        }

    def _to_db(self, item: dict) -> dict:
        bid_item = item.get("bidItem") or "0001"
        try:
            line_number = int(bid_item)
        except (ValueError, TypeError):
            line_number = 0
        return {
            "id":               item["id"],
            "rfp_id":           item.get("bidId") or "",
            "bid_item":         bid_item,
            "line_number":      line_number,
            "mpc_code":         item.get("mpcCode") or "",
            "mfg_code":         item.get("mfgCode") or "",
            "gtin":             item.get("gtin") or "",
            "subcategory":      item.get("subcategory") or "",
            "supc":             item.get("supc"),
            "brand":            item.get("brand") or "",
            "description":      item.get("description") or "",
            "pack":             item.get("pack") or "",
            "size":             item.get("size") or "",
            "unit":             item.get("unit") or "",
            "category":         item.get("category") or "",
            "qty":              item.get("qty") or 0,
            "storage":          item.get("storage") or "",
            "cw":               item.get("cw") or "N",
            "stk_type":         item.get("stkType") or "A",
            "buy_american":     bool(item.get("buyAmerican", False)),
            "child_nutrition":  bool(item.get("childNutrition", False)),
            "pfs_required":     bool(item.get("pfsRequired", False)),
            "exact_spec":       bool(item.get("exactSpec", False)),
            "whole_grain":      bool(item.get("wholeGrain", False)),
            "halal":            bool(item.get("halal", False)),
            "kosher":           bool(item.get("kosher", False)),
            "rfp_populated":    bool(item.get("rfpPopulated", True)),
            "source":           item.get("_source") or "",
            "true_vendor":      item.get("trueVendor"),
            "supplied_price":   item.get("suppliedPrice"),
            "allw":             item.get("allw"),
            "dl":               item.get("dl"),
            "price_case":       item.get("priceCase"),
            "dev_type":         item.get("devType"),
            "open_review":      bool(item.get("openReview", False)),
            "status":           item.get("status") or "No Response",
            "confidence":       item.get("confidence"),
            "supplier_pricing": item.get("supplierPricing") or [],
        }

    async def _insert_returning(self, conn, item: dict):
        d = item if "rfp_id" in item else self._to_db(item)
        return await conn.fetchrow(
            """
            INSERT INTO rfp_line_items (
                id, rfp_id,
                bid_item, line_number, mpc_code, mfg_code, gtin, subcategory, supc,
                brand, description, pack, size, unit, category,
                qty, storage, cw, stk_type,
                buy_american, child_nutrition, pfs_required, exact_spec,
                whole_grain, halal, kosher,
                rfp_populated, source,
                true_vendor, supplied_price, allw, dl, price_case, dev_type,
                open_review, status, confidence, supplier_pricing
            ) VALUES (
                $1,  $2,
                $3,  $4,  $5,  $6,  $7,  $8,  $9,
                $10, $11, $12, $13, $14, $15,
                $16, $17, $18, $19,
                $20, $21, $22, $23,
                $24, $25, $26,
                $27, $28,
                $29, $30, $31, $32, $33, $34,
                $35, $36, $37, $38::jsonb
            )
            RETURNING *
            """,
            d["id"], d["rfp_id"],
            d["bid_item"], d["line_number"], d["mpc_code"], d["mfg_code"],
            d["gtin"], d["subcategory"], d["supc"],
            d["brand"], d["description"], d["pack"], d["size"], d["unit"], d["category"],
            d["qty"], d["storage"], d["cw"], d["stk_type"],
            d["buy_american"], d["child_nutrition"], d["pfs_required"], d["exact_spec"],
            d["whole_grain"], d["halal"], d["kosher"],
            d["rfp_populated"], d["source"],
            d["true_vendor"], d["supplied_price"], d["allw"], d["dl"],
            d["price_case"], d["dev_type"],
            d["open_review"], d["status"], d["confidence"], d["supplier_pricing"],
        )

    async def append(self, item: dict) -> dict:
        db = self._to_db(item)
        async with self._pool().acquire() as conn:
            row = await self._insert_returning(conn, db)
        return self._to_app(row) if row else item

    async def append_many(self, records: list[dict]) -> None:
        """Insert N line items in a single connection acquire + executemany."""
        if not records:
            return
        args = [
            (
                d["id"], d["rfp_id"],
                d["bid_item"], d["line_number"], d["mpc_code"], d["mfg_code"],
                d["gtin"], d["subcategory"], d["supc"],
                d["brand"], d["description"], d["pack"], d["size"], d["unit"], d["category"],
                d["qty"], d["storage"], d["cw"], d["stk_type"],
                d["buy_american"], d["child_nutrition"], d["pfs_required"], d["exact_spec"],
                d["whole_grain"], d["halal"], d["kosher"],
                d["rfp_populated"], d["source"],
                d["true_vendor"], d["supplied_price"], d["allw"], d["dl"],
                d["price_case"], d["dev_type"],
                d["open_review"], d["status"], d["confidence"], d["supplier_pricing"],
            )
            for d in [self._to_db(r) for r in records]
        ]
        async with self._pool().acquire() as conn:
            await conn.executemany(
                """
                INSERT INTO rfp_line_items (
                    id, rfp_id,
                    bid_item, line_number, mpc_code, mfg_code, gtin, subcategory, supc,
                    brand, description, pack, size, unit, category,
                    qty, storage, cw, stk_type,
                    buy_american, child_nutrition, pfs_required, exact_spec,
                    whole_grain, halal, kosher,
                    rfp_populated, source,
                    true_vendor, supplied_price, allw, dl, price_case, dev_type,
                    open_review, status, confidence, supplier_pricing
                ) VALUES (
                    $1,  $2,
                    $3,  $4,  $5,  $6,  $7,  $8,  $9,
                    $10, $11, $12, $13, $14, $15,
                    $16, $17, $18, $19,
                    $20, $21, $22, $23,
                    $24, $25, $26,
                    $27, $28,
                    $29, $30, $31, $32, $33, $34,
                    $35, $36, $37, $38::jsonb
                )
                ON CONFLICT (id) DO NOTHING
                """,
                args,
            )

    async def _update_in_place(self, conn, updated: dict) -> None:
        d = self._to_db(updated)
        await conn.execute(
            """
            UPDATE rfp_line_items SET
                rfp_id          = $2,
                bid_item        = $3,
                line_number     = $4,
                mpc_code        = $5,
                mfg_code        = $6,
                gtin            = $7,
                subcategory     = $8,
                supc            = $9,
                brand           = $10,
                description     = $11,
                pack            = $12,
                size            = $13,
                unit            = $14,
                category        = $15,
                qty             = $16,
                storage         = $17,
                cw              = $18,
                stk_type        = $19,
                buy_american    = $20,
                child_nutrition = $21,
                pfs_required    = $22,
                exact_spec      = $23,
                whole_grain     = $24,
                halal           = $25,
                kosher          = $26,
                rfp_populated   = $27,
                source          = $28,
                true_vendor     = $29,
                supplied_price  = $30,
                allw            = $31,
                dl              = $32,
                price_case      = $33,
                dev_type        = $34,
                open_review     = $35,
                status          = $36,
                confidence      = $37,
                supplier_pricing= $38::jsonb,
                updated_at      = now()
            WHERE id = $1
            """,
            d["id"], d["rfp_id"],
            d["bid_item"], d["line_number"], d["mpc_code"], d["mfg_code"],
            d["gtin"], d["subcategory"], d["supc"],
            d["brand"], d["description"], d["pack"], d["size"], d["unit"], d["category"],
            d["qty"], d["storage"], d["cw"], d["stk_type"],
            d["buy_american"], d["child_nutrition"], d["pfs_required"], d["exact_spec"],
            d["whole_grain"], d["halal"], d["kosher"],
            d["rfp_populated"], d["source"],
            d["true_vendor"], d["supplied_price"], d["allw"], d["dl"],
            d["price_case"], d["dev_type"],
            d["open_review"], d["status"], d["confidence"], d["supplier_pricing"],
        )

    # ── Extra methods ─────────────────────────────────────────────────────────

    async def get_for_bid(self, bid_id: str) -> list[dict]:
        async with self._pool().acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM rfp_line_items WHERE rfp_id = $1 ORDER BY line_number, bid_item",
                bid_id,
            )
        return [self._to_app(r) for r in rows]

    async def update_by_id(self, line_id: str, updater) -> dict | None:
        """Update one line item by PK — avoids full table scan.

        Uses SELECT … FOR UPDATE inside a transaction so concurrent updates on
        the same row serialize instead of racing on a stale snapshot.
        """
        async with self._pool().acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT * FROM rfp_line_items WHERE id = $1 FOR UPDATE", line_id
                )
                if row is None:
                    return None
                updated = updater(self._to_app(row))
                await self._update_in_place(conn, updated)
        return updated

    async def delete_by_id(self, line_id: str, bid_id: str) -> int:
        """Delete one line item by PK + rfp_id guard — avoids full table scan."""
        async with self._pool().acquire() as conn:
            result = await conn.execute(
                "DELETE FROM rfp_line_items WHERE id = $1 AND rfp_id = $2",
                line_id, bid_id,
            )
        return int(result.split()[-1])

    async def delete_for_bid(self, bid_id: str) -> int:
        """Delete all line items for a bid — single targeted DELETE instead of full scan."""
        async with self._pool().acquire() as conn:
            result = await conn.execute(
                "DELETE FROM rfp_line_items WHERE rfp_id = $1", bid_id
            )
        return int(result.split()[-1])

    @staticmethod
    def _merge_pricing(existing: list, new_pricing: list[dict]) -> list:
        """Merge new_pricing into existing supplier_pricing without duplicating entries."""
        for ne in new_pricing:
            if not isinstance(ne, dict):
                continue
            nn = ne.get("supplierName", "")
            ni = ne.get("supplierItemNo", "")
            neid = ne.get("emailId", "")
            dup_idx = next(
                (
                    i for i, e in enumerate(existing)
                    if isinstance(e, dict)
                    and e.get("supplierName") == nn
                    and (
                        (ni and e.get("supplierItemNo") and e.get("supplierItemNo") == ni)
                        or (not ni and not e.get("supplierItemNo") and neid and e.get("emailId") == neid)
                    )
                ),
                None,
            )
            if dup_idx is not None:
                existing[dup_idx] = {**existing[dup_idx], **ne}
            else:
                existing.append(ne)
        return existing

    async def update_with_pricing(
        self, line_id: str, updater, new_pricing: list[dict[str, Any]]
    ) -> dict[str, Any] | None:
        """Update fields + merge supplier pricing — one transaction, one pool acquire, 2 RT.

        Replaces the separate update_by_id + smart_merge_pricing calls that used
        3 pool acquires and 4 round-trips per item. With 20 concurrent saves and a
        10-connection pool this cuts total time from ~8 s to ~1.3 s.
        """
        async with self._pool().acquire() as conn:
            async with conn.transaction():
                row = await conn.fetchrow(
                    "SELECT * FROM rfp_line_items WHERE id = $1 FOR UPDATE", line_id
                )
                if row is None:
                    return None
                item = self._to_app(row)
                updated = updater(item)
                updated["supplierPricing"] = self._merge_pricing(
                    _safe_list(updated.get("supplierPricing")), new_pricing
                )
                await self._update_in_place(conn, updated)
        return updated

    async def smart_merge_pricing(
        self, line_id: str, new_pricing: list[dict[str, Any]]
    ) -> dict[str, Any] | None:
        """
        Merge new_pricing into supplier_pricing JSONB without duplicating entries.

        Deduplication rules (mirrors JsonRepository.LineItemsRepository):
        1. Both entries have supplierItemNo → match on supplierName + supplierItemNo.
        2. Neither has supplierItemNo → match on supplierName + emailId.
        """
        async with self._pool().acquire() as conn:
            row = await conn.fetchrow(
                "SELECT * FROM rfp_line_items WHERE id = $1", line_id
            )
        if row is None:
            return None

        item = self._to_app(row)
        existing: list[dict] = _safe_list(item.get("supplierPricing"))
        existing = self._merge_pricing(existing, new_pricing)

        async with self._pool().acquire() as conn:
            await conn.execute(
                "UPDATE rfp_line_items SET supplier_pricing = $1::jsonb, updated_at = now() WHERE id = $2",
                existing, line_id,
            )
        item["supplierPricing"] = existing
        return item
