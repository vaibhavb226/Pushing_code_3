# Python Backend — Architecture & Deployment

## Key Architectural Patterns

### Real-Time Collaboration — PostgreSQL LISTEN/NOTIFY + SSE

Why: Multiple Bid COE users editing the same bid needed live updates without page refresh. PostgreSQL LISTEN/NOTIFY is used as the cross-process/cross-instance broker instead of Redis — no new infrastructure, already deployed.

**`backend_py/services/sse_broadcast.py`** — Per-bid asyncio.Queue registry (in-process fan-out) + global user location registry
- `subscribe(bid_id, user_name) → asyncio.Queue` — creates a queue, stores `user_name` on the queue object
- `unsubscribe(bid_id, q)` — removes from registry; cleans up empty bid entries
- `push(bid_id, event)` — non-blocking `put_nowait`; drops silently if a slow client's queue is full (maxsize=64)
- `get_viewers(bid_id) → list[str]` — returns user names of all connected SSE clients for a bid
- `update_user_location(name, bid_id, tab, cell_id)` — upserts `_user_locations[name]` dict with `lastSeen=time.time()`
- `get_online_users(max_age=60.0) → list[dict]` — returns users seen within the TTL window
- `cleanup_stale_users(max_age=60.0) → int` — evicts stale entries; called every 30s from `main.py` cleanup task

**`backend_py/routers/presence.py`** — Global presence REST endpoints (no SSE stream — REST poll is sufficient for global state)
- `POST /api/presence/update` — accepts `{name, bidId, tab, cellId?}`; calls `update_user_location`; if `bidId` is set, fires `pg_notify` with `{type:"presence_tab", bidId, user, tab, cellId}` so SSE clients watching that bid see tab/cell changes immediately
- `GET /api/presence` — returns `{users: get_online_users()}` (60s TTL filter applied inline)
- Frontend polls this every 30s for the sidebar online panel; does NOT open a second SSE stream

**`backend_py/services/pg_listener.py`** — Dedicated long-lived `asyncpg.connect()` (NOT from the CRUD pool)
- Holds `LISTEN bid_events` for the process lifetime
- Auto-reconnects on any exception (5s backoff); loop exits only on `CancelledError`
- `_on_notify(conn, pid, channel, payload)` — sync callback: parses JSON → extracts `bidId` → calls `push()`
- `start_pg_listener(settings) → asyncio.Task` — called once in `main.py` lifespan after the CRUD pool .is created, guarded by `if pg_pool:` so it's skipped in local JSON dev mode

**`GET /api/bids/{bid_id}/stream`** (in `routers/bids.py`) — SSE endpoint
- **Must be declared BEFORE `GET /{bid_id}`** in the router — FastAPI matches literal-first and "stream" would match as a bid_id otherwise
- Returns `StreamingResponse(generator(), media_type="text/event-stream")`
- Headers: `Cache-Control: no-cache`, `X-Accel-Buffering: no` (disables nginx response buffering)
- On connect: sends immediate `{type:"viewers", viewers:[...]}` frame + announces `presence.joined` via `_notify_bid`
- Keeps-alive: 25s `asyncio.wait_for` timeout → sends SSE comment `: keepalive\n\n` to prevent nginx/CDN timeout
- On disconnect (generator `finally`): `unsubscribe` + announces `presence.left` via `_notify_bid`

**`_notify_bid(bid_id, event)`** — fire-and-forget `pg_notify` helper
- Acquires from CRUD pool, executes `SELECT pg_notify('bid_events', $1::text)`
- All callers use `asyncio.ensure_future(_notify_bid(...))` — never blocks the mutation HTTP response
- Fires on: `update_bid`, `update_line_item`, `delete_line_item`, `create_bid_email`, `override_supplier_status`
- Returns silently if pool is None (local JSON dev mode)

**Event payload shapes:**
```
{type:"bid_updated",       bidId, fields}
{type:"line_item_updated", bidId, lineId, fields}   # fields includes supplierPricing when present
{type:"line_item_deleted", bidId, lineId}
{type:"email_sent",        bidId}
{type:"presence_tab",      bidId, user, tab, cellId}  # fired by presence.py on POST /update
{type:"supplier_updated",  bidId, supplierId, status}
{type:"presence",          bidId, action:"joined"|"left", user}
{type:"viewers",           bidId, viewers:[...]}
```

**Multi-instance behaviour:** Each Cloud Run instance runs its own `pg_listener.py`. PostgreSQL delivers NOTIFY to all LISTEN sessions simultaneously — each instance fans out to its own connected SSE clients. Works correctly with no coordination layer.

### Repository Backend — Dual-mode (asyncpg PG or JSON flat-file)

The app supports two storage backends selected at startup via `settings.db_host`:

| `DB_HOST` set? | Backend | Write safety |
|---|---|---|
| Yes | asyncpg PostgreSQL pool | DB transactions + pool concurrency |
| No | JSON flat-file (local dev) | Per-file `asyncio.Lock` |

**`dependencies.py`** — each `get_*_repo()` factory checks `get_settings().db_host`:
```python
def get_bids_repo():
    if get_settings().db_host:
        from repositories.pg_bids_repo import PgBidsRepository
        return PgBidsRepository()
    return _bids   # JSON singleton fallback
```
PG repo instances are stateless (pool is the singleton) — new instance per request is cheap.

**AbstractRepository interface** (6 methods, both backends implement):
`load()`, `save()`, `find_one()`, `update_one()`, `append()`, `delete_where()`

**PG repos** live in `repositories/pg_*.py`. `save()` raises `NotImplementedError` in all PG repos except `pg_unmatched_emails_repo` (which implements it as UPSERT ON CONFLICT).

### PostgreSQL Connection — Two Separate Pools

`db/connection.py` holds two independent pools:
1. **asyncpg pool** (`_pg_pool`) — used by all CRUD repos. Created at startup via `create_asyncpg_pool(settings)`. Registered JSON/JSONB codecs in `_init_connection` auto-encode/decode Python dicts/lists.
2. **SQLAlchemy AsyncEngine** (`_engine`) — used exclusively by `vector_repo.py` (pgvector ANN search). Not used by any CRUD repo.

Pool config: `min_size=2, max_size=10, ssl="require", command_timeout=30`.

### Field-Name Mapping Layer (DB ↔ App)

Every PG repo has `_to_app(row)` and `_to_db(item)` methods that translate between DB snake_case and app camelCase. Critical renames:

| DB column | App key |
|---|---|
| `rfp_id` | `bidId` |
| `from_address` | `from` |
| `to_address` | `to` |
| `bcc_addresses` | `bcc` |
| `email_date` | `date` |
| `bounce_info` | `bounceDetails` |
| `message_id` | `messageId` |
| `auto_matched` | `autoMatched` |
| `contact_email` | `contact` |
| `original_recipient` | `originalRecipient` |
| `graph_internet_message_id` | `graphInternetMessageId` |

`document_vectors.bid_id` stays as `bid_id` — used only in `vector_repo.py`, never in CRUD repos.

### solicitedSuppliers — Two-Query Join in PgBidsRepository

`bids["solicitedSuppliers"]` is a junction table (`rfp_solicited_suppliers`) in DB. `pg_bids_repo.load()` fetches both `rfps` and `rfp_solicited_suppliers` in two parallel queries via `asyncio.gather` (two separate pool connections), then stitches by `rfp_id` using a `defaultdict`. Zero N+1 queries regardless of bid count. Both queries run concurrently — wall-clock ≈ 1 round-trip instead of 2.

**Single-bid fast path:** `find_by_id(bid_id)` and `update_by_id(bid_id, updater)` do targeted `WHERE id = $1` queries on both tables — avoids a full table scan for the common case. `find_by_id` also runs its two targeted queries in parallel via `asyncio.gather`. All `bids_repo.find_one(lambda b: b.get("id") == bid_id)` and `update_one(lambda b: b.get("id") == bid_id, ...)` call sites were replaced with `find_by_id` / `update_by_id`. The Email Repo tab polls every 15 s — without this optimization every poll loaded the entire `rfps` + `rfp_solicited_suppliers` tables.

**Line item fast path:** `PgLineItemsRepository` exposes `update_by_id(line_id, updater)` (SELECT FOR UPDATE + UPDATE by PK), `update_with_pricing(line_id, updater, new_pricing)` (combined field update + pricing merge in one transaction — 1 pool acquire / 2 RT instead of 3 acquires / 4 RT), `delete_by_id(line_id, bid_id)` and `delete_for_bid(bid_id)`. These are also defined on the JSON base `LineItemsRepository` as load+filter fallbacks. The `PATCH /line-items/{line_id}` router calls `update_with_pricing` when `supplierPricing` is present (pricing extraction save), and `update_by_id` otherwise. Do not revert to `update_one(lambda x: x.get("id") == id)` which loads the entire rfp_line_items table.

**Customer fast path:** `PgCustomersRepository` exposes `update_by_id(customer_id, updater)` and `delete_by_id(customer_id)`. `customers.py` uses these directly — never `update_one`/`delete_where`.

**Email poller bid list:** `run_poll()` calls `bids_repo.load()` on every cycle to get a fresh bid list. There is no cache — caching would cause manual `poll-now` refreshes (and the automatic loop) to match against stale bid data, missing newly created bids. `bids_repo.load()` runs two parallel queries (~330ms total), which is acceptable at a 15-minute poll interval. Empty inbox cycles skip the `_save_poll_state` write — the mark only advances when messages are actually processed.

**`get_emails_by_supplier` parallel reads:** `bids_repo.find_by_id(bid_id)` and `email_threads_repo.get_for_bid(bid_id)` run concurrently via `asyncio.gather` — both only need `bid_id` and are independent. `get_broker_flags` stays sequential after (needs `solicited` from the bid result). Broker lookup uses `suppliers_repo.get_broker_flags(ids)` (2-column targeted query on `PgSuppliersRepository`) — fetches only `id, broker` for the supplier IDs in the bid instead of loading the full suppliers table.

**Batch email_threads INSERT:** `PgEmailThreadsRepository.append_many(records)` inserts N records via a single `executemany` call inside one pool connection acquire — one DB round-trip instead of N. `JsonRepository.append_many` reads+extends+writes under one file lock. Used by: `create_bid_email` (BCC solicitation loop in `bids.py`) and bounce fan-out in `email_poller._handle_matched`. The single `append()` method is unchanged and still used for non-batch paths.

**Bulk `graphInternetMessageId` update:** `PgEmailThreadsRepository.update_graph_message_ids(record_ids, graph_id)` issues one `UPDATE ... WHERE id = ANY($ids)` — replaces the old N×(full-scan+UPDATE) loop in `_send_and_flag`. `EmailThreadsRepository.update_graph_message_ids` (JSON) does load+patch+write under one file lock. Used by: `_send_and_flag` in `bids.py` (BCC solicitation background task) and the portal-reply path. Do NOT revert to `update_one` loop — that was 21 × full table scan (SELECT * FROM email_threads) per solicitation, and the updates were no-ops because `graphInternetMessageId` was missing from `_to_db`.

**`add_solicited_suppliers` on `PgBidsRepository`:** Add-only solicitation update — 2 round-trips instead of the 5-round-trip `update_by_id` transaction. Does `UPDATE rfps SET last_solicitation_date` + `executemany INSERT INTO rfp_solicited_suppliers ON CONFLICT DO NOTHING`. Used by `_update_solicited_suppliers` in `bids.py` via `hasattr` check; JSON fallback uses `update_by_id`. `_update_solicited_suppliers` now returns `list[dict]` (resolved `{supplierId, supplierName, email}` for all BCC emails) so `create_bid_email` can skip the subsequent `find_one`/`find_by_id` DB call entirely.

**`create_bid_email` parallel entry reads:** `bids_repo.find_by_id(bid_id)` and `email_threads_repo.get_for_bid(bid_id)` run concurrently via `asyncio.gather` at the start of the function. Pre-fetched emails passed to `_get_last_internet_message_id` via `_prefetched_emails` param — no second round-trip. `_get_last_internet_message_id` still works as before for other callers that don't pre-fetch (auto_reminder, award email).

**Batch rfp_line_items INSERT:** `PgLineItemsRepository.append_many(records)` — same `executemany` pattern as email_threads. Used by all three line-item write paths: `bids.py` (POST /api/bids), `rfp_parser.py` (POST /api/bids re-parse), and `line_item_parser.py` (email attachment parser). All three do `delete_for_bid(bid_id)` then `append_many(items)` — a typical RFP has 50–150 items, so this reduces 50–150 sequential round-trips to one.

**`unmatched_emails` load LIMIT:** `PgUnmatchedEmailsRepository.load()` is overridden to return the 500 most recent records (`ORDER BY received_at DESC LIMIT 500`). The poller only needs a recent window for UID dedup. `save()` will then cap the table to ~500 records over time — sufficient for investigation.

`update_one()` for bids: DELETE all `rfp_solicited_suppliers` for the bid, then re-INSERT the updated list. Simple, correct, avoids complex UPSERT ID tracking. Why: the `rfp_solicited_suppliers` row IDs (e.g. `RSS-{bid_id}-001`) are internal — no external code references them by ID.

### Concurrent Write Safety (JSON fallback)
`repositories/base.py` — module-level `dict[Path, asyncio.Lock]`. Every JSON file op acquires the lock for that path. Reads with `encoding="utf-8-sig"` (handles PowerShell-generated BOM files).

### FastAPI Route Ordering
`GET /api/bids/portal-templates` declared **before** `GET /api/bids/{bid_id}` in `routers/bids.py`. FastAPI matches in declaration order.

### Secrets — Never Logged
All credentials are `pydantic.SecretStr`. `.get_secret_value()` only at point of use.

### Background Tasks at Startup
Four backfill coroutines + demo data injector run via `asyncio.create_task()` during lifespan startup. Non-blocking.

### Dependency Injection
`dependencies.py` — repo + service singletons injected via `Depends()`. GCS client: `get_gcs_client(settings)` returns `None` when `GCS_BUCKET` unset (safe for local dev).

## Inbox Poller Details

- **Single-instance requirement:** poller MUST run on one instance only — JSON files are per-instance
- **Single-flight:** `asyncio.Lock` prevents overlap between 15s loop and `GET /api/email/poll-now`
- **Tier-1 early-return:** if bid ID pattern matched in subject but bid doesn't exist → write to `unmatchedEmails` immediately, do NOT fall through to tier 3 (prevents mis-matching NDRs to wrong bids)
- **Bounce fan-out:** one record per affected supplier; body excerpted to per-recipient paragraph via `_extract_recipient_block()`
- **`_parse_bounce` returns:** `{ bounceCode, bounceReason, recipients, originalRecipient }` — if this function returns None, bounce fan-out crashes. Structure: return dict is at end of `_parse_bounce`, NOT inside `_extract_recipient_block`.
- **Bounce DSN permanent fix:** `_handle_matched()` fetches raw MIME via `email_service.fetch_raw_mime(msg.uid)` → `GET /messages/{id}/$value` → `_parse_dsn_mime()` extracts per-recipient `Diagnostic-Code` from `message/delivery-status` MIME part (RFC 3464). Each supplier's bounce `body` is their own diagnostic only. Falls back to `_parse_bounce()` regex text parse if `$value` is unavailable. `_extract_recipient_block()` regex also fixed for CRLF endings: `re.split(r"(?:\r?\n){2,}", body)` instead of `r"\n{2,}"`.

## Supplier Auto-Populate Scoring

`POST /api/suppliers/auto-populate` → `_score_supplier()` in `routers/suppliers.py`:
1. Category gate (hard fail) — must match needed category + "Broker" always included
2. Compliance — 50 pts — only bid's required flags count; extra supplier certs don't penalize
3. Segment — 30 pts — binary if supplier serves bid's segment or "All"
4. TF-IDF — 20 pts — IDF-weighted token overlap (rare tokens like "halal"/"k-12" outweigh "food")

## GCS Integration (b29ef9e8)

**EmailComposer.jsx** reads `bid.uploadedFiles[].path` (which stores `gs://` URIs for modern bids):
```js
const attachableTypes = new Set(['RFP Document', 'RFP', 'Item List'])
const attachments = bid.uploadedFiles?.length
  ? bid.uploadedFiles.filter(f => attachableTypes.has(f.type) && f.path).map(f => f.path)
  : [bid.uploadedRfpPath, bid.uploadedItemListPath].filter(Boolean)
```

**`create_bid_email` in `bids.py`** passes `gs://` URIs through directly:
```python
if a.startswith("gs://"):
    attachment_paths.append(a)    # _build_attachments handles download
else:
    full_path = UPLOADS_DIR / Path(a).name  # local path fallback
```

**`_build_attachments`** is `async def` — handles both local paths and `gs://` URIs via `run_in_executor`.

**`_download_attachments`** (inbound poller) dual-writes: local disk + `inbound/{saved_name}` in GCS.

**`submissions.py:post_message`** dual-writes portal message attachments: local + `{bidId}/PortalMsg/{fname}` in GCS.

**`files.py`** GCS fallback: local disk first → if missing, proxy from `inbound/{safe_filename}` in GCS.

## Pricing Extraction

`POST /api/bids/{bid_id}/emails/{email_id}/extract-pricing` (in `routers/bids.py`):
- PDF extraction via `fitz` (PyMuPDF)
- `_normalize_pricing_items()` + `_backend_confidence()`: fuzzy description overlap ≥ 0.2 for fallback match; confidence blend 60%/40% (LLM/fuzzy); base score +10 for any match; word-length floor >2 chars
- `max_tokens=16384` for pricing extraction — prevents truncation on large sheets
- `analysisResult` on email record is for display only — does NOT affect supplier status in `solicitedSuppliers`
- **Confidence thresholds (unified 3-tier):** `_score_to_label()` maps scores to `high` (≥70), `medium` (40–69), `low` (0–39). The old 4-tier system (80/50/20/none) was replaced. Do not revert — the frontend (WorkingFileTab badge, PricingExtractModal) uses the same 70/40 thresholds.
- **Extraction LLM uses determinism settings:** `temperature=0`, `top_p=1`, `top_k=1`, `seed` (Vertex AI only, optional via `LLM_EXTRACTION_SEED` env var). Configured in `config.py` under `llm_extraction_*` fields. These settings apply only to pricing extraction — the chat AIQ still uses `temperature=0.1`. Do not change the extraction defaults — variability causes inconsistent confidence scores across runs.
- **Confidence scoring rubric is binary/additive:** The prompt instructs the LLM to score using exact binary rules (each criterion either fires or not — no partial credit). This removes LLM discretion over the numeric value and makes scores more reproducible. Do not revert to "give partial credit generously" wording.
- **All items extracted including null-price rows** — items with missing prices are included with price fields null; `notes` field explains why (e.g. "Pending commodity pricing").
- **Column identification is semantic, not name-based** — extraction rules describe the *meaning* of each field (e.g. "final all-in delivered price") so any supplier's column naming convention works; do NOT hardcode specific column names in the prompt (column names vary per supplier — "Delivered Case pr" vs "Net/Case" vs "Net Price" are all the same thing)
- `description` in extracted output shows the matched RFP item description (intentional — supplier's internal codes like "SFS CHO CHG & VEG WHL-WHT OMP 2 SL 400" are not user-readable); `matchedBidDescription` and `matchedBidItemNo` are the match fields
- **Do NOT add `deliveredPrice`, `fobPrice`, `allowance`, `devType` back to the schema** — these were in an early Python port but not in the working Node.js version; the LLM hallucinates values for named schema fields even when the column doesn't exist in the document
- **Large Excel scalability:** row-chunked extraction when `len(doc_text) > 45_000` — splits into 100-row chunks with header prepended, runs in parallel via `asyncio.gather`, merges by `matchedBidItemNo` (highest confidence wins per bid item). Prevents silent truncation at ~90 rows.
- **`.xls` support:** `_extract_excel()` in `document_text.py` tries `openpyxl` first, falls back to `xlrd` for old binary XLS format. `xlrd==2.0.2` in `requirements.txt`.
- **`pdf_char_limit` now applied:** `_extract_pdf()` in `document_text.py` reads `get_settings().pdf_char_limit` and truncates if set (was declared but never read).
- **Multi-file extraction:** `?files=filename1&files=filename2` query param on extract endpoint — each file extracted in parallel via `asyncio.gather`, items tagged with `sourceFile`, results concatenated. Response includes `multiFile: true, fileCount: N`.

## Key Backend File Locations

### Repository layer
| File | Table(s) | Notes |
|---|---|---|
| `repositories/base.py` | — | `AbstractRepository` ABC + `JsonRepository` implementation |
| `repositories/pg_base.py` | — | `PgRepository` base + `_str_date/_str_dt/_dt/_dt_flex/_js/_jo` helpers |
| `repositories/pg_bids_repo.py` | `rfps` + `rfp_solicited_suppliers` | Two-query load, delete+re-insert for SS updates |
| `repositories/pg_email_threads_repo.py` | `email_threads` | `get_for_bid()`, `find_by_uid()` |
| `repositories/pg_suppliers_repo.py` | `suppliers` | `contact_email` → `contact` rename |
| `repositories/pg_documents_repo.py` | `documents` | |
| `repositories/pg_portal_templates_repo.py` | `portal_templates` | `label`/`segment` dual-write |
| `repositories/pg_line_items_repo.py` | `rfp_line_items` | `get_for_bid()`, `smart_merge_pricing()` |
| `repositories/pg_submissions_repo.py` | `bids` + `bid_line_items` + `submission_messages` | Custom interface (not AbstractRepository); `upsert_from_extraction(bid_id, submission)` for email extractions |
| `repositories/pg_unmatched_emails_repo.py` | `unmatched_emails` | `save()` as UPSERT ON CONFLICT |
| `db/connection.py` | — | `create_asyncpg_pool()`, `get_asyncpg_pool()`, SQLAlchemy engine |
| `dependencies.py` | — | `get_*_repo()` factories — PG if `db_host` set, JSON singleton otherwise |

### Services / routing
- Chat AIQ endpoint: `backend_py/routers/ai_chat.py` — `chat()` function, `max_tokens` param on `llm.chat_with_history()`
- Pricing extraction: `backend_py/routers/bids.py` — `_extract_generic_pricing()`, `_normalize_pricing_items()`, `_backend_confidence()`
- All LLM prompts: `backend_py/routers/prompts.py` — `PRICING_EXTRACTION_SYSTEM`, `BEX_SYSTEM_PROMPT`, `EXTRACT_PROMPT`, `RFPAIQ_IDENTITY`
- LLM provider implementations: `backend_py/services/llm/provider.py` — `_vertex_direct()`, `_anthropic_direct()`
- Email service: `backend_py/services/email/msgraph_provider.py` — `_build_attachments()`, `_download_attachments()`
- Email service factory: `backend_py/services/email/factory.py`
- Email poller: `backend_py/services/email_poller.py` — `_detect_bounce()`, `_parse_bounce()`, `_bounce_updater()`
- `get_emails_by_supplier()` (by-supplier endpoint): `backend_py/routers/bids.py`

### Document Embedding Pipeline (live)

**Trigger:** `asyncio.ensure_future(index_document_background(doc_record, gcs_client, settings))` is called:
- In `bids.py` (`POST /api/bids`) after the parallel `asyncio.gather(*writes)` — one call per uploaded file
- In `documents.py` (`POST /api/documents/upload`) after `repo.append(doc_record)`
- Both guards check `settings.db_host` — skips silently in local JSON dev mode

**Pipeline (all in `services/document_indexer.py`):**
1. Read content from `filePath` (gs:// via `blob.download_as_bytes` or local path)
2. `extract_full_text(content, suffix=...)` — fitz/openpyxl without `pdf_char_limit` (full text for indexing)
3. **Branch on file extension** — `.xlsx`/`.xls` → `chunk_excel_text()`; all other types → `chunk_text()`
4. `embed_texts(batch, task_type="RETRIEVAL_DOCUMENT", settings)` in slices of 20
5. `vector_repo.upsert_document_chunks(conn, doc_id, rows)` — DELETE old chunks + INSERT new

**Generic chunker — `chunk_text()` (`services/document_chunker.py`):** For PDFs and all non-Excel files.
- Separator hierarchy: `\n\n` → `\n` → ` ` → char (paragraph-first preserves semantic units)
- Merges small atoms greedily; overlap=150 chars carries tail of previous chunk as context prefix
- Prepends `[Bid: X | Type: Y | Src: Z | Chunk n/N]` header to each chunk for provenance
- Chunks < 50 chars discarded

**Excel chunker — `chunk_excel_text()` (`services/document_chunker.py`):** For `.xlsx`/`.xls` files only.
- Why: the generic chunker's `re.sub(r"[ \t]+", " ", text)` (line 121) destroys tab-delimited column structure, and raw column values without headers are meaningless for embedding. Do NOT run Excel text through `chunk_text()`.
- Parses `=== Sheet: X ===` section markers from `_extract_excel` output
- Per sheet: detects header row (first non-blank line), formats each data row as `Header1: val | Header2: val | ...`
- Auto-generated column names (`Col_N`) skipped when value is also blank
- Greedy row packing into chunks up to 800 chars — **no overlap** (rows are atomic units; overlap would bisect a row)
- `metadata` JSONB includes `sheet_name`, `row_start`, `row_end` for provenance
- Chunk header: `[Bid: X | Type: Y | Src: Z | Sheet: S | Rows: R1-R2 | Chunk n/N]`
- Sheets with only a header and no data rows are skipped entirely

**`_extract_excel()` is unchanged** — its tab-delimited format preserves column positions needed by the chunker and extraction heuristics. Do not modify it.

**Vector repo additions (`repositories/vector_repo.py`):**
- `upsert_document_chunks(conn, doc_id, rows)` — DELETE by `document_id` + executemany INSERT ON CONFLICT
- `delete_document_chunks(conn, doc_id)` — DELETE by `document_id`, returns row count
- `search_documents(conn, query_embedding, top_k=8, bid_id=None, similarity_threshold=0.50)` — ANN cosine, optional bid filter, returns top_k after threshold. Now returns `metadata` dict per result (sheet_name, row_start, row_end populated for Excel chunks).

**`_run_vector_search` in `nodes.py`:** Accepts plain string or JSON `{"query": "...", "bid_id": "RFP-xxx"}`. Uses `vector_repo.search_documents` (no inline SQL). Returns `{similarity:.0%} match` per chunk, grouped by source file. Returns `"No relevant document chunks found (similarity < 50%)"` on zero results. Do NOT revert to inline SQL — the function now handles bid-scoped search.

**Cleanup:** `delete_bid` calls `delete_document_index(doc_id, settings)` for each doc in `uploadedFiles` — best-effort, fire-and-forget.

**Backfill existing Excel documents:** `POST /api/documents/reindex-excel` — loads all `.xlsx`/`.xls` docs from the vault and queues `index_document_background()` for each. Idempotent (upsert replaces old chunks). Returns `{queued: N}`. Only available in DB mode.

## Testing / Code Quality / Deployment

> Commands and deploy steps: `.claude/docs/05b-ops.md`

## SQL + Vector RAG Chatbot (RFP AIQ v2)

**Files:** `backend_py/services/sql_agent/` package + `backend_py/routers/ai_chat.py`

### Architecture (v3 — agentic ReAct loop)

`POST /api/ai/chat` returns `text/event-stream` (SSE). The LangGraph StateGraph is a ReAct loop:

```
planner → agent → execute_tool → agent (loop) ... → synthesize → END
                ↑___________________________|
```

- **planner**: one LLM call to produce a 2–5 step execution plan (shown as collapsible thinking block)
- **agent**: ReAct reasoning — outputs `{thought, calls:[{action,input},...], final_answer}`. Can issue N parallel tool calls per step.
- **execute_tool**: runs all calls via `asyncio.gather` (parallel). Emits one thinking block per result after all complete.
- **synthesize**: fast path = streams `final_answer` directly; slow path (MAX_AGENT_STEPS=8) = synthesizes via LLM

**Tool actions:** `sql_query` (read-only SELECT, validated + auto-limited) | `vector_search` (pgvector ANN, RETRIEVAL_QUERY embed)

**Parallel calls:** agent may issue multiple independent tool calls in a single step (e.g. querying two different tables, or the same table for two different RFP IDs). `asyncio.gather` runs them concurrently.

**Self-correction:** if SQL fails, the error is added to the scratchpad and the agent sees it on the next step and rewrites the query.

### SSE event protocol

```
{"type":"thinking_start","node":"plan","label":"Building approach"}
{"type":"thinking_content","text":"1. Query rfps table\n2. ..."}
{"type":"thinking_end","node":"plan"}
{"type":"thinking_start","node":"think","label":"Step 1: ..."}
{"type":"thinking_content","text":"**Thought:** ...\n**Tool calls (2):**\n  1. `sql_query`: SELECT..."}
{"type":"thinking_end","node":"think"}
{"type":"thinking_start","node":"query","label":"SQL · results"}
{"type":"thinking_content","text":"| bid_id | ..."}
{"type":"thinking_end","node":"query"}
... (repeat think/query/search per loop iteration)
{"type":"token","text":"chunk of answer text"}
{"type":"done"}
```

**Node keys in SSE:** `plan`, `think`, `query` (SQL result), `search` (vector result)

### SQL Safety layer (`services/sql_agent/safety.py`)
- `validate_sql()` — blocks DDL/DML, system table access, non-SELECT queries
- `auto_limit()` — appends `LIMIT 200` if missing
- `format_results()` — asyncpg Record list → markdown table

### SSE Queue (`services/sql_agent/nodes.py`)
- `contextvars.ContextVar[asyncio.Queue]` — each request gets its own queue
- `set_sse_queue(queue)` / `reset_sse_queue(token)` called from ai_chat.py
- Node functions emit `thinking_*` + `token` events; sentinel `None` signals stream end

### AgentState (`services/sql_agent/graph.py`)
```python
class AgentState(TypedDict, total=False):
    messages: list[dict]      # conversation history
    query: str                # current user question
    plan: str                 # planner output
    scratchpad: list[dict]    # [{step, idx, action, input, result?, error?}]
    agent_step: int           # loop iteration count (ceiling MAX_AGENT_STEPS=8)
    last_calls: list[dict]    # [{action, input}] from latest agent step
    last_action: str          # "tool" | "final_answer"
    last_action_input: str    # final answer text
    final_response: str       # streamed by synthesize
```

### Graph compilation
`init_sql_agent_graph()` called during main.py lifespan startup — compiles once using current LLM service + asyncpg pool. If startup fails, `ai_chat.py` lazily compiles on first request.

### Prompt locations
- `AGENT_PLANNER_SYSTEM` — `routers/prompts.py`; simple plan-generation prompt
- `AGENT_REACT_SYSTEM` — `routers/prompts.py`; `{schema}` substituted via `.replace()` in agent node
- `SQL_SYNTHESIS_SYSTEM` — `routers/prompts.py`; used only in slow-path synthesize (max steps hit)

### Frontend
- `ThinkingBlock.jsx` — collapsible block with orange left-border, spinner while in-progress. Node types: `plan` (ListChecks), `think` (Brain), `query` (Database), `search` (FileText)
- `RfpAiqMessageBubble.jsx` — accepts `thinking: [{node, label, content, done}]` prop
- `RfpAiqDrawer.jsx` — SSE ReadableStream reader; builds message incrementally from token events; strips `thinking` from messages before API call (backend expects `{role, content}` only)

## Python-only Reports

`POST /api/reports/send-email` (`routers/reports.py`):
- Loads live bid data from `bids_repo`
- Injects live JSON into `FoodCorp_Bid_Pipeline_Report.html` replacing hardcoded `const bids = [...]`
- Appends JS IIFE to update KPI cards, alert table, gauge, footer date
- Sends as HTML file attachment via `svc.send_email()`
- Temp file cleaned up in `finally`

The report HTML also fetches `/api/bids` live on page load (for browser view) — falls back to static injected data when viewed offline from email.

## Web Search (LangSearch)

`POST /api/web-search/suppliers` and `POST /api/web-search/find-email` (`routers/web_search.py`):
- **Provider:** LangSearch (free, https://langsearch.com) — plain `httpx` POST, no SDK. Response at `data.webPages.value[]`. Requires `LANGSEARCH_API_KEY` in env; returns 503 if unset.
- **`/suppliers`:** builds query from `{category} {keywords} food supplier {segment} {region} contact email`, calls LangSearch with `summary=true` (full page text), passes results to LLM with `SUPPLIER_EXTRACTION_PROMPT`, returns `{results:[{name,contactEmail,description,segments,categories,tags}]}` — **no `website` field** (email is the actionable import field; URL was confusing users into thinking the website was being saved)
- **`/find-email`:** builds query `"{companyName}" food company contact email ...`, passes results to LLM with `EMAIL_EXTRACTION_PROMPT`, returns `{candidates:[{email,type,context}]}` (deduped, max 5)
- **Prompts:** `SUPPLIER_EXTRACTION_PROMPT` and `EMAIL_EXTRACTION_PROMPT` in `routers/prompts.py`. Both use `extract_json()` for LLM response parsing. LLM failures return partial/empty results (not 500). `SUPPLIER_EXTRACTION_PROMPT` explicitly instructs the LLM to skip scam/spam/non-food results and to search all text aggressively for email addresses (including personal contact emails like `john@acmefood.com`).
- **Input validation:** `_validate_search_input()` in `web_search.py` — called before LangSearch on both endpoints. Rejects fields over 200 chars and inputs containing a blocklist of inappropriate terms (adult content, stalking-related phrases, drug/weapon keywords). Returns HTTP 400. Rule-based — no extra LLM call.
- **Service layer:** `services/web_search_service.py` — `langsearch_search(query, count, summary)` handles auth, timeout (20 s), and error mapping (HTTP 4xx/5xx → 502).
- **Config:** `langsearch_api_key: SecretStr = SecretStr("")` in `config.py` — leave empty to disable (503 response, feature degrades gracefully).
- **Chat AIQ guardrail:** `RFPAIQ_IDENTITY` in `routers/prompts.py` includes a GUARDRAIL block that instructs the LLM to decline off-topic questions (redirecting to procurement topics) and refuse unethical requests. Zero extra LLM calls — guardrail is part of the existing system prompt.
