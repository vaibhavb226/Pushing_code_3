# Frontend — Pages, UI & Business Logic

## Pages & Routes

| URL | Component | Description |
|-----|-----------|-------------|
| `/` or `/bids` | `BidQueue` | Homepage — bid dashboard grouped by segment |
| `/bex` | `BexAI` | Upload RFP — BEX AI parser |
| `/vault` | `DocumentVault` | Document vault — categorised file browser |
| `/bids/:bidId` | `BidDetail` | 4-tab bid detail view |
| `/submit/:bidId` | `SupplierPortal` | Public portal — pricing submission form |
| `/submit/:bidId/thread/:threadId` | `SupplierPortal` | Public portal — conversation thread (email-gated) |

**Router:** `createBrowserRouter` in `main.jsx` (needed for `useBlocker` in BEX upload page).

## Sidebar
- Collapsible: 64px (icons only) | 220px (expanded). State in `localStorage` as `'sidebar_collapsed'`.
- **"Chat with AIQ" button** — orange (`#E05A2B`), `MessageSquare` icon, at bottom of nav. Toggles the RFP AIQ drawer open/closed. Orange when active.
- Logo: `/public/exl_logo_sidebar.png` (navy background version)

## Real-Time Collaboration (PostgreSQL LISTEN/NOTIFY + SSE)

One SSE connection per bid detail page — shared across all 4 tabs. Production-grade: PG is the cross-instance broker (works across multiple uvicorn workers / Cloud Run instances). No Redis, no Firebase.

**Hook:** `frontend/src/hooks/useBidStream.js` — `useBidStream(bidId, userName, onEvent)`
- Opens `GET /api/bids/{bidId}/stream?user=<name>` as EventSource
- Reconnects 5s after any error (one retry per failure — `done` guard prevents the onerror-storm caused by EventSource firing onerror multiple times before `es.close()` takes effect)
- `onEvent` stored in a ref — stable across renders without needing to be in the dep array

**BidDetail mount pattern** (`frontend/src/components/BidDetail/index.jsx`):
```jsx
useBidStream(bid?.id, userName, (event) => {
  setLatestEvent(event)
  // viewers/presence/bid_updated/presence_tab handled inline; pass latestEvent to child tabs as prop
})
```
- `userName` read from `localStorage.rfpaiq_user` (no auth middleware required)
- `latestEvent` passed as prop to `WorkingFileTab`, `EmailRepoTab`, `SuppliersTab`
- Presence strip (blue banner above tabs) shows other viewers; filtered to exclude self

**Child tab reactions via `latestEvent` prop:**

| Tab | Event type | Action |
|-----|-----------|--------|
| `WorkingFileTab` | `line_item_updated` | Merge `fields` into that row; show amber `⚠` conflict badge if user has unsaved edits on same row |
| `WorkingFileTab` | `line_item_deleted` | Filter row out of `lineItems` immediately |
| `WorkingFileTab` | `presence_tab` (tab=workingfile) | Update `rowEditors` map — show colored left border on row another user is focused on |
| `EmailRepoTab` | `email_sent`, `supplier_updated` | Call `fetchData()` immediately (skips the 15s poll wait) |
| `SuppliersTab` | `supplier_updated` | Call `fetchSolicited()` immediately |

**Conflict resolution:** Last-Write-Wins with amber warning. When a remote `line_item_updated` arrives for a row with unsaved local `pendingEdits`, the row gets `_remoteConflict: true` instead of being overwritten — user's unsaved value is preserved and they see the ⚠ badge. Badge clears on save.

**Do NOT use inline `style={{ backgroundColor }}` for the presence strip** — use `className="bg-blue-50 dark:bg-blue-900/20"`.

## Presence System (Layers 1–3)

Three layers of presence built on top of real-time collaboration. No live typing — all events are human-paced (tab clicks, cell focus).

### Layer 1 — Global Online Panel (sidebar)

**Poll:** `AppLayout` (`App.jsx`) polls `GET /api/presence` every 30s, passes `onlineUsers[]` to `Sidebar`.
**Component:** `OnlinePanel` (defined in `App.jsx`) — renders above the sidebar footer.
- Collapsed sidebar (64px): stacked colored avatars with tooltip
- Expanded sidebar (256px): name + location chip ("RFP-xxx · Working File")
- Filters self (by name) from the list

### Layer 2 — Tab-Level Presence (tab bar avatars)

**Mechanism:** `usePresence` hook (below) fires `POST /api/presence/update` on tab switch. Backend fires `pg_notify` → SSE clients for that bid receive a `presence_tab` event.

`BidDetail/index.jsx` handles `presence_tab` events:
- `tabPresence: {tabId → [userName]}` state — tracks which tab each other user is on
- Tab bar renders tiny colored initial-avatar badges for each user on that tab
- User color is deterministic from name hash — same color every session, every device

### Layer 3 — Cell-Level Focus (Working File row highlight)

**Mechanism:** `WorkingFileTab` accepts `onCellFocus(lineId)` + `onCellBlur()` props from parent. When user starts editing any cell in a row, `onCellFocus(li.id)` is called → parent's `usePresence` hook sends update with `cellId = li.id` → backend notifies SSE clients.

Other users' Working File tab handles the `presence_tab` event: if `tab === 'workingfile' && cellId`, adds user to `rowEditors[cellId]`. The row renders with `boxShadow: inset 3px 0 0 {color}` (left accent stripe) — color is deterministic from the remote user's name.

### Support Files

| File | Purpose |
|------|---------|
| `frontend/src/utils/presenceColors.js` | `getUserColor(name)` → `{bg, text, borderColor}` — 6 colors, hash-stable |
| `frontend/src/hooks/usePresence.js` | Heartbeat 30s + immediate fire on location change; `sendBeacon` on page unload |
| `backend_py/routers/presence.py` | `POST /update` + `GET /` — single endpoint for all presence |
| `backend_py/services/sse_broadcast.py` | `_user_locations` dict + `update_user_location`, `get_online_users`, `cleanup_stale_users` |

**TTL:** 30s heartbeat, 60s eviction. A 30s background cleanup task runs in `main.py`. Users appear offline within 60s of closing their tab (or immediately via `sendBeacon`).

## Bid Detail Tabs

| Order | Tab | Default |
|-------|-----|---------|
| 1 | `overview` | ✓ (default) |
| 2 | `emailrepo` | |
| 3 | `workingfile` | |
| 4 | `suppliers` | |

- `?tab=workingfile` switches tab on load
- `?edit=1` auto-opens edit form on Overview, then cleaned from URL
- **Email Repo badge:** fetched from `GET /api/bids/:id/emails/by-supplier` → count of `suppliers[]` (conversations, not raw emails)
- **Supplier List badge:** `bid.solicitedSuppliers?.length ?? bid.suppliersContacted ?? 0`

## Working File — 3 Sections

**CUSTOMER RFP (white):** Item #, SUPC (blank/TBD), MPC Code, UOM, Volume, Pack, Size, Brand, Description, Category, CW, STK Type, Compliance flags
**SUPPLIER RESPONSES (blue `#EBF3FB`, dark: `#1a2f45`):** True Vendor, Dev Type, Supplied Price, ALLW $, DL $, Net $/Case, Open Review, Confidence
**BID COE INTERNAL (yellow `#FEFCE8`, dark: `#2a2000`):** Award Decision, Internal Notes, Pricing Score, Follow-up Required

- Right-side blue uses `className` (not `style={}`) so dark mode `dark:bg-[#1a2f45]` works
- Section headers: `colSpan={13}` "Customer RFP" + `colSpan={8}` "Supplier Responses"
- Confidence: ≥70% high/green, 40–69% medium/amber, <40% low/red
- Custom portal columns appear after standard supplier columns (filtered by `showInWorkingFile: true`)

## At Risk Logic
A bid is "At Risk" if: `status === 'At Risk'` OR `getDaysUntilDue(internalDue) <= 7`
DueBadge: >7d → grey | 1–7d → amber | 0 → red "Due Today" | past → dark red "Xd overdue"

## Response Rate Calculation
```js
// From frontend/src/utils/bidUtils.js
const RESPONDED_STATUSES = ['Responded', 'Issues Found', 'Follow-up Sent', 'Complete']
getSuppliersContacted = (bid) => bid.solicitedSuppliers?.length ?? bid.suppliersContacted ?? 0
getResponsesReceived = (bid) => bid.solicitedSuppliers
  ? bid.solicitedSuppliers.filter(s => RESPONDED_STATUSES.includes(s.status)).length
  : bid.responsesReceived ?? 0
```
Stat card scoped to bids in `"Solicitation"` status only.

## Key Business Rules
- Bid ID cannot be changed after creation (read-only in edit form)
- SUPC not extracted from RFP — filled later from item master
- All suppliers BCC'd on solicitation (no To: field)
- Bounce suppliers (`bounce: true`) auto-excluded from solicitation
- `True Vendor` = supplier who submitted pricing (renamed from "Supplier")
- Internal due date defaults to 5 days before customer due date
- Dev Type: `ALLW` = allowance off-invoice, `DL` = delivered cost override

## Dark Mode Patterns
- **NEVER use inline `style={{ backgroundColor: '...' }}`** for section backgrounds — use `className` with Tailwind dark variants
- `text-exl-navy` elements always need `dark:text-blue-300`
- Orange opacity backgrounds: `bg-exl-orange/10` → `dark:bg-orange-900/30`
- Dark card/panel: `dark:bg-[#1E293B]` | Secondary panel: `dark:bg-[#253347]`
- Tab transitions: Overview/Email (opacity + translateY) | Working File/Suppliers (opacity only — no Y reflow on large tables)

> Login credentials, status CSS classes, component paths: `.claude/docs/03b-reference.md`
