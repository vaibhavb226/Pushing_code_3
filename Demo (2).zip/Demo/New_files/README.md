# RFP extraction stress-test corpus

21 synthetic documents across 7 fictional school districts, built as graded test
fixtures for a document-extraction / RAG pipeline. Each district ships three files
that describe the *same* underlying solicitation:

| file | role |
|---|---|
| `<CODE>_<District>_RFP_Document.pdf` | the solicitation only — no supplier pricing |
| `<CODE>_<District>_RFP_Pricing.xlsx` | the supplier's pricing response |
| `<CODE>_<District>_RFP_Test_File.xlsx` | 4-sheet workbook: cover, item list, messy response, test hints |

Because all three encode the same facts, you can score a pipeline on cross-document
consistency as well as on raw extraction.

Two extra files sit alongside them:

* **`ground_truth.json`** — the answer key. Every district's metadata, item list,
  supplier response, derived aggregates, expected answers to nine standard
  questions, and — for each PDF — the **trap key**: the question, the answer a
  careless read produces, the correct answer, and why the document misleads.
* **`extraction_baseline.json`** — measured, not claimed. What `pdftotext`,
  `pypdf`, `openpyxl` and `pandas.read_excel` actually recover from each file.

> Everything here is invented. Districts, suppliers, contacts, GTINs and prices are
> synthetic. Do not treat them as real solicitations or real supplier pricing.

---

## What the PDFs test

**Every PDF has a complete, correct text layer. None of them needs OCR.** Extraction
always succeeds. The difficulty is entirely in *comprehension*: reading order,
indirection, superseded values, conditional rules and near-duplicates. A pipeline
that reports "extracted 100% of the text" and then answers the questions wrong is
exactly what these documents are built to expose.

Supplier pricing never appears in a PDF. It lives only in the companion workbooks,
so a pipeline that hallucinates a price from the solicitation is caught immediately.

| Tier | RFP | District | The trap |
|---|---|---|---|
| 1 | `CR260118` | Cedar Ridge USD | Borderless table with one rule; a footnote turns one quantity from per-semester into annual; four date formats on one page. |
| 2 | `WC260297` | Willow Creek ISD | Table rotated 90° across sheets, 5.6pt, header row repeated on every sheet so header rows get counted as line items. |
| 3 | `MG260512` | Maple Grove Public Schools | Two-column flow that interleaves on a linear read; the watermark is real text and splices into sentences; a clause hides in the rotated left margin. |
| 4 | `BW260734` | Birchwood County Schools | An addendum on a later page changes the due date and three quantities and deletes a line — and its own summary table omits one of the changes. |
| 5 | `SB260856` | Stonebridge Unified | The schedule carries Spec Ref codes and quantities only. Descriptions are in Appendix A (sorted alphabetically), compliance codes in Appendix B. |
| 6 | `HM260977` | Harper Mill CUSD | Every quantity is per delivery cycle. Cycles per year live in prose and differ by storage class, and a footnote excepts two lines. |
| 7 | `RP261089` | Rockport Township HSD | The table is written to the content stream column by column — rows are destroyed on a naive read while the page looks normal. Plus an addendum, codes and ligatures. |

---

## Measured extraction baseline

`pdftotext -layout` (position-aware) and `pypdf.extract_text` (stream-order) for the
PDFs; `openpyxl` and `pandas.read_excel` defaults for the workbooks.

* **Facts %** — share of 20 solicitation facts found in the extracted text.
* **Rows naive / layout** — of the item rows found, the share where the description
  still sits next to a value from *its own row*. This is the structural signal:
  100% means rows survived, 0% means the table was flattened into columns.
* **Naive table** — whether a default `pd.read_excel(path)` lands on a real header
  row. It fails on all 14 workbooks; that is the point.

| Tier | RFP | Pages | Chars | Facts % | Rows naive | Rows layout | Traps | Verdict |
|---|---|---|---|---|---|---|---|---|
| 1 | `CR260118` | 2 | 4,949 | 75% | 93% | 93% | 3 | text complete; column association and the per-semester footnote are the failure points |
| 2 | `WC260297` | 3 | 6,808 | 100% | 93% | 93% | 2 | text complete; repeated headers inflate the row count, rotation scrambles row association |
| 3 | `MG260512` | 2 | 26,430 | 100% | 93% | 93% | 3 | text complete; watermark splices into sentences and column flow interleaves |
| 4 | `BW260734` | 3 | 8,084 | 100% | 94% | 94% | 4 | text complete; page 1 and the addendum disagree and the addendum governs |
| 5 | `SB260856` | 4 | 8,976 | 100% | 100% | 100% | 3 | text complete; no line is self-describing - three pages must be joined |
| 6 | `HM260977` | 3 | 7,565 | 100% | 100% | 100% | 3 | text complete; every printed quantity is per cycle and must be annualised by prose rule |
| 7 | `RP261089` | 3 | 7,179 | 90% | 0% | 69% | 6 | text complete but rows destroyed - stream order is column-major |

Workbooks (unchanged from the previous build):

| Tier | Pricing % | Test-file % | Naive table |
|---|---|---|---|
| 1 | 94% | 83% | fail / fail |
| 2 | 89% | 83% | fail / fail |
| 3 | 72% | 78% | fail / fail |
| 4 | 56% | 83% | fail / fail |
| 5 | 94% | 100% | fail / fail |
| 6 | 83% | 89% | fail / fail |
| 7 | 89% | 94% | fail / fail |

Reading the numbers:

* **Text is complete everywhere.** No file needs OCR. Character counts run
  4,949–26,430 and facts recovery is 90–100% on six of seven documents.
  Extraction is not the problem these files pose.
* **Tier 1's 75% is by design, not a defect.** Like the reference files, the tier 1
  PDF is a condensed extract that omits the MFG Code column entirely, so those five
  probes cannot be found. Those facts live in the workbook. A pipeline that invents
  MFG codes from this PDF is wrong, and this file catches that.
* **Tier 7 is the structural headline: 0% row integrity naive, 69% layout-aware.**
  The item table is emitted to the content stream column by column, so
  `pypdf.extract_text` returns every line number, then every category, then every
  description — the rows are gone. The rendered page looks completely ordinary.
  This is the cleanest available test of whether your pipeline is position-aware or
  just reading the stream.
* **Tiers 4–6 score near-perfectly on every mechanical metric and are still wrong.**
  Their traps are semantic: an addendum that supersedes page 1, a schedule where no
  line is self-describing, quantities that are per-cycle rather than annual. No
  extraction metric catches these. Only the trap keys in `ground_truth.json` do.

---

## Scoring against the trap keys

Each district in `ground_truth.json` carries a `pdf_traps` array. Every entry is:

```json
{
  "trap": "Superseding addendum - due date",
  "question": "What is the response due date?",
  "likely_wrong_answer": "06/25/2026 5:00 PM local time - the date printed in the Section 1 summary",
  "correct_answer": "07/02/2026 4:00 PM local time - Addendum 1 supersedes it",
  "why_it_misleads": "Section 1 keeps the original date; the addendum that changes it is a later page."
}
```

Ask your pipeline the `question`, then check its answer against both fields. Matching
`likely_wrong_answer` is more informative than a generic miss — it tells you *which*
reasoning step failed. 24 traps ship across the seven documents.

---

## Technique index

Every trick used, per file.

### Tier 1 — Cedar Ridge USD (`CR260118`)

*Borderless tables, footnote-carried exceptions, mixed date formats*

**`CR260118_Cedar_Ridge_USD_RFP_Document.pdf`** — text layer, no OCR

- Item table has one horizontal rule and no cell borders - column and row association must be inferred from x/y position alone
- Solicitation metadata split into two independent key/value columns, so a linear read pairs the wrong key with the wrong value
- Four different date formats on one page: '2 June 2026', '06/18/2026', '2026-07-01', '30 Jun 2027'
- One quantity is marked with an asterisk whose footnote at the page foot says the printed figure is per semester, not annual
- Buyer notes replaced in-table by 'see note'; the actual text sits in numbered footnotes far from the row

Trap key:

- **Borderless table** — *Which compliance flags apply to line 3?*  
  wrong: Flags from an adjacent row, because no cell borders mark the boundary  
  right: The flags printed on the line 3 row
- **Footnote-carried exception** — *What is the annual estimated quantity for line 4?*  
  wrong: 320 - the number printed in the Est Qty column  
  right: 640 - the footnote states the printed figure is per semester
- **Mixed date formats** — *What is the bid start date?*  
  wrong: Confusion between the four different date formats used on one page  
  right: 07/01/2026

**`CR260118_Cedar_Ridge_USD_RFP_Pricing.xlsx`**

- Eight rows of pasted email headers above the data; the real header row is row 9
- Prices keyed inconsistently as number, "$52.33", " 52.33 ", "52.33 USD" and "52,33"
- Item-line column mixes 10, "10" and "Ln 10"
- Two "--- supplier export inserted ---" break rows mid-table
- An unlabeled TOTAL row below the data that naive parsers read as a line item
- Enlarged row heights on every third row

**`CR260118_Cedar_Ridge_USD_RFP_Test_File.xlsx`**

- Four sheets; the item list and the supplier response are in different orders
- Cover sheet mixes metadata, compliance text and difficulty notes in one column

### Tier 2 — Willow Creek ISD (`WC260297`)

*Sideways dense table, repeated headers across sheets*

**`WC260297_Willow_Creek_ISD_RFP_Document.pdf`** — text layer, no OCR

- Item table drawn rotated 90 degrees inside a portrait page whose /Rotate is 270
- 5.6pt type across a 13-column table
- Table split across sheets, each repeating the full header row, so header rows get counted as data
- A 'continued - header row repeats' marker and a running footer sit between the data blocks
- Rotated coordinates mean extracted x/y do not correspond to visual rows

Trap key:

- **Repeated headers inside the table** — *How many line items are in the item list?*  
  wrong: More than 15 - repeated header rows and 'continued' markers get counted as data  
  right: 15
- **Rotated page** — *What is the GTIN for the highest-quantity item?*  
  wrong: A GTIN from the wrong row, because rotated coordinates scramble row association  
  right: The GTIN printed on that item's row

**`WC260297_Willow_Creek_ISD_RFP_Pricing.xlsx`**

- Two-level header: a merged group band (row 4) over the detail header (row 5) - no single header row exists
- Row heights of 72-136pt with wrapped multi-line supplier commentary
- Column C hidden
- Column L hidden and holds the authoritative recalculated delivered price; the visible column J is stale
- Freeze panes and an autofilter anchored to row 5, not row 1

**`WC260297_Willow_Creek_ISD_RFP_Test_File.xlsx`**

- Merged group bands on the item list too
- Row heights of 64-112pt with wrapped buyer notes
- A hidden 'Buyer Working Copy' sheet holding the authoritative delivered prices

### Tier 3 — Maple Grove Public Schools (`MG260512`)

*Two-column reading order, watermark in the text stream*

**`MG260512_Maple_Grove_Public_Schools_RFP_Document.pdf`** — text layer, no OCR

- Two-column newspaper flow - reading order is column 1 top-to-bottom then column 2, which naive extraction interleaves
- The CONFIDENTIAL / PROCUREMENT COPY watermark is REAL TEXT emitted between body lines, so it splices into the middle of sentences during extraction
- A record-retention clause runs up the left margin rotated 90 degrees and is easily missed entirely
- A shaded sidebar callout is dropped into the middle of the column flow
- The Award clause is deliberately split across the column break, so a linear read welds the wrong halves together
- Item records are flowing paragraphs rather than a table

Trap key:

- **Two-column reading order** — *What does the Award clause say in full?*  
  wrong: A sentence welded from the bottom of column 1 and the top of column 2  
  right: The clause as it reads down column 1 then down column 2
- **Watermark text in the content stream** — *Quote the pricing-basis sentence verbatim.*  
  wrong: A sentence with CONFIDENTIAL or PROCUREMENT COPY spliced into the middle  
  right: Pricing basis for this solicitation is Billback-Case Price.
- **Marginalia** — *What is the record retention period?*  
  wrong: Missed entirely, or attributed to the body text  
  right: Seven years, per the rotated note running up the left margin

**`MG260512_Maple_Grove_Public_Schools_RFP_Pricing.xlsx`**

- Three separate island tables side by side on one sheet, at different column offsets and different header rows
- Header text rotated 90 degrees
- Allowance program terms exist ONLY as cell comments, never as cell values
- Row status conveyed by fill colour alone, with the legend on a different sheet
- Row heights of 46-96pt

**`MG260512_Maple_Grove_Public_Schools_RFP_Test_File.xlsx`**

- Rotated item-list headers
- Enlarged wrapped rows on the item list and the response sheet

### Tier 4 — Birchwood County Schools (`BW260734`)

*Superseding addendum*

**`BW260734_Birchwood_County_Schools_RFP_Document.pdf`** — text layer, no OCR

- A later ADDENDUM NO. 1 page changes the response due date; Section 1 still prints the original
- Three quantities are revised by the addendum; the item table is never reprinted
- One line is deleted by the addendum but remains printed, un-struck, in the item table
- The addendum's own Summary of Changes table is INCOMPLETE - one change appears only in the narrative at section 3
- The correct answer to almost any factual question requires reconciling two pages that disagree

Trap key:

- **Superseding addendum - due date** — *What is the response due date?*  
  wrong: 06/25/2026 5:00 PM local time - the date printed in the Section 1 summary  
  right: 07/02/2026 4:00 PM local time - Addendum 1 supersedes it
- **Superseding addendum - quantity** — *What is the estimated quantity for line 17 (Marinara Sauce, Low Sodium)?*  
  wrong: 47 - the figure in the item table  
  right: 25 - revised by the addendum
- **Change omitted from the summary table** — *What changed for line 12?*  
  wrong: Nothing - it is absent from the addendum's Summary of Changes table  
  right: pack size revised to 6/5 LB and Buy American now applies
- **Deleted line** — *Is line 2 (Ranch Dressing Cup, 1.5 oz) still in scope?*  
  wrong: Yes - it is still printed in the item table  
  right: No - the addendum deletes it

**`BW260734_Birchwood_County_Schools_RFP_Pricing.xlsx`**

- Number formats display a rounded value that differs from the stored value ($#,##0 over 52.33)
- Delivered price, unit cost and freight-percentage cells hold formulas with NO cached result, so every value reader sees None
- A hidden 'Pricing (OLD do not use)' sheet holds superseded round-one pricing inflated 8.5%
- One date stored as the serial 46175, one rate stored as the fraction 0.0325

**`BW260734_Birchwood_County_Schools_RFP_Test_File.xlsx`**

- A hidden 'Item List (round 1)' sheet with quantities inflated 18%

### Tier 5 — Stonebridge Unified (`SB260856`)

*Indirection: spec refs, numeric codes, appendices*

**`SB260856_Stonebridge_Unified_RFP_Document.pdf`** — text layer, no OCR

- The item schedule carries Spec Ref codes and quantities only - no descriptions, brands or pack sizes
- Descriptions live in Appendix A, sorted alphabetically by description rather than by schedule line
- Compliance obligations are printed as codes C1-C5 with the legend on a separate Appendix B page
- One Spec Ref appears on two schedule lines under different funding sources and must be summed
- Answering a single question about one line requires joining three pages

Trap key:

- **Description indirection** — *What is the pack size for line 4?*  
  wrong: Cannot answer - the item table shows only a Spec Ref code and a quantity  
  right: 100/1.5 OZ - via Appendix A, entry SR-480
- **Numeric compliance codes** — *Which lines require a CN label?*  
  wrong: Lines flagged 'CN' - but no line is flagged that way  
  right: Lines carrying code C1, per the Appendix B legend
- **Split quantity for one spec ref** — *What is the total quantity for spec ref SR-347?*  
  wrong: The quantity on the first matching line only  
  right: The sum of both lines carrying that spec ref

**`SB260856_Stonebridge_Unified_RFP_Pricing.xlsx`**

- No table anywhere - every figure is embedded in a prose sentence in a pasted email body
- Four different sentence templates, so the same fact appears in four different word orders
- Some lines omit freight or the allowance entirely; one gives FOB but explicitly withholds the delivered price
- No-bid lines are stated in prose and warn against reading them as zero
- A second sheet is a later reply correcting two of the prices sent in the first mail - the correction governs

**`SB260856_Stonebridge_Unified_RFP_Test_File.xlsx`**

- The item list is narrative too: one paragraph per line rather than a row
- The supplier response sheet is prose, so there is no column to map

### Tier 6 — Harper Mill CUSD (`HM260977`)

*Conditional prose rules and unit traps*

**`HM260977_Harper_Mill_CUSD_RFP_Document.pdf`** — text layer, no OCR

- Quantities are stated PER DELIVERY CYCLE, not per year; the column header says so and nothing else does
- Cycles per year are defined in prose and differ by storage class: Dry and Cooler 36, Freezer 18
- A footnote overrides the rule for exactly two lines, setting them to 9 cycles
- Annual figures are never printed - they must be derived by multiplication
- A servings-per-case column invites a second multiplication with units named only in the headers

Trap key:

- **Per-cycle quantities** — *What is the annual case requirement for line 1?*  
  wrong: 298 - the figure in the Est Qty column  
  right: 10,728 - 298 per cycle x 36 cycles (Dry)
- **Footnote override of the rule** — *What is the annual case requirement for line 15?*  
  wrong: 12,204 - applying the general rule  
  right: 3,051 - a footnote sets this line to 9 cycles
- **Servings arithmetic** — *How many servings does line 15 represent annually?*  
  wrong: 339 - the case count, mistaken for a serving count  
  right: 350,865 - 339 cases x 9 cycles x 115 servings per case

**`HM260977_Harper_Mill_CUSD_RFP_Pricing.xlsx`**

- The grid is TRANSPOSED: supplier lines run across the sheet as columns, field names are in column A
- Allowances are not on the pricing sheet at all - they are on a separate sheet keyed by vendor SKU
- Those SKUs carry R, -A and /ALT suffixes that must be stripped before they match the item schedule
- A sheet named FINAL holds superseded round-one pricing inflated 6.2%; the live data is on a sheet called 'working draft v2'
- A missing allowance row means no allowance, which is not the same as a quoted zero
- Enlarged wrapped rows throughout

**`HM260977_Harper_Mill_CUSD_RFP_Test_File.xlsx`**

- Item list and supplier response are both transposed
- Field names in column A, records running across

### Tier 7 — Rockport Township HSD (`RP261089`)

*Column-major stream, addendum, codes, typographic artefacts*

**`RP261089_Rockport_Township_HSD_RFP_Document.pdf`** — text layer, no OCR

- The item table is emitted to the content stream COLUMN BY COLUMN - stream-order extraction returns every line number, then every category, then every description, with rows destroyed. The rendered page looks completely normal
- Descriptions carry ligatures, soft hyphens and non-breaking spaces, so exact string matching fails on characters that look identical
- Compliance printed as C1-C5 codes with the legend back on page 1
- An ADDENDUM 1 page revises the due date, three quantities and one pack size, and deletes a line
- The Section 4A volume summary is explicitly stale and contradicts the addendum
- Near-duplicate alternate rows differ only in brand and pack

Trap key:

- **Superseding addendum - due date** — *What is the response due date?*  
  wrong: 07/02/2026 12:00 PM local time - the date printed in the Section 1 summary  
  right: 07/09/2026 4:00 PM local time - Addendum 1 supersedes it
- **Superseding addendum - quantity** — *What is the estimated quantity for line 3 (Chicken Tenders, Breaded, WG, 1.0 oz)?*  
  wrong: 309 - the figure in the item table  
  right: 216 - revised by the addendum
- **Change omitted from the summary table** — *What changed for line 11?*  
  wrong: Nothing - it is absent from the addendum's Summary of Changes table  
  right: pack size revised to 6/5 LB and Buy American now applies
- **Deleted line** — *Is line 5 (Cheese Stick, Mozzarella, IW) still in scope?*  
  wrong: Yes - it is still printed in the item table  
  right: No - the addendum deletes it
- **Column-major content stream** — *Read the item table row by row.*  
  wrong: Column-major output: every line number, then every category, then every description - rows destroyed  
  right: The visual rows, recoverable only with position-aware extraction
- **Typographic artefacts** — *Find the item whose description contains 'Fries'.*  
  wrong: Not found - the string contains a ligature or soft hyphen  
  right: Sweet Potato Fries, Crinkle Cut

**`RP261089_Rockport_Township_HSD_RFP_Pricing.xlsx`**

- Four stacked blocks on one sheet with four different schemas that must not be read as one table
- Block B renames every column (Net Case, Case Cost, Off-Inv, Vendor SKU) and reorders them - net price comes BEFORE case cost
- Block C has its numeric columns pasted one row BELOW the line they belong to: the first line has no figures on its row and the last numeric row belongs to the line above it
- Block D holds resubmitted lines that supersede earlier ones, distinguishable only by a timestamp
- A Buyer Notes sheet carries the full figures as cell comments
- An 'Archive 2025' sheet is veryHidden - invisible in the normal sheet tab list
- Workbook structure password protected (rfp2026)

**`RP261089_Rockport_Township_HSD_RFP_Test_File.xlsx`**

- Item list assembled from two exports with different columns and a coded compliance column
- Supplier response merged from two submissions with different schemas
- Workbook structure locked


---

## A note on the workbooks

The workbooks were built under the earlier brief and tiers 5–7 still hold their
pricing grids as embedded images, which do require OCR. The PDFs no longer do. If
you want the workbooks converted to the same text-layer-but-hard approach, that is a
change to `xlsxgen.py` alone — the data model, ground truth and PDFs are unaffected.

## Suggested use

1. **Regression floor.** Score against `ground_truth.json`; anything below
   `extraction_baseline.json` is a bug in the pipeline, not the fixture.
2. **Position-awareness check.** Tier 7 alone separates a position-aware reader from
   a stream reader. If it scores 0% row integrity, your extraction layer is the
   problem, not your prompt.
3. **Prompt robustness.** Tiers 4–6 are prompt tests, not extraction tests. They
   reward instructions like *"check for addenda and prefer the later document"*,
   *"resolve every code against its legend before answering"*, and *"state the units
   a figure is in before computing with it"*.
4. **Confidence calibration.** A pipeline that answers tier 4 and tier 1 with equal
   confidence has no calibration at all.
5. **Hallucination check.** No PDF contains supplier pricing. Any price quoted from
   a PDF is invented.

## Regenerating

The generator is deterministic — same seed, same bytes.

```bash
python3 data.py        # sanity-check the data model
python3 pdfgen.py      # 7 PDFs (text layer only)
python3 xlsxgen.py     # 14 workbooks
python3 groundtruth.py # ground_truth.json, including the trap keys
python3 verify.py      # extraction_baseline.json
python3 make_readme.py # this file
```
